#####################################################################
TestNameMap = {
            #  TEST NAME           TEST NUMBER     TIMEOUT
               "Download"       :   (8,               60),
               "InitiatorTest"  :   (535,            100),
               }




#######################################################################
for testName,(testNumber,timeout) in list(TestNameMap.items()):
  functionDefinition =  """
def %s(*args,**argsd):  
  try:
     if not argsd.has_key('timeout'):
       argsd['timeout'] = %d
  except:
     pass
  return run_st(%d,args,argsd)
""" % (testName,timeout,testNumber)
  #print functionDefinition
  exec(functionDefinition)

