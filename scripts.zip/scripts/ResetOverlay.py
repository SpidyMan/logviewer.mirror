import os
FOFexecfile(('', 'scriptfuncs.py'))

print("Reset Overlay File name...")

RegisterOvCall()
cacheFile = os.path.join(UserDownloadsPath,"%02d-%d-OverlayFileNameCache"%(CellIndex,TrayIndex,))
if os.path.exists(cacheFile):
   os.unlink(cacheFile)
