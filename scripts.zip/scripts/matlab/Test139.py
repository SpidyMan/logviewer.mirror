
FOFexecfile(("", "scriptfuncs.py"))
FOFexecfile(("matlab", "StartGraphs.py"))

RegisterBaudRate(1228000)
SetESlipBaud(1228000)

DBlogParserOn()
dblData={}

prm_139 = {
  "CWORD1" : (0x135,),  # Used when testing one cylinder - uncomment TEST_CYL too
  #"CWORD1" : (0x125,),
  "TEST_HEAD" : (0x0000,),
  "OFFSET_SETTING" : (-1200,1200,0x0a05,),
  "NUM_ADJ_ERASE" : (0xa,),
  "NON_DIS_WEDGES" : (0x505,),
  "SET_OCLIM" : (0x4E1,),
  "ERASE_OFFSET" : (100,),
  "AC_ERASE" :(),
  "LIMIT" :(4,),
  "TEST_CYL" : (0x0000,100,),
}

prm_139_ups = {
  "Cwrd1" : (0x135,),  # Used when testing one cylinder - uncomment TEST_CYL too
  #"CWORD1" : (0x125,),
  "HdRg" : (0x0000,0x0000),
  "OfstSetg" : (-1200,1200,0x0a05,),
  "AdjcntEraseCnt" : (0xa,),
  "NonDisWdgCnt" : (0x505,),
  "Oclim" : (0x4E1,),
  "EraseOfst" : (100,),
  # "AC_ERASE" :(),
  "Lmt" :(4,),
  "TstCyl" : (0x0000,100,),
}

if not UPSEnabled: st(139, prm_139, timeout=3600)
else:              st(139, prm_139_ups, timeout=3600)  
    
# Get Data points
## Using Old format
#x=[int(val['OFFSET']) for val in dblData['P139_BUCKET1_FINESCAN_VGA'] ]
#y=[int(val['VGA']) for val in dblData['P139_BUCKET1_FINESCAN_VGA'] ] 
#y1=[int(val['VGA']) for val in dblData['P139_BUCKET2_FINESCAN_VGA'] ]

# New format
x= [int(val)  for val in dblData['P139_BUCKET1_FINESCAN_VGA']['OFFSET'] ]
y= [int(val)  for val in dblData['P139_BUCKET1_FINESCAN_VGA']['VGA'] ] 
y1=[int(val)  for val in dblData['P139_BUCKET2_FINESCAN_VGA']['VGA'] ]

# when running for multiple cylinders
#x= [int(val)  for val,phy in map(None, dblData['P139_BUCKET1_FINESCAN_VGA']['OFFSET'],dblData['P139_BUCKET1_FINESCAN_VGA']['PHYS_TRK'] )  if phy == '114688']
#y= [int(val)  for val,phy in map(None, dblData['P139_BUCKET1_FINESCAN_VGA']['VGA'],dblData['P139_BUCKET1_FINESCAN_VGA']['PHYS_TRK'] )     if phy == '114688']
#y1=[int(val)  for val,phy in map(None, dblData['P139_BUCKET2_FINESCAN_VGA']['VGA'],dblData['P139_BUCKET2_FINESCAN_VGA']['PHYS_TRK'] )     if phy == '114688']

# Start a plot
startPlot(repr(x),repr(y),xlab='OFFSET', ylab1='VGA-BUCKET1', heading='P139_BUCKET2_FINESCAN_VGA',yval2=repr(y1), ylab2='VGA-BUCKET2', plot='dots',indYAx=1)

