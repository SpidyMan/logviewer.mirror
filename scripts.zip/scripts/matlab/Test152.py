
FOFexecfile(("", "scriptfuncs.py"))
FOFexecfile(("matlab", "StartGraphs.py"))

RegisterBaudRate(1228000)
SetESlipBaud(1228000)

DBlogParserOn()
dblData={}

prm={'PLOT_TYPE': [1], 
     'SAP_ONLY': [], 
     'GAIN_LIMIT': [800], 
     'PEAK_SUMMARY': [0], 
     'MASK_VALUE': [7], 
     'NBR_TFA_SAMPS': [14], 
     'FREQ_INCR': [50], 
     'END_CYL': [0, 50000],
     'FREQ_RANGE': [500, 39900], 
     'INJ_AMPL': [50], 
     'NUM_FCS_CTRL': [7], 
     'START_CYL': [0, 50000], 
     'HEAD_RANGE': [771], 
     'NBR_MEAS_REPS': [2], 
     'MEASURE_PHASE': [], 
     'CWORD1': [1]}

prm={'PlotTyp': [1], 
     #'SAP_ONLY': [],             # eliminated in UPS
     'GainLmt': [800], 
     'PkSmry': [0], 
     'Msk': [7], 
     'TfaSampCnt': [14], 
     'FrqInc': [50], 
     'CylRg': [50000, 50000],
     'FrqRg': [500, 39900], 
     'FrqRg': [50], 
     'FcsCtrlCnt': [7], 
     'HdRg': [3,3], 
     'MeasRepCnt': [2], 
     'Crwd2': 0x2000, 
     'Cwrd1': [1]}

try: 
    if not UPSEnabled: st(152, prm, timeout=100)
    else:              st(152, prm_ups, timeout=100)
except: pass # This test may fail for Read pc file.

# Get Data points
## Using Old format
#x=[int(val['FREQUENCY']) for val in dblData['P152_BODE_GAIN_PHASE'] ]
#y=[float(val['GAIN']) for val in dblData['P152_BODE_GAIN_PHASE'] ]
#y1=[float(val['PHASE']) for val in dblData['P152_BODE_GAIN_PHASE'] ]

# New format
x= [int(val)   for val in dblData['P152_BODE_GAIN_PHASE']['FREQUENCY'] ]
y= [float(val) for val in dblData['P152_BODE_GAIN_PHASE']['GAIN'] ]
y1=[float(val) for val in dblData['P152_BODE_GAIN_PHASE']['PHASE'] ]

# Start Line Plot
startPlot(repr(x),repr(y),xlab='FREQ', ylab1='GAIN', heading='P152_BODE_GAIN_PHASE',yval2=repr(y1), ylab2='PHASE')

