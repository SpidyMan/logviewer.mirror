if RestrictedMode: 
   print("""
ERROR: StartGraphs cannot run under restricted mode.
Go to the 'Configure' tab, select 'Yes' for 'Disable Restricted Mode' and click on the 'Update' button.
You'll have to restart WinFOF for this change to take affect.
""")

else:

  import subprocess, traceback, pickle, sys
  import numpy as np
  from pylab import *
  
  def startPlot(xval, yval1, xlab='X-Axis', ylab1='Y-Axis', heading='Data Plot', yval2=repr(np.array([])), ylab2='Y-Axis 2', yval3=repr(np.array([])), ylab3='Y-Axis 3',yval4=repr(np.array([])), ylab4='Y-Axis 4',plot='dots', indYAx=0):
    # eval first
    try:   
      xval  = eval(xval)
      yval1 = eval(yval1)
      yval2 = eval(yval2)
      yval3 = eval(yval3)
      yval4 = eval(yval4)
    except:  
        traceback.print_exc()
        raise FOFParameterError("startPlot: Data (x-axis) and y-axis should be a list of integers or float.")
    
    if not isinstance(xval,(list,tuple,ndarray)) or [val for val in xval if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (x-axis) should be a list of integers or float.")  

    if not isinstance(yval1,(list,tuple,ndarray)) or [val for val in yval1 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (y-axis 1) should be a list of integers or float.")  
    
    if not isinstance(yval2,(list,tuple,ndarray)) or [val for val in yval2 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (y-axis 2) should be a list of integers or float.")    
  
    if not isinstance(yval3,(list,tuple,ndarray)) or [val for val in yval3 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (y-axis 3) should be a list of integers or float.")  
    
    if not isinstance(yval4,(list,tuple,ndarray)) or [val for val in yval4 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (y-axis 4) should be a list of integers or float.") 
    
    yval2=list(yval2)
    yval3=list(yval3)
    yval4=list(yval4)
    
    if not isinstance(xlab,str) or not isinstance(ylab1,str) or not isinstance(ylab2,str) or not isinstance(ylab3,str) or not isinstance(ylab4,str) or not isinstance(heading,str):
        raise FOFParameterError("startPlot: labels/heading should be a string.")  
    
    pltData = {}
    pltData['xval']  = xval
    pltData['yval1'] = yval1
    pltData['yval2'] = yval2
    pltData['yval3'] = yval3
    pltData['yval4'] = yval4
    pltData['xlab']  = xlab
    pltData['ylab1'] = ylab1
    pltData['ylab2'] = ylab2
    pltData['ylab3'] = ylab3
    pltData['ylab4'] = ylab4
    pltData['head']  = heading
    pltData['type']  = plot
    pltData['indAx'] = indYAx
    
    # Pickle the data.
    id = "%.3f"%time.time()
    cachedFile = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(id,))
    pickle.dump(pltData,open(cachedFile,'wb',0))
    
    result = subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "plot", id],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)   
    
  #################################################################### 
  
  def startPie(frac, labels=repr([]), heading='Pie Chart'):
    # eval first
    try:   
      frac  = eval(frac)
      labels = eval(labels)    
    except:  
        traceback.print_exc()
        raise FOFParameterError("startPlot: Data (x-axis) should be a list of integers or float.")
        
    if not isinstance(frac,(list,tuple,ndarray)) or [val for val in frac if not isinstance(val, (int,float))]:
      raise FOFParameterError("startPie: fracs should be a list of integers or float.")  
    
    if not isinstance(labels,(list,tuple,ndarray)) or [val for val in labels if not isinstance(val, str)]:
        raise FOFParameterError("startPie: labels should be a list of strings.")  
     
    labels = list(labels) # Convert from other data type to list
    if len(labels) >= len(frac): labels = labels[:len(frac)]
    else: labels = labels[:] + ["F%d"%val for val in range(len(labels)+1,len(frac)+1)]
    
    pltData = {}
    pltData['frac']  = frac
    pltData['lab']   = labels
    pltData['head']  = heading
    
    # Pickle the data.
    id = "%.3f"%time.time()
    cachedFile = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(id,))
    pickle.dump(pltData,open(cachedFile,'wb',0))
      
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "pie", id],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  ####################################################################
    
  def start2Plot(xval, yval1,  yval2, xlab='X-Axis', ylab1='Y-Axis', ylab2='Y-Axis 2', heading='Data Plot', plot='dots'):
    # eval first
    try:   
      xval  = eval(xval)
      yval1 = eval(yval1)
      yval2 = eval(yval2)
    except:  
        traceback.print_exc()
        raise FOFParameterError("startPlot: Data (x-axis) and y-axis should be a list of integers or float.")
    
    if not isinstance(xval,(list,tuple,ndarray)) or [val for val in xval if not isinstance(val, (int,float))]:
        raise FOFParameterError("start2Plot: Data (x-axis) should be a list of integers or float.")  
  
    if not isinstance(yval1,(list,tuple,ndarray)) or [val for val in yval1 if not isinstance(val, (int,float))]:
        raise FOFParameterError("start2Plot: Data (y-axis 1) should be a list of integers or float.")  
    
    if not isinstance(yval2,(list,tuple,ndarray)) or [val for val in yval2 if not isinstance(val, (int,float))]:
        raise FOFParameterError("start2Plot: Data (y-axis 2) should be a list of integers or float.")  
    
    if not isinstance(xlab,str) or not isinstance(ylab1,str) or not isinstance(ylab2,str) or not isinstance(heading,str):
        raise FOFParameterError("start2Plot: labels/heading should be a string.")  
    
    pltData = {}
    pltData['xval']  = xval
    pltData['yval1'] = yval1
    pltData['yval2'] = yval2
    pltData['xlab']  = xlab
    pltData['ylab1'] = ylab1
    pltData['ylab2'] = ylab2
    pltData['head']  = heading
    pltData['type']  = plot  
  
    # Pickle the data.
    id = "%.3f"%time.time()
    cachedFile = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(id,))
    pickle.dump(pltData,open(cachedFile,'wb',0))
    
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "2plot", id],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)  
  ####################################################################
    
  def startHist(xval,bins,normed=repr(1),rangeVal=repr(-1),xlab='X-Axis',ylab='Y-Axis',heading='Histogram'):
    # eval first
    try:   
      xval  = eval(xval)
      bins   = eval(bins)    
    except:  
        traceback.print_exc()
        raise FOFParameterError("startHist: Data (x-axis) and y-axis should be a list of integers or float.")
        
    if not isinstance(xval,(list,tuple,ndarray)) or [val for val in xval if not isinstance(val, (int,float))]:
        raise FOFParameterError("startHist: Data Points should be a list of integers or float.")  
    
    if not isinstance(bins,int):
        raise FOFParameterError("startHist: Bins should be integer.")   
    
    try: normed=eval(normed)
    except: normed=1
    
    try: 
        rangeVal=eval(rangeVal)
        if not isinstance(rangeVal,(list,tuple,ndarray)) or len(rangeVal)!=2 or [val for val in rangeVal if not isinstance(val, (int,float))]: raise FOFParameterError
    except:
        print("Using X-Axis' Min and Max as 'Range'")
        # Convert to array so that we can use min() max() functions
        x=np.array(xval)
        rangeVal=(x.min(), x.max())
        #print rangeVal
        del x
  
    pltData = {}
    pltData['xval']  = xval
    pltData['bins']  = bins
    pltData['rVal']  = rangeVal
    pltData['norm']  = normed
    pltData['xlab']  = xlab
    pltData['ylab'] =  ylab
    pltData['head']  = heading
    
    # Pickle the data.
    id = "%.3f"%time.time()
    cachedFile = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(id,))
    pickle.dump(pltData,open(cachedFile,'wb',0))
    
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "hist", id],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  ####################################################################
  
  def startScatter(xval, yval1, xlab='X-Axis', ylab1='Y-Axis', heading='Data Plot', yval2=repr(np.array([])), ylab2='Y-Axis 2', yval3=repr(np.array([])), ylab3='Y-Axis 3',yval4=repr(np.array([])), ylab4='Y-Axis 4', indYAx=0):
    # eval first
    try:   
      xval  = eval(xval)
      yval1 = eval(yval1)
      yval2 = eval(yval2)
      yval3 = eval(yval3)
      yval4 = eval(yval4)
    except:  
        traceback.print_exc()
        raise FOFParameterError("startScatter: Data (x-axis) and y-axis should be a list of integers or float.")
        
    if not isinstance(xval,(list,tuple,ndarray)) or [val for val in xval if not isinstance(val, (int,float))]:
        raise FOFParameterError("startScatter: Data (x-axis) should be a list of integers or float.")  
  
    if not isinstance(yval1,(list,tuple,ndarray)) or [val for val in yval1 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startScatter: Data (y-axis 1) should be a list of integers or float.")  
    
    if not isinstance(yval2,(list,tuple,ndarray)) or [val for val in yval2 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startScatter: Data (y-axis 2) should be a list of integers or float.") 
  
    if not isinstance(yval3,(list,tuple,ndarray)) or [val for val in yval3 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (y-axis 3) should be a list of integers or float.")  
    
    if not isinstance(yval4,(list,tuple,ndarray)) or [val for val in yval4 if not isinstance(val, (int,float))]:
        raise FOFParameterError("startPlot: Data (y-axis 4) should be a list of integers or float.") 
    
    yval2=list(yval2)
    yval3=list(yval3)
    yval4=list(yval4)
    
    pltData = {}
    pltData['xval']  = xval
    pltData['yval1'] = yval1
    pltData['yval2'] = yval2
    pltData['yval3'] = yval3
    pltData['yval4'] = yval4
    pltData['xlab']  = xlab
    pltData['ylab1'] = ylab1
    pltData['ylab2'] = ylab2
    pltData['ylab3'] = ylab3
    pltData['ylab4'] = ylab4
    pltData['head']  = heading
    pltData['indAx'] = indYAx
    
    # Pickle the data.
    id = "%.3f"%time.time()
    cachedFile = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(id,))
    pickle.dump(pltData,open(cachedFile,'wb',0))
    
    if not isinstance(xlab,str) or not isinstance(ylab1,str) or not isinstance(ylab2,str) or not isinstance(heading,str):
        raise FOFParameterError("startScatter: labels/heading should be a string.")  
        
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "scatter", id],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
####################################################################  
              
  def startPolar():
    r = np.arange(0, 3.0, 0.01)
    theta = 2*np.pi*r  
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "polar", repr(theta), repr(r)],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  #################################################################### 
   
  def startColor():
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', "color"],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  #################################################################### 
  
  def testGr(type='log'):
    subprocess.Popen([r'C:\WinFOFpy3\WinFOF_venv\Scripts\pythonw.exe', '-u', r'/var/merlin3/scripts/matlab/userGraphsDef.py', type],   bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  