
FOFexecfile(("", "scriptfuncs.py"))
FOFexecfile(("matlab", "StartGraphs.py"))

RegisterBaudRate(1228000)
SetESlipBaud(1228000)

DBlogParserOn()
dblData={}

prm= { "CWORD1" : (0x0400,),      # x0400 REQ'D FOR SUMMARY REPORTING
  "TEST_HEAD" : (0x00,),
  "SEEK_ERR_LIMIT" : (0x31F,),
  "CWORD2" : (5,),
  "GAIN" : (50,),
  "RETRIES" : (6,),
  "LIMIT2" : (150,),
  "SEEK_LENGTH" : (1000,0x0CCC,),
  "SEEK_NUMS" : (100,),
  "DELTA_LIMIT" : (10000,),
}

prm_ups= { "Cwrd1" : (0x0400,),      # x0400 REQ'D FOR SUMMARY REPORTING
  "TstHd" : (0x00,),
  # "SkErrLm" : (0x31F,),        # Parameter has been eliminated in UPS
  "Cwrd2" : (5,),
  "Gain" : (50,),
  "RtryCnt" : (6,),
  "Lmt2" : (150,),
  #"SkLen" : (1000,0x0CCC,),      # Parameter has been eliminated in UPS
  "SkCnt" : (100,),
  "DltaLmt" : (10000,),
}

if not UPSEnabled: st(10, prm, timeout=3600)
else:              st(10, prm_ups, timeout=3600)

# Get Data points
## Using Old format
#x=[int(val['POINT']) for val in dblData['P010_FORCE_CONSTANT'] if val['ITER']=='255']
#y=[int(val['ZTAB']) for val in dblData['P010_FORCE_CONSTANT'] if val['ITER']=='255' ]
#y1=[int(val['ZTAB']) for val in dblData['P010_FORCE_CONSTANT'] if val['ITER']=='0' ]

# New format
x= [int(point) for point,iter in map(None,dblData['P010_FORCE_CONSTANT']['POINT'],dblData['P010_FORCE_CONSTANT']['ITER'])  if iter=='255']
y= [int(ztab)  for ztab,iter  in map(None,dblData['P010_FORCE_CONSTANT']['ZTAB'], dblData['P010_FORCE_CONSTANT']['ITER'])  if iter=='255']
y1=[int(ztab)  for ztab,iter  in map(None,dblData['P010_FORCE_CONSTANT']['ZTAB'], dblData['P010_FORCE_CONSTANT']['ITER'])  if iter=='0']


# Start a scatter-plot
startPlot(repr(x),repr(y),xlab='ITER', ylab1='ZTAB(255)', heading='P010_FORCE_CONSTANT',yval2=repr(y1), ylab2='ZTAB(0)',indYAx=1)
startScatter(repr(x),repr(y),xlab='ITER', ylab1='ZTAB(255)', heading='P010_FORCE_CONSTANT',yval2=repr(y1), ylab2='ZTAB(0)',indYAx=1)


