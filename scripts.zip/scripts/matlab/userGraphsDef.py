import numpy as np
import matplotlib,sys, os, pickle
import matplotlib.mlab as mlab
from scipy import *
from pylab import * 
import math
from matplotlib.widgets import Slider, Button, RadioButtons



class AnnoteFinder:
  """
  callback for matplotlib to display an annotation when points are clicked on.  The
  point which is closest to the click and within xtol and ytol is identified.
    
  Register this function like this:
    
  scatter(xdata, ydata)
  af = AnnoteFinder(xdata, ydata, annotes)
  connect('button_press_event', af)
  """

  def __init__(self, xdata, ydata, annotes, axis=None, xtol=None, ytol=None):
    self.data = list(zip(xdata, ydata, annotes))
    if xtol is None:
      xtol = ((max(xdata) - min(xdata))/float(len(xdata)))/2
    if ytol is None:
      ytol = ((max(ydata) - min(ydata))/float(len(ydata)))/2
    self.xtol = xtol
    self.ytol = ytol
    if axis is None:
      self.axis = gca()
    else:
      self.axis= axis
    self.drawnAnnotations = {}
    self.links = []

  def distance(self, x1, x2, y1, y2):
    """
    return the distance between two points
    """
    return(math.sqrt( (x1 - x2)**2 + (y1 - y2)**2 ))

  def __call__(self, event):
    if event.inaxes:
      clickX = event.xdata
      clickY = event.ydata
      if (self.axis is None) or (self.axis==event.inaxes):
        annotes = []
        for x,y,a in self.data:
          if  (clickX-self.xtol < x < clickX+self.xtol) and  (clickY-self.ytol < y < clickY+self.ytol) :
            annotes.append((self.distance(x,clickX,y,clickY),x,y, a) )
        if annotes:
          annotes.sort()
          distance, x, y, annote = annotes[0]
          self.drawAnnote(event.inaxes, x, y, annote)
          for l in self.links:
            l.drawSpecificAnnote(annote)

  def drawAnnote(self, axis, x, y, annote):
    """
    Draw the annotation on the plot
    """
    if (x,y) in self.drawnAnnotations:
      markers = self.drawnAnnotations[(x,y)]
      for m in markers:
        m.set_visible(not m.get_visible())
      self.axis.figure.canvas.draw()
    else:
      #t = axis.text(x,y, "(%3.2f, %3.2f) - %s"%(x,y,annote), )
      t = axis.text(x,y, "(%3.2f, %3.2f) %s"%(x,y,annote), )
      m = axis.scatter([x],[y], marker='d', c='r', zorder=100)
      self.drawnAnnotations[(x,y)] =(t,m)
      self.axis.figure.canvas.draw()

  def drawSpecificAnnote(self, annote):
    annotesToDraw = [(x,y,a) for x,y,a in self.data if a==annote]
    for x,y,a in annotesToDraw:
      self.drawAnnote(self.axis, x, y, a)
      
def click(event):
   """If the left mouse button is pressed: draw a little square. """
   tb = get_current_fig_manager().toolbar
   if event.button==1 and event.inaxes and tb.mode == '':
       x,y = event.xdata,event.ydata
       plot([x],[y],'rs')
       draw()

def linkAnnotationFinders(afs):
  for i in range(len(afs)):
    allButSelfAfs = afs[:i]+afs[i+1:]
    afs[i].links.extend(allButSelfAfs)


def plotFunc():
    close('all')
    matplotlib.interactive(False)
          
    # Read the file containing the marshalled recipe.
    mmsg = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(sys.argv[2],)) 
    pltData = pickle.load(open(mmsg, 'rb'))
    os.unlink(mmsg)
   
    figure(1, figsize=(12,10))
    rect=[0.12,0.12,0.76,0.72]
    a1=axes(rect)
    a1.yaxis.tick_left()
    
    annotes = []
    for i in range(len(list(pltData['xval']))):
        #annotes.append('P%d'%i)
        annotes.append(' ')
    
    if pltData['type'] == 'dots': marker = 'o-'
    else:                         marker = '-'
    
    #plot(pltData['xval'], pltData['yval1'], 'bo-', pltData['xval'], pltData['yval2'], 'go-', pltData['xval'], arange(5.0, 7.0, 0.01), 'ro-')
    #af1 =  AnnoteFinder(pltData['xval'],pltData['xval1'], annotes)
    #connect('button_press_event', af1)    
    #gca().set_autoscale_on(False)
    ##connect('button_press_event',click)
    
    rects1 = plot(pltData['xval'], pltData['yval1'], 'b%s'%marker, label=pltData['ylab1'])

    # If we want to plot on the same Y-Axis    
    if not pltData['indAx']:       
      if pltData['yval2']:  plot(pltData['xval'], pltData['yval2'], 'g%s'%marker, label=pltData['ylab2'])      
      if pltData['yval3']:  plot(pltData['xval'], pltData['yval3'], 'r%s'%marker, label=pltData['ylab3'])
      if pltData['yval4']:  plot(pltData['xval'], pltData['yval4'], 'm%s'%marker, label=pltData['ylab4'])      
      legend(loc=(0.0, 1.06))
      
      
    ylabel(pltData['ylab1'], color='blue')
    xlabel(pltData['xlab'])
    grid(True)
    for tl in a1.get_yticklabels():
       tl.set_color('b')

    if (pltData['yval2'] or pltData['yval3'] or pltData['yval4']) and pltData['indAx']:
        a2=axes(rect,frameon=False)
        a2.yaxis.tick_right()
        a2.yaxis.set_label_position('right')
        a2.set_xticks([])
                
        objList = [rects1[0],]; labList = [pltData['ylab1'],]
        
        if pltData['yval2']:
            rects2=plot(pltData['xval'], pltData['yval2'], 'g%s'%marker)
            objList.append(rects2[0]); labList.append(pltData['ylab2'])
            ylabel(pltData['ylab2'], color='green')
            for tl in a2.get_yticklabels(): tl.set_color('green')
        
        #af2 =  AnnoteFinder(pltData['xval'],pltData['yval2'], annotes)
        #connect('button_press_event', af2)
        #linkAnnotationFinders([af1, af2])
        #gca().set_autoscale_on(False)
      
        # The following lines are for preventing independent y-axes
        if 0:
        #if not pltData['indAx']:
          y1lo, y1hi =  a1.get_ylim()
          y2lo, y2hi =  a2.get_ylim()
          lo = min(y1lo, y2lo)
          hi = max(y1hi, y2hi)
          a1.set_ylim((lo,hi))
          a2.set_ylim((lo,hi))
          ticks = arange(lo, hi, (hi-lo)/4)
          ticks = append(ticks,hi)
          a1.set_yticks(ticks)
          a2.set_yticks(ticks)           
          #a2.set_yticks(a1.get_yticks())
          #a2.set_ylim(a1.get_ylim())
        
        if pltData['yval3']: 
            rects3=plot(pltData['xval'], pltData['yval3'], 'r%s'%marker)
            objList.append(rects3[0]); labList.append(pltData['ylab3'])
            ylabel(pltData['ylab3'], color='red')
            for tl in a2.get_yticklabels(): tl.set_color('red')
        if pltData['yval4']: 
            rects4=plot(pltData['xval'], pltData['yval4'], 'm%s'%marker)
            objList.append(rects4[0]); labList.append(pltData['ylab4'])
            ylabel(pltData['ylab4'], color='magenta')
            for tl in a2.get_yticklabels(): tl.set_color('magenta')
            
        legend( tuple(objList), tuple(labList), loc=(0.0, 1.06) )
    
    
    title(pltData['head'])
    grid(True)
    show()
    
####################################################################

def pieFunc():
    close('all')
    matplotlib.interactive(False)
    
    # Read the file containing the marshalled recipe.
    mmsg = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(sys.argv[2],)) 
    pltData = pickle.load(open(mmsg, 'rb'))
    os.unlink(mmsg)
    
    # make a square figure and axes
    figure(1, figsize=(10,8))
    
    pie(pltData['frac'], labels=pltData['lab'], autopct='%1.1f%%', shadow=True)  
    title(pltData['head'], bbox={'facecolor':'0.8', 'pad':5})
    show() 
####################################################################    
    
def f(t):
    s1 = cos(2*pi*t)
    e1 = exp(-t)
    return multiply(s1,e1) 

def Plot2Func():
    close('all')
    matplotlib.interactive(False)
    
    # Read the file containing the marshalled recipe.
    mmsg = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(sys.argv[2],)) 
    pltData = pickle.load(open(mmsg, 'rb'))
    os.unlink(mmsg)

    figure(1, figsize=(10,8))    
    subplot(211)    
    l = plot(pltData['xval'], pltData['yval1'], 'bo', pltData['xval'], pltData['yval1'], 'k--', markerfacecolor='green')
    grid(True)
    
    title(pltData['head'])
    ylabel(pltData['ylab1'])
    matplotlib.interactive(False)
    
    subplot(212)
    plot(pltData['xval'], pltData['yval2'], 'r.')
    grid(True)
    xlabel(pltData['xlab'])
    ylabel(pltData['ylab2'])
    show()
####################################################################    

def histFunc():
    close('all')
    matplotlib.interactive(False)
    
    # Read the file containing the marshalled recipe.
    mmsg = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(sys.argv[2],)) 
    pltData = pickle.load(open(mmsg, 'rb'))
    os.unlink(mmsg)
    
    figure(1, figsize=(10,8))
     
    if pltData['norm']: n, bins, patches = hist(pltData['xval'], pltData['bins'], normed=pltData['norm'], range=pltData['rVal'], facecolor='green', alpha=0.75)    
    else:               n, bins, patches = hist(pltData['xval'], pltData['bins'], range=pltData['rVal'], facecolor='green', alpha=0.75)    
    
    print(max(n))
    print('++++++++++++\n',bins)
    
    # add a 'best fit' line
    pltData['xval'] = np.array(pltData['xval'])
    mu = np.mean(pltData['xval'])
    sigma = np.std(pltData['xval'])    
    y = mlab.normpdf( bins, mu, sigma)                                         
    l = plot(bins, y, 'r--', linewidth=2)
    
    xlabel(pltData['xlab'])
    ylabel(pltData['ylab'])
    title(pltData['head'])
    #axis([0, 160, 0, 0.03])
    #yticks(arange(sorted(n)[-1]))
    #axis('scaled')
    ylim((0,max(n)*1.1))
    hsepVal = max(pltData['xval']) - min(pltData['xval'])
    xlim((min(pltData['xval']), (max(pltData['xval']) + hsepVal*0.1)))
    grid(True)
    show()
####################################################################

def scatterFunc111():
    close('all')
    matplotlib.interactive(False)
    
    try: 
        xval = eval(sys.argv[2])
        yval = eval(sys.argv[3])
    except: raise
    
    try: xlab = sys.argv[4]
    except: xlab='X-Axis'
    
    try: ylab = sys.argv[5]
    except: ylab='Y-Axis'
    
    try: heading = sys.argv[6]
    except: heading='Data Plot'
    
    try: yval2 = eval(sys.argv[7])
    except: yval2=np.array([])     
    
    #xval = arange(0.0, 2.0, 0.01)
    #yval = sin(2*pi*xval)
    #xlab='XXX'
    #ylab='YYY'
    #heading = 'head'
    #yval2=  cos(2*pi*xval)
    
    ax = subplot(111)
    
    ax.scatter(xval, yval, linewidth=1.0)
    
    if yval2.any(): ax.scatter(xval, yval2, linewidth=1.0, marker='s',color='red' )
    
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(heading)
    grid(True)
    show()
####################################################################

def scatterFunc():
    close('all')
    matplotlib.interactive(False)
    
    # Read the file containing the marshalled recipe.
    mmsg = os.path.join(r"C:\var\merlin3\pickle", "graph-%s.mmsg"%(sys.argv[2],)) 
    pltData = pickle.load(open(mmsg, 'rb'))
    os.unlink(mmsg)
       
    #ax = subplot(111)
    figure(1, figsize=(10,8))
    rect=[0.12,0.12,0.76,0.72]
    #rect=[0.1,0.1,0.8,0.8]
    a1=axes(rect)
    a1.yaxis.tick_left()
    rects1 = scatter(pltData['xval'], pltData['yval1'], label=pltData['ylab1'], linewidth=0.1)
    
    # If we want to plot on the same Y-Axis    
    if not pltData['indAx']:       
      if pltData['yval2']:  scatter(pltData['xval'], pltData['yval2'], label=pltData['ylab2'], linewidth=0.1, marker='s',color='green') 
      if pltData['yval3']:  scatter(pltData['xval'], pltData['yval3'], label=pltData['ylab3'], linewidth=0.1, marker='+',color='red')
      if pltData['yval4']:  scatter(pltData['xval'], pltData['yval4'], label=pltData['ylab4'], linewidth=0.1, marker='x',color='magenta') 
      legend(loc=(0.0, 1.06))
    
    ylabel(pltData['ylab1'], color='blue')    
    xlabel(pltData['xlab'])
    grid(True)
    
    #if pltData['yval2'].any(): 
    if (pltData['yval2'] or pltData['yval3'] or pltData['yval4']) and pltData['indAx']:
        a2=axes(rect,frameon=False)
        a2.yaxis.tick_right()
        a2.yaxis.set_label_position('right')
        a2.set_xticks([]) 
        
        objList = [rects1,]; labList = [pltData['ylab1'],]
        
        if pltData['yval2']:
            rects2 = scatter(pltData['xval'], pltData['yval2'], linewidth=0.1, marker='s',color='green' )            
            objList.append(rects2); labList.append(pltData['ylab2'])
            ylabel(pltData['ylab2'], color='green')
            for tl in a2.get_yticklabels(): tl.set_color('green')
        if pltData['yval3']:
            rects3 = scatter(pltData['xval'], pltData['yval3'], linewidth=0.1, marker='+',color='red' )            
            objList.append(rects3); labList.append(pltData['ylab3'])
            ylabel(pltData['ylab3'], color='red')
            for tl in a2.get_yticklabels(): tl.set_color('red')            
        if pltData['yval4']:
            rects4 = scatter(pltData['xval'], pltData['yval4'], linewidth=0.1, marker='+',color='magenta' )            
            objList.append(rects4); labList.append(pltData['ylab4'])
            ylabel(pltData['ylab4'], color='magenta')
            for tl in a2.get_yticklabels(): tl.set_color('magenta')
        
        legend( tuple(objList), tuple(labList), loc=(0.0, 1.06) )   
        
    title(pltData['head'])
    grid(True)
    show()
####################################################################

def polarFunc():    
    from matplotlib.pyplot import figure, show, rc, grid
    
    close('all')
    matplotlib.interactive(False)
    
    try: 
        theta = eval(sys.argv[2])
        r     = eval(sys.argv[3])
    except: raise
    
    try: heading = sys.argv[4]
    except: heading='Polar Plot'
    
    # radar green, solid grid lines
    rc('grid', color='#316931', linewidth=1, linestyle='-')
    rc('xtick', labelsize=15)
    rc('ytick', labelsize=15)

    # force square figure and square axes looks better for polar, IMO
    #width, height = matplotlib.rcParams['figure.figsize']
    #size = min(width, height)
    #fig = figure(figsize=(size, size))
    fig = figure(figsize=(8, 8))
    
    # changed bg to white
    #ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], polar=True, axisbg='#d5de9c')
    ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], polar=True)
    
    #ax.plot(theta, r, color='#ee8d18', lw=3)
    ax.plot(theta, r, lw=3)
    ax.set_rmax(2.0)
    grid(True)
    ax.set_title(heading, fontsize=20)
    show()

    #angles = arange(0,360,45)
    #rad_angles = [elem*(pi/180) for elem in angles]
    #data = [18, 11, 11, 17, 39, 43, 25, 9]
    #fig = figure(figsize=(8,8))
    #title('Wind Speed/Direction Frequency.', fontsize=13)
    #ax = fig.add_subplot(111)
    #fig.add_axes(([0.15,0.15,0.725,0.725]), polar=True)
    #labels = arange(0,360,22.5)
    #lines = arange(0,360,22.5)
    #ax.axis('off')
    #w = 45*pi/180
    #bar(rad_angles, data, alpha=0.75, align='center', width=w, linewidth=0)
    #grid(True)
    #show()

def contourPlotFunc():
    from matplotlib.mlab import griddata
    import numpy.ma as ma
    from numpy.random import uniform
    
    close('all')
    matplotlib.interactive(False)
    
    # make up some randomly distributed data
    npts = 200
    x = uniform(-2,2,npts)
    y = uniform(-5,5,npts)
    z = x*np.exp(-x**2-y**2)
    # define grid.
    xi = np.linspace(-2.1,2.1,100)
    yi = np.linspace(-5.1,5.1,500)
    # grid the data.
    zi = griddata(x,y,z,xi,yi)
    
    # contour the gridded data, plotting dots at the randomly spaced data points.
    CS = contour(xi,yi,zi,15,linewidths=0.5,colors='k')
    CS = contourf(xi,yi,zi,15,cmap=cm.jet)
    cb=colorbar() # draw colorbar
    cb.ax.set_ylabel("colorbar label")
    # plot data points.                      
    scatter(x,y,marker='o',c='b',s=5)
    xlim(-2,2)
    ylim(-5,5)
    xlabel("X-Axis")
    ylabel("Y-Axis")
    title('griddata test (%d points)' % npts)
    show()

# Formulas from C. Pickover
def colorPlotFunc():
  
    from numpy.random import randn
    
    # Make plot with vertical (default) colorbar
    fig = figure()
    ax = fig.add_subplot(111)
    
    data = np.clip(randn(250, 250), -1, 1)
    
    cax = ax.imshow(data, interpolation='nearest')
    ax.set_title('Gaussian noise with vertical colorbar')
    
    # Add colorbar, make sure to specify tick locations to match desired ticklabels
    cbar = fig.colorbar(cax, ticks=[-1, 0, 1])
    cbar.ax.set_yticklabels(['< -1', '0', '> 1'])# vertically oriented colorbar
    
    # Make plot with horizontal colorbar
    #fig = figure()
    #ax = fig.add_subplot(111)
    
    #data = np.clip(randn(250, 250), -1, 1)
    
    #cax = ax.imshow(data, interpolation='nearest')
    #ax.set_title('Gaussian noise with horizontal colorbar')
    
    #cbar = fig.colorbar(cax, ticks=[-1, 0, 1], orientation='horizontal')
    #cbar.ax.set_xticklabels(['Low', 'Medium', 'High'])# horizontal colorbar
    
    show()


def logPlots():
   subplots_adjust(hspace=0.4)
   t = np.arange(0.01, 20.0, 0.01)
   
   # log y axis
   subplot(311)
   semilogy(t, np.exp(-t/5.0))   
   ylabel('semilogy')
   grid(True)
   
   # log x axis
   subplot(312)
   semilogx(t, np.sin(2*np.pi*t))
   ylabel('semilogx')
   grid(True)
   
   # log x and y axis
   subplot(313)
   loglog(t, 20*np.exp(-t/10.0), basex=4)
   grid(True)
   ylabel('loglog base 4 on x')

   show()
   
def barPlots():
   N = 5
   menMeans = (20, 35, 30, 35, 27)
   menStd =   (2, 3, 4, 1, 2)
   
   ind = np.arange(N)  # the x locations for the groups
   width = 0.35       # the width of the bars     
   
   subplot(111)
   rects1 = bar(ind, menMeans, width, color='blue', yerr=menStd)
   
   womenMeans = (25, 32, 34, 20, 25)
   womenStd =   (3, 5, 2, 3, 3)
   rects2 = bar(ind+width, womenMeans, width, color='green', yerr=womenStd)
   
   # add some
   ylabel('Scores')
   title('Scores by group and gender')
   xticks(ind+width, ('G1', 'G2', 'G3', 'G4', 'G5') )
   
   legend( (rects1[0], rects2[0]), ('Men', 'Women') )
   
   def autolabel(rects):
      # attach some text labels
      for rect in rects:
         height = rect.get_height()
         text(rect.get_x()+rect.get_width()/2., 1.05*height, '%d'%int(height),
                ha='center', va='bottom')

   autolabel(rects1)
   autolabel(rects2)

   show()


def test111():
  cdict = {'red': ((0.0, 0.0, 0.0),
                 (0.5, 1.0, 0.7),
                 (1.0, 1.0, 1.0)),
         'green': ((0.0, 0.0, 0.0),
                   (0.5, 1.0, 0.0),
                   (1.0, 1.0, 1.0)),
         'blue': ((0.0, 0.0, 0.0),
                  (0.5, 1.0, 0.0),
                  (1.0, 0.5, 1.0))}
  #my_cmap = matplotlib.colors.LinearSegmentedColormap('my_colormap',cdict,256)
  #pcolor(rand(10,10),cmap=my_cmap)
  pcolor(rand(10,10))
  xval = arange(0.0, 2.0, 0.01)
  yval = sin(2*pi*xval)
  plot(xval, yval)
  colorbar()
  show()

def multiAxes():    
  t = arange(0.0, 2.0, 0.01)
  s1 = sin(2*pi*t)
  s2 = exp(-t)
  s3 = sin(2*pi*t)*exp(-t)
  s4 = sin(2*pi*t)*cos(4*pi*t)
  s4 = arange(0.0, 4.0, 0.02)
  
  fig = figure(figsize=(10,8))
  t = arange(0.0, 2.0, 0.01)
  
  yprops = dict(rotation=0,
                horizontalalignment='right',
                verticalalignment='center',
                x=-0.01)
  
  axprops = dict(yticks=[])
  
  ax1 =fig.add_axes([0.1, 0.76, 0.8, 0.2], **axprops)
  ax1.plot(t, s1)
  ax1.yaxis.tick_left()
  lo, hi =  ax1.get_ylim()
  ticks = arange(lo, hi+(hi-lo)/4, (hi-lo)/4)
  ticks = append(ticks,hi+(hi-lo)/4)
  print("S1 ticks: %s"%ticks)
  ax1.set_yticks(ticks)
  ax1.set_ylabel('S1', **yprops)
  
  
  axprops['sharex'] = ax1
  axprops['sharey'] = ax1
  # force x axes to remain in register, even with toolbar navigation
  ax2 = fig.add_axes([0.1, 0.54, 0.8, 0.2], **axprops)

  ax2.plot(t, s2)
  ax2.yaxis.tick_left()
  lo, hi =  ax2.get_ylim()
  ticks = arange(lo, hi+(hi-lo)/4, (hi-lo)/4)
  ticks = append(ticks,hi+(hi-lo)/4)
  print("S2 ticks: %s"%ticks)
  ax2.set_yticks(ticks)
  ax2.set_ylabel('S2', **yprops)
  
  
  ax3 = fig.add_axes([0.1, 0.32, 0.8, 0.2], **axprops)
  ax3.plot(t, s4)
  ax3.yaxis.tick_left()
  lo, hi =  ax3.get_ylim()
  ticks = arange(lo, hi+(hi-lo)/4, (hi-lo)/4)
  ticks = append(ticks,hi+(hi-lo)/4)
  print("S3 ticks: %s"%ticks)
  ax3.set_yticks(ticks)
  ax3.set_ylabel('S3', **yprops)
  
  
  ax4 = fig.add_axes([0.1, 0.1, 0.8, 0.2], **axprops)
  ax4.plot(t, s4)
  ax4.yaxis.tick_left()
  lo, hi =  ax4.get_ylim()
  ticks = arange(lo, hi+(hi-lo)/4, (hi-lo)/4)
  ticks = append(ticks,hi+(hi-lo)/4)
  print("S4 ticks: %s"%ticks)
  ax4.set_yticks(ticks)
  ax4.set_ylabel('S4', **yprops)
  
  
  # turn off x ticklabels for all but the lower axes
  for ax in ax1, ax2, ax3: setp(ax.get_xticklabels(), visible=False)

  show()

def slider():
    
   close('all')
   matplotlib.interactive(False)
    
   ax = subplot(111)
   subplots_adjust(left=0.25, bottom=0.25)
   t = arange(0.0, 1.0, 0.001)
   a0 = 5
   f0 = 3
   s = a0*sin(2*pi*f0*t)
   l, = plot(t,s, lw=2, color='red')
   axis([0, 1, -10, 10])
   
   axcolor = 'lightgoldenrodyellow'
   axfreq = axes([0.25, 0.1, 0.65, 0.03], axisbg=axcolor)
   axamp  = axes([0.25, 0.15, 0.65, 0.03], axisbg=axcolor)
   
   sfreq = Slider(axfreq, 'Freq', 0.1, 30.0, valinit=f0)
   samp = Slider(axamp, 'Amp', 0.1, 10.0, valinit=a0)
   
   def update(val):
       amp = samp.val
       freq = sfreq.val
       l.set_ydata(amp*sin(2*pi*freq*t))
       draw()
   sfreq.on_changed(update)
   samp.on_changed(update)
   
   resetax = axes([0.8, 0.025, 0.1, 0.04])
   button = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')
   def reset(event):
       sfreq.reset()
       samp.reset()
   button.on_clicked(reset)
   
   rax = axes([0.025, 0.5, 0.15, 0.15], axisbg=axcolor)
   radio = RadioButtons(rax, ('red', 'blue', 'green'), active=0)
   def colorfunc(label):
       l.set_color(label)
       draw()
   radio.on_clicked(colorfunc)
   
   show()


if sys.argv[1] == 'plot':
   plotFunc()
   
elif sys.argv[1] == 'pie':
   pieFunc()

elif sys.argv[1] == '2plot':
   Plot2Func()

elif sys.argv[1] == 'hist':
   histFunc()

elif sys.argv[1] == 'scatter':
   scatterFunc()

elif sys.argv[1] == 'polar':
   polarFunc()

elif sys.argv[1] == 'contour':
   contourPlotFunc() 

elif sys.argv[1] == 'color':
   colorPlotFunc() 
   #colorPlot2()

elif sys.argv[1] == 'log':
   logPlots()

elif sys.argv[1] == 'bar':
   barPlots()
   
elif sys.argv[1] == 'slider':
   slider()
   
elif sys.argv[1] == 'test111':
   test111()

elif sys.argv[1] == 'mux':   
   multiAxes()



