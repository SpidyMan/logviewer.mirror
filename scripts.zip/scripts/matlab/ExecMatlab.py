if RestrictedMode: 
   print("""
ERROR: ExecMatlab cannot run under restricted mode.
Go to the 'Configure' tab, select 'Yes' for 'Disable Restricted Mode' and click on the 'Update' button.
You'll have to restart WinFOF for this change to take affect.
""")

else:  
  import os
  try: 
    if "mlabwrap" in sys.modules:
       # mlabraw.close(mlabwrap.mlab._session)
       #del sys.modules['mlabraw']
       #del sys.modules['mlabwrap']    
       reload(mlabwrap)
       reload(mlabraw)
    import mlabwrap #from mlabwrap1 import mlab
    import mlabraw
    
  except: 
    print("""
  
  =========================================================
  Error: "Matlab Wrapper Import Failed!!!
  Make sure that:
  1. You are running WinFOF v3.0 or higher.
  2. Make sure that you have 32-bit Matlab installed. This will not work with 64-bit Matlab installations
  3. The Path variable has been updated to point to you Matlab installation. 
   Control Panel -> Device Manager -> Advanced -> Environment Variables -> 
     If your Matlab installation directory is  C:\Program Files\R2009b then add 'C:\Program Files\R2009b\\bin\win32' to the "Path" variable 
  ==========================================================
  
  """)
    raise
  
  print("Current UserPath: '%s'"%mlabwrap.mlab.userpath())   

  
  def SetMatlabUserPath(pathname):
    if not os.path.isdir(pathname):
       raise Exception("Path does not exist: '%s'" % (pathname))
        
    # Set correct path using  mlab.userpath(r"C:\var\merlin3\scripts") -- ignore the exception)
    try:    mlabwrap.mlab.userpath(pathname)
    except: pass
   
  def ExecMatlabScript(scriptName):
    #mlabraw.eval(mlab._session,"mt2")   # where mt2.m is the name of Matlab script
    print(mlabraw.eval(mlabwrap.mlab._session,scriptName))
  
  
  
  
  
  
  
  
  
  