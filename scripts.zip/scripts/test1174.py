import ctypes
#################################################
#
DEBUG = 0
BYTE = ctypes.c_ubyte
CHAR = ctypes.c_char
LPVOID = ctypes.c_void_p
LPCWSTR = ctypes.c_wchar_p
WORD = ctypes.c_ushort
DWORD = ctypes.c_uint
HANDLE = DWORD

INVALID_HANDLE_VALUE = -1 #0xffffffffL

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
GENERIC_EXECUTE = 0x20000000
GENERIC_ALL = 0x10000000

CREATE_NEW = 1
CREATE_ALWAYS = 2
OPEN_EXISTING = 3
OPEN_ALWAYS = 4
TRUNCATE_EXISTING = 5

def CheckHANDLE(value):
   if value == INVALID_HANDLE_VALUE:
       raise ctypes.WinError()
   return value

def CheckBOOL(value):
   if not value:
       raise ctypes.WinError()
   return value

class DCB(ctypes.Structure):
   FLAG_BINARY = 0x1
   FLAG_PARITY = 0x2
   FLAG_OUTXCTSFLOW = 0x4
   FLAG_OUTXDSRFLOW = 0x8
   MASK_DTRCONTROL = 0x30
   DTR_CONTROL_ENABLE = 0x10
   FLAG_DSRSENSITIVITY = 0x40
   FLAG_TXCONTINUEONXOFF = 0x80
   FLAG_OUTX = 0x100
   FLAG_INX = 0x200
   FLAG_ERROR_CHAR = 0x400
   FLAG_NULL = 0x800
   MASK_RTS_CONTROL = 0x3000
   RTS_CONTROL_ENABLE = 0x1000

   NOPARITY = 0
   ODDPARITY = 1
   EVENPARITY = 2
   MARKPARITY = 3
   SPACEPARITY = 4

   ONESTOPBIT = 0
   ONE5STOPBITS = 1
   TWOSTOPBITS = 2

   _fields_ = [
       ('DCBlength', DWORD),
       ('BaudRate', DWORD),
       ('flags', DWORD),
       ('wReserved', WORD),
       ('XonLim', WORD),
       ('XoffLim', WORD),
       ('ByteSize', BYTE),
       ('Parity', BYTE),
       ('StopBits', BYTE), # 0=1, 1=1.5, 2=2
       ('XonChar', CHAR),
       ('XoffChar', CHAR),
       ('ErrorChar', CHAR),
       ('EofChar', CHAR),
       ('EvtChar', CHAR),
       ('wReserved1', WORD),
       ]

   def __init__(self):
       ctypes.Structure.__init__(self)
       self.DCBlength = ctypes.sizeof(self)

MAXDWORD = 0xffffffff

class COMMTIMEOUTS(ctypes.Structure):
   _fields_ = [
       ('ReadIntervalTimeout', DWORD),
       ('ReadTotalTimeoutMultiplier', DWORD),
       ('ReadTotalTimeoutConstant', DWORD),
       ('WriteTotalTimeoutMultiplier', DWORD),
       ('WriteTotalTimeoutConstant', DWORD),
       ]

SETXOFF = 1
SETXON = 2
SETRTS = 3
CLRRTS = 4
SETDTR = 5
CLRDTR = 6
SETBREAK = 8
CLRBREAK = 9

kernel32 = ctypes.windll.kernel32

CreateFileW = kernel32.CreateFileW
# TODO: support SECURITY_ATTRIBUTES
CreateFileW.argtypes = [ LPCWSTR, DWORD, DWORD, LPVOID, DWORD, DWORD, HANDLE ]
CreateFileW.restype = CheckHANDLE

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [ HANDLE ]
CloseHandle.restype = CheckBOOL

ReadFile = kernel32.ReadFile
# TODO: support OVERLAPPED
ReadFile.argtypes = [ HANDLE, LPVOID, DWORD, ctypes.POINTER(DWORD), LPVOID ]
ReadFile.restype = CheckBOOL

WriteFile = kernel32.WriteFile
# TODO: support OVERLAPPED
WriteFile.argtypes = [ HANDLE, LPVOID, DWORD, ctypes.POINTER(DWORD), LPVOID ]
WriteFile.restype = CheckBOOL

GetCommState = kernel32.GetCommState
GetCommState.argtypes = [ HANDLE, ctypes.POINTER(DCB) ]
GetCommState.restype = CheckBOOL

SetCommState = kernel32.SetCommState
SetCommState.argtypes = [ HANDLE, ctypes.POINTER(DCB) ]
SetCommState.restype = CheckBOOL

GetCommTimeouts = kernel32.GetCommTimeouts
GetCommTimeouts.argtypes = [ HANDLE, ctypes.POINTER(COMMTIMEOUTS) ]
GetCommTimeouts.restype = CheckBOOL

SetCommTimeouts = kernel32.SetCommTimeouts
SetCommTimeouts.argtypes = [ HANDLE, ctypes.POINTER(COMMTIMEOUTS) ]
SetCommTimeouts.restype = CheckBOOL

SetupComm = kernel32.SetupComm
SetupComm.argtypes = [ HANDLE, DWORD, DWORD ]
SetupComm.restype = CheckBOOL

EscapeCommFunction = kernel32.EscapeCommFunction
EscapeCommFunction.argtypes = [ HANDLE, DWORD ]
EscapeCommFunction.restype = CheckBOOL

#################################################


class SerialPort(object):
   def __init__(self, name):
       if not name.startswith('\\\\.\\'):
           name = '\\\\.\\' + name
       self.name = name
       self.handle=None
       self.handle = CreateFileW(name, GENERIC_READ | GENERIC_WRITE, 0, None, OPEN_EXISTING, 0, 0)

   def close(self):
       if self.handle: CloseHandle(self.handle)
       self.handle = None

   def __del__(self):
       self.close()

   def read(self, n):
       dwRead = DWORD(0)
       buf = ctypes.create_string_buffer(n)
       ReadFile(self.handle, buf, n, ctypes.byref(dwRead), None)
       if DEBUG: print(" R<%s> "%buf.value, end=' ')
       return buf.raw[:dwRead.value]

   def write(self, data):
       dwWritten = DWORD(0)
       WriteFile(self.handle, data, len(data), ctypes.byref(dwWritten), None)
       if DEBUG: print(" W<%d> "% dwWritten.value, end=' ') 
       assert dwWritten.value == len(data)

   def Setup(self, baud=9600, bits=8, parity=None, non_blocking=False):
       cto = COMMTIMEOUTS()
       if non_blocking:
           cto.ReadIntervalTimeout = MAXDWORD
       cto.ReadTotalTimeoutConstant = 30
       cto.ReadTotalTimeoutMultiplier = 10
       cto.WriteTotalTimeoutMultiplier = 10
       #cto.WriteTotalTimeoutConstant = 500
       SetCommTimeouts(self.handle, ctypes.byref(cto))
       SetupComm(self.handle, 4096, 4096)
       dcb = DCB()
       GetCommState(self.handle, ctypes.byref(dcb))
       dcb.BaudRate = baud
       dcb.flags = DCB.FLAG_BINARY
       #dcb.flags = DCB.FLAG_BINARY | DCB.DTR_CONTROL_ENABLE | DCB.RTS_CONTROL_ENABLE | DCB.FLAG_TXCONTINUEONXOFF
       dcb.ByteSize = bits
       if parity is None:
           parity = DCB.NOPARITY
       dcb.Parity = parity
       dcb.StopBits = DCB.ONESTOPBIT
       dcb.XonLim = 0
       dcb.XoffLim = 0
       SetCommState(self.handle, ctypes.byref(dcb))
       self.SetDTR()

   def SetDTR(self):
       EscapeCommFunction(self.handle, SETDTR)

###################################################################3

def testSerial(portList):
   if not isinstance(portList, (tuple,list)):
      raise FOFParameterError("testSerial: Pass in a list/tuple of COM ports.")
   
   if [port for port in portList if not (isinstance(port,int) and (0<port<256))]: 
      raise FOFParameterError("testSerial: All ports should be integers between 0 and 255.")
   
   inpBuffer = "Hello World"
          
   for port in portList:
     deviceName = "COM%d"%port
     print("Testing Device: %s  ....   "%deviceName, end=' ')
     
     try:
         obj = SerialPort(deviceName)    # Open COM Port
     except: 
         print("FAILED (Open Failed)")
         continue 
         
     obj.Setup(non_blocking=True)    # Set Baud Rate and reads as non blocking
     obj.write(inpBuffer)            # Write Data
     buf = obj.read(len(inpBuffer))  # Read Data
     obj.close()                     # Close COM Port
     
     if buf == inpBuffer: print("PASSED")
     else: print("FAILED (Write/Read mismatch)")
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   

   