import time

GENERIC_READ  = 0x80000000
GENERIC_WRITE = 0x40000000
OPEN_EXISTING = 0x3

def SixPackDriveOn(levelFor5V=5000,levelFor12V=12000,pauseTime=30,levelFor3V=3000,controlSerialIO=0,**kwargs):  
  #  Look for the parameters that ask us to send '\x1b' escape characters before and after applying drive power.
  preEscapes  = kwargs.get("preEscapes")
  postEscapes = kwargs.get("postEscapes")  
    
  try:
     SixPackIndex
     if not isinstance(SixPackIndex, type(1)): raise NameError      
  except NameError:
     print("Error: SixPackIndex (integer value) should be defined before using this function")
     return 
  try:
     SixPackBasePort
     if not isinstance(SixPackBasePort, type(1)): raise NameError     
  except NameError:
     print("Error: SixPackBasePort (integer value) should be defined before using this function")
     return 
     
  # Send a bunch of escapes just before we turn on drive power
  if isinstance(preEscapes,int) and preEscapes > 0:
     Send(preEscapes*'\x1b')
  
  # Open Six Pack Base-Port
  for i in range(10):
     hnd = ctypes.windll.kernel32.CreateFileW("\\\\.\\COM%d"%SixPackBasePort,GENERIC_READ | GENERIC_WRITE, 0,None,OPEN_EXISTING,0,None)
     if hnd > 0: break
     ScriptPause(0.25)
  else:    
     print("Error: Unable to open Com Port: COM%d"%SixPackBasePort)
     return
  
  cbWritten  = ctypes.c_ulong(0)
  dataPacket = "P%d\r"%SixPackIndex
  # Write data and close serial-port
  ctypes.windll.kernel32.WriteFile(hnd, ctypes.c_char_p(dataPacket),len(dataPacket), ctypes.byref(cbWritten), None);ctypes.windll.kernel32.CloseHandle(hnd)
  
  # Send a bunch of escapes just after we turn on drive power
  if isinstance(postEscapes,int) and postEscapes > 0:
     Send(postEscapes*'\x1b')
   
  print("%s: DriveOn: pause --> %s seconds"%(time.asctime(), pauseTime,))
  ScriptPause(pauseTime)


def SixPackDriveOff(pauseTime=30,controlSerialIO=0):
  try:
     SixPackIndex
     if not isinstance(SixPackIndex, type(1)): raise NameError      
  except NameError:
     print("Error: SixPackIndex (integer value) should be defined before using this function")
     return 
  try:
     SixPackBasePort
     if not isinstance(SixPackBasePort, type(1)): raise NameError     
  except NameError:
     print("Error: SixPackBasePort (integer value) should be defined before using this function")
     return 
  
  # Open Six Pack Base-Port
  for i in range(10):
     hnd = ctypes.windll.kernel32.CreateFileW("\\\\.\\COM%d"%SixPackBasePort,GENERIC_READ | GENERIC_WRITE, 0,None,OPEN_EXISTING,0,None)
     if hnd > 0: break
     ScriptPause(0.25)
  else:    
     print("Error: Unable to open Com Port: COM%d"%SixPackBasePort)
     return
  
  cbWritten  = ctypes.c_ulong(0)
  dataPacket = "O%d\r"%SixPackIndex
  # Write data and close serial-port
  ctypes.windll.kernel32.WriteFile(hnd, ctypes.c_char_p(dataPacket),len(dataPacket), ctypes.byref(cbWritten), None);ctypes.windll.kernel32.CloseHandle(hnd)
  
  print("%s: DriveOff: pause --> %s seconds"%(time.asctime(), pauseTime,))
  ScriptPause(pauseTime)
####################################################################
####################################################################

DriveOn  = SixPackDriveOn
DriveOff = SixPackDriveOff
#RimOn    = SixPackDriveOn
#RimOff   = SixPackDriveOff
####################################################################
#     Request Handler for Drive On and Drive Off request           #
####################################################################
def processDriveOnOff(buf, *args, **kargs):
  requestKey = buf[0]
  # code 6 typically requests a block of data from the download file;  get_data_file()
  if requestKey == 13:
      DriveOff()
  elif requestKey == 14:
      DriveOn() 
  else:
    str = "Unsupported requestKey in processDriveOnOff ==>",requestKey
    raise FOFParameterError(str)    
    
RegisterResultsCallback(processDriveOnOff, [13,14], 0)