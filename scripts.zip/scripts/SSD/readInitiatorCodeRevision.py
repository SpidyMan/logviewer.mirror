
UseESlip(1)
SetBaudRate(38400)

FOFexecfile(('', 'scriptfuncs.py'))
#FOFexecfile(('', 'hyperpower.py'))
#DriveOn(pauseTime=5)         
  
FOFexecfile(('ssd','si_testparameters.py'))  
FOFexecfile(('ssd','HardReset.py'))

st(535,prm_535_ReportInitiatorCodeRevision, timeout=30)  # Read Initiator Code Rev.

