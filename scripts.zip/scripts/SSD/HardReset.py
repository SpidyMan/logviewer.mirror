import time

FOFexecfile(('ssd','si_testparameters.py'))

UseESlip(1)
SetBaudRate(38400)

#timeOutInSeconds = 15
timeOutInSeconds = 4       # ssd
si_debug = 1
if( si_debug ) :
   timeOutInSeconds = 10 * 60

st(535,prm_535_SataHardReset,timeout=timeOutInSeconds)  # Hard Reset    
st(535,prm_535_ReportTransferRate)
