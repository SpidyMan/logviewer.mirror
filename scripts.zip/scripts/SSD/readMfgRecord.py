
UseESlip(1)
SetBaudRate(38400)

FOFexecfile(('', 'scriptfuncs.py'))
#FOFexecfile(('', 'hyperpower.py'))
#DriveOn(pauseTime=5)

FOFexecfile(('ssd','si_testparameters.py'))  
FOFexecfile(('ssd','HardReset.py'))

st(642, prm_642_Vela_Unlock, timeout=30)

st(642, prm_642_Vela_Read_Mfg_Record, timeout=30)

full_defined_mfg_record = 0
if full_defined_mfg_record:
   st(508,
      CTRL_WORD1          = (p508_cw1_tf_read_and_display_read_buffer),
      BYTE_OFFSET         = (0x0000,0x0000),
      BUFFER_LENGTH       = (0x0001,0x0000),
   timeout=300)


st(642, prm_642_Vela_Lock, timeout=30)


