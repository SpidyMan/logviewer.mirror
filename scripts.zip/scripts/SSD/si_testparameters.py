def ConvertNumberToTuple( value, numberOf16BitWords ):
   wordList = []                             # Create empty list
   for i in range( numberOf16BitWords ):
      wordList.append( value & 0xffff )      # Append each 16 bit word
      value >>= 16
   if( numberOf16BitWords > 1 ):
      wordList.reverse()                     # Need most significant words first
   return tuple( wordList ) 

def U16T( value ):
   return ConvertNumberToTuple( value, 1 )

def U32T( value ):
   return ConvertNumberToTuple( value, 2 )

def U64T( value ):
   return ConvertNumberToTuple( value, 4 )


# print U16T( 12816 )                   # 3210
# print U32T( 1985229328 )              # 7654 3210
# print U64T( 0xFEDCBA9876543210 )      # FEDC BA98 7654 3210





# ==================================================================
# start 504
# ==================================================================
prm_504_TASK_FILE_REGISTERS = {
   'TEST_FUNCTION'     : (0x0000)
}

# ====START_INITIATOR_SOFTWARE_DEBUG_ONLY=====
prm_504_SOFTWARE_DEBUG_SI_REGISTER_DUMP = {
   'TEST_FUNCTION'     : (0x0000),
   'DEBUG_FLAG'        : (0x8000),
}
# ====END_INITIATOR_SOFTWARE_DEBUG_ONLY=====
# ==================================================================
# stop 504
# ==================================================================


# ==================================================================
# start 506
# ==================================================================
prm_506_IO_COMMAND_TIMEOUT_100_mS = {
   'COMMAND_TIMEOUT_MS'     : (100)
}

prm_506_IO_COMMAND_TIMEOUT_500_mS = {
   'COMMAND_TIMEOUT_MS'     : (500)
}

prm_506_IO_COMMAND_TIMEOUT_1_S = {
   'COMMAND_TIMEOUT_MS'     : (1000)
}

prm_506_IO_COMMAND_TIMEOUT_10_S = {
   'COMMAND_TIMEOUT_SECONDS' : (10)
}

prm_506_IO_COMMAND_TIMEOUT_20_S = {
   'COMMAND_TIMEOUT'         : (0,20)
}

prm_506_BUFFER_LENGTH_00000100 = {
   'BUFFER_LENGTH'           : (0x0000,0x100)
}

prm_506_BUFFER_LENGTH_00010100 = {
   'BUFFER_LENGTH'           : (0x0001,0x100)
}

prm_506_TEST_TIME_510_10_SECONDS = {
   'TEST_RUN_TIME'           : (40)
}

prm_506_CTRL_WORD1_8000 = {
   'CTRL_WORD1'              : (0x8000)
}

prm_506_CTRL_WORD1_0001 = {
   'CTRL_WORD1'              : (0x0001)
}

prm_506_CTRL_WORD1_0002 = {
   'CTRL_WORD1'              : (0x0002)
}

prm_506_IO_COMMAND_TIMEOUT_ILLEGAL = {
   'COMMAND_TIMEOUT_MS'     : (500),
   'COMMAND_TIMEOUT_SECONDS' : (10)
}
# ==================================================================
# stop 506
# ==================================================================

# ==================================================================
# start 507
# ==================================================================
p507_drive_active_led_enable                      = 0x2
p507_drive_active_led_off                         = 0x0
prm_507_SWITCH_SERIAL_PORT_TO_DRIVE = {
   'ACTIVE_LED_ON' : (p507_drive_active_led_enable | p507_drive_active_led_off)
}
# ==================================================================
# stop 507
# ==================================================================

# ==================================================================
# start 508
# ==================================================================
p508_cw1_enable_drive_var_mask                    = 0x8000
p508_cw1_report_buffer_data_as_binary_mask        = 0x4000
p508_cw1_function_mask                            = 0x000f

p508_cw1_tf_write_pattern_to_write_buffer         =  0    # 0x0
p508_cw1_tf_write_pattern_to_read_buffer          =  1    # 0x1
p508_cw1_tf_write_parameters_to_write_buffer      =  2    # 0x2
p508_cw1_tf_write_parameters_to_read_buffer       =  3    # 0x3
p508_cw1_tf_read_and_display_write_buffer         =  4    # 0x4
p508_cw1_tf_read_and_display_read_buffer          =  5    # 0x5
p508_cw1_tf_copy_read_buffer_to_write_buffer      =  6    # 0x6
p508_cw1_tf_copy_write_buffer_to_read_buffer      =  7    # 0x7
p508_cw1_tf_compare_write_buffer_to_read_buffer   =  8    # 0x8
p508_cw1_tf_check_range_16bit_read_buffer         =  9    # 0x9
p508_cw1_tf_write_block_data_file_to_write_buffer = 10    # 0xa
p508_cw1_tf_write_block_data_file_to_read_buffer  = 11    # 0xb
p508_cw1_tf_write_1_64bit_pattern_to_write_buffer = 12    # 0xc
p508_cw1_tf_write_1_64bit_pattern_to_read_buffer  = 13    # 0xd
p508_cw1_tf_write_write_buffer_to_file            = 14    # 0xe
p508_cw1_tf_write_read_buffer_to_file             = 15    # 0xf

p508_pattern_type_fixed       = 0
p508_pattern_type_random      = 1
p508_pattern_type_incremental = 2

prm_508_PARAM_CHECK_WILL_FAIL = {
   'CTRL_WORD1'          : (p508_cw1_tf_write_pattern_to_write_buffer),
   'BYTE_OFFSET'         : (0x1234,0x5678),
   'BUFFER_LENGTH'       : (0x0001,0x0000),
   'BYTE_PATTERN_LENGTH' : (8),
   'RANDOM_SEED'         : (0x3145),
   'DATA_PATTERN0'       : (0x7654,0x4AB4),
   'DATA_PATTERN1'       : (0x8899,0xAACC),
   'BIT_PATTERN_LENGTH'  : (4),
   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
   'DEBUG_FLAG'          : (0x8000),
}

#prm_508_WRITE_FIXED_PATTERN_TO_WRITE_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'DATA_PATTERN0'       : (0x0123,0x4567),
#   'DATA_PATTERN1'       : (0x89ab,0xcdef),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_WRITE_FIXED_PATTERN_TO_WRITE_BUFFER_0100_0200 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0100),
#   'DATA_PATTERN0'       : (0x3333,0x4444),
#   'DATA_PATTERN1'       : (0x5555,0x6666),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_WRITE_FIXED_PATTERN_TO_READ_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'DATA_PATTERN0'       : (0x0123,0x4567),
#   'DATA_PATTERN1'       : (0x89ab,0xcdef),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_WRITE_FIXED_PATTERN_TO_READ_BUFFER_0200_0300 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0200),
#   'DATA_PATTERN0'       : (0xDDDD,0xCCCC),
#   'DATA_PATTERN1'       : (0xBBBB,0xAAAA),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_DISPLAY_WRITE_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#}

#prm_508_DISPLAY_WRITE_BUFFER_0100_0200 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0100),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#}

#prm_508_DISPLAY_READ_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#}

#prm_508_DISPLAY_READ_BUFFER_0100_0200 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0100),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#}

prm_508_WRITE_FIXED_FFFFFFFF_PATTERN_TO_READ_BUFFER_0000_2000 = {
   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_read_buffer),
   'BYTE_OFFSET'         : (0x0000,0x0000),
   'DATA_PATTERN0'       : (0xffff,0xffff),
   'BUFFER_LENGTH'       : (0x0000,0x2000),
   'BYTE_PATTERN_LENGTH' : (4),
   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
}

prm_508_WRITE_FIXED_FFFFFFFF_PATTERN_TO_WRITE_BUFFER_0000_2000 = {
   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_write_buffer),
   'BYTE_OFFSET'         : (0x0000,0x0000),
   'DATA_PATTERN0'       : (0xffff,0xffff),
   'BUFFER_LENGTH'       : (0x0000,0x2000),
   'BYTE_PATTERN_LENGTH' : (4),
   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
}

def DisplayReadWriteBuffer( cmd508, address, length ):
   address_hw = (address >> 16) & 0xffff
   address_lw = address         & 0xffff

   length_hw = (length >> 16) & 0xffff
   length_lw = length         & 0xffff
   st(508, CTRL_WORD1            = cmd508,
           BYTE_OFFSET           = (address_hw,address_lw),
           BUFFER_LENGTH         = (length_hw,length_lw),
           timeout = 10)

def DisplayReadBuffer( address, length ):
   DisplayReadWriteBuffer( p508_cw1_tf_read_and_display_read_buffer, address, length )

def DisplayWriteBuffer( address, length ):
   DisplayReadWriteBuffer( p508_cw1_tf_read_and_display_write_buffer, address, length )


def DisplayReadBufferBase( length ):
   DisplayReadBuffer( 0, length )

def DisplayWriteBufferBase( length ):
   DisplayWriteBuffer( 0, length )

def DisplayReadBufferFirstSector():
   DisplayReadBufferBase( 0x200 )

def DisplayWriteBufferFirstSector():
   DisplayWriteBufferBase( 0x200 )





def FillReadWriteBuffer( cmd508, address, length, data ):
   address_hw = (address >> 16) & 0xffff
   address_lw = address         & 0xffff

   length_hw  = (length >> 16)  & 0xffff
   length_lw  = length          & 0xffff

   data_hw    = (data >> 16)    & 0xffff
   data_lw    = data            & 0xffff

   st(508, CTRL_WORD1            = cmd508,
           BYTE_OFFSET           = (address_hw,address_lw),
           BUFFER_LENGTH         = (length_hw,length_lw),
           DATA_PATTERN0         = (data_hw,data_lw),
           BYTE_PATTERN_LENGTH   = (4),
           PATTERN_TYPE          = (0),
           timeout = 10)

def FillReadBuffer( address, length, data ):
   FillReadWriteBuffer( p508_cw1_tf_write_pattern_to_read_buffer, address, length, data )

def FillWriteBuffer( address, length, data ):
   FillReadWriteBuffer( p508_cw1_tf_write_pattern_to_write_buffer, address, length, data )


def FillReadBufferBase( length, data ):
   FillReadBuffer( 0, length, data )

def FillWriteBufferBase( length, data ):
   FillWriteBuffer( 0, length, data )


def FillReadBufferFirstSector( data ):
   FillReadBuffer( 0, 512, data )

def FillWriteBufferFirstSector( data ):
   FillWriteBuffer( 0, 512, data )

def FillReadBufferFirstSector_FFFFFFFF():
   FillReadBufferFirstSector( 0xffffffff )


# ==================================================================
# stop 508
# ==================================================================


# ==================================================================
# start 510
# ==================================================================
p510_write        = 0x20
p510_read         = 0x10
p510_write_read   = 0x00
p510_fixed        = 0x80
p510_incrementing = 0x02

prm_510_W_FIXED_ZEROS_PCBA_ONLY = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x100),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_FIXED_ZEROS_PCBA_ONLY = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x100),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_FIXED_ZEROS_PCBA_ONLY_VELA = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x0010),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_ZEROS_PCBA_ONLY = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x80),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_FIXED_ZEROS_FP_500G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x3A38,0x602F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_FIXED_ZEROS_FP_500G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x3A38,0x602F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_ZEROS_FP_500G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x3A38,0x602F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_WR_FIXED_SS_1001_00000000 = {
   'STARTING_LBA'            : (0x0000,0x0000,0x0000,0x0000),
   'TOTAL_BLKS_TO_XFR64'     : (0x0000,0x0000,0x0000,0x0001),
   'DATA_PATTERN0'           : (0x0000,0x1001),
   'BLKS_PER_XFR'            : (0x1),
   'CTRL_WORD1'              : (p510_write_read),
   'CTRL_WORD2'              : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN'   : (1),
}

prm_510_WR_INCREMENTING_SS_00000000 = {
   'STARTING_LBA'            : (0x0000,0x0000,0x0000,0x0000),
   'TOTAL_BLKS_TO_XFR64'     : (0x0000,0x0000,0x0000,0x0001),
   'DATA_PATTERN0'           : (0x0000,0x0000),
   'BLKS_PER_XFR'            : (0x1),
   'CTRL_WORD1'              : (p510_write_read),
   'CTRL_WORD2'              : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN'   : (1),
}

prm_510_W_INCREMENTING_SS_00000000 = {
   'STARTING_LBA'            : (0x0000,0x0000,0x0000,0x0000),
   'TOTAL_BLKS_TO_XFR64'     : (0x0000,0x0000,0x0000,0x0001),
   'DATA_PATTERN0'           : (0x0000,0x0000),
   'BLKS_PER_XFR'            : (0x1),
   'CTRL_WORD1'              : (p510_write),
   'CTRL_WORD2'              : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN'   : (1),
}

prm_510_R_INCREMENTING_SS_00000000 = {
   'STARTING_LBA'            : (0x0000,0x0000,0x0000,0x0000),
   'TOTAL_BLKS_TO_XFR64'     : (0x0000,0x0000,0x0000,0x0001),
   'DATA_PATTERN0'           : (0x0000,0x0000),
   'BLKS_PER_XFR'            : (0x1),
   'CTRL_WORD1'              : (p510_read),
   'CTRL_WORD2'              : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN'   : (1),
}

# cannot write a single sector at lba 0, using max lba,
# because max_lba == 0, has initiator code get max sector from drive

prm_510_WR_FIXED_SS_0001_00001000 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0001),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0001),
   'DATA_PATTERN0'         : (0x0000,0x1000),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_SS_0008_00081008 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0008),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0008),
   'DATA_PATTERN0'         : (0x0008,0x1008),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_SS_0018_00181018 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0018),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0018),
   'DATA_PATTERN0'         : (0x0018,0x1018),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_SS_0038_00381038 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0038),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0038),
   'DATA_PATTERN0'         : (0x0038,0x1038),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_WR_FIXED_SS_0041_07654321 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0041),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0041),
   'DATA_PATTERN0'         : (0x0765,0x4321),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_SS_0100_01234567 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0100),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0100),
   'DATA_PATTERN0'         : (0x0123,0x4567),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_SS_0120_01200122 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0120),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0120),
   'DATA_PATTERN0'         : (0x0120,0x0122),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_WR_FIXED_SS_01F0_01020304 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x01F0),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01F0),
   'DATA_PATTERN0'         : (0x0102,0x0304),
   'BLKS_PER_XFR'          : (0x1),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_FIXED_SS_UNIQUE_LBA = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0304,0x0506),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0304,0xFFFF),
   'DATA_PATTERN0'         : (0x0102,0x0304),
   'BLKS_PER_XFR'          : (0x0102),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


#--------------------                                       # PCBA Only
prm_510_W_INCREMENTING_PCBA_ONLY = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0001,0x0001),
   'BLKS_PER_XFR'          : (0x40),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_INCREMENTING_PCBA_ONLY_VELA = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0001,0x0001),
   'BLKS_PER_XFR'          : (0x10),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_R_INCREMENTING_PCBA_ONLY = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0001,0x0001),
   'BLKS_PER_XFR'          : (0x40),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_INCREMENTING_PCBA_ONLY_VELA = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0001,0x0001),
   'BLKS_PER_XFR'          : (0x10),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_PCBA_ONLY = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0001,0x0001),
   'BLKS_PER_XFR'          : (0x40),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_PCBA_ONLY_VELA = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x01FF),
   'DATA_PATTERN0'         : (0x0001,0x0001),
   'BLKS_PER_XFR'          : (0x10),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_INCREMENTING_FP_1G = {                           # FP 1 G
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x001D,0xCDFF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x1000),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_INCREMENTING_FP_1G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x001D,0xCDFF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x1000),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_FP_1G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x001D,0xCDFF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x0010),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_20000 = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x001F,0xFFFF),
   'DATA_PATTERN0'         : (0x1111,0x1111),
   'BLKS_PER_XFR'          : (0x1000),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_INCREMENTING_FP_32G = {                           # FP 32 G
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x03B9,0xBFFF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x0010),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_INCREMENTING_FP_32G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x03B9,0xBFFF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x0010),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_FP_32G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x03B9,0xBFFF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x0010),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_ZEROS_FP_50G = {                              
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x05D2,0x1DBF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xEFFF),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_01234567_FP_50G = {                              
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x05D2,0x1DBF),
   'DATA_PATTERN0'         : (0x0123,0x4567),
   'BLKS_PER_XFR'          : (0xEFFF),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_01A55AA5_FP_50G = {                              
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x05D2,0x1DBF),
   'DATA_PATTERN0'         : (0x0A5,0x5AA5),
   'BLKS_PER_XFR'          : (0xEFFF),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}
prm_510_R_01FFFFFF_FP_50G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000), 
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x05D2,0x1DBF),
   'DATA_PATTERN0'         : (0x01FF,0xFFFF),
   'BLKS_PER_XFR'          : (0xEFFF),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_ZEROS_FP_100G = {                                # FP Vela 100 G
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0BA4,0x3B77),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x8000),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_fixed),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_INCREMENTING_FP_100G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0BA4,0x3B77),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x8000),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_R_INCREMENTING_FP_100G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0BA4,0x3B77),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x8000),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_FP_100G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0BA4,0x3B77),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0x1000),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_W_INCREMENTING_FP_250G = {                          # FP 250 G
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x1D1C,0x596F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_INCREMENTING_FP_250G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x1D1C,0x596F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_WR_INCREMENTING_FP_250G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x1D1C,0x596F),
   'DATA_PATTERN0'         : (0x0250,0xBEEF),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_INCREMENTING_FP_320G = {                            # FP 320 G
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x2542,0xEAAF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_INCREMENTING_FP_320G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x2542,0xEAAF),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_FP_320G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x2542,0xEAAF),
   'DATA_PATTERN0'         : (0x0320,0xBEEF),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_W_INCREMENTING_FP_500G = {                            # FP 500 G
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x3A38,0x602F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_R_INCREMENTING_FP_500G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x3A38,0x602F),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_510_WR_INCREMENTING_FP_500G = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x3A38,0x602F),
   'DATA_PATTERN0'         : (0x0500,0xBEEF),
   'BLKS_PER_XFR'          : (0xffff),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}


prm_510_WR_INCREMENTING_FP = {
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0000),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'BLKS_PER_XFR'          : (0xE000),
   'CTRL_WORD1'            : (p510_write_read),
   'CTRL_WORD2'            : (p510_incrementing),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

# ==================================================================
# stop 510
# ==================================================================


# ==================================================================
# start 514
# ==================================================================
p514_cw1_report_identify_device_data           = 0x1
p514_cw1_report_identify_device_data_range     = 0x2
p514_cw1_report_identify_device_data_driveVars = 0x8001

def Test514_Cw2_IdentifyRange( starting_word, ending_word ):
   starting_word = starting_word & 0xff
   ending_word = (ending_word & 0xff) << 8
   return ( ending_word | starting_word )

prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA = {
  "CTRL_WORD1"           : (p514_cw1_report_identify_device_data),
}

prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA_DRIVEVARS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_driveVars ),
}

prm_514_REPORT_MAX_USER_48BIT_LBAS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
}

prm_514_REPORT_SN = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange(  10,  19 )),
}

prm_514_REPORT_WWN = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 108, 111 )),
}

prm_514_REPORT_MODEL_NUMBER = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 27, 46 )),
}

# ==================================================================
# stop 514
# ==================================================================


# ==================================================================
# start 533
# ==================================================================
prm_533_6GB = {
   "FC_SAS_TRANSFER_RATE" : (0x0006),
}

prm_533_3GB = {
   "FC_SAS_TRANSFER_RATE" : (0x0003),
}

prm_533_1_5GB = {
   "FC_SAS_TRANSFER_RATE" : (0x0001),
}

prm_533_6GB_with_power_cycle = {             # START - Has not been verified
   "FC_SAS_TRANSFER_RATE" : (0x0006),
   "POWER_OFF_TIME"       : (30),            # seconds
}

prm_533_3GB_with_power_cycle = {
   "FC_SAS_TRANSFER_RATE" : (0x0003),
   "POWER_OFF_TIME"       : (20),            # seconds
}

prm_533_1_5GB_with_power_cycle = {
   "FC_SAS_TRANSFER_RATE" : (0x0001),
   "POWER_OFF_TIME"       : (15),            # seconds
}

prm_533_6GB_with_power_cycle_zero = {
   "FC_SAS_TRANSFER_RATE" : (0x0006),
   "POWER_OFF_TIME"       : (0),             # 30 seconds
}

prm_533_3GB_with_power_cycle_zero = {
   "FC_SAS_TRANSFER_RATE" : (0x0003),
   "POWER_OFF_TIME"       : (0),             # 30 seconds
}

prm_533_1_5GB_with_power_cycle_zero = {
   "FC_SAS_TRANSFER_RATE" : (0x0001),
   "POWER_OFF_TIME"       : (0),             # 30 seconds
}                                            # END - Has not been verified
# ==================================================================
# stop 533
# ==================================================================

# ==================================================================
# start 535
# ==================================================================
p535_report_initiator_code_version    = 2
p535_report_io_transfer_rate          = 3

p535_modify_host_controller_register  = 6
p535_display_host_controller_register = 7
p535_verify_expected_transfer_rate    = 9

p535_retry_phy_ready_and_hard_reset   = 10
p535_hard_reset                       = 11
p535_soft_reset                       = 12
p535_loop_hard_resets                 = 13
p535_phy_fep                          = 14
p535_phy_fes                          = 15

p535_Banshee_soc_outer_diag_mux       = 90
p535_Banshee_soc_inner_diag_mux       = 91
p535_Banshee_soc_sata_diag_mux        = 92
p535_Banshee_pbm_diag_mux             = 93
p535_Banshee_sata_vhdi_diag_mux       = 95
p535_Banshee_sata_phy_ctl_diag_mux    = 96
p535_Banshee_sata_transport_diag_mux  = 97
p535_Banshee_sata_top_levels_diag_mux = 98
p535_Banshee_sata_si_diag_mux         = 99

p535_ChangeListBasedFileName          = 0x0800
p535_ChangeListBasedFileNameDriveVars = 0x8800

prm_535_ReportInitiatorCodeRevision = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
}

prm_535_ReportInitiatorCodeRevision_DriveVars = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
   "TEST_FUNCTION"        : (0x8000),
}

prm_535_ReportInitiatorChangeListCodeRevision = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
   "TEST_FUNCTION"        : (p535_ChangeListBasedFileName),
}

prm_535_ReportInitiatorChangeListCodeRevision_DriveVars = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
   "TEST_FUNCTION"        : (p535_ChangeListBasedFileNameDriveVars),
}

prm_535_ReportTransferRate = {
   "TEST_OPERATING_MODE"  : (p535_report_io_transfer_rate),
}

prm_535_RetryPhyReadyAndSataHardReset = {
   "TEST_OPERATING_MODE"  : (p535_retry_phy_ready_and_hard_reset),
}

prm_535_SataHardReset = {
   "TEST_OPERATING_MODE"  : (p535_hard_reset),
}

prm_535_SataSoftReset = {
   "TEST_OPERATING_MODE"  : (p535_soft_reset),
}

prm_535_Verify_1_5GB_TransferRate = {
   "FC_SAS_TRANSFER_RATE" : (0x0001),
   "TEST_OPERATING_MODE"  : (p535_verify_expected_transfer_rate),
}

prm_535_Verify_3GB_TransferRate = {
   "FC_SAS_TRANSFER_RATE" : (0x0003),
   "TEST_OPERATING_MODE"  : (p535_verify_expected_transfer_rate),
}

prm_535_Verify_6GB_TransferRate = {
   "FC_SAS_TRANSFER_RATE" : (0x0006),
   "TEST_OPERATING_MODE"  : (p535_verify_expected_transfer_rate),
}

prm_535_Set_Phy_FEP = {
   "TEST_OPERATING_MODE"  : (p535_phy_fep),
}

prm_535_Set_Phy_FES = {
   "TEST_OPERATING_MODE"  : (p535_phy_fes),
}


# ==================================================================
# stop 535
# ==================================================================


# ==================================================================
# start 538
# ==================================================================
p538_CHS_Registers = 0x0000
p538_LBA_Registers = 0x2000
# ==================================================================
# start 538
# ==================================================================



# ==================================================================
# start 550
# ==================================================================
p550_read         = 0x01
p550_write        = 0x02
p550_write_read   = 0x03
p550_fixed        = 0x80
p550_random       = 0x01
p550_incrementing = 0x02

prm_550_W_FIXED_01020304_10 = {
   'WRITE_READ_MODE'       : (p550_write),
   'DATA_PATTERN0'         : (0x0102,0x0304),
   'PATTERN_TYPE'          : (p550_fixed),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0010),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_R_FIXED_01020304_10 = {
   'WRITE_READ_MODE'       : (p550_read),
   'DATA_PATTERN0'         : (0x0102,0x0304),
   'PATTERN_TYPE'          : (p550_fixed),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0010),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_W_FIXED_01020304 = {
   'WRITE_READ_MODE'       : (p550_write),
   'DATA_PATTERN0'         : (0x0102,0x0304),
   'PATTERN_TYPE'          : (p550_fixed),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0001),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_R_FIXED_01020304 = {
   'WRITE_READ_MODE'       : (p550_read),
   'DATA_PATTERN0'         : (0x0102,0x0304),
   'PATTERN_TYPE'          : (p550_fixed),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0001),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_WR_FIXED_01234567_0100 = {
   'WRITE_READ_MODE'       : (p550_write_read),
   'DATA_PATTERN0'         : (0x0123,0x4567),
   'PATTERN_TYPE'          : (p550_fixed),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0100),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_R_FIXED_01234567 = {
   'WRITE_READ_MODE'       : (p550_read),
   'DATA_PATTERN0'         : (0x0123,0x4567),
   'PATTERN_TYPE'          : (p550_fixed),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0001),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_WR_INCREMENTING_ZERO_10 = {
   'WRITE_READ_MODE'       : (p550_write_read),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'PATTERN_TYPE'          : (p550_incrementing),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0010),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_R_INCREMENTING_ZERO = {
   'WRITE_READ_MODE'       : (p550_read),
   'DATA_PATTERN0'         : (0x0000,0x0000),
   'PATTERN_TYPE'          : (p550_incrementing),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0000,0x0001),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_550_WR_INCREMENTING_07777777_10000 = {
   'WRITE_READ_MODE'       : (p550_write_read),
   'DATA_PATTERN0'         : (0x0777,0x7777),
   'PATTERN_TYPE'          : (p550_incrementing),
   'TOTAL_BLKS_TO_XFR64'   : (0x0000,0x0000,0x0001,0x0000),
   'ENABLE_HW_PATTERN_GEN' : (1),
}
# ==================================================================
# stop 550
# ==================================================================

# ==================================================================
# start 597
# ==================================================================
p597_cw1_driveVars                                         = 0x8000
p597_cw1_non_ncq_mode                                      = (1 << 8)
p597_cw1_write                                             = (1 << 4)
p597_cw1_read                                              = (2 << 4)
p597_cw1_write_read                                        = (3 << 4)
p597_cw1_ratio                                             = 2
p597_cw1_random                                            = 1
p597_cw1_sequential                                        = 0

p597_verify_min_iops                                       = (1 << 2)

# ==================================================================
# stop 597
# ==================================================================

prm_597_Iops_Fp_Random_Write_4096 = {
   'CTRL_WORD1'            : (p597_cw1_non_ncq_mode | p597_cw1_write | p597_cw1_random),
   'MINIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0000),
   'RANDOM_SEED'           : (0xA596),
   'LOOP_COUNT'            : (0x0100),
   'MULTIPLIER'            : (0x0001),
   'BLKS_PER_XFR'          : (8),
   'IOPS_LOWER_LIM'        : (10000),
#   'OPERATIONAL_FLAGS'     : (p597_verify_min_iops),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

prm_597_Iops_Fp_Random_Read_4096 = {
   'CTRL_WORD1'            : (p597_cw1_non_ncq_mode | p597_cw1_read | p597_cw1_random),
   'MINIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0x0000),
   'RANDOM_SEED'           : (0xA596),
   'LOOP_COUNT'            : (0x0100),
   'MULTIPLIER'            : (0x0001),
   'BLKS_PER_XFR'          : (8),
   'IOPS_LOWER_LIM'        : (10000),
#   'OPERATIONAL_FLAGS'     : (p597_verify_min_iops),
   'ENABLE_HW_PATTERN_GEN' : (1),
}

# ==================================================================
# start 604
# ==================================================================
prm_604_DUMP_LINK_COUNTER_REGISTERS_AND_RESET = {
   'RESET_OPTION'     : (0x0000)
}

prm_604_RESET_ONLY = {
   'RESET_OPTION'     : (0x0001)
}
# ==================================================================
# stop 604
# ==================================================================




# ==================================================================
# start 638
# ==================================================================
p638_tf_normal_dfb_parameters                              = 0x0000
p638_tf_backward_compatability_parameter                   = 0xffff

p638_cw1_bypass_internal_initializations                   = 0x0010
p638_cw1_dets_command                                      = 0x0008
p638_cw1_use_existing_buffer_space                         = 0x0004
p638_cw1_report_read_data_in_P508_table                    = 0x0002
p638_cw1_suppress_results                                  = 0x0001

prm_638_Unlock = {
   'DFB_WORD_0'      : (0xFFFF),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x9A32),      # Key 0x034F329A
   'DFB_WORD_3'      : (0x4F03),
}

prm_638_Unlock_BypassInitializations = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0xFFFF),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x9A32),      # Key 0x034F329A
   'DFB_WORD_3'      : (0x4F03),
}

prm_638_Lock_BypassInitializations = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0xFFFF),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x9A32),      # Key 0x834F329A
   'DFB_WORD_3'      : (0x4F83),
}

prm_638_SpinDown = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations | p638_cw1_suppress_results),
   'DFB_WORD_0'      : (0x5701),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0000),      # Spin Down
}

prm_638_SpinUp = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations | p638_cw1_suppress_results),
   'DFB_WORD_0'      : (0x5701),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0100),      # Spin Up
}

prm_638_GetCurrentSmartFrame = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x5201),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0300),      # smartCmd, arg1
   'DFB_WORD_3'      : (0x0000),      # arg2
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # AllocationLength - LSW
   'DFB_WORD_7'      : (0x0000),      # AllocationLength - MSW
}

prm_638_GetSmartThresholds = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x5201),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0400),      # smartCmd, arg1
   'DFB_WORD_3'      : (0x0000),      # arg2
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # AllocationLength - LSW
   'DFB_WORD_7'      : (0x0000),      # AllocationLength - MSW
}

prm_638_GetSmartThresholds_P508 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations | p638_cw1_report_read_data_in_P508_table),
   'DFB_WORD_0'      : (0x5201),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0400),      # smartCmd, arg1
   'DFB_WORD_3'      : (0x0000),      # arg2
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # AllocationLength - LSW
   'DFB_WORD_7'      : (0x0000),      # AllocationLength - MSW
}

prm_638_GetSystemFile_CapCapacity = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4401),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0700),      # File #
   'DFB_WORD_3'      : (0x0000),      # Transfer Length
   'DFB_WORD_4'      : (0x0000),      # StartingBlock - LSW
   'DFB_WORD_5'      : (0x0000),      # StartingBlock - MSW
   'DFB_WORD_6'      : (0x0100),      # SelectCopy, Capacity
}

prm_638_GetSystemFile_Cap = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4401),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0700),      # File #
   'DFB_WORD_3'      : (0x0000),      # Transfer Length
   'DFB_WORD_4'      : (0x0000),      # StartingBlock - LSW
   'DFB_WORD_5'      : (0x0000),      # StartingBlock - MSW
   'DFB_WORD_6'      : (0x0000),      # SelectCopy, Capacity
}

prm_638_GetSystemFile_B2DCapacity = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4401),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0b00),      # File #
   'DFB_WORD_3'      : (0x0000),      # Transfer Length
   'DFB_WORD_4'      : (0x0000),      # StartingBlock - LSW
   'DFB_WORD_5'      : (0x0000),      # StartingBlock - MSW
   'DFB_WORD_6'      : (0x0100),      # SelectCopy, B2Dacity
}

prm_638_GetSystemFile_B2D = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4401),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0b00),      # File #
   'DFB_WORD_3'      : (0x0004),      # Transfer Length
   'DFB_WORD_4'      : (0x0000),      # StartingBlock - LSW
   'DFB_WORD_5'      : (0x0000),      # StartingBlock - MSW
   'DFB_WORD_6'      : (0x0000),      # SelectCopy, Capacity
}

prm_638_WriteSystemFile_B2D = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4501),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0b00),      # File #
   'DFB_WORD_3'      : (0x0004),      # Transfer Length
   'DFB_WORD_4'      : (0x0000),      # StartingBlock - LSW
   'DFB_WORD_5'      : (0x0000),      # StartingBlock - MSW
   'DFB_WORD_6'      : (0x0000),      # SelectCopy, Capacity
}

prm_638_Dets_Format = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations | p638_cw1_dets_command),
   'TEST_FUNCTION'   : (p638_tf_normal_dfb_parameters),
   'DFB_WORD_0'      : (0x7200),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0000),
   'DFB_WORD_3'      : (0x0000),
   'DFB_WORD_4'      : (0x0500),
   'DFB_WORD_5'      : (0x0000),
   'DFB_WORD_6'      : (0x0200),
   'DFB_WORD_7'      : (0x0000),
   'DFB_WORD_8'      : (0x0101),
   'DFB_WORD_9'      : (0x0000),
   'DFB_WORD_10'     : (0x0A00),
   'DFB_WORD_11'     : (0x0A00),
}

prm_638_Read_Cap = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x7200),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0000),
   'DFB_WORD_3'      : (0x0000),
   'DFB_WORD_4'      : (0x0500),
   'DFB_WORD_5'      : (0x0000),
   'DFB_WORD_6'      : (0x0200),
   'DFB_WORD_7'      : (0x0000),
   'DFB_WORD_8'      : (0x0101),
   'DFB_WORD_9'      : (0x0000),
   'DFB_WORD_10'     : (0x0A00),
   'DFB_WORD_11'     : (0x0A00),
}

prm_638_GetSystemDriveTable_CapCapacityRev1 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4B01),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0201),      # Capacity, Table #
   'DFB_WORD_3'      : (0x0000),      # Reserved
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # Reserved
   'DFB_WORD_7'      : (0x0000),      # Transfer Length
}

prm_638_GetSystemDriveTable_CapRev1 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4B01),      # Function ID
   'DFB_WORD_1'      : (0x0100),      # Revision
   'DFB_WORD_2'      : (0x0001),      # Capacity, Table #
   'DFB_WORD_3'      : (0x0000),      # Reserved
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # Reserved
   'DFB_WORD_7'      : (0x0000),      # Transfer Length
}

prm_638_GetSystemDriveTable_CapCapacityRev2 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4B01),      # Function ID
   'DFB_WORD_1'      : (0x0200),      # Revision
   'DFB_WORD_2'      : (0x0401),      # Capacity, Table #
   'DFB_WORD_3'      : (0x0000),      # Reserved
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # Transfer Length - LSW
   'DFB_WORD_7'      : (0x0000),      # Transfer Length - MSW
}

prm_638_GetSystemDriveTable_CapRev2 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'DFB_WORD_0'      : (0x4B01),      # Function ID
   'DFB_WORD_1'      : (0x0200),      # Revision
   'DFB_WORD_2'      : (0x0001),      # Capacity, Table #
   'DFB_WORD_3'      : (0x0000),      # Reserved
   'DFB_WORD_4'      : (0x0000),      # MemoryOffset - LSW
   'DFB_WORD_5'      : (0x0000),      # MemoryOffset - MSW
   'DFB_WORD_6'      : (0x0000),      # Transfer Length - LSW
   'DFB_WORD_7'      : (0x0000),      # Transfer Length - MSW
}



prm_638_Legacy_Unlock = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'TEST_FUNCTION'   : (p638_tf_backward_compatability_parameter),
   'PARAMETER_1'     : (0x0001),      # 
   'PARAMETER_2'     : (0x0001),      #
   'PARAMETER_3'     : (0x0008),      # Number of bytes in cmd block
   'PARAMETER_4'     : (0x0000),      #
   'PARAMETER_5'     : (0xFFFF),      # Function ID
   'PARAMETER_6'     : (0x0001),      # Revision 
   'PARAMETER_7'     : (0x329A),      # 
   'PARAMETER_8'     : (0x034F),
   'PARAMETER_9'     : (0x0000),
}

prm_638_Legacy_Read_Lba_00000000_01020304_Length_00010203 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'TEST_FUNCTION'   : (p638_tf_backward_compatability_parameter),
   'PARAMETER_1'     : (0x0001),      # 
   'PARAMETER_2'     : (0x0001),      #
   'PARAMETER_3'     : (0x0012),      # Number of bytes in cmd block
   'PARAMETER_4'     : (0x0000),      #
   'PARAMETER_5'     : (0x0137),      # Function ID
   'PARAMETER_6'     : (0x0001),      # Revision 
   'PARAMETER_7'     : (0x0304),      # Lba - 64 bits - 0x000_0000_0102_0304
   'PARAMETER_8'     : (0x0102),      # Lba
   'PARAMETER_9'     : (0x0000),      # Lba
   'PARAMETER_10'    : (0x0000),      # Lba
   'PARAMETER_11'    : (0x0203),      # Length - 32 bits 0x0001_0203
   'PARAMETER_12'    : (0x0001),      # 
}

prm_638_Legacy_Write_Lba_00000000_02030506_Length_00000001 = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'TEST_FUNCTION'   : (p638_tf_backward_compatability_parameter),
   'PARAMETER_1'     : (0x0001),      # 
   'PARAMETER_2'     : (0x0001),      #
   'PARAMETER_3'     : (0x0012),      # Number of bytes in cmd block
   'PARAMETER_4'     : (0x0000),      #
   'PARAMETER_5'     : (0x0137),      # Function ID
   'PARAMETER_6'     : (0x0001),      # Revision 
   'PARAMETER_7'     : (0x0506),      # Lba - 64 bits - 0x000_0000_0203_0506
   'PARAMETER_8'     : (0x0203),      # Lba
   'PARAMETER_9'     : (0x0000),      # Lba
   'PARAMETER_10'    : (0x0000),      # Lba
   'PARAMETER_11'    : (0x0001),      # Length - 32 bits 0x0000_0001
   'PARAMETER_12'    : (0x0000),      # 
}

prm_638_Legacy_Read_Cap_Size = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'TEST_FUNCTION'   : (p638_tf_backward_compatability_parameter),
   'PARAMETER_1'     : (0x0001),      # 
   'PARAMETER_2'     : (0x0001),      #
   'PARAMETER_3'     : (0x0016),      # Number of bytes in cmd block
   'PARAMETER_4'     : (0x0000),      #
   'PARAMETER_5'     : (0x0144),      # Function ID
   'PARAMETER_6'     : (0x0001),      # Revision 
   'PARAMETER_7'     : (0x0007),      # File #
   'PARAMETER_8'     : (0x0000),      # Transfer Length
   'PARAMETER_9'     : (0x0000),      # Starting Block - uint32
   'PARAMETER_10'    : (0x0000),      # 
   'PARAMETER_11'    : (0x0001),      # Size
}

prm_638_Legacy_Read_Cap = {
   'CTRL_WORD1'      : (p638_cw1_bypass_internal_initializations),
   'TEST_FUNCTION'   : (p638_tf_backward_compatability_parameter),
   'PARAMETER_1'     : (0x0001),      # 
   'PARAMETER_2'     : (0x0001),      #
   'PARAMETER_3'     : (0x0016),      # Number of bytes in cmd block
   'PARAMETER_4'     : (0x0000),      #
   'PARAMETER_5'     : (0x0144),      # Function ID
   'PARAMETER_6'     : (0x0001),      # Revision 
   'PARAMETER_7'     : (0x0007),      # File #
   'PARAMETER_8'     : (0x0000),      # Transfer Length
   'PARAMETER_9'     : (0x0000),      # Starting Block - uint32
   'PARAMETER_10'    : (0x0000),      # 
   'PARAMETER_11'    : (0x0000),      # Size
}

# ==================================================================
# end 638
# ==================================================================


# ==================================================================
# start 639
# ==================================================================
p639_cw1_BluenunScan                                       = 0x0000
p639_cw1_BluenunAuto                                       = 0x0001
p639_cw1_BluenunSlide                                      = 0x0002
p639_cw1_BluenunMulti                                      = 0x0003

prm_639_BluenunSlide = {
   'CTRL_WORD1'            : (0x00d2),
   'CTRL_WORD2'            : (0x0364),
   'BLKS_PER_XFR'          : (0x100),
   'STARTING_LBA'          : (0x0000,0x0000,0x0000,0x0000),
   'MAXIMUM_LBA'           : (0x0000,0x0000,0x0000,0xA000),
}
# ==================================================================
# end 639
# ==================================================================


# ==================================================================
# start 642
# ==================================================================
p642_tf_getdiag                                            = 0x0000
p642_tf_lock                                               = 0x0100
p642_tf_unlock                                             = 0x0110
p642_tf_diag_identify                                      = 0x0200
p642_tf_read_last_format                                   = 0x0300
p642_tf_format                                             = 0x0310
p642_tf_format_preserve_system_area_preserve_grown_defects = 0x0320
p642_tf_format_preserve_system_area_remove_grown_defects   = 0x0330
p642_tf_config_phy_read                                    = 0x0400
p642_tf_config_phy_write                                   = 0x0410
p642_tf_config_drive_unique_read                           = 0x0800
p642_tf_write_sn                                           = 0x0811
p642_tf_write_wwn                                          = 0x0812
p642_tf_write_model_number                                 = 0x0813
p642_tf_write_firmware_version                             = 0x0814
p642_tf_restore_default_identify_data                      = 0x0815
p642_tf_write_config_drive_unique_flags                    = 0x0816
p642_tf_write_mfg_record                                   = 0x0900
p642_tf_read_mfg_record                                    = 0x0A00
p642_tf_update_mfg_record                                  = 0x0A01
p642_tf_update_mfg_record_final_assembly_date              = 0x0A02
p642_tf_self_test_start                                    = 0x2000
p642_tf_self_test_stop                                     = 0x2100
p642_tf_self_test_get_status_regular                       = 0x2200
p642_tf_self_test_get_status_extended                      = 0x2210
p642_tf_read_factory_defect_list                           = 0x2310
p642_tf_read_grown_defect_list                             = 0x2311
p642_tf_read_defect_count                                  = 0x2312
p642_tf_read_wear_distribution                             = 0x2600

p642_tf_read_i2c_temperature_sensor                        = 0x2820
p642_tf_get_supercap_controller                            = 0x2831

p642_tf_write_i2c_register                                 = 0x2900
p642_tf_write_i2c_eeprom_register                          = 0x2901
p642_tf_write_i2c_temperature_sensor_register              = 0x2902
p642_tf_write_i2c_supercap_controller_register             = 0x2903

p642_tf_error_dump                                         = 0x2A00
p642_tf_initialize_smart_logs                              = 0x2B00
p642_tf_initialize_smart_logs_and_reset_supercap_health    = 0x2B01
p642_tf_read_flash_unique_id                               = 0x2C00

#  User Capacity (GB)		 LBA Count (512Byte)
#  50	                       97,696,368
#  60		                    117,231,408
#  100                      195,371,568
#  120                      234,441,648
#  200		                  390,721,968
#  250		                  488,397,168
#  400		                  781,422,768
#  500		                  976,773,168


prm_flash_slc_Samsung                             = 0xD5EC  # high byte is device, low byte mfg
prm_flash_mlc_Samsung                             = 0xD7EC  # Mfg is 0xEC

prm_flash_mlc_Micron_64_128GB                     = 0x682C  # Mfg is 0x2C
prm_flash_mlc_Micron_256_512GB                    = 0x882C

prm_flash_slc_Micron_32_64GB                      = 0x482C  # Mfg is 0x2C
prm_flash_slc_Micron_128_256GB                    = 0x682C

prm_642_Vela_GetDiag = {
   'TEST_FUNCTION'     : (p642_tf_getdiag),
}

prm_642_Vela_Unlock = {
   'TEST_FUNCTION'     : (p642_tf_unlock),
}

prm_642_Vela_Lock = {
   'TEST_FUNCTION'     : (p642_tf_lock),
}

prm_642_Vela_WriteSn = {
   'TEST_FUNCTION'     : (p642_tf_write_sn),
}

prm_642_Vela_WriteModelNumber = {
   'TEST_FUNCTION'     : (p642_tf_write_model_number),
}


prm_642_Vela_WriteWwn = {
   'TEST_FUNCTION'     : (p642_tf_write_wwn),
}

prm_642_Vela_WriteFirmwareVersion = {
   'TEST_FUNCTION'     : (p642_tf_write_firmware_version)
}

prm_642_Vela_RestoreIdentifyDeviceData = {
   'TEST_FUNCTION'     : (p642_tf_restore_default_identify_data)
}

prm_642_Vela_WriteConfigUniqueFlags_Coalescing = {
   'TEST_FUNCTION'     : (p642_tf_write_config_drive_unique_flags),
   'FLAGS'             : (0x0001)
}

prm_642_Vela_WriteConfigUniqueFlags_PerformanceTuning = {
   'TEST_FUNCTION'     : (p642_tf_write_config_drive_unique_flags),
   'FLAGS'             : (0x0002)
}

prm_642_Vela_Clear_WriteConfigUniqueFlags = {
   'TEST_FUNCTION'     : (p642_tf_write_config_drive_unique_flags),
   'FLAGS'             : (0x0000)
}

prm_642_Vela_DiagnosticIdentify = {
   'TEST_FUNCTION'     : (p642_tf_diag_identify),
}

prm_642_Vela_Format_64G = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x05D2,0xBA70),           # 50G - 97,696,368
}

prm_642_Vela_Format_128G = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'ERASE_RBLOCK0'     : (0x0001),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
}

prm_642_Vela_Format_128G_PA = {
   'TEST_FUNCTION'        : (p642_tf_format),
   'FLASH_MFGDEV_ID'      : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE'    : (0x0000,0x2710),
   'MAXIMUM_LBA'          : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
#   'EXP_NUMBER_FLASH_DIE' : (0x0000),
   'FORMAT_MISC_FLAG'     : (0x0006),
}

prm_642_Vela_Format_Micron_64_128G = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_mlc_Micron_64_128GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
#   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0000,0x0000),           #
}

prm_642_Vela_Format_Micron_256_512G = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_mlc_Micron_256_512GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
}

prm_642_Vela_Format_Micron_Slc_1_8_128 = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Micron_128_256GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
}

prm_642_Vela_Format_Micron_Slc_2_5_128 = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Micron_128_256GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
}

prm_642_Vela_Format_Preserve_System_Growth_Micron_Slc_2_5_128 = {
   'TEST_FUNCTION'     : (p642_tf_format_preserve_system_area_preserve_grown_defects),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Micron_128_256GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
}

prm_642_Vela_Format_Preserve_System_Remove_Growth_Micron_Slc_2_5_128 = {
   'TEST_FUNCTION'     : (p642_tf_format_preserve_system_area_remove_grown_defects),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Micron_128_256GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
}

prm_642_Vela_Format_Preserve_System_Growth_Micron_Slc_2_5_128_Life = {
   'TEST_FUNCTION'          : (p642_tf_format_preserve_system_area_preserve_grown_defects),
   'FLASH_MFGDEV_ID'        : (prm_flash_slc_Micron_128_256GB),
   'MEMORY_WEAR_CYCLE'      : (0x0000,0x2710),
   'MAXIMUM_LBA'            : (0x0000,0x0000,0x0BA5,0x2230),           # 100G - 195,371,568
   'CURRENT_PE_CYCLE_COUNT' : (0x0001,0x0203),                         # Dummy value - don't use
   'LIFE_IN_SECONDS'        : (0x0967,0xa760),                         # 5yr==157,788,000==0x0967a760, 3yr==94,672,800==0x05A497A0
}

prm_642_Vela_Format_Micron_Slc_2_5_256 = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Micron_128_256GB),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'MAXIMUM_LBA'       : (0x0000,0x0000,0x1749,0xf1b0),           # 200G - 390,721,968
}

# ==== START ======== PLACEHOLDER - does not work =============
prm_642_Vela_Format_Preserve_System_And_Grown_Defects_64G = {
   'TEST_FUNCTION'     : (p642_tf_format_preserve_system_area_preserve_grown_defects),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
}

prm_642_Vela_Format_Preserve_System_And_Grown_Defects_128G = {
   'TEST_FUNCTION'     : (p642_tf_format_preserve_system_area_preserve_grown_defects),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'ERASE_RBLOCK0'     : (0x0001),
}

prm_642_Vela_Format_Preserve_System_And_Remove_Grown_Defects_64G = {
   'TEST_FUNCTION'     : (p642_tf_format_preserve_system_area_remove_grown_defects),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
}

prm_642_Vela_Format_Preserve_System_And_Remove_Grown_Defects_128G = {
   'TEST_FUNCTION'     : (p642_tf_format_preserve_system_area_remove_grown_defects),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
   'ERASE_RBLOCK0'     : (0x0001),
}
# ==== END ======== PLACEHOLDER - does not work =============

prm_642_Vela_Read_Last_Format_Command = {
   'TEST_FUNCTION'     : (p642_tf_read_last_format),
}


prm_642_Vela_Read_Phy = {
   'TEST_FUNCTION'     : (p642_tf_config_phy_read),
}

prm_642_Vela_Read_Drive_Unique = {
   'TEST_FUNCTION'     : (p642_tf_config_drive_unique_read),
}

prm_642_Vela_Read_Factory_Defect_List = {
   'TEST_FUNCTION'     : (p642_tf_read_factory_defect_list),
}

prm_642_Vela_Read_Grown_Defect_List = {
   'TEST_FUNCTION'     : (p642_tf_read_grown_defect_list),
}

prm_642_Vela_Read_Defect_Count = {
   'TEST_FUNCTION'     : (p642_tf_read_defect_count),
}

prm_642_Vela_Read_Wear_Distribution = {
   'TEST_FUNCTION'     : (p642_tf_read_wear_distribution),
}

prm_642_Vela_Read_Mfg_Record = {
   'TEST_FUNCTION'     : (p642_tf_read_mfg_record),
}

prm_642_Vela_Write_Mfg_Record = {
   'TEST_FUNCTION'     : (p642_tf_write_mfg_record),
}

prm_642_Vela_Update_Mfg_Record = {
   'TEST_FUNCTION'     : (p642_tf_update_mfg_record),
}

prm_642_Vela_Self_Test_Start = {
   'TEST_FUNCTION'     : (p642_tf_self_test_start),
   'CTRL_WORD1'        : (0x0009),
   'PATTERN_TYPE'      : (0x0000),
   'DATA_PATTERN0'     : (0x0000,0x0000),
}

prm_642_Vela_Self_Test_Get_Status_Regular = {
   'TEST_FUNCTION'     : (p642_tf_self_test_get_status_regular),
}

prm_642_Vela_Self_Test_Get_Status_Extended = {
   'TEST_FUNCTION'     : (p642_tf_self_test_get_status_extended),
}

prm_642_Vela_Self_Test_Stop = {
   'TEST_FUNCTION'     : (p642_tf_self_test_stop),
}

prm_642_Vela_Initialize_Smart_Logs = {
   'TEST_FUNCTION'     : (p642_tf_initialize_smart_logs),
}

prm_642_Vela_Initialize_Smart_Logs_And_Reset_Supercap_Health = {
   'TEST_FUNCTION'     : (p642_tf_initialize_smart_logs_and_reset_supercap_health),
}

prm_642_Vela_Error_Dump_To_Serial_Port = {
   'TEST_FUNCTION'     : (p642_tf_error_dump),
}

prm_642_Vela_Get_SuperCap = {
   'TEST_FUNCTION'     : (p642_tf_get_supercap_controller),
}

prm_642_Vela_Temperature_Sensor = {
   'TEST_FUNCTION'     : (p642_tf_read_i2c_temperature_sensor),
}

prm_642_Vela_Temperature_Sensor_Drivevars = {
   'TEST_FUNCTION'     : (p642_tf_read_i2c_temperature_sensor),
   'CTRL_WORD1'        : (0x8000),
}

prm_642_Vela_Read_Flash_Unique_Ids = {
   'TEST_FUNCTION'     : (p642_tf_read_flash_unique_id),
}

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# ++++ START ++++++++ ILLEGAL_PARAMETERS +++++++++++++++++
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prm_642_Vela_Illegal_GetDiag_1 = {
   'TEST_FUNCTION'     : (p642_tf_getdiag),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
}

prm_642_Vela_Illegal_GetDiag_2 = {
   'TEST_FUNCTION'     : (p642_tf_getdiag),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
}

prm_642_Vela_Illegal_Format_1 = {
   'TEST_FUNCTION'     : (p642_tf_format),
}

prm_642_Vela_Illegal_Format_2 = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x2710),
}

prm_642_Vela_Illegal_Format_3 = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (prm_flash_slc_Samsung),
}

prm_642_Vela_Illegal_Format_4 = {
   'TEST_FUNCTION'     : (p642_tf_format),
   'FLASH_MFGDEV_ID'   : (0x0000),
   'MEMORY_WEAR_CYCLE' : (0x0000,0x0000),
}
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# ++++ END ++++++++++ ILLEGAL_PARAMETERS +++++++++++++++++
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# ==================================================================
# stop 642
# ==================================================================

# ==================================================================
# start 643
# ==================================================================
p643_tf_write_mobil                                        = 0x0000
p643_tf_dram_screen                                        = 0x0010

# ==================================================================
# stop 643
# ==================================================================
