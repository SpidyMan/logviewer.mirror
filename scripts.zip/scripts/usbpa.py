# USB Power Adapter (USBPA)
# usbpa.py
# Henri Begin, Self Test Firmware
# LCO NW2U04A, 8-684-2992
# Seagate Technology

#print "USBPA v1.3, 01/22/2008"

import time

## DEFINES #
try:
    ftd2xx = ctypes.windll.ftd2xx64
except OSError:  # 32-bit, or 64-bit library with plain name
    try:
        ftd2xx = ctypes.windll.ftd2xx
    except OSError as e:
        if e.winerror == 126:
            error_message = (
                e.args[1] + "Unable to find D2XX DLL. "
                "Please make sure that the directory containing your DLL is in "
                "one (or both) environment variables: 'PATH', 'FTD2XX_DLL_DIR'. "
                "Also, you must use 'ftd2xx.dll' or 'ftd2xx64.dll' as the filename."
            )
            e.args = (e.args[0], error_message) + e.args[2:]
        raise e
ON = 0xB1                        # bit mask to turn adapter on
OFF = 0x71                       # bit mask to turn adapter off
FT_OPEN_BY_SERIAL_NUMBER = 1     # bit mask for OpenEx
FT_OPEN_BY_DESCRIPTION = 2       # bit mask for OpenEx
FT_OPEN_BY_LOCATION = 4          # bit mask for OpenEx
FT_LIST_NUMBER_ONLY = 0x80000000 # bit mask for ListDevices
FT_LIST_BY_INDEX = 0x40000000    # bit mask for ListDevices
FT_LIST_ALL = 0x20000000         # bit mask for ListDevices

STRING = ctypes.c_char_p
UCHAR = ctypes.c_ubyte
PUCHAR = ctypes.POINTER(ctypes.c_ubyte)
PVOID = ctypes.c_void_p
ULONG = ctypes.c_ulong
LPDWORD = ctypes.POINTER(ctypes.wintypes.DWORD)
FT_HANDLE = PVOID
FT_STATUS = ULONG

USBOpen = ftd2xx.FT_Open
USBOpen.restype = FT_STATUS
# FT_Open(deviceNumber, pHandle)
USBOpen.argtypes = [ctypes.c_int, ctypes.POINTER(FT_HANDLE)]

USBOpenEx = ftd2xx.FT_OpenEx
USBOpenEx.restype = FT_STATUS
# FT_OpenEx(pArg1, Flags, pHandle)
USBOpenEx.argtypes = [PVOID, ctypes.wintypes.DWORD, ctypes.POINTER(FT_HANDLE)]

USBListDevices = ftd2xx.FT_ListDevices
USBListDevices.restype = FT_STATUS
# FT_ListDevices(pArg1, pArg2, Flags)
USBListDevices.argtypes = [PVOID, PVOID, ctypes.wintypes.DWORD]

USBWrite = ftd2xx.FT_Write
USBWrite.restype = FT_STATUS
# FT_Write(ftHandle, lpBuffer, nBufferSize, lpBytesWritten)
USBWrite.argtypes = [FT_HANDLE, PVOID, ctypes.wintypes.DWORD, LPDWORD]

USBSetBaudRate = ftd2xx.FT_SetBaudRate
USBSetBaudRate.restype = FT_STATUS
# FT_SetBaudRate(ftHandle, BaudRate)
USBSetBaudRate.argtypes = [FT_HANDLE, ULONG]

USBSetTimer = ftd2xx.FT_SetLatencyTimer
USBSetTimer.restype = FT_STATUS
# FT_SetLatencyTimer(ftHandle, ucLatency)
USBSetTimer.argtypes = [FT_HANDLE, UCHAR]

USBSetBitMode = ftd2xx.FT_SetBitMode
USBSetBitMode.restype = FT_STATUS
# FT_SetBitMode(ftHandle, ucMask, ucEnable)
USBSetBitMode.argtypes = [FT_HANDLE, UCHAR, UCHAR]

USBGetBitMode = ftd2xx.FT_GetBitMode
USBGetBitMode.restype = FT_STATUS
# FT_GetBitMode(ftHandle, pucMode)
USBGetBitMode.argtypes = [FT_HANDLE, PUCHAR]

USBClose = ftd2xx.FT_Close
USBClose.restype = FT_STATUS
# FT_Close(ftHandle)
USBClose.argtypes = [FT_HANDLE]

DELAY = 10                       # powercycle delay time (in secs)

def USBPA_PC(port_addr,state):   # for USB devices by PC index
    handle = FT_HANDLE()
    status = 0
    status = USBOpen( port_addr, ctypes.byref(handle) )
    if(status != 0):
        print("USB OPEN HANDLE FAILED.  CHECK DLL.")
    else:
        status = USBSetTimer(handle.value, 2);
        if(status != 0):
            print("USB LATENCY TIMER NOT SET")
        else:
            status = USBSetBitMode(handle.value, state, 1)
            if(status != 0):
                print("USB BITBANG WRITE FAILED")
        status = USBClose(handle.value)
        if(status != 0):
            print("USB DEVICE NOT CLOSED")

def USBPA_ID(LocID,state):       # for specific USB devices on this PC
    handle = FT_HANDLE()
    status = 0
    status = USBOpenEx( LocID, FT_OPEN_BY_LOCATION, ctypes.byref(handle) )
    if(status != 0):
        print("USB OPEN HANDLE FAILED.  CHECK DLL.")
    else:
        status = USBSetTimer(handle.value, 2);
        if(status != 0):
            print("USB LATENCY TIMER NOT SET")
        else:
            status = USBSetBitMode(handle.value, state, 1)
            if(status != 0):
                print("USB BITBANG WRITE FAILED")
        status = USBClose(handle.value)
        if(status != 0):
            print("USB DEVICE NOT CLOSED")

# Shorthand functions (legacy Maxtor)
def pwron(*args):
    Devices = ctypes.wintypes.DWORD()
    if not args:
        USBListDevices(ctypes.byref(Devices),0,FT_LIST_NUMBER_ONLY)
        for dev in range(Devices.value):
            USBPA_PC(dev,ON)
    else:
        USBPA_ID(args[0],ON)
def pwroff(*args):
    Devices = ctypes.wintypes.DWORD()
    if not args:
        USBListDevices(ctypes.byref(Devices),0,FT_LIST_NUMBER_ONLY)
        for dev in range(Devices.value):
            USBPA_PC(dev,OFF)
    else:
        USBPA_ID(args[0],OFF)
def pwrcycle(*args):
    Devices = ctypes.wintypes.DWORD()
    if not args:
        USBListDevices(ctypes.byref(Devices),0,FT_LIST_NUMBER_ONLY)
        for dev in range(Devices.value):
            USBPA_PC(dev,OFF)
        time.sleep(DELAY)
        for dev in range(Devices.value):
            USBPA_PC(dev,ON)
    else:
        USBPA_ID(args[0],OFF)
        time.sleep(DELAY)
        USBPA_ID(args[0],ON)

def USBPAList():
    status = 0
    numDevs = ctypes.wintypes.DWORD()
    Description = ctypes.create_string_buffer(64)
    LocationID = ctypes.wintypes.DWORD()
    
    status = USBListDevices(ctypes.byref(numDevs),0,FT_LIST_NUMBER_ONLY)
    if(status == 0):
        if(numDevs.value == 0):
            print("NO D2XX USB DEVICES")
        else:
            print("D2XX USB DEVICES")
            for i in range(numDevs.value):
                status = USBListDevices(i,ctypes.byref(Description),FT_LIST_BY_INDEX|FT_OPEN_BY_DESCRIPTION)
                if(status == 0):
                    status = USBListDevices(i,ctypes.byref(LocationID),FT_LIST_BY_INDEX|FT_OPEN_BY_LOCATION)
                    if(status == 0):
                        print(i,", LocationID: ",LocationID.value,", Desc: ",Description.value)
                    else:
                        print("LIST DEVICES FAILED: LOCID, DEV = ",i)
                else:
                    print("LIST DEVICES FAILED: DESC, DEV = ",i)
    else:
        print("LIST DEVICES FAILED: NUMDEVS")
        


def USBPADriveOn(levelFor5V=5000,levelFor12V=12000,pauseTime=30,levelFor3V=3000,controlSerialIO=0,**kwargs): 
  #  Look for the parameters that ask us to send '\x1b' escape characters before and after applying drive power.
  preEscapes  = kwargs.get("preEscapes")
  postEscapes = kwargs.get("postEscapes")  
    
  try:
     USBPAId
     if not isinstance(USBPAId, type(1)): raise NameError      
  except NameError:
     print("Error: USBPAId (integer value) should be defined before using this function")
     return
  
  # Send a bunch of escapes just before we turn on drive power
  if isinstance(preEscapes,int) and preEscapes > 0:
     Send(preEscapes*'\x1b')
     
  pwron(USBPAId)
  
  # Send a bunch of escapes just after we turn on drive power
  if isinstance(postEscapes,int) and postEscapes > 0:
     Send(postEscapes*'\x1b')
   
  print("%s: DriveOn: pause --> %s seconds"%(time.asctime(), pauseTime,))
  ScriptPause(pauseTime)
  

def USBPADriveOff(pauseTime=30,controlSerialIO=0):  
  try:
     USBPAId
     if not isinstance(USBPAId, type(1)): raise NameError      
  except NameError:
     print("Error: USBPAId (integer value) should be defined before using this function")
     return

  pwroff(USBPAId)
  
  print("%s: DriveOff: pause --> %s seconds"%(time.asctime(), pauseTime,))
  ScriptPause(pauseTime)
####################################################################
####################################################################

DriveOn  = USBPADriveOn
DriveOff = USBPADriveOff
#RimOn    = USBPADriveOn
#RimOff   = USBPADriveOff
####################################################################
#     Request Handler for Drive On and Drive Off request           #
####################################################################
def processDriveOnOff(buf, *args, **kargs):
  requestKey = buf[0:1]
  # code 6 typically requests a block of data from the download file;  get_data_file()
  if requestKey == 13:
      DriveOff()
  elif requestKey == 14:
      DriveOn() 
  else:
    str = "Unsupported requestKey in processDriveOnOff ==>",requestKey
    raise FOFParameterError(str)    
    
RegisterResultsCallback(processDriveOnOff, [13,14], 0)