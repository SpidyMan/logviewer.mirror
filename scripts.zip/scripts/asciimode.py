
# Author: Matthew Piehl

import time
def readBuffer():
    output = GChar(1, 0)
    if output:
      print(output, end=' ')

def runCommand(cmd = ""):
  if cmd:
    PBlock(cmd)
    # time.sleep(1)
  # else:
  # output = ""
  # while True:
  #  output = GChar(1,0)
  #  print output,
  #  if output == "":
  #    break
  # print

if __name__ == '__main__':
  runCommand('\x1A')
  time.sleep(10)
  output = GChar()

  runCommand('\x1A')
