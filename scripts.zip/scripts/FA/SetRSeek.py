gFlagRSeek=1  # set read seek mode
gMaxUsedHead=svram(88)
print("Goto Read Seek Mode    Max Head = %d" % gMaxUsedHead)
rsk(gCylinder,gHead)
