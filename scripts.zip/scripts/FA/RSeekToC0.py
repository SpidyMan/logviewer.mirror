try:
   if gCylIncrValue==0: gCylIncrValue=1
except:
   gCylIncrValue=1
gCylinder=0
print("Read-Seek to Cylinder 0")
gFlagRSeek=1
rsk(gCylinder,gHead)
