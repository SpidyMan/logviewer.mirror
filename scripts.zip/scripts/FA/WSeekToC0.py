try:
   if gCylIncrValue==0: gCylIncrValue=1
except:
   gCylIncrValue=1
gCylinder=0
print("Write-Seek to Cylinder 0")
gFlagRSeek=0
wsk(gCylinder,gHead)
