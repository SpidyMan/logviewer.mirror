# xftab.py
version = '3.01'

"""
to use this script with WinFOF:
  1) Copy this xftab.py file to the C:\var\merlin3\scripts folder.
  2) Add the following line to the end of the scriptfuncs.py file, which is also located in the C:\var\merlin3\scripts
     folder.  Alternatively, you can add this line to the userCustom.py file which gets called by scriptfuncs.py.
        --> FOFexecfile(("","xftab.py"))
  3) Restart WinFOF.
  4) Execute the setxf command in the WinFOF command line or in a script.  See examples below.

version 3.01
  - Tui and Karnak did not work in version 3 due to an incorrect register address.  Updated
  the register address and verified operation on a Tui (Thunderbolt) drive.  Do not have a
  Karnak drive to verify XF Tab operation, but it may work.

previous versions:
version 3
  - Updated to include tui and karnak chips.
  - Implemented change for wide pulse width variation (per Bob Relling).
  - Added option to allow this script to work in either serial port or IO environment
  via the new Intf parameter.
  - NOTE: It is normal for many tests to be executed when running this script in 'io' mode.
  For this reason, the dexParserOff() function is executed at the beginning of the script to
  minimize output in the WinFOF output window.  The dexParserOn() function is executed at
  the end of the script to restore normal operation.  This script will take several seconds
  to run in 'io' mode.
version 2
  - Updated to include moa chip.
version 1
  - Initial release.

examples of XF Tab calls, must always specify the first two parameters (Intf and Chip)
  setxf('sp','kahu')          display all current XF Tab settings (using serial port)
  setxf('io','moa')           display all current XF Tab settings (using initiator)
  clrxf('sp','moa')           clear all XF Tabs (using serial port)
  clrxf('io','kahu')          clear all XF Tabs (using initiator)
  setxf('sp','skua',8,100)    set XF Tab 8 to pulse width 100
  setxf('sp','tui',5,30)      set XF Tab 5 to pulse width 30
  setxf('io','kahu',5,0)      disable XF Tab 5

valid Chip parameter values are: 'legacy', 'kahu', 'skua', 'banshee', 'moa', 'tui', 'karnak'
"""

EnableDebugOutput = 0   # debug output (1 = debug output, 2 = debug output and test parameter output)
ShowTestOutput = 0      # DEX parser state (test parameter output, no effect when Intf='sp')
ShowTestCount = 0       # used for debug

####################################################################

# the user should not need to alter this setting, however it can be set to 0 if the user encounters problems with this script
EnableSpeedUp = 2       # speed-up effective only if Intf = 'io' (speed-up reduces the number of tests required to execute)
# EnableSpeedUp values: 0 = no speed-up, 1 = speed-up, 2 = alternate speed-up
#   note: method 2 is needed due to a drive FW issue found on moa with value=1 (cannot write servo memory using WriteDriveMemory command)

def clrxf(Intf, Chip):
  setxf(Intf, Chip, -1)

def setxf(Intf, Chip, XfIndex = -2, PulseWidth = 0):
  """
  Intf = 'sp' or 'io' to specify serial port or io setup
  Chip = 'legacy', 'kahu', 'skua', 'banshee', 'moa', 'tui', karnak ; legacy means products prior to F3
  XfIndex = -2 means display all xf tabs but do not set any xf tab, this is the default setting
  XfIndex = -1 means clear all xf tabs, can use clrxf() instead, see above
  XfIndex = 0 to 15 means set that xf tab to the value in PulseWidth
  """

  print("xftab.py version " + version)

  # used for debug
  global stCounter
  stCounter = 0

  # validate Chip parameter
  if Chip not in ['legacy', 'kahu', 'skua', 'banshee', 'moa', 'tui', 'karnak']:
    print("Invalid Chip parameter: %s" % Chip)
    return

  # setup for chip type
  NewerASIC = 1     # see Matlab setxf.m script
  if Chip in ['legacy', 'kahu', 'skua', 'banshee']: NewerASIC = 0
  if NewerASIC: maxPW = 127
  else: maxPW = 255

  # instantiate interface specified by Intf parameter
  ioSpeedUp = 0
  if (Intf == 'sp'):
    IOFcns = 0  # not used in serial port mode
    drv = spIntfCls(EnableDebugOutput)
  elif (Intf == 'io'):
    IOFcns = ioFcnCls(NewerASIC)   # ioIntfCls needs this object
    drv = ioIntfCls(IOFcns, EnableDebugOutput)
    ioSpeedUp = EnableSpeedUp
  else:
    print("Invalid Intf parameter: %s" % Intf)
    return

  # validate XT Tab index
  if XfIndex < -2 or XfIndex > 15:
    print("Invalid XfIndex parameter: %d" % XfIndex)
    return

  # validate pulse width value
  if PulseWidth < 0 or PulseWidth > maxPW:
    print("Invalid PulseWidth parameter: %d" % PulseWidth)
    max = maxPW
    if NewerASIC == 0: max = 252  # pulse widths > 252 do not work on older ASIC
    print("Valid range is: 0 to %d" % maxPW)
    return

  if ShowTestOutput: dexParserOn()
  else: dexParserOff()
  # any return statements after this point must ensure that DEX parser is turned back on

  XfPulseWidthTable = 196   # index to servo XF Tab pulse width table
  svoIndexAddr = 0
  if ioSpeedUp:   # get index pointer value
    svoIndexAddr = drv.xf_svram(svAddrIndex = 196, size = 32, addressMode = "DIRECT")
    # print "servo index address = 0x%X" % svoIndexAddr

  # status, table = IOFcns.readDriveMem(addr = svoIndexAddr, regSize = 2, byteCount = 32, area = 2)
  # print binascii.hexlify(table)
  # return

  if ShowTestCount:
    print("Test Counter A = %d" % stCounter)   # debug info

  if XfIndex == -1:   # set all XF Tab pulse widths to zero
    if ioSpeedUp == 1:  # desired speed-up option, but does not work:
      # the following causes a 05/2602/10 error (unsupported memory area) on Lightning product, maybe others
      IOFcns.writeDriveMem(addr = svoIndexAddr, regSize = 2, byteCount = 32, wData = '\x00' * 32, area = 2)
    else:
      if ioSpeedUp == 2:    # alternative speed-up option for clearing servo ram
        drv.xf_options(0x0001)  # setup for sequential writes (eliminates redundant test calls)
      for idx in range(0, 16):
        drv.xf_svram(svAddrIndex = XfPulseWidthTable, offset = 2 * idx, size = 16, wrFlag = "WRITE", wData = 0)
      drv.xf_options(0)     # go back to normal mode

  if XfIndex >= 0:    # set specified XF Tab pulse width
    pw = PulseWidth
    if pw > 0:        # pw=0 turns off trigger
      pw = maxPW + 1 - pw     # modify value for hardware
      if NewerASIC: pw <<= 2  # shift up by 2 bits, lower 2 bits not used
    drv.xf_svram(svAddrIndex = XfPulseWidthTable, offset = 2 * XfIndex, size = 16, wrFlag = "WRITE", wData = pw)

  if XfIndex >= -1:   # setup hardware
    ioreg_base = 0x40070000   # default base address
    if Chip == 'kahu':
      pass  # nothing required here for kahu
    elif Chip == 'skua':
      ioreg_base = 0x80070000
    elif Chip == 'banshee':
      ioreg_base = 0x80070000
      ioreg_addr = 0x80018078   # SOC_gpio_alt_out_en register
      ioreg_data = drv.xf_reg(address = ioreg_addr, size = 32)
      ioreg_data &= 0xFFFFFEFF    # clear bit 8
      ioreg_data |= 0x00000002    # set bit 1
      drv.xf_reg(address = ioreg_addr, size = 32, writeFlag = 1, data = ioreg_data)
    elif Chip == 'moa':
      ioreg_base = 0x80070000
      ioreg_addr = 0x80018078;  # sr_cgpio_func_ctl_0 register
      ioreg_data = drv.xf_reg(address = ioreg_addr, size = 32)
      ioreg_data &= 0xFFFFFFF7    # clear bit 3
      ioreg_data |= 0x00000004    # set bit 2
      drv.xf_reg(address = ioreg_addr, size = 32, writeFlag = 1, data = ioreg_data)
    elif Chip == 'tui':
      ioreg_base = 0x44026000
      ioreg_addr = 0x44028098;  # sr_led_func_ctl_reg register
      ioreg_data = drv.xf_reg(address = ioreg_addr, size = 32)
      ioreg_data |= 0x00000003    # set bits 0 and 1
      drv.xf_reg(address = ioreg_addr, size = 32, writeFlag = 1, data = ioreg_data)
    elif Chip == 'karnak':
      ioreg_base = 0x44026000
      ioreg_addr = 0x44028348   # vismux_diag18_control
      ioreg_data = 0x00000BDA    # LED <- Servo LED
      drv.xf_reg(address = ioreg_addr, size = 32, writeFlag = 1, data = ioreg_data)
    else:   # legacy product/chip
      drv.xf_reg(address = 0x400D4024, size = 16, writeFlag = 1, data = 0x2203)  # write 0x2203 to second level of mux

    # enable XF Tab output (addressing modeled after Matlab setxf script)
    drv.xf_reg(address = ioreg_base | (0xC0 << 2), size = 16, writeFlag = 1, data = 0x0000)  # clear bit 15 to enable trigger
    led_ioreg_data = drv.xf_reg(address = ioreg_base + (0x50 << 2), size = 16)   # save reg value for use at end of function
    drv.xf_reg(address = ioreg_base | (0x50 << 2), size = 16, writeFlag = 1, data = led_ioreg_data | 0x0001)   # set bit 0 to enable XF pulse to LED

  if ShowTestCount:
    print("Test Counter B = %d" % stCounter)   # debug info

  # read pulse width table
  xf_pw_data = []
  if ioSpeedUp:   # read table in one shot
    # needed to double the byte count for skua, 32 byte count works for moa, but leave at 64
    status, table = IOFcns.readDriveMem(addr = svoIndexAddr, regSize = 2, byteCount = 64, area = 2)
    for idx in range(0, 16):
      xf_pw_data.append(ord(table[2*idx]) + (ord(table[2*idx+1]) << 8))
  else:   # perform individual reads
    for idx in range(0, 16):
      xf_pw_data.append(drv.xf_svram(svAddrIndex = XfPulseWidthTable, offset = 2*idx, size = 16))

  # back-convert pulse width values
  nonZero = 0
  for idx in range(0, 16):
    pw = xf_pw_data[idx]
    nonZero |= pw
    if NewerASIC: pw >>= 2
    if pw > 0: pw = maxPW + 1 - pw
    xf_pw_data[idx] = pw

  if ShowTestCount:
    print("Test Counter C = %d" % stCounter)   # debug info

  if nonZero == 0 and XfIndex >= -1:
    drv.xf_reg(address = ioreg_base | (0xC0 << 2), size = 16, writeFlag = 1, data = 0x8000)  # set bit 15 to disable trigger
    drv.xf_reg(address = ioreg_base | (0x50 << 2), size = 16, writeFlag = 1, data = led_ioreg_data & 0xFFFE)   # clear bit 0 to restore normal LED operation

  # all non-debug print output is deferred to after all IO test output

  dexParserOn()   # ensure parser is turned back on
  print()

  if XfIndex >= -1:   # setup hardware
    print("setxf %(ix)d,%(pw)d" % {'ix': XfIndex, 'pw': PulseWidth})
  else:
    print("setxf (display only)")

  # show current XF Tab settings, disable XF Tab output to LED if no XF Tabs are set
  print("XF_Tab     PulseWidth")
  print("---------------------")
  for idx in range(0, 16):
    print("%(index)2d (%(index)X)            %(result)3d" % {'index': idx, 'result': xf_pw_data[idx]})

  if nonZero == 0 and XfIndex >= -1:
    print("XF Tab operation has been disabled")

  if ShowTestCount:
    print("Test Counter D = %d" % stCounter)   # debug info

####################################################################

# Utility Functions

stCounter = 0

def _st(*inPrm, **kwargs):  # wrapper used to return status and optionally display params/results
  global stCounter
  if EnableDebugOutput == 2:
    print(inPrm)
    print(kwargs)
  (test_name, test_number, test_status, test_time) = st(*inPrm, **kwargs)
  stCounter += 1
  #print test_name
  #print test_number
  #print test_status
  #print test_time
  return test_status

def lsb(dataWord):  # returns the least significant byte of the the 16-bit word
  return dataWord & 0xFF;

def msb(dataWord):  # returns the most significant byte of the the 16-bit word
  return (dataWord >> 8) & 0xFF;

def lsw(dataLongWord):  # returns the least significant word of the 32-bit data word
  return dataLongWord & 0x0000FFFF

def msw(dataLongWord):  # returns the most significant word of the 32-bit data word
  return (dataLongWord >> 16) & 0x0000FFFF

def flipw(dataWord):    # swaps the high and low bytes of the 16-bit data word and returns the result
  return ((dataWord & 0x00FF) << 8) | ((dataWord & 0xFF00) >> 8)

def flipdw(dataLongWord):   # swaps the the order of the 4 data bytes
  lower = dataLongWord & 0xFFFF;
  upper = (dataLongWord >> 16) & 0xFFFF;
  lower = msb(lower) + (lsb(lower) << 8);
  upper = msb(upper) + (lsb(upper) << 8);
  return (lower << 16) + upper;

# Cudacom Utility Functions (renamed)

def t_bytes(the_word):  # was __bytes
  """
  @return: tuple of bytes from a word
  """
  return ((the_word>>8)&0xFF,the_word&0xFF)

def t_lbytes(the_lword):  # was __lbytes
  """
  @return: tuple of bytes from long/double word
  """
  return ((the_lword>>24)&0xFF,(the_lword>>16)&0xFF,(the_lword>>8)&0xFF,the_lword&0xFF)

def t_lwords(the_lword):  # was _lwords
  """
  @return: tuple of words from long/double word
  """
  return (((the_lword>>16)&0xFFFF),the_lword&0xFFFF)

def byteArrayToWordTuple(byteData):
  # length of byteData must be a multiple of two to work correctly
  temp = []   # first, build bytes into word list
  for idx in range(len(byteData)/2):
    temp.append((ord(byteData[2*idx]) << 8) + ord(byteData[2*idx+1]))
  return tuple(temp)  # second, convert to tuple and return

####################################################################

class spIntfCls:

  def __init__(self, result_output):
    self.resultOutput = result_output
    self.optionBits = 0   # not used in the sp class

  def xf_options(self, options):
    self.optionBits = options

#------------------------------------------------------------------#

# the following functions are renamed copies of the cudacom reg() and svram() functions
# they have been modified to optionally not print any results

  def xf_reg(self, address, size = 16, writeFlag = 0, data = 0):
    """
    Read or write to memory mapped registers
    @param address: Address to read or write
    @param data: Data to write
    @param size: Size in bits of the controller register, 8, 16, and 32 are valid entries
    @param writeFlag: Set to enable write mode, defaults to zero for read mode
    @return: Error code
    """

    if size != 8 and size != 16 and size != 32:
      print("xf_reg(): Invalid size parameter")
      print(size)
      return 0

    lswData = data
    mswData = 0
    if size == 32:
      mswData, lswData = t_lwords(data)
    mswAddress, lswAddress = t_lwords(address)
    buf, errorCode = fn(1216, lswAddress, mswAddress, size, writeFlag, lswData, mswData)
    #buf, errorCode = __ReceiveResults()

    if size == 8:
      result = struct.unpack("BBBB",buf)
    if size == 16:
      result = struct.unpack("HH",buf)
    if size == 32:
      result = struct.unpack("L",buf)
    #print "Hex: %x  " % result[0:1] + "Dec: %d" % result[0:1]
    #data = result[0:1]
    #return int(data[0])

    if self.resultOutput:
      print("xf_reg(): Address (0x%X) --> 0x%X (%d)"% (address, result[0], result[0],))
    return int(result[0])

  def xf_svram(self, svAddrIndex, offset = 0, size = 16, addressMode = "INDIRECT", wrFlag = "READ", wData = 0):
    """
    Read/Write Servo RAM
    @param svAddrIndex: Index into array of servo RAM addresses to begin read/write operations
    @param offset: Offset into table from beginning address times length (ie addr+0, addr+2 etc. for word length)
    @param size: Operation length: 8 (byte), 16 (default word), or 32 (long word)
    @param addressMode: Address servo RAM via read_servo_ram (INDIRECT) or directly through the variable name
    @param wrFlag: Set to anything besides "READ" to enable write mode
    @param wData: Data to write when in write mode
    @return: Binary response from drive
    """

    if size != 8 and size != 16 and size != 32:
      print("xf_svram(): Invalid size parameter")
      print(size)
      return 0
    writeFlag = 0     # Default to read
    addrMode = 0      # Default to INDIRECT mode (read_servo_ram)

    if addressMode != "INDIRECT":
      addrMode = 1  # Address the servo var directly
      if wrFlag != "READ":
        print("xf_svram(): Cannot use direct mode with writes")
        return 0

    if wrFlag == "WRITE":
      writeFlag = 1 # Write servo RAM
      if size == 32:
        msData, lsData = __lwords(wData)
        buf, errorCode = fn(1291, svAddrIndex, offset, size, addrMode, writeFlag, lsData, msData)
      else:
        buf, errorCode = fn(1291, svAddrIndex, offset, size, addrMode, writeFlag, wData)
      #buf, errorCode = __ReceiveResults()

    # Read the data (echo if write cmd)
    buf, errorCode = fn(1291, svAddrIndex, offset, size, addrMode, 0, wData)
    #buf, errorCode = __ReceiveResults()

    if size == 8:
      result = struct.unpack("BBBB",buf)
    if size == 16:
      result = struct.unpack("HH",buf)
    if size == 32:
      result = struct.unpack("L",buf)
    #print "\nHex: %x  " % result[0:1] + "Dec: %d" % result[0:1]
    #data = result[0:1]
    #return int(data[0])

    if self.resultOutput:
      print("xf_svram(): Servo Address,Offset (0x%X,%d) --> 0x%X (%d)"% (svAddrIndex, offset, result[0], result[0],))
    return int(result[0])

####################################################################

class ioIntfCls:   # io interface

# the following functions are IO versions of the xf_reg() and xF_svram() functions

  def __init__(self, io_fcns, result_ouput):
    self.ioFcns = io_fcns
    self.resultOutput = result_ouput
    self.optionBits = 0
    self.svram_EnableAddressing = 1   # used with optionBits: bit 0

  def xf_options(self, options):
    self.optionBits = options
    self.svram_EnableAddressing = 1   # return to normal operation when any option is changed

#------------------------------------------------------------------#

  def xf_reg(self, address, size = 16, writeFlag = 0, data = 0):
    """
    Read or write to memory mapped registers
    @param address: Address to read or write
    @param data: Data to write
    @param size: Size in bits of the controller register, 8, 16, and 32 are valid entries
    @param writeFlag: Set to enable write mode, defaults to zero for read mode
    @return: Error code
    """

    if size != 8 and size != 16 and size != 32:
      print("xf_reg(): Invalid size parameter")
      print(size)
      return 0
    wordSize = size // 8  # number of bytes in word

    if (writeFlag):
      status = self.ioFcns.writeCtlrReg(addr=address, value=data, regSize=wordSize)
      value = 0
    else:
      status, value = self.ioFcns.readCtlrReg(addr=address, regSize=wordSize)

    if self.resultOutput:
      print("xf_reg(): Address (0x%X) --> 0x%X (%d)"% (address, value, value))
    return value  # status is not returned, to be compatible with sp version of this function

  def xf_svram(self, svAddrIndex, offset = 0, size = 16, addressMode = "INDIRECT", wrFlag = "READ", wData = 0):
    """
    Read/Write Servo RAM
    @param svAddrIndex: Index into array of servo RAM addresses to begin read/write operations
    @param offset: Offset into table from beginning address times length (ie addr+0, addr+2 etc. for word length)
    @param size: Operation length: 8 (byte), 16 (default word), or 32 (long word)
       note: the size param has no effect in this io based function (servo index pointer is 32, servo words are 16)
    @param addressMode: Address servo RAM via read_servo_ram (INDIRECT) or directly through the variable name
    @param wrFlag: Set to anything besides "READ" to enable write mode
    @param wData: Data to write when in write mode
    @return: Binary response from drive
    """

    dataOnlyOption = self.optionBits & 0x0001   # skip

    if size != 8 and size != 16 and size != 32:
      print("xf_svram(): Invalid size parameter")
      print(size)
      return 0

    writeFlag = 0     # Default to read
    addrMode = 0      # Default to INDIRECT mode (read_servo_ram)

    if addressMode != "INDIRECT":
      addrMode = 1    # Address the servo var directly
      if wrFlag != "READ":
        print("xf_svram(): Cannot use direct mode with writes")
        return 0

    if wrFlag == "WRITE":
      writeFlag = 1   # Write servo RAM

    if self.svram_EnableAddressing:
      status, value = self.ioFcns.getServoIndexValue(svAddrIndex)   # get xf table address
      # print "servo index address = 0x%04X" % value

    if addrMode:  # direct
      pass  # nothing more required, value contains the index pointer
    else:         # indirect
      if writeFlag:
        status = 0
        if self.svram_EnableAddressing:
          addr = value + offset
          stat, value = self.ioFcns.sendServoCmd(0x0001, lsw(addr), 0, msw(addr))     # setup write address
          status |= stat
        stat, value = self.ioFcns.sendServoCmd(0x0201, wData)   # write memory (will write consecutive locations if addressing disabled)
        status |= stat
        value = 0
      else:
        addr = value + offset
        status, value = self.ioFcns.getServoMemoryWord(addr)

    if self.optionBits & 0x0001:  # disable addressing now that it has been setup
      self.svram_EnableAddressing = 0

    if self.resultOutput:
      print("xf_svram(): Servo Address,Offset (0x%X,%d) --> 0x%X (%d)"% (svAddrIndex, offset, value, value))
    return value  # status is not returned, to be compatible with sp version of this function

####################################################################

class ioFcnCls:   # io functions

  def __init__(self, new_asic):
    self.newASIC = new_asic

    self.prm_508_get_read_buffer = {
       # 'test_num' : 508,
       # 'prm_name' : 'prm_508_get_read_buffer',
       'timeout' : 30,

       'PARAMETER_1' :  (0x8005,),  # display Read Buffer (bit15 enables DriveVar, bits 11:8 is high #bytes)
       'PARAMETER_2' :  (0x0000,),  # offset
       'PARAMETER_3' :  (0x0100,),  # number of bytes (0x0100) - the DriveVar does not support more than 64 bytes, but show more here anyway
       'PARAMETER_4' :  (0x0000,),  # high offset byte
       'PARAMETER_5' :  (0x0000,),  # do not use legacy format
    }

    self.prm_638_write_drive_memory = {
       # 'test_num' : 638,
       # 'prm_name' : 'prm_638_write_drive_memory',
       'timeout' : 30,

       "WRITE_SECTOR_CMD_ALL_HDS" : (0x0000,),
       "ATTRIBUTE_MODE" : (0x0001,), # specify transfer params, 0 = let initiator decide params
       "REPORT_OPTION" : (0x0001,),
       "SCSI_COMMAND" : (0x0000,),
       "TEST_FUNCTION" : (0x0000,),
       "BYPASS_WAIT_UNIT_RDY" : (0x0001,),
       "LONG_COMMAND" : (0x0001,),   # enable CMD_BYTE_GROUP_x params
       "CMD_DFB_LENGTH" : (0x0018,), # appears to be required to be >=24 to get params 8 and beyond out

       # the bytes in following words are in little endian format
       "PARAMETER_0" : (0x4A01,),    # WriteDriveMemory DITS function
       "PARAMETER_1" : (0x0100,),    # DITS command revision
       "PARAMETER_2" : (0x0000,),    # low address word
       "PARAMETER_3" : (0x0000,),    # high address word
       "PARAMETER_4" : (0x0000,),    # reserved bytes
       "PARAMETER_5" : (0x0000,),    # transfer length
       "PARAMETER_6" : (0x0000,),    # low byte = area, high byte = reg type
       "PARAMETER_7" : (0x0000,),    # reserved bytes
       "PARAMETER_8" : (0x0000,),    # low data word
       "PARAMETER_9" : (0xFFFF,),    # ignored, high data word is below

       "CMD_BYTE_GROUP_0" : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),   # starts after param 8
       "CMD_BYTE_GROUP_1" : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),
       "CMD_BYTE_GROUP_2" : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),   # last word not used
    }

    self.prm_638_read_drive_memory = {  # rev 1, do not need rev 2 for this case
       # 'test_num' : 638,
       # 'prm_name' : 'prm_638_read_drive_memory',
       'timeout' : 30,

       # set these control params based on an example from the factory process (prm_638_CheckTemp)
       # could not get T638 to transfer to read buffer prior to this change
       "WRITE_SECTOR_CMD_ALL_HDS" : (0x0000,),
       "ATTRIBUTE_MODE" : (0x0000,),
       "REPORT_OPTION" : (0x0000,),
       "SCSI_COMMAND" : (0x0000,),
       "TEST_FUNCTION" : (0x0000,),
       "BYPASS_WAIT_UNIT_RDY" : (0x0001,),
       "LONG_COMMAND" : (0x0000,),

       # the bytes in following words are in little endian format
       "PARAMETER_0" : (0x4901,),    # ReadDriveMemory DITS function
       "PARAMETER_1" : (0x0100,),    # DITS command revision
       "PARAMETER_2" : (0x0000,),    # low address word
       "PARAMETER_3" : (0x0000,),    # high address word
       "PARAMETER_4" : (0x0000,),    # reserved bytes
       "PARAMETER_5" : (0x0000,),    # transfer length
       "PARAMETER_6" : (0x0000,),    # low byte = area, high byte = reg type
       "PARAMETER_7" : (0x0000,),    # reserved bytes
    }

    self.prm_638_send_servo_command = {
       # 'test_num' : 638,
       # 'prm_name' : 'prm_638_read_productID_code',
       'timeout' : 1200,

       "WRITE_SECTOR_CMD_ALL_HDS" : (0x0000,),
       "ATTRIBUTE_MODE" : (0x0000,),
       "REPORT_OPTION" : (0x0001,),
       "SCSI_COMMAND" : (0x0000,),
       "TEST_FUNCTION" : (0x0000,),
       "BYPASS_WAIT_UNIT_RDY" : (0x0001,),
       "LONG_COMMAND" : (0x0000,),
       "CMD_DFB_LENGTH" : (0x000A,),

       # the bytes in following words are in little endian format
       "PARAMETER_0" : (0x4F01,),    # SendServoCommand DITS function
       "PARAMETER_1" : (0x0000,),    # DITS command revision (updated below)
       "PARAMETER_2" : (0x1000,),    # control value
       "PARAMETER_3" : (0x0000,),    # servo command code
       "PARAMETER_4" : (0x0000,),    # servo command parameter 1 (data value)
       "PARAMETER_5" : (0x0000,),    # servo command parameter 2 (data value)
       "PARAMETER_6" : (0x0000,),    # servo command parameter 3 (data value)
       "PARAMETER_7" : (0x0000,),    # servo command parameter 4 (data value)
    }

    self.prm_638_read_servo_index = {
       # 'test_num' : 638,
       # 'prm_name' : 'prm_638_read_servo_index',
       'timeout' : 1200,

       "WRITE_SECTOR_CMD_ALL_HDS" : (0x0000,),
       "ATTRIBUTE_MODE" : (0x0000,),
       "REPORT_OPTION" : (0x0001,),
       "SCSI_COMMAND" : (0x0000,),
       "TEST_FUNCTION" : (0x0000,),
       "BYPASS_WAIT_UNIT_RDY" : (0x0001,),
       "LONG_COMMAND" : (0x0000,),
       "CMD_DFB_LENGTH" : (0x000A,),

       # the bytes in following words are in little endian format
       "PARAMETER_0" : (0x4F01,),    # SendServoCommand DITS function
       "PARAMETER_1" : (0x0000,),    # DITS command revision (updated below)
       "PARAMETER_2" : (0x1000,),    # control value
       "PARAMETER_3" : (0x0105,),    # servo command code (0x0501 = ReadServoSymbolTable)
       "PARAMETER_4" : (0x0800,),    # servo command parameter 1 (symbol index)
    }

    self.prm_638_read_servo_ram_word = {
       # 'test_num' : 638,
       # 'prm_name' : 'prm_638_read_servo_ram_word',
       'timeout' : 1200,

       "WRITE_SECTOR_CMD_ALL_HDS" : (0x0000,),
       "ATTRIBUTE_MODE" : (0x0000,),
       "REPORT_OPTION" : (0x0001,),
       "SCSI_COMMAND" : (0x0000,),
       "TEST_FUNCTION" : (0x0000,),
       "BYPASS_WAIT_UNIT_RDY" : (0x0001,),
       "LONG_COMMAND" : (0x0000,),
       "CMD_DFB_LENGTH" : (0x0010,),

       # the bytes in following words are in little endian format
       "PARAMETER_0" : (0x4F01,),    # SendServoCommand DITS function
       "PARAMETER_1" : (0x0000,),    # DITS command revision (updated below)
       "PARAMETER_2" : (0x1000,),    # control value
       "PARAMETER_3" : (0x0101,),    # servo command code (0x0101 = ReadDataWord)
       "PARAMETER_4" : (0x667D,),    # servo command parameter 1 (LSWord of starting address - 0x7D66)
       "PARAMETER_5" : (0x0000,),    # servo command parameter 2 (not used - 0)
       "PARAMETER_6" : (0x0100,),    # servo command parameter 3 (MSWord of starting address - 0x0001)
       "PARAMETER_7" : (0x0000,),    # servo command parameter 4 (word size: 0 - Read 16-bit Word, 1 - Read 8-bit byte (ARM only), 2 - Read 32-bit Word)
    }

    # update DITS servo command rev, based on ASIC type
    if self.newASIC: rev = 3
    else: rev = 1
    revx = flipw(rev)
    self.prm_638_send_servo_command['PARAMETER_1'] = revx
    self.prm_638_read_servo_index['PARAMETER_1'] = revx
    self.prm_638_read_servo_ram_word['PARAMETER_1'] = revx

    # update servo command returned data buffer offset, based on DITS command rev
    self.SCRevRetDataOffset = 0   # Servo Command Returned Data Offset difference between DITS revs 1 and 3
    if rev == 3: self.SCRevRetDataOffset = 48   # puts rev 3 returned data at same byte location as rev 1 data

#------------------------------------------------------------------#
   # Controller Memory/Register Access:

  def writeCtlrReg(self, addr, value, regSize):
    # regSize = 1, 2, or 4 bytes
    P2 = flipw(lsw(addr))   # LSWord of address
    P3 = flipw(msw(addr))   # MSWord of address
    P5 = flipw(regSize)     # transfer length
    area = 0                # controller address space
    regType = regSize // 2  # DITS cmd uses 0, 1, or 2 for register size
    P6 = flipw((regType << 8) | area)   # DITS cmd uses 0, 1, or 2 for register size
    P8 = flipw(lsw(value))  # LSWord of data
    P9 = flipw(msw(value))  # MSWord of data (cannot use PARAMETER_9, P9 starts in parameter group 0
    PG0 = (P9,0x0000,0x0000,0x0000,0x0000,0x0000,)
    status = _st(638, self.prm_638_write_drive_memory, PARAMETER_2=P2, PARAMETER_3=P3, PARAMETER_5=P5, PARAMETER_6=P6, PARAMETER_8=P8,
      CMD_BYTE_GROUP_0=PG0)
    # print "writeCtlrReg: status %d, addr 0x%X, value 0x%X, regSize %d" % (status, addr, value, regSize)
    return status

  def readCtlrReg(self, addr, regSize):
    # regSize = 1, 2, or 4 bytes
    P2 = flipw(lsw(addr))   # LSWord of address
    P3 = flipw(msw(addr))   # MSWord of address
    P5 = flipw(regSize)     # transfer length
    area = 0        # controller address space
    regType = regSize // 2  # DITS cmd uses 0, 1, or 2 for register size
    P6 = flipw((regType << 8) | area)   # DITS cmd uses 0, 1, or 2 for register size
    status = 0
    status |= _st(638, self.prm_638_read_drive_memory, PARAMETER_2=P2, PARAMETER_3=P3, PARAMETER_5=P5, PARAMETER_6=P6)
    status |= _st(508, self.prm_508_get_read_buffer)   # get returned data value
    bufferData = DriveVars["Buffer Data"]  # 64 bytes max
    strValue = bufferData[0:2*regSize]
    # print "strValue = " + strValue
    value = int(strValue, 16)
    if regSize == 2: value = flipw(value)
    if regSize == 4: value = flipdw(value)
    # print "readCtlrReg: status %d, addr 0x%X, value 0x%X, regSize %d" % (status, addr, value, regSize)
    return status, value

#------------------------------------------------------------------#
   # Drive Memory Access:

  def readDriveMem(self, addr, regSize, byteCount, area = 0):   # max of 64 data bytes returned
    # regSize = 1, 2, or 4 bytes, default area to controller address space (0), servo space area = 2
    P2 = flipw(lsw(addr))   # LSWord of address
    P3 = flipw(msw(addr))   # MSWord of address
    P5 = flipw(byteCount)   # transfer length in bytes
    regType = regSize // 2  # DITS cmd uses 0, 1, or 2 for register size
    P6 = flipw((regType << 8) | area)   # DITS cmd uses 0, 1, or 2 for register size
    status = 0
    status |= _st(638, self.prm_638_read_drive_memory, PARAMETER_2=P2, PARAMETER_3=P3, PARAMETER_5=P5, PARAMETER_6=P6)
    status |= _st(508, self.prm_508_get_read_buffer)   # get returned data value
    bufferData = DriveVars["Buffer Data"]  # DriveVar has 64 byte max
    strValue = bufferData[0:2*byteCount]
    # print "readDriveMem: status %d, addr 0x%X, regSize %d, count %d, area %d" % (status, addr, regSize, byteCount, area)
    # print "strValue = " + strValue
    value = binascii.unhexlify(strValue)
    return status, value

  def writeDriveMem(self, addr, regSize, byteCount, wData, area = 0):   # max of 36 data bytes sent (TSE param limit)
    # regSize = 1, 2, or 4 bytes, default area to controller address space (0), servo space area = 2
    P2 = flipw(lsw(addr))   # LSWord of address
    P3 = flipw(msw(addr))   # MSWord of address
    P5 = flipw(byteCount)   # transfer length in bytes
    regType = regSize // 2  # DITS cmd uses 0, 1, or 2 for register size
    P6 = flipw((regType << 8) | area)   # DITS cmd uses 0, 1, or 2 for register size
    # create a duplicate array and extend it if necessary to ensure enough data to fill P8 and the 3 parameter groups
    dataLength = (1 + 3 * 6) * 2    # P8 + 3 * 6 words, 2 bytes per word
    data = wData + ('\x00' * (dataLength - len(wData)))
    P8 = (ord(data[0]) << 8) + ord(data[1])   # first word of data, flip not required since wData is a byte string
    PG0 = byteArrayToWordTuple(data[ 2:14])
    PG1 = byteArrayToWordTuple(data[14:26])
    PG2 = byteArrayToWordTuple(data[26:38])
    dfb_len = 20 + byteCount    # what works: DFB length = 24 with 4 bytes of data, so extend with this
    status = _st(638, self.prm_638_write_drive_memory, PARAMETER_2=P2, PARAMETER_3=P3, PARAMETER_5=P5, PARAMETER_6=P6, PARAMETER_8=P8,
      CMD_BYTE_GROUP_0=PG0, CMD_BYTE_GROUP_1=PG1, CMD_BYTE_GROUP_2=PG2, CMD_DFB_LENGTH=dfb_len)
    return status

#------------------------------------------------------------------#
   # Servo Command / Servo Memory Access:

# should handle _st return status in the following functions

  def sendServoCmd(self, command, data1, data2 = 0, data3 = 0, data4 = 0):  # data1 is required (no default to 0)
    P3 = flipw(command)   # servo command parameter 3 (command)
    P4 = flipw(data1)     # servo command parameter 4 (first parameter)
    P5 = flipw(data2)     # servo command parameter 5
    P6 = flipw(data3)     # servo command parameter 6
    P7 = flipw(data4)     # servo command parameter 7
    status = 0
    status |= _st(638, self.prm_638_send_servo_command, PARAMETER_3 = P3, PARAMETER_4 = P4, PARAMETER_5 = P5, PARAMETER_6 = P6, PARAMETER_7 = P7)
    status |= _st(508, self.prm_508_get_read_buffer, PARAMETER_2 = self.SCRevRetDataOffset)
    bufferData = DriveVars["Buffer Data"]  # 64 bytes max
    strData = bufferData[38:40] + bufferData[36:38]
    # print "Servo Data Value = 0x%s" % strData
    value = int(strData, 16)
    return status, value

  def getServoMemoryWord(self, address):
    P4 = flipw(lsw(address))   # servo command parameter 1 (LSWord of address)
    P6 = flipw(msw(address))   # servo command parameter 3 (MSWord of address)
    status = 0
    status |= _st(638, self.prm_638_read_servo_ram_word, PARAMETER_4 = P4, PARAMETER_6 = P6)
    status |= _st(508, self.prm_508_get_read_buffer, PARAMETER_2 = self.SCRevRetDataOffset)
    bufferData = DriveVars["Buffer Data"]  # 64 bytes max
    strData = bufferData[38:40] + bufferData[36:38]
    # print "Servo Memory Address 0x%X Data Value = 0x%s" % (address, strData)
    value = int(strData, 16)
    return status, value

  def getServoIndexValue(self, symbol_index):
    P4 = flipw(symbol_index)   # servo command parameter 1 (symbol index)
    status = 0
    status |= _st(638, self.prm_638_read_servo_index, PARAMETER_4 = P4)
    status |= _st(508, self.prm_508_get_read_buffer, PARAMETER_2 = self.SCRevRetDataOffset)
    bufferData = DriveVars["Buffer Data"]  # 64 bytes max
    strAddr = bufferData[50:52] + bufferData[48:50] + bufferData[46:48] + bufferData[44:46]
    # print "Servo Symbol %d Value = 0x%s" % (symbol_index, strAddr)
    value = int(strAddr, 16)
    return status, value

####################################################################

print("xftab.py loaded")
