gMaxUsedHead=svram(88)
print("Goto Write Seek Mode   Max Head = %d" % gMaxUsedHead)
gFlagRSeek=0  # set write seek mode
wsk(gCylinder,gHead)
