try:
   if gMaxUsedHead==0: gMaxUsedHead=svram(88)
except:
   gMaxUsedHead=svram(88)
if gHead<gMaxUsedHead:
   if gFlagRSeek:
      rsk(gCylinder,gHead+1)
   else:
      wsk(gCylinder,gHead+1)
else:
   print("------ Cannot increment above max head %d" % gMaxUsedHead)
