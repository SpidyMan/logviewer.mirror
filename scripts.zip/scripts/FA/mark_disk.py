# xftab.py
version = '1.00'

# Wedge Mode Disc Tagging for serial port (allows negative cylinders)


# --- Parameter Input Section ---

location = [
# specify single or multiple marking locations: function, cylinder, head, wedge [, skip_start, skip_count]
# function is 'tag_wedge' to write a disk tag, or 'band_erase' to just erase a band of tracks
# for 'band_erase', cylinder is starting cylinder of band, then incrementing up (inward)
# can optionally specify a wedge range to skip when writing DC erase tracks (applies to 'tag_wedge' and 'band_erase')
# wedge skip is useful to avoid wedges where servo faults occur which would otherwise prematurely terminate the DC erase
#     skip_start specifies starting wedge number to avoid when performing track DC erase
#     skip_count specifies number of wedges to avoid (starting at skip_start) when performing track DC erase

# examples -
#    ['tag_wedge', -4900, 2, 248, 0, 0, ],
#    ['tag_wedge',  -300, 0, 195, 0, 0, ],
#    ['band_erase', -100, 3,   0, 324, 16, ],
#    ['tag_wedge',  5000, 3, 382, 370, 30, ],

   ['band_erase', -5220, 2, 0, 190, 16],   # skip 16 wedges starting at 190
   ['band_erase',  -100, 2, 0,   0,  0],   # did not need to skip wedges
]

wedgesPerTrack = 448    # for Compass <-- change this to read wedge count from servo

noEraseBandWidth = 7
DCEraseBandWidth = 100
wedgeEraseBandWidth = 200

# --- Functions ---

def postMsg(msg):
   print(msg)
   ScriptComment(msg)

def writeTrack2T(cylinder, head, do_rsk=0):  # (for debug)
   wsk(cylinder, head)                 # write seek to cyl/hd
   ssaw(0, -1, Pattern = 0xCCCC)       # write 2T on all wedges
   if do_rsk: rsk(cylinder, head)

def writeTrack4T(cylinder, head, do_rsk=0):  # (for debug)
   wsk(cylinder, head)                 # write seek to cyl/hd
   ssaw(0, -1, Pattern = 0xF0F0)       # write 4T on all wedges
   if do_rsk: rsk(cylinder, head)

def eraseTrack(cylinder, head, do_rsk=0):
   wsk(cylinder, head)                 # write seek to cyl/hd
   ssaw(0, -1, Pattern = 0x0000)       # erase all wedges
   if do_rsk: rsk(cylinder, head)

def eraseTrackWithSkip(cylinder, head, wedge, count, do_rsk=0):   # CHECK AND HANDLE wedge, count INPUT PARAMETERS ******************
   # same as eraseTrack except do not erase 'count' wedges starting at 'wedge'
   wsk(cylinder, head)                 # write seek to cyl/hd
   resumeWedge = wedge + count         # wedge where erase resumes
   if resumeWedge >= wedgesPerTrack:      # only one erase required in this case
      ssaw(resumeWedge - wedgesPerTrack, wedgesPerTrack - count, Pattern = 0x0000)
   else:                                  # one or two writes required
      if wedge > 0: ssaw(0, wedge, Pattern = 0x0000)    # erase up to but not including starting wedge
      ssaw(resumeWedge, wedgesPerTrack - resumeWedge, Pattern = 0x0000)    # erase second section
   if do_rsk: rsk(cylinder, head)

def eraseWedge(cylinder, head, wedge, do_rsk=0):
   wsk(cylinder, head)                 # write seek to cyl/hd
   ssaw(wedge, 1, Pattern = 0x0000)    # erase wedge
   if do_rsk: rsk(cylinder, head)

# --- Parameter Display Section ---

postMsg("")
postMsg("Serial Port Disk Marking Program")
print("mark_disk.py version " + version)

postMsg("")
postMsg("Tag Location(s):   Cylinder   Head   Wedge   Function")
postMsg("                   --------   ----   -----   --------")
for locIdx in range(len(location)):
   function = location[locIdx][0]
   targetCylinder = location[locIdx][1]
   targetHead = location[locIdx][2]
   targetWedge = location[locIdx][3]
   postMsg("                   %8d   %4d   %5d   %s" % (targetCylinder, targetHead, targetWedge, function))

postMsg("")
postMsg("Tagging Parameters:")
postMsg("   No Erase Band Width            = %d" % noEraseBandWidth)
postMsg("   DC Erase Band Width            = %d" % DCEraseBandWidth)
postMsg("   Wedge Erase Band Width         = %d" % wedgeEraseBandWidth)
postMsg("   Product Servo Wedges per Track = %d" % wedgesPerTrack)

# --- Program Section ---

for locIdx in range(len(location)):

   function = location[locIdx][0]
   targetCylinder = location[locIdx][1]
   targetHead = location[locIdx][2]
   targetWedge = location[locIdx][3]
   skipStart = location[locIdx][4]
   skipCount = location[locIdx][5]

   if function == 'tag_wedge':

      postMsg("")
      postMsg("Tagging in progress: Cylinder %d   Head %d   Wedge %d" % (targetCylinder, targetHead, targetWedge))

      # do the track band DC erases
      postMsg("")
      postMsg("DC Erase Tracks ...")
      postMsg("")
      for direction in range(-1, 2, 2):  # direction is -1 or +1
         cylinder = targetCylinder + (noEraseBandWidth + 1) * direction    # initialize to start cylinder
         for count in range(DCEraseBandWidth):
            postMsg("erase track @ cyl: %d, hd: %d" % (cylinder, targetHead))
            if skipCount > 0:
               eraseTrackWithSkip(cylinder, targetHead, skipStart, skipCount);
            else:
               eraseTrack(cylinder, targetHead);
            cylinder = cylinder + direction

      # do the wedge band DC erases
      postMsg("")
      postMsg("DC Erase Wedges ...")
      postMsg("")
      for direction in range(-1, 2, 2):  # direction is -1 or +1
         cylinder = targetCylinder + (noEraseBandWidth + DCEraseBandWidth + 1) * direction    # initialize to start cylinder
         for count in range(wedgeEraseBandWidth):
            postMsg("erase wedge @ cyl: %d, hd: %d, wdg: %d" % (cylinder, targetHead, targetWedge))
            eraseWedge(cylinder, targetHead, targetWedge);
            cylinder = cylinder + direction

   if function == 'band_erase':

      postMsg("")
      postMsg("Band Erase in progress: Cylinder %d   Head %d" % (targetCylinder, targetHead))

      # do the track band DC erase
      postMsg("")
      postMsg("DC Erase Tracks ...")
      postMsg("")
      direction = 1  # direction is always +1 (inward)
      cylinder = targetCylinder    # initialize to start cylinder
      for count in range(DCEraseBandWidth):
         postMsg("erase track @ cyl: %d, hd: %d" % (cylinder, targetHead))
         if skipCount > 0:
            eraseTrackWithSkip(cylinder, targetHead, skipStart, skipCount);
         else:
            eraseTrack(cylinder, targetHead);
         cylinder = cylinder + direction

postMsg("")
postMsg("Disk Tagging Complete")
