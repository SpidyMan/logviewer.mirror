try:
   if gCylIncrValue==0: gCylIncrValue=1
except:
   gCylIncrValue=1
if gFlagRSeek:
   rsk(gCylinder-gCylIncrValue,gHead)
else:
   wsk(gCylinder-gCylIncrValue,gHead)
