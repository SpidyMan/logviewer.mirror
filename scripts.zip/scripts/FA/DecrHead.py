if gHead>0:
   if gFlagRSeek:
      rsk(gCylinder,gHead-1)
   else:
      wsk(gCylinder,gHead-1)
else:
   print("------ Cannot decrement below head 0")
