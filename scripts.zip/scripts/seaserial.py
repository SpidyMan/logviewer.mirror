SeaSerVers = "2.7.2.4 - SBP3 SUPPORT with RSA2048/3072"

import re
import time
import sys
import os
import traceback
import binascii
import struct
import base64

CR = '\x0D'
prPat = "(?<!.)\>"
DEBUG = 0
"""
DEBUG > 0: General Print Debug
      > 1: Secure Boot Debug
      > 2: Timing/Prompt Read Dub
"""

##SANDBOX_TPM_SUPPORT = 0  #Remove all SANDBOX_TPM_SUPPORT == 1 if statments after ASIC with SBP arrives

def FeedBack(message):
  TraceMessage ("%s" % (message,))
  ScriptComment (message)

FeedBack("SeaSerial Version: %s" % SeaSerVers)

def promptRead(timeout = 30, raiseException = 1, newPrompt = prPat):
   startTime = time.time()
   curTime = time.time()
   result = b''
   if not isinstance(newPrompt, bytes):
       newPrompt = newPrompt.encode()

   prompt = re.compile(newPrompt)

   while (curTime - startTime) < timeout:
      tmpChar = GChar(readSize = 1)
      result += tmpChar

      matches = prompt.findall(result)
      if len(matches) > 0:
         break
      elif b'FlashLED' in result:
         curTime = startTime + timeout
      else:
         curTime = time.time()
   else:
      if b'FlashLED' not in result and raiseException:
         raise ScriptTestFailure("Timeout reached waiting for prompt...Recd: %s" % result)

      elif b'FlashLED' in result and raiseException:
         raise ScriptTestFailure("FlashLED Error...Recd: %s" % result)

   if DEBUG > 2:
      readTime = curTime - startTime
      if readTime > 0:
         FeedBack("PromptReadTime = %s" % (readTime))
   return result.decode(encoding="ISO-8859-1",errors="surrogateescape")

def VerifyPrompt():
   for x in range(10):
      try:
         PBlock('?')
         FeedBack("%s: Verifying command prompt" % (time.asctime(),))
         time.sleep(1)
         res = promptRead(2, 1)
         FeedBack("%s: Verified command prompt" % (time.asctime(),))
         break
      except:
         FeedBack("Failed command prompt verification --- try %d" % (x + 1,))
   else:
      raise ScriptTestFailure("Sync Comm: Reached Timeout. ")

def promptWritePlusVerifyData(cmd='',data = '',bypassFail=False):
   writeString = ''
   if cmd != '':
      writeString = cmd
   if data != '':
      writeString += ' %s' %data
   PBlock(writeString+CR)

   tmpData = b''
   for x in range(10):
      tmpData += GChar(readSize=0)
      if (writeString.encode() in tmpData) and (b'>' in tmpData):
         break
      elif (x == 9) and (bypassFail == False):
         response = "COULDN'T FIND RESPONSE FOR:  %s" %writeString
         FeedBack('%s' %str(response))
         raise ScriptTestFailure("... %s" % str(response))
      time.sleep(0.1)

   return tmpData.decode(encoding="ISO-8859-1",errors="surrogateescape")
def syncBootLoader(uSyncCount = 500, syncRetries = 10):
    FeedBack("\n############################################################")
    FeedBack("###            S Y N C   B O O T   L O A D E R           ###")
    FeedBack("############################################################\n")
    for retry in range(syncRetries):
       try:
          # Put some output U's on the serial out FIFO
          FeedBack("*"*10 + " CLICK OK ON POWER CYCLE BOX BERFORE POWERING ON HDA " + "*"*10)
          DriveOff(10)
          DriveOn(5000, 12000, 0)
          for x in range(10):
            PBlock('%s' % (uSyncCount * 'U'))
            time.sleep(.1)

          # Look for the boot command id
          PBlock('%s' % (CR * 3))
          # Wait for sync data to be flushed from raw boot loader in flash
          time.sleep(1)
          retData = promptRead(10, 1, b'Boot Cmds:')
          # set passing status
          FeedBack("%s: Found Flash program boot prompt" % (time.asctime(),))
          break
       except KeyboardInterrupt:
          raise
       except:
          FeedBack(traceback.format_exc())
          FeedBack("Timeout in Boot synchronizer: %s" % sys.exc_info()[1])
    else:
       raise

def authenticateBootLoader():
   SYMK_CHALLENGE_LEN = 56  #Length of data from AR Command

   promptWritePlusVerifyData('TE')
   response = promptWritePlusVerifyData('AP','00000100',bypassFail=True)
   #AP command supported means ASIC Pre-SBP3 or disabled Secure Binding
   if "Bad cmd:" not in response:
       FeedBack("\n  *****PRE-SBP3 ASIC OR SECURE BINDING DISABLED*****   \n")
       return

   response = promptWritePlusVerifyData('AR',bypassFail=True)
   if "Bad cmd:" in response:
       FeedBack("\n  ***** AR Command Failed *****   \n")
       return


   FeedBack("\n############################################################################")
   FeedBack("###            A U T H E N T I C A T E   B O O T   L O A D E R           ###")
   FeedBack("############################################################################\n")

   challengeBinStr = b''

   #Set Address pointer to 0x100
   promptWritePlusVerifyData('AP','00000100')

   for x in range(SYMK_CHALLENGE_LEN//4):
      response = promptWritePlusVerifyData('RW')
      asciiVal = response[response.rfind('0x') + 2:response.rfind('0x') + 10]
      if DEBUG > 1:
         FeedBack('RW %s' %(asciiVal))
      challengeBinStr += struct.pack('L',int(asciiVal,16))

   #Send request to TDCI
   method,prms = RequestService("TDCIToolRequest",('doMAsymKeyAuthentication', ('nonce',challengeBinStr), HDASerialNumber,'HOST_ID'))

   requestStat = int(prms['EC'][0])

   if requestStat > 0:
      response = 'TDCI FAILURE - ERROR %d: %s' %(requestStat,str(prms['EC'][1]))
      FeedBack('\n%s' %str(response))
      raise ScriptTestFailure("... %s" % str(response))

   signedChallenge = base64.b64decode(prms['AuthenticationResponse'])

   rsaSize = int((len(signedChallenge)-72)*8)

   if DEBUG > 1:
      FeedBack("\n  ***USING RSA%d" %(rsaSize))
      FeedBack('SerialNum: %s' %str(HDASerialNumber))
      FeedBack('TDCI Server Request ErrorCode:%d' %requestStat)
      FeedBack("\n***Signature for authentication: %s  \n" %str(binascii.b2a_hex(signedChallenge)).upper())

   promptWritePlusVerifyData('AP','00000100')
   for x in range(0,len(signedChallenge),4):
      challengeAsciiStr = hex(struct.unpack('L',signedChallenge[x:x+4])[0])[2:].upper().rstrip('L').zfill(8)
      response = promptWritePlusVerifyData('WW',challengeAsciiStr)
      if DEBUG > 1:
         FeedBack("%s" %''.join(response[:response.rfind('>')].splitlines()))

   promptWritePlusVerifyData('AP','00000100')
   promptWritePlusVerifyData('TE')
   response = promptWritePlusVerifyData('RR')

   if 'RSA Verify Passed' in response:
      FeedBack("\n#################################################################################")
      FeedBack("###   A U T H E N T I C A T E   B O O T   L O A D E R   S U C C E S S F U L   ###")
      FeedBack("#################################################################################\n")
   else:
      response = response + '\nUNABLE TO AUTHENICATE TO BOOT LOADER'
      FeedBack("Failed, response: %s" %response)
      raise ScriptTestFailure("... %s" % (response))


def loadTextTPM(filename,EXIT_STRING = 'SEND FILE NOW'):
   FeedBack("\n############################################################")
   FeedBack("###             L O A D    T E X T    T P M              ###")
   FeedBack("############################################################\n")
   cmdFile = open(filename, 'r').readlines()
   # Put a CR out to sync the comm stucture

   VerifyPrompt()

   try:
      FeedBack("%s: Clearing que" % (time.asctime(),))
      PBlock(CR * 3)
      data = GChar(readSize = 0)  # will force GChar to wait for 1 sec
      while b"Bad cmd:" in data: #data returns  bytes and we only need to check
         time.sleep(1)
         data = GChar(readSize = 0)

      FeedBack("%s: Sending TPM Text File" % (time.asctime(),))
      lineNo = 0
      retries = 0
      for line in cmdFile:
         # Check that we aren't sending blank lines
         if lineNo % 200 == 0:
            FeedBack("%s: sending line number %d" % (time.asctime(), lineNo,))
         if not line in ['', '\n', '\r', CR]:
            # Give the command 10 retries
            lineNo += 1
            for x in range(10):
               if 'GO' not in line:
                  # send Command
                  startTime = time.time()
                  PBlock(line.strip() + CR)
                  if DEBUG > 2:
                     sendTime = time.time() - startTime
                     if sendTime > 0:
                        FeedBack("send time %s" % sendTime)
                  # If we didn't tell the TPM to reboot then look for a prompt
                  ret = promptRead(0.5)  # Changed from 2
                  if "Bad cmd:" in ret: retries += 1
                  else: break
               else:
                  FeedBack("Reached End of TPM Text File")
                  break
            else:
                raise ScriptTestFailure("TPM Programming command retries exceeded on line: %d; cmd: %s" % (lineNo, str(line)))

      FeedBack("%s: Sending GO command for reboot" % (time.asctime(),))
      for x in range(10):
        PBlock('GO' + CR)
        FeedBack("%s: Wait for %s" % (time.asctime(),EXIT_STRING))
        ret = promptRead(20, 0, EXIT_STRING,)
        if EXIT_STRING in ret: break
      else:
        response =  "Failed to receive %s response\n" %EXIT_STRING
        FeedBack('%s' %str(response))
        raise ScriptTestFailure("... %s" % str(response))
   except:
      FeedBack(traceback.format_exc())
      raise

   FeedBack("##############     TPM PROGRAMMING COMPLETE     ##############")

def loadBinaryImage(filename, fileType = 'BINARY', protocolInPython = 0):
   FeedBack("\n############################################################")
   FeedBack("###         L O A D  %14s   I M A G E          ###" % (" ".join(fileType),))
   FeedBack("############################################################\n")
   if protocolInPython:
      FOFexecfile(('', 'legacyProtocol.py'))
      serObj = LegacyProtocol()
   try:
      try:
         ret = ''
         blockSize = 512
         FeedBack("%s: Setting baud to 115200" % (time.asctime()))
         SetBaudRate(Baud115200)
         UseESlip(0)

         # flush remnant drive data in buffer
         data = GChar(readSize = 0)
         FeedBack("%s: Flushing queue: %s" % (time.asctime(), data.decode()))

         fData = open(filename, 'rb').read()
         fileSize = len(fData)

         FeedBack("%s: Sending %s IMG File" % (fileType, time.asctime(),))
         runtBlock = (fileSize // blockSize)
         if ((fileSize % blockSize) != 0): runtBlock += 1
         remainSize = fileSize

         for requestBlock in range(runtBlock):
            readSize = remainSize
            if remainSize > blockSize:
              readSize = blockSize
              notAFullRead = chr(0)
            else:
              notAFullRead = chr(1)
            remainSize -= blockSize

            if requestBlock % 100 == 0:
               FeedBack("%s: Sending Block: %d of %d: Size=%d" % (time.asctime(), requestBlock + 1, runtBlock, readSize))
            if requestBlock + 1 == runtBlock:
               FeedBack("%s: Sending Last Block: %d of %d: Size=%d" % (time.asctime(), requestBlock + 1, runtBlock, readSize))

            data = fData[ requestBlock * blockSize: (requestBlock * blockSize) + readSize]

            if protocolInPython:  serObj.SendBuffer(data)
            else:                 SendBuffer(data, checkSRQ = 0)

         FeedBack("%s: Setting baud to 38400" % (time.asctime()))
         SetBaudRate(Baud38400)
         FeedBack("%s: Waiting for flash program complete status" % (time.asctime()))

         try:
            ret = ''
            ret += promptRead(120, 1, 'Done')
         except:
            raise ScriptTestFailure("Failed to receive completion status from drive after flash re-programming")

      finally:
         FeedBack("Return Data:\n%s" % ret)
         UseESlip(1)
   except:
      # traceback.print_exc()
      FeedBack(traceback.format_exc())
      raise

   FeedBack("##############     LOAD %14s IMAGE COMPLETE     ##############" % (" ".join(fileType),))

# sldFile for  backward compatibilty. No longer used
def SeaSerialBoard(txtTPMFile, binImageFile, sldFile = '', protocolInPython = 0):
   for file in [txtTPMFile, binImageFile]:
      if not os.path.isfile(file):
         raise FOFFileIsMissing("Missing File: %s" % file)

   try:
      FeedBack("\n%s:Starting Download...\n" % (time.asctime(),))
      UseESlip(0)
      SetBaudRate(Baud38400)

      FeedBack('Power on the drive in bootstrap mode')
      syncBootLoader()

      VerifyPrompt()

      #If pre-SBP3, this function will exit without authenication as it's not needed
      FeedBack('Authenticate Bootstrap Mode')
      authenticateBootLoader()

      FeedBack('Put text tpm for binary load')
      loadTextTPM(txtTPMFile)

      FeedBack('Load binary flash image')
      loadBinaryImage(binImageFile, protocolInPython = protocolInPython)

      FeedBack("\n%s:   Finished Download...\n" % (time.asctime(),))
   except:
      # traceback.print_exc()
      FeedBack(traceback.format_exc())
      raise

def SeaSerialDump(txtTPMFile, binTarget):
  if not os.path.isfile(txtTPMFile):
    raise FOFFileIsMissing("Missing TPM File: %s" % txtTPMFile)

  try:
    FeedBack(" \n%s:Starting Download...\n" % (time.asctime(),))
    UseESlip(0)
    SetBaudRate(Baud38400)
    FeedBack('Power on the drive in bootstrap mode')
    syncBootLoader()
    FeedBack('Authenticate Bootstrap Mode')
    authenticateBootLoader()
    FeedBack('Dump binary flash image')
    dumpBinaryImage(binTarget, txtTPMFile)
  except:
    FeedBack(traceback.format_exc())
    raise

def dumpBinaryImage(targetFilename, filename, fileType = 'BINARY'):

  ACK = '\x06'
  NAK = '\x15'
  STX = '\x02'
  CRC = '\x43'
  SOH = '\x01'
  EOT = '\x04'

  BINTarget = r'C:\var\merlin3\%s' % (targetFilename,)
  if os.path.exists(BINTarget): raise Exception("%s already exists" % BINTarget)

  FeedBack("\n############################################################")
  FeedBack("###             L O A D    T E X T    T P M              ###")
  FeedBack("############################################################\n")
  cmdFile = open(filename, 'r').readlines()
  # Put a CR out to sync the comm stucture
  for x in range(10):
    try:
      PBlock('?')
      FeedBack("%s: Verifying command prompt" % (time.asctime(),))
      time.sleep(1)
      res = promptRead(2, 1)
      FeedBack("%s: Verified command prompt" % (time.asctime(),))
      break
    except:
      FeedBack("Failed command prompt verification --- try %d" % (x + 1,))
  try:
    FeedBack("%s: Clearing que" % (time.asctime(),))
    PBlock(CR * 3)
    data = GChar(readSize = 0)  # will force GChar to wait for 1 sec
    while b"Bad cmd:" in data:
      # PBlock(CR*3)
      time.sleep(1)
      data = GChar(readSize = 0)

    FeedBack("%s: Sending TPM Text File" % (time.asctime(),))
    lineNo = 0
    retries = 0
    for line in cmdFile:
      # Check that we aren't sending blank lines
      if lineNo % 200 == 0:
        FeedBack("%s: sending line number %d" % (time.asctime(), lineNo,))
      if not line in ['', '\n', '\r', CR]:
        # Give the command 10 retries
        lineNo += 1
        for x in range(10):
          if 'GO' not in line:
            # send Command
            startTime = time.time()
            PBlock(line.strip() + CR)
            if DEBUG > 2:
              sendTime = time.time() - startTime
              if sendTime > 0:
                FeedBack("send time %s" % sendTime)
            # If we didn't tell the TPM to reboot then look for a prompt
            ret = promptRead(0.5)  # Changed from 2
            if "Bad cmd:" in ret: retries += 1
            else: break
          else:
            FeedBack("Reached End of TPM Text File")
            break
    # TPM loaded. Send the Go command
    FeedBack("%s: Sending GO command" % (time.asctime(),))
    PBlock('GO' + CR)
    ret = promptRead(10, 0,)
    FeedBack("Recd: '%s'" % ret)

    # Ymodem protocol begin.
    FeedBack("Ymodem protocol initiated")
    PChar(CRC)
    # Read the header
    # Get the CRC char
    crc = GChar(readSize = 1)
    # Get the SOH char
    soh = GChar(readSize = 1)
    # Get SEQ1 char
    seq1 = GChar(readSize = 1)
    # Get SEQ2 char
    seq2 = GChar(readSize = 1)
    # Pull the remaining bytes from the buffer
    remain = GChar()
    # ACK and CRC the header
    PChar(ACK)
    PChar(CRC)
    FeedBack("Received header block")
    finalResult = b''
    # 11111111 & 00000001 = 1
    # Next packet will have a sequence of 1
    sequence = 1 & 0xFF
    ABORT = 0

    FeedBack("Transfer starting...")
    while not ABORT:
      # Some header will begin with CRC others can begin with STX;
      # Loop on the buffer until you hit an STX. SEQ1 and SEQ2 will follow
      ret = GChar(readSize = 1)
      while not ABORT:
        if ret == CRC:
          ret = GChar(readSize = 1)
          continue
        elif ret == ACK:
          ret = GChar(readSize = 1)
          continue
        elif ret == NAK:
          ret = GChar(readSize = 1)
          continue
        elif ret == STX:
          packetSize = 1024
          break
        elif ret == SOH:
          packetSize = 128
          break
        elif ret == EOT:
          ABORT = 1
          break
        else:
          ret = GChar(readSize = 1)
          continue
      if ABORT:
        break

      # Found STX. Get Sequence characters
      seq1 = GChar(readSize = 1)
      sseq1 = int(hex(ord(seq1)), 16)

      seq2 = GChar(readSize = 1)
      sseq2 = 0xFF - int(hex(ord(seq2)), 16)

      # Verify sequence numbers
      if sseq1 == sequence and sseq2 == sequence:
        length = 0
        data = b''
        while length < packetSize + 2:
          ret = GChar(readSize = 1)
          data += ret
          length += 1
        # Last 2 bytes part of the CRC ignore them
        finalResult += data[:-2]
        # ACK the packet
        PChar(ACK)
        # Increment expected sequence
        sequence = (sequence + 1) & 0xFF
      else:
        # Sequence mismatch... clear the buffer and request retransmission
        FeedBack("CRC Error -- Requesting Retransmission")
        length = 0
        while length < packetSize + 2:
          ret = GChar(readSize = 1)
          length += 1
        PChar(NAK)
        PChar(CRC)

    FeedBack("Flash contents successfully received")
    FeedBack("File length = %d" % len(finalResult))
    FeedBack("Preparing Header")
    # Header block is 72 bytes
    header = ['\x00'] * 72
    file_length = len(finalResult)
    header[22] = '\x0F'  # File type = flash image
    header[4] = '\x40'
    # Store file size at byte 6
    f1 = 6
    # Also store file size starting at byte 26
    f2 = 26
    # Get the string representation of the hexadecimal value of file size
    hexa = hex(file_length)
    # Ignore the '0x' of the hexa string atleast
    start = 2
    # If the string is even, process the first number for example on 0x80000:
    # strip 0x
    # process the 8
    if len(hexa[2:]) % 2 != 0:
      header[f1] = chr(int(hexa[2:3], 16))
      header[f2] = chr(int(hexa[2:3], 16))
      start = 4
      f1 += 1
      f2 += 1
    # Now loop over the rest of the string processing 2 numbers at a time (00, 00)
    for i in range(start, len(hex(file_length)), 2):
      header[f1] = chr(int(hexa[i:i + 2], 16))
      header[f2] = chr(int(hexa[i:i + 2], 16))
      f1 += 1
      f2 += 1
    try:
      fileh = open(BINTarget, "wb")
      for item in header:
        fileh.write("%s" % item)
      fileh.write(finalResult)
    except: raise
    fileh.close()
    FeedBack("Flash contents successfully received")
  except:
    FeedBack(traceback.format_exc())
    raise

def SeaSerialEraseFlash(txtTPMFile):
  if not os.path.isfile(txtTPMFile):
    raise FOFFileIsMissing("Missing TPM File: %s" % txtTPMFile)

  try:
    FeedBack(" \n%s:Starting Download...\n" % (time.asctime(),))
    UseESlip(0)
    SetBaudRate(Baud38400)
    FeedBack('Power on the drive in bootstrap mode')
    syncBootLoader()
    FeedBack('Authenticate Bootstrap Mode')
    authenticateBootLoader()
    FeedBack('Dump binary flash image')
    eraseFlash(txtTPMFile)
  except:
    FeedBack(traceback.format_exc())
    raise
  finally:
    UseESlip(1)

def eraseFlash(txtTPMFile):
   FeedBack("\n############################################################")
   FeedBack("###             L O A D    T E X T    T P M              ###")
   FeedBack("############################################################\n")
   cmdFile = open(txtTPMFile, 'r').readlines()
   # Put a CR out to sync the comm stucture
   for x in range(10):
      try:
         PBlock('?')
         FeedBack("%s: Verifying command prompt" % (time.asctime(),))
         time.sleep(1)
         res = promptRead(2, 1)
         FeedBack("%s: Verified command prompt" % (time.asctime(),))
         break
      except:
         FeedBack("Failed command prompt verification --- try %d" % (x + 1,))
   else:
      raise ScriptTestFailure("Sync Comm: Reached Timeout. ")

   try:
      FeedBack("%s: Clearing que" % (time.asctime(),))
      PBlock(CR * 3)
      data = GChar(readSize = 0)  # will force GChar to wait for 1 sec
      while b"Bad cmd:" in data:
         time.sleep(1)
         data = GChar(readSize = 0)

      FeedBack("%s: Sending TPM Text File" % (time.asctime(),))
      lineNo = 0
      retries = 0
      for line in cmdFile:
         # Check that we aren't sending blank lines
         if lineNo % 200 == 0:
            FeedBack("%s: sending line number %d" % (time.asctime(), lineNo,))
         if not line in ['', '\n', '\r', CR]:
            # Give the command 10 retries
            lineNo += 1
            for x in range(10):
               if 'GO' not in line:
                  startTime = time.time()
                  PBlock(line.strip() + CR)
                  if DEBUG > 2:
                     sendTime = time.time() - startTime
                     if sendTime > 0:
                        FeedBack("send time %s" % sendTime)
                  # If we didn't tell the TPM to reboot then look for a prompt
                  ret = promptRead(0.5)  # Changed from 2
                  if "Bad cmd:" in ret: retries += 1
                  else: break
               else:
                  FeedBack("Reached End of TPM Text File")
                  break
            else:
                raise ScriptTestFailure("TPM Programming command retries exceeded on line: %d; cmd: %s" % (lineNo, str(line)))

      FeedBack("%s: Sending GO command for reboot" % (time.asctime(),))
      for x in range(10):
        PBlock('GO' + CR)
        FeedBack("%s: Wait for ERASING FLASH" % (time.asctime()))
        ret = promptRead(60, 0, 'ERASING FLASH')
        if 'ERASING FLASH' in ret:
          FeedBack("Recd: '%s'" % ret)
          break
        FeedBack("Recd: '%s'" % ret)
      else:
        raise ScriptTestFailure("Failed to receive ERASING FLASH response\n")

      try:
          FeedBack("\nWaiting to receive completion status from drive. This may take up to 30 seconds...")
          ret = ''
          ret += promptRead(120, 1, 'Done')
          FeedBack("Completion received!")
      except:
          raise ScriptTestFailure("Failed to receive completion status from drive after flash re-programming")
   except:
      FeedBack(traceback.format_exc())
      raise

   FeedBack("##############     Flash Erase Complete    ##############")

