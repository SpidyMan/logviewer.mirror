import sys, binascii, struct, time, os, stat, types, string, traceback
####################################################################
print("scriptfuncs.py: Version 4.06  %s" % time.ctime(os.stat(r"C:\var\merlin3\scripts\scriptfuncs.py")[stat.ST_MTIME]))
try:
  print("DeviceType = '%s'" % DeviceType)
except:
    DeviceType = "MIRKWOOD"
    print("'DeviceType' not exported. Please install WinFOF version 1.7 or later.")
####################################################################

# These are the common baud rates that PL-2303, CP210X and FT230RL support by default.
# If the user wants to use, any other baud rate, then those baud rates must be registered first.
# #UARTBaudList = [Baud38400, Baud115200, Baud460800, Baud921600]

# # Will Depreacte RegisterBaudRate calls in the future releases of WinFOF.
# # Let users set any baud they want, if it fails then they can try another baud. Do not automatically make decision for them.
# UARTBaudList = [Baud9600,   Baud9615,   Baud19200,  Baud37500,  Baud38400,
#                Baud57600,  Baud75000,  Baud115200, Baud230400, Baud375000,
#                Baud384000, Baud390000, Baud460800, Baud625000, Baud921600, Baud1228000]

def RegisterBaudRate(baudList, set = 1):
   print("!!!!   RegisterBaudRate is deprecated and will be removed in a future release. No need to register baud rate any more.   !!!!")
   print("!!!!   RegisterBaudRate is deprecated and will be removed in a future release. No need to register baud rate any more.   !!!!")
   print("!!!!   RegisterBaudRate is deprecated and will be removed in a future release. No need to register baud rate any more.   !!!!")

#   if DeviceType != 'HYPERPORT':
#      print "RegisterBaudRate: Only required for USB-UARTs."
#      return

#   import types
#   if isinstance(baudList,types.IntType):
#       baudList = [baudList]

#   if not isinstance(baudList,types.ListType) or 0 in [isinstance(baud,types.IntType) for baud in baudList]:
#       raise Exception,"RegisterBaudRate: baud rate should be a integer or a list of integers."

#   for baud in baudList:
#      if DeviceType == "HYPERPORT" and set:
#         if  baud not in UARTBaudList:  UARTBaudList.append(baud)
#      elif DeviceType == "HYPERPORT" and not set:
#         if  baud in UARTBaudList:  UARTBaudList.remove(baud)

#   print "The Baud rates supported by this USB-UART are: %s"%UARTBaudList
####################################################################

def dbg(msg):
  """
  Print Stub
  @param msg: String input to print to stdout
  """
  print(msg)
####################################################################

'''def bytes(the_word):
  """
  Return tuple of bytes from a word
  """
  return ((the_word >> 8) & 0xFF, the_word & 0xFF)'''
####################################################################

def lbytes(the_lword):
  """
  Return tuple of bytes from long/double word
  """
  return ((the_lword >> 24) & 0xFF, (the_lword >> 16) & 0xFF, (the_lword >> 8) & 0xFF, the_lword & 0xFF)
####################################################################

def lwords(the_lword):
  """
  Return tuple of words from long/double word
  """
  return (((the_lword >> 16) & 0xFFFF), the_lword & 0xFFFF)
####################################################################

def rb(timeout = 10):
  """
  Call CM function RecieveBuffer(timeout)
  @return: buffer contents in binary string
  """
  return ReceiveBuffer(timeout)
####################################################################


ALL_CHARACTERS = bytearray.maketrans(b'', b'').decode(encoding="ISO-8859-1") #type <class 'str'>
NON_PRINTABLE_CHARACTERS = ALL_CHARACTERS.translate(string.printable) #type <class 'str'>
# A 256 character translation table.  All non-printable characters are replaced with '.' (a period character).
PRINTABLE_TRANSLATE = "".join((ch in string.printable) and ch or '.' for ch in ALL_CHARACTERS) #type <class 'str'>

def cleanASCII(self, data):
      return data.translate(ALL_CHARACTERS, NON_PRINTABLE_CHARACTERS)

def printBin(binData, lineWidth = 32, retBuf = 0, insertAddr = 0):
  chars = [binascii.hexlify(bytes([ch])).decode() for ch in binData]
  #if cannot use [binascii.hexlify(chr(ch).encode('latin-1')).decode() for ch in binData]
  data = __printBin(chars, lineWidth, retBuf, insertAddr)
  return data

def printBinAscii(binData, lineWidth = 32, retBuf = 0):
  binData = binData.translate(PRINTABLE_TRANSLATE)
  __printBin(binData, lineWidth, retBuf)

def __printBin(chars, lineWidth, retBuf, insertAddr):
  addr = 0
  if insertAddr: result = "%08X   " % addr
  else:          result = "++ "
  addr += lineWidth
  while chars:
    for group in range(lineWidth // 8):
      charSet, chars = chars[:8], chars[8:]
      result = "%s%s   " % (result, " ".join(charSet),)
      if not chars: break

    if insertAddr:  result = "%s\n%08X   " % (result.strip(), addr,)
    else: result = "%s\n   " % (result.strip(),)
    addr += lineWidth

  print("\n", result.strip())
  if retBuf: return "\n" + result.strip()
  else: return None
####################################################################
displayBuffer = printBin
####################################################################
# def displayBuffer(buf):
#  """
#  Print a binary string buffer to the string in "pretty" format- bit separated hex
#  """
#  data = binascii.hexlify(buf)
#  i1=0
#  cnt=0
#  print "   ",
#  for i2 in range(2,len(data),2):
#     print data[i1:i2],
#     i1=i2
#     cnt+=1
#     if cnt == 8 or cnt == 16 or cnt == 24:
#         print "  ",
#     if cnt == 32:
#         cnt=0
#         print "\n   ",
#  print data[i1:]

####################################################################
def p3():
  """
  Change baud to 115200 on drive and host using non-ESLIP com.
  """
  fn(1331)  # CHANGE_BAUD_TO_115K  use 1280 for hi baud rate, use 1351 for low baud rate.
  SetBaudRate(Baud115200)
  dbg("  p3() complete\n")
####################################################################
def p5():
  """
  Change baud to 390000 on drive and host using non-ESLIP com.
  """
  fn(1280, maxRetries = 1)  # Use 1280 for hi baud rate, use 1351 for low baud rate, 1331 for mid baud.
  SetBaudRate(Baud390000)
  dbg("  p5() complete\n")
####################################################################

def SetESlipLoBaud(FirstBaud = "Current Baud"):
  print("!!!!   SetESlipLoBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  print("!!!!   SetESlipLoBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  print("!!!!   SetESlipLoBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  SetESlipBaud(Baud38400)
####################################################################

def SetESlipMidBaud(FirstBaud = "Current Baud"):
  print("!!!!   SetESlipMidBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  print("!!!!   SetESlipMidBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  print("!!!!   SetESlipMidBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  SetESlipBaud(Baud115200)
####################################################################

# MaxBaud used for HyperPort Devices
def SetESlipHiBaud(MaxBaud = 115200, FirstBaud = "Current Baud"):
  print("!!!!   SetESlipHiBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  print("!!!!   SetESlipHiBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  print("!!!!   SetESlipHiBaud is deprecated and will be removed in a future release. Please use SetESlipBaud(baudrate) instead.   !!!!")
  SetESlipBaud(Baud390000)
####################################################################

def SetESlipBaud(finalBaud, FirstBaud = "Current Baud"):
  UseESlip(1)
  baudList = ["Current Baud", Baud38400, Baud115200, Baud390000, Baud460800, Baud625000, Baud921600, Baud1228000, Baud3000000, Baud6000000]

  if not finalBaud in baudList:
     TraceMessage("Error: Unsupported baud rate: %s\nSupported Baud Rates: %s" % (finalBaud, baudList[1:],))
     raise Exception("Invalid Baud Rate")

  if finalBaud <= 1228000:
    sendData = "00000%s00" % (baudList.index(finalBaud),)
  else:
    if finalBaud == 3000000:
      sendData = "00000900"
    if finalBaud == 6000000:
      sendData = "00000A00"
  sendData = binascii.unhexlify(sendData)
  logString = "SetESlipBaud(%d)" % finalBaud

  if FirstBaud in baudList:
     baudList.remove(FirstBaud)
  baudList = [FirstBaud, ] + baudList

  for baud in baudList:
     if baud != "Current Baud": SetBaudRate(baud)
     try:
        SendBuffer(sendData, fromAddress = 0x8001, toAddress = 0x8002, checkSRQ = 0, maxRetries = 1)
     except:
        TraceMessage("%s:         Failed at %s" % (logString, baud,))
        if baud == baudList[-1]: raise  # raise exception, if fails at all baud rates
        continue
     else:
        buf = ReceiveBuffer(fromAddress = 0x8002, toAddress = 0x8001, timeout = 5, maxRetries = 1)
        TraceMessage("%s:         Passed at %s" % (logString, baud,))
        break
  ScriptPause(0.2)  # Without this delay, boards like DJTE1179 - have issues changing the baud rate.
  SetBaudRate(finalBaud)
####################################################################

def SetHiBaud(MaxBaud = 115200):
  UseESlip(0)
  if DeviceType == "MIRKWOOD" or MaxBaud == 390000:
     finalBaud = Baud390000
  elif DeviceType == "HYPERPORT":
     finalBaud = Baud115200

  SetBaudRate(Baud38400)
  SetBaudRate(finalBaud)
####################################################################

def SetMidBaud():
  UseESlip(0)
  SetBaudRate(Baud38400)
  fn(1331)  # Set Drive to mid baud rate
  SetBaudRate(Baud115200)
####################################################################

def removeDuplicatePath():
    # sys.path = list(set(sys.path))
    sys.path = [ x for i, x in enumerate(sys.path) if i == sys.path.index(x) ]

# def updateSysPath(baseDir=UserScriptPath, removePath=[]):
#  for fname in os.listdir(baseDir):
#    pName = os.path.normcase(os.path.join(baseDir,fname))
#    if os.path.isdir(pName) and pName not in sys.path:
#       sys.path.append(pName)

#  if isinstance(removePath,basestring):
#       removePath = [removePath]

#  if not isinstance(removePath,list) or 0 in [isinstance(fname,basestring) for fname in removePath]:
#       raise Exception,"updateSysPath: removePath should be a string or a list of strings."

#  for pName in removePath:
#    while pName in sys.path: sys.path.remove(pName)
####################################################################

# Get Drive SN when controller firmware is on the drive (using DITS)
def getDriveSN(option = 1):
  UseESlip(1)
  hdaSN = "Unknown"

  # Unlock the drive
  # Function ID         =  0xFFFF        (2-Bytes)
  # Revision ID         =  0x01          (2-Bytes)
  # Seagate Unlock Code =  0x34F329A     (4-Bytes)
  SendBuffer(b"\xFF\xFF\x01\x00\x9a\x32\x4f\x03", checkSRQ = 0, fromAddress = 0o1, toAddress = 0o1)
  data = ReceiveBuffer(checkSRQ = 0, fromAddress = 0o1, toAddress = 0o1, timeout = 15)
  displayBuffer(data)

  if len(data) >= 4 and data[:4] == "\x00\x03\x10\x03":
     print("\n###########    SELF-TEST Code on the drive    ###########")

     # # Send Command 1
     # try:
     #    data = SendAndReceiveBuffer(chr(1))
     # except:
     #  print "SendAndReceiveBuffer failed...."
     #  SendBuffer(chr(1))
     #  data = ReceiveBuffer(checkSRQ=1, timeout=100)
     # cardSN = data[9:21]

     if not UPSEnabled: st(166, CWORD1 = (0x0800), timeout = 300)
     else:              st(166, Cwrd1 = (0x0800), timeout = 300)
     if "PCBA_NUM" in DriveVars:
        cardSN = DriveVars["PCBA_NUM"]
     else:
        print("DriveVars %s has no PCBA_NUM value" % (repr(list(DriveVars.keys())),))
        return hdaSN

     cardSN = cardSN[4:]

  else:
      print("\n###########    TARGET Code on the drive    ###########")

      # # Since option to directly read drive serial number (0x00) is not working in Get Drive Information (0x156) command,
      # # we will use either Unit Serial Numbers Inquire page (0x05) or Drive Information inquire page(0x04)

      # if option == 1:
      #  # Drive Information Inquiry Page
      #  # Function ID           =  0x0156        (2-Bytes)
      #  # Revision ID           =  0x01          (2-Bytes)
      #  # Information Specifier =  0x04          (1-Byte)
      #  SendBuffer("\x56\x01\x01\x00\x04\x00\x00\x00", checkSRQ=0, toAddress=01, fromAddress=01)
      #  data = ReceiveBuffer(checkSRQ=0, fromAddress=01, toAddress=01, timeout=15)
      #  hdaSN = data[52:60]

      # else:
      #  # Unit Serial Numbers Inquiry Page
      #  # Function ID           =  0x0156        (2-Bytes)
      #  # Revision ID           =  0x01          (2-Bytes)
      #  # Information Specifier =  0x05          (1-Byte)
      #  SendBuffer("\x56\x01\x01\x00\x05\x00\x00\x00", checkSRQ=0, toAddress=01, fromAddress=01)
      #  data = ReceiveBuffer(checkSRQ=0, fromAddress=01, toAddress=01, timeout=15)
      #  hdaSN = data[20:28]

      # Unit Serial Numbers Inquiry Page
      # Function ID           =  0x0156        (2-Bytes)
      # Revision ID           =  0x01          (2-Bytes)
      # Information Specifier =  0x05          (1-Byte)
      SendBuffer(b"\x56\x01\x01\x00\x05\x00\x00\x00", checkSRQ = 0, toAddress = 0o1, fromAddress = 0o1)
      data = ReceiveBuffer(checkSRQ = 0, fromAddress = 0x01, toAddress = 0o1, timeout = 15)

      if len(data) >= 40:
         cardSN = data[32:40]
      else:
         print("Could not find PCBA Serial number in Unit Serial Number Inquiry Page: %s" % (binascii.hexlify(data),))
         displayBuffer(data)
         return hdaSN

  print("PCBA SN: %s" % cardSN)
  # New Host Service to update the hdaSN (using Card SN) in host database
  hdaSN = RequestService('GetDriveSN', (cardSN,))[1]

  return hdaSN
####################################################################

# The data (if more than one byte needs to sent) must be converted to litte endian by the user
def DitsCommand(FunctionID, data, RevID = 1):
    import struct
    data = struct.pack("<2H", FunctionID, RevID) + data
    SendBuffer(data, checkSRQ = 0, toAddress = 0o1, fromAddress = 0o1)
    return ReceiveBuffer(checkSRQ = 0, fromAddress = 0o1, toAddress = 0o1, timeout = 15)
####################################################################

####################################################################
####################################################################
# ##   Overlay download request handler
####################################################################
global OVL_FileLength, OVL_FileName
OVL_FileName = None
OVL_FileLength = 0

def processRequest70(requestData, *args, **kargs):
   global OVL_FileLength, OVL_FileName

   # requestData is a string from the UUT asking for a block from a file
   # return a frame, raise an exception on error

   if not OVL_FileName:
      OVL_FileName = FileRequestDialog("Select Overlay File")
      if not OVL_FileName:
         msg = "Drive requests file data from overlay but there is no file registered as overlay."
         raise FOFFileIsMissing(msg)

   if not os.path.isfile(OVL_FileName):
      msg = "Missing File: %s" % OVL_FileName
      print(msg)
      raise FOFFileIsMissing(msg)
   else:
      OVL_FileLength = os.stat(OVL_FileName)[stat.ST_SIZE]

   requestKey = requestData[0:1]
   # code 6 typically requests a block of data from the download file;  get_data_file()
   if requestKey in b'FG': # requestKey == 70 or requestKey == 71:
     blockSize,requestBlock = struct.unpack('<2H',requestData[2:6])  # little Endian
     requestBlockS = requestData[4:6]
   else:
     str = "Unsupported requestKey in processRequest70==>", requestKey
     raise FOFParameterError(str)

   # look up the file size, and validate the block request
   # fileSize = self.getFileSize()
   fileSize = OVL_FileLength  # a global from above

   # *Every* file has a last block called the runt block, and the runt block will be sized from 0 to (blockSize-1) (e.g. 0 to 511)
   # It is legal for the firmware to request the runt block, but no blocks beyond that.
   # If the firmware requests the runt block, we'll read a partial block from the file, and set the 'notAFullRead' flag in the response packet.
   runtBlock = fileSize / blockSize
   runtSize = fileSize % blockSize

   # print "Sending Block: %d of %d"%(requestBlock+1, runtBlock)
   if requestBlock == 1: print('Downloading Overlay file: "%s"' % OVL_FileName)
   if (requestBlock % 80) / 79: print(".")
   else: print(".else", end=' ')

   if requestBlock < runtBlock:
     readSize = blockSize
     notAFullRead = b'\x00'
   elif requestBlock == runtBlock:
     readSize = runtSize
     notAFullRead = b'\x01'
   else:
     str = "processRequest70(): Request for block %s is beyond than last block %s." % (requestBlock, runtBlock)
     raise FOFParameterError(str)

   # read from their file
   # fileObj = self.dlfile[FILEOBJ]
   fileObj = open(OVL_FileName, "rb")
   fileObj.seek(requestBlock * blockSize)
   data = fileObj.read(readSize)
   fileObj.close()
   #returnData = requestData[0] + notAFullRead + requestLO + requestHI + data
   returnData = b"".join((requestKey,notAFullRead,requestBlockS,data))

   SendBuffer(returnData)

####################################################################
def RegisterOvCall(fileName = None):
   global OVL_FileLength, OVL_FileName
   if fileName:
     OVL_FileName = fileName
     if not os.path.isfile(OVL_FileName):
        msg = "Missing File: %s" % OVL_FileName
        print(msg)
        raise FOFFileIsMissing(msg)
     else:
        OVL_FileLength = os.stat(OVL_FileName)[stat.ST_SIZE]
        # print "DL file len = " , OVL_FileLength
   else:
      OVL_FileName = None
   # intercept request key 70 (SPT) and 71 (Initiator) from core code
   if isinstance(OVL_FileName, str) and OVL_FileName.find('OverlayFileNameCache') > -1:
     print('Using Cached Overlay file')
   else:
     print("Registering Overlay File: '%s'" % OVL_FileName)
   RegisterResultsCallback(processRequest70, [70, 71], 0)
####################################################################

# Register callback for request 70 and if the user did not
# call RegisterOvCall with a file name, then processRequest70 would
# call FileRequestDialog and prompt user to enter file name
def UseCachedOverlayName():
  fname = ''
  cacheFile = os.path.join(UserDownloadsPath, "%02d-%d-OverlayFileNameCache" % (CellIndex, TrayIndex,))
  if os.path.exists(cacheFile):
     fd = open(cacheFile, 'r')
     fname = fd.read()
     fd.close()
     RegisterOvCall(fname)
  else:
     print("Cached Overlay file does not exist. Resetting Overlay file name.")
     RegisterOvCall(None)
####################################################################

####################################################################
#
####################################################################
def dexModulesReload():
  try:
    dexFileLoc = "dex."
    if (isinstance(DexFilePath, tuple) and 2 == len(DexFilePath)):
       dexFileLoc = DexFilePath[0]
       if dexFileLoc: dexFileLoc = dexFileLoc + '.'
  except: dexFileLoc = "dex."

  modulesToBeRemoved = ['parseresults', 'resultshandlers', 'tabledictionary', 'viewerextractors']
  modulesToBeRemoved = [ '%s%s' % (dexFileLoc, mod,) for mod in modulesToBeRemoved ]
  print("Reload: ", modulesToBeRemoved)

  for i in range(2):  # Have to do this twice to get all module linkages properly
    for mod in modulesToBeRemoved:
      # if sys.modules.has_key(mod): del sys.modules[mod]
      if mod in sys.modules:  reload(sys.modules[mod])

####################################################################
# DEX Parser
####################################################################
def getDexHandler():
   try:
       paramFileLoc = ParamFilePath
       if (isinstance(ParamCodeFile, tuple) and len(ParamCodeFile) == 2):
          paramFileLoc = os.path.join(ParamFilePath, ParamCodeFile[0])
   except: pass
   try:
       dexFileLoc = "dex"
       if (isinstance(DexFilePath, tuple) and len(DexFilePath) == 2):
          dexFileLoc = DexFilePath[0]
          if dexFileLoc: importStr = "%s.parseresults" % dexFileLoc
          else:          importStr = "parseresults"
   except: importStr = "dex.parseresults"

   try:
      dexMod = __import__(importStr)

      if  hasattr(dexMod, "parseresults"): ResultsParser = dexMod.parseresults.ResultsParser
      else: ResultsParser = dexMod.ResultsParser

      # The destructor inside DEX for resultshandler has some timing issue and it clears Stream class object.
      # Call destructor before calling createHandlers()
      try:
        del ResultsParser.resultsHandlers
      except: pass

      # createHandlers(self,textResultsOnly=0,paramResultsOnly=0,paramFilePath="",ignoreSpcId=0,errorCodeFile="",procErrorCodeFile="",messagesFile="",winFOFInstance=None):
      # ResultsParser.createHandlers(textResultsOnly=1, paramFilePath=os.path.join(paramFileLoc, "param_cd.h"), errorCodeFile=os.path.join(paramFileLoc,"codes.h"), procErrorCodeFile=os.path.join(paramFileLoc,"proc_codes.h"),messagesFile=os.path.join(paramFileLoc,"messages.h"), winFOFInstance=1)
      ResultsParser.createHandlers(textResultsOnly = 1, paramFilePath = os.path.join(paramFileLoc, "param_cd.h"), errorCodeFile = os.path.join(paramFileLoc, "codes.h"), messagesFile = os.path.join(paramFileLoc, "messages.h"), winFOFInstance = 1)

      return ResultsParser.resultsCallBack
   except:
      print("<<<< Initialilize DEX Parser failed.")
      print("<<<< Make sure that you have DEX v2.14 or higher installed.")
      raise

dexHandler = None
dexParserEnabled = False

def dexParserOn():
   global dexHandler, dexParserEnabled
   if dexHandler == None:
      dexHandler = getDexHandler()
   dexParserEnabled = True
   RegisterResultsCallback(dexHandler)

def dexParserOff():
    RegisterResultsCallback(None)
    global dexHandler, dexParserEnabled
    dexHandler = None
    dexParserEnabled = False
####################################################################

# Display all the data received from the drive, while running a test
def prnDrvData(buf, *args, **kargs):
   # print "==> %s"%(binascii.hexlify(buf),)
   # ScriptComment("==> %s"%(binascii.hexlify(buf),))
   displayBuffer(buf)

def ShowResponse(flag = 1, requests = list(range(0, 255))):
   if flag:
      if requests == list(range(0, 255)): print("Registered CallBack : Print everything coming from the drive.")
      else: print("Registered CallBack : Print data for requests: %s" % requests)
      RegisterResultsCallback(prnDrvData, requests, 1)

   else:
      # print "Registered CallBack : Print everything coming from the drive."
      RegisterResultsCallback(None, requests, 1)
      global dexParserEnabled
      if 'dexParserOn' in globals() and dexParserEnabled:
         dexParserOn()
####################################################################


def fx(val):
    if int(val) == val:
        msb, lsb = lwords(int(val))
        return msb, lsb, 0
####################################################################

def floatX(floatVal, prec = 'f'):  # floatStr - string representation of the floating point value, prec - 'f' for single precision or 'd for double precision
   if int(floatVal) == floatVal:
      integerVal = int(floatVal)
      fraction = ""

   else:
      intgr, fraction = str(floatVal).split(".")
      integerVal = int(intgr + fraction)

   flt_ints = 0
   if prec == 'f':
      if (integerVal > 0xffffffff):
         print("Error: Floating point precision or value too large for single prec: %f" % floatStr)
      else:
         flt_ints = integerVal >> 16 & 0xFFFF, integerVal & 0xFFFF, -len(fraction)
   if prec == 'd':
      flt_ints = integerVal >> 48 & 0xFFFF, integerVal >> 32 & 0xFFFF, integerVal >> 16 & 0xFFFF, integerVal & 0xFFFF, -len(fraction)

   return flt_ints
####################################################################

import struct
def doubleTo64Bit(value):
	return struct.unpack('Q', struct.pack('d', value))[0]

def doubleFrom64Bit(bits):
  return struct.unpack('d', struct.pack('Q', bits))[0]

def floatTo32Bit(value):
	return struct.unpack('L', struct.pack('f', value))[0]

def floatFrom32Bit(bits):
  return struct.unpack('f', struct.pack('L', bits))[0]
####################################################################

# Skua has a hardware bug that requires a power-cycle any time you update flash.
# SPT code sends 0xbebe along with test completion (2). The scripts should power-cycle
# the drive and renegotiate baudrate when it receives this packet.
def processRequest2(requestData, *args, **kargs):
   requestKey = ord(requestData[0])
   if requestKey == 2:
     displayBuffer(requestData)
     if len(requestData) > 7 and ord(requestData[5]) == 0xbe and ord(requestData[6]) == 0xbe:
        DriveOff(pauseTime = 5)
        DriveOn(pauseTime = 5)
        SetBaudRate(38400)
        RegisterBaudRate(1228000)
        SetESlipBaud(1228000)
   else:
     str = "Unsupported requestKey in processRequest2==>", requestKey
     raise FOFParameterError(str)

# Uncomment if using Skua drive.
# RegisterResultsCallback(processRequest2, 2, 1)
####################################################################

def DisplayCTypesObject(obj, mode = 1):
  from ctypes import Array
  str = obj.__class__.__name__ + " struct:\n"

  if isinstance(obj, Array):
    for index in range(obj._length_):
      str += "\t[%d]:  %s\n" % (index, obj[index])

  else:
    for fieldData  in obj._fields_:
      try: fieldName, fieldType = fieldData
      except: fieldName, fieldType, bitOp = fieldData

      if not isinstance(getattr(obj, fieldName), Array):
        str += "%20s:  %s\n" % (fieldName, repr(getattr(obj, fieldName)))
      else:
        if mode: str += "%14s[%d..%d]:  " % (fieldName, 0, getattr(obj, fieldName)._length_)
        for index in range(getattr(obj, fieldName)._length_):
          if mode: str += "%s, " % (getattr(obj, fieldName)[index],)
          else:    str += "%17s[%d]:  %s\n" % (fieldName, index, getattr(obj, fieldName)[index])
        if mode: str += "\n"

  print(str)
#######################################

#########################################################################
# ##  Default Initialization Steps.
# ##  Add all your customizations inside C:\var\merlin3\scripts\userCustom.py
# ##  Do not make changes here as this file is overwritten during
###  WinFOF installation.!!!
#########################################################################
try:
  UseESlip(1)
  dexParserOn()
  FOFexecfile(("", "cudacom.py"))  # This should be replaced by cudacomUPS.py if using UPS.
  FOFexecfile(("", "seaserial.py"))
  FOFexecfile(("", "hyperpower.py"))
  FOFexecfile(("", "parmX.py"))

  # RegisterOvCall()
  UseCachedOverlayName()  # Do not prompt for Overlay file name. Use last overlay file used.
except:
  traceback.print_exc()

#############################################
try:    FOFexecfile(("", "userCustom.py"))
except: pass
#############################################
