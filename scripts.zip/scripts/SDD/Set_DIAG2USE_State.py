
#####################################################################
#
# $RCSfile: Set_DIAG2USE_State.py,v $LightingBug_SAS_SED_regression.py
# $Revision$1.0.0
# $Date$11/11/07
# $Author$robert.stafki
#
#
# REFERENCES:
# * Hurricane FC FDE Drive Personalization Doc
# * TCG Storage Architecture Core Spec
# * M2TD Cryptographic Infrastructure - KCI Interface Spec
#
#####################################################################

import random, binascii, struct, base64, time, sys


# *** GLOBALS
global lastInitiatorData
lastInitiatorData = 0x0
global lastInitiatorFileName
lastInitiatorFileName = ""



testHardware = 1 # 0 = no initiator/fde-drive, server calls only
if testHardware == 0:
  noTestHardware = 1
else:
  noTestHardware = 0

def tMsg(msg):
  TraceMessage(msg+"\n")

def statMsg(msg):
  TraceMessage(msg)
  ScriptComment(msg)


CN='file_cfg'
FOFexecfile(("","Della_IOTest_parameter.py")),
# ===================================================================
# ===================================================================
# ===================================================================
# Main entry into script
# ===================================================================
# ===================================================================
# ===================================================================

tMsg("Running LightningBug_SED_regression.py")

RegisterResultsCallback(customHandler,[32,33,34,35,36,37,38,39,43,44,45,46,47,48,49,50,51,52,53,54],useCMLogic=0)
RegisterResultsCallback(customIntiatorHandler, list(range(80,85)), useCMLogic=1)

st(575,prm_575_SetSSCDella_np,timeout=300)
#
tMsg("Get Features")
st(575,prm_575_FDE_GetFeatures,timeout=60)
##tMsg("Start Admin Session")
##st(575,prm_575_FDE_StartAdminSession,timeout=30)

try:
    tMsg("Get PSID from ODS and if available, write it to LSS")
    name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'ASLU'))
    TraceMessage("entire return data from XML-RPC Server (dictionary) %s" % (data))
    responseString = data['SIDResponse']
    print("SIDResponse string  ", responseString)
    sidStr = responseString
    DriveAttributes['TD_SID'] = sidStr
    RequestService("PutAttributes", ({"TD_SID": sidStr}, "FIN2"))
except:
    tMsg("PSID not available from ODS")
tMsg("Get PSID from LSS")
st(575,prm_575_FDE_GetPSIDfromFIS,timeout=30)
tMsg("Start Admin Session")
st(575,prm_575_FDE_StartAdminSession,timeout=30)

st(575,prm_575_FDE_AuthPSID,timeout=30)
st(575,prm_575_FDE_AuthMakerSymKUniqueAES,timeout=30)
tMsg("Get MSID from Drive")
st(575,prm_575_FDE_GetMSIDFromDrive,timeout=30)
st(575,prm_575_FDE_AuthSID,timeout=30)
st(575,prm_575_FDE_Set_Setup_State,timeout=60)
st(575,prm_575_FDE_Set_Mfg_State,timeout=60)
st(575,prm_575_FDE_Set_Use_State,timeout=60)
st(575,prm_575_FDE_GetFeatures,timeout=60)

tMsg("Close Admin Session")
st(575,prm_575_FDE_CloseAdminSession,timeout=30)
