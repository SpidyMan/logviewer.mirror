#--------------------------------------------------------------------------------------------------------#
# Property of Seagate Technology, Copyright 2006, All rights reserved                                     #
#---------------------------------------------------------------------------------------------------------#
# Description: IF3 test parameter for FIN2 process(Firefly)
# $File$
# $Revision$
# $DateTime: 01/22/2009
# $Author: Bob Stafki
# $Header$
# Level: 1
#---------------------------------------------------------------------------------------------------------#

###################################################################################################
#==================================================================================================
from time import localtime
##from State import CState
##from Constants import *
##from Test_Switches import testSwitch
##from Utility import CUtility, staticDefaultDict
##import ScrCmds

global MMDD
global YYYY
year,month,day = localtime()[:3]
MonDayString = "%02d%02d"%(month,day)
YearString = "%04d"%(year)
MMDD = int(MonDayString,16)
YYYY = int(YearString,16)

import random, binascii, struct, base64, time, sys
# *** GLOBALS
global lastInitiatorData
lastInitiatorData = 0x0
global lastInitiatorFileName
lastInitiatorFileName = ""
global suppress_print



testHardware = 1 # 0 = no initiator/fde-drive, server calls only
debug_flag = 0
tdcitool = 0
CN='file_cfg'
if testHardware == 0:
  noTestHardware = 0
else:
  noTestHardware = 0

def tMsg(msg):
##  if debug_flag == 1:
    TraceMessage(msg+"\n")

def statMsg(msg):
##  if debug_flag == 1:
##    TraceMessage(msg)
##    ScriptComment(msg)
    TraceMessage(msg+"\n")

##def print (msg):
##  if debug_flag == 1:
##    print (msg)


# ===================================================================
# getPSIDFromRemoteSite(...):
# Gets'PSID' from the mfg site via TDCI Tools and stores it in
# the TD_SID drive attribute in SHKs FIS.
# ===================================================================
def getPSIDFromSite(updateAttrs=1):

  sidStatus = "1" # 0 = get exisiting SID from FIS
                  # 1 = calculate new SID
  sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far

##  name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'suzhou'))
##  name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'lco'))
##  name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'tco'))
##  name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'spl'))
  name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,HOST_ID, 'ASLU'))
##  name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'korat'))
  TraceMessage("name %s" % (name))
##  TraceMessage("SID Response %s" % (SIDResponse))
  TraceMessage("entire return data from XML-RPC Server (dictionary) %s" % (data))
  responseString = data['SIDResponse']
  print("SIDResponse string  ", responseString)
##  TraceMessage("SID Response key , %s" (responseString))
  TraceMessage("\n")

  sidStr = responseString
##  DriveAttributes['TD_SID'] = sidStr
##  RequestService("PutAttributes", ({"TD_SID": sidStr}, "FIN2"))
  return sidStatus,sidStr


# ===================================================================
# CustomRequestMsidWriteHandler(...):
# Puts an MSID read from the drive into FIS for later use by the secure boot authentication
# method.
# ===================================================================
def CustomRequestMsidWriteHandler(updateAttrs=1):  # actually is putMSID

  sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far
  ## sidStr = responseString
  msid = binascii.b2a_hex(lastInitiatorData[0:32])
  print("MSID  ", msid)

  print("MSID length =  ", len(msid))
  tMsg('MSID = %s' % msid)
##  sidStatus = 2

#  DriveAttributes['MSID'] = msid
#  RequestService("PutAttributes", ({"MSID": msid}, "FIN2"))
#  Set up frame of data to send to initiator
  frame = msid + HDASerialNumber
  print("sending frame of data w/ SID to the initiator")
  SendBuffer(frame)
# ===================================================================
# getSID(...):
# Gets/generates a Secure ID (i.e. 'PSID' or 'MSID') that is printed
# on the drive label and stored internally on the drive in the EF_SID
# file.  It will also create the appropriate drive attribute in FIS.
# ===================================================================
def getSID(updateAttrs=1):  # actually is getTD_SID

  sidStatus = "1" # 0 = get exisiting SID from FIS
                  # 1 = calculate new SID
  sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far
  charChoices = ['H','U','7','C','J','9','T','5','R','B',\
                 'G','M','E','0','F','Z','4','8','Y','K',\
                 '2','L','V','D','S','1','A','W','3','Q',\
                 'X','6','P','N']
  sidStr = ''

#  print "FIS TD_SID from getSID"
  if tdcitool:
    # do this first and if it works, load it to LSS for later usage
    try:
      tMsg("Get PSID from ODS and if available, write it to LSS")
      name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'ASLU'))
      TraceMessage("entire return data from XML-RPC Server (dictionary) %s" % (data))
      responseString = data['SIDResponse']
      print("SIDResponse string  ", responseString)
      sidStr = responseString
      DriveAttributes['TD_SID'] = sidStr
      RequestService("PutAttributes", ({"TD_SID": sidStr}, "FIN2"))
    except:
      # didnt work, post message and go to the LSS attribute serach
      tMsg("PSID not available from ODS")
      tMsg("Get PSID from LSS")
  #end of if tdcitool

  if 'TD_SID' in DriveAttributes:
    # do this if the LSS version exists
    sidStr = DriveAttributes['TD_SID']
    statMsg("FIS TD_SID from FIS    = %s" % sidStr)
    sidStatus = "0"
  else:
    # no sid available
     tMsg("No PSID availabe from LSS")
#     name,data = RequestService("TDCIToolRequest",('getSID',HDASerialNumber,'ASLU'))
#     sidStr = data['SIDResponse']
#     statMsg("FIS TD_SID from TDCITools    = %s" % sidStr)

  if sidStr == '':
    if tdcitool == 0:
      statMsg("No TD_SID found for serial number: %s - creating one" % HDASerialNumber)
      random.shuffle(charChoices)
      random.seed()
      for i in range(0, sidLength):
        sidStr += charChoices[int(random.random() * 34)]
      print(sidStr)
      if updateAttrs:
        DriveAttributes['TD_SID'] = sidStr
        RequestService("PutAttributes", ({"TD_SID": sidStr}, "FIN2"))
    else:
      sidStatus = "2"
  return sidStatus,sidStr
# ===================================================================
# getMSIDfromAttributeMSID(...):
# ===================================================================
def getMSIDfromAttributeMSID(updateAttrs=1):

  sidStatus = "1" # 0 = get exisiting SID from FIS
                  # 1 = calculate new SID
  sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far
  charChoices = ['H','U','7','C','J','9','T','5','R','B',\
                 'G','M','E','0','F','Z','4','8','Y','K',\
                 '2','L','V','D','S','1','A','W','3','Q',\
                 'X','6','P','N']
  sidStr = ''
  if 'MSID' in DriveAttributes:
    sidStr = DriveAttributes['MSID']
    statMsg("FIS MSID from getSID    = %s" % sidStr)
    sidStatus = "0"
  else:
    ScriptComment("No MSID found for serial number: %s - creating one" % HDASerialNumber)
    random.shuffle(charChoices)
    random.seed()
    for i in range(0, sidLength):
      sidStr += charChoices[int(random.random() * 34)]
    if updateAttrs:
      DriveAttributes['MSID'] = sidStr
      RequestService("PutAttributes", ({"MSID": sidStr}, "FIN2"))

  return sidStatus,sidStr
# ===================================================================
# generateSID(...):
# Gets/generates a Secure ID (i.e. 'SID' or 'MSID' or 'PSID) that is printed
# on the drive label and stored internally on the drive in the EF_SID
# file.
# ===================================================================
def generateSID():

  sidStatus = "1" # 0 = get exisiting SID from FIS
                  # 1 = calculate new SID

  #sidLength = 25  # =25, per TCG Storage Architecture Core Spec
  sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far

  # Possible SID characters:
  # random ordering of 24 uppercase letters (No 'I' and No 'O') and
  # numerals 0 through 9
  # per TCG Storage Architecture Core SpecHDASerialNumber
  charChoices = ['H','U','7','C','J','9','T','5','R','B',\
                 'G','M','E','0','F','Z','4','8','Y','K',\
                 '2','L','V','D','S','1','A','W','3','Q',\
                 'X','6','P','N']

  # Create an empty SID string to be filled with random characters
  sidStr = ''

  # statMsg("no SID found @ FIS - calculating virgin SID")

  # Shuffle the list prior to seeding the random number generator -
  # this ensures a unique SID even if the 'RandomSeed' value is the
  # same as a previous one.  Prevents duplicate SID's !!!
  random.shuffle(charChoices)
  # Seed the python random-number generator from an OS-specific
  # randomness source
  random.seed()

  # Generate a string of random characters
  for i in range(0, sidLength):
    # Generate a random number between 0 and 34, and use it to
    # select a character from the choices list
    # NOTE: random() generates a number between 0 and 1
    sidStr += charChoices[int(random.random() * 34)]

  return sidStatus,sidStr


# ===================================================================
# ESGSaveResults(...):
# sends the results data to the results file
# ===================================================================
def ESGSaveResults(data,currentTemp,drive5,drive12,collectParametric):
  # Save to a file in the STP format
  import struct,array,time

  size = len(data) + 10
  currentTime = time.time()
  v5 = (drive5/1000.0 - 5.0)/0.014668 + 86  # per STP report generator file c_rep.cpp
  v12 = (drive12/1000.0 - 12.0)/0.0324774 + 115  # per STP report generator file c_rep.cpp
  if v5 < 0: v5 = 0  # rpt gen does not handle negative values here
  if v12 < 0: v12 = 0  # rpt gen does not handle negative values here
  rptTemp = currentTemp/10 # convert decivolts to volts; Centigrade

  # WRITE THESE VALUES INTO A BINARY STRING
  str1 = struct.pack('<HLbbbb',size,currentTime,v5,v12,collectParametric,rptTemp)

  # SET HI BIT IN TEST NUMBER IF THIS IS PARTIAL RESULTS
  block_code = data[0]

  char_1 = ord(data[1])
  if '\003'==block_code:
    char_1 = char_1 | 0x80

  # WE DON'T SAVE THE FIRST BYTE OF DATA
  data = chr(char_1) + data[2:]

  # CREATE AN ARRAY OF BYTES SO WE CAN WRITE IT TO THE FILE
  str2 = (array.array('B',data)).tostring()

  str3 = "\000"  # ALIGNMENT BYTE

  WriteToResultsFile(str1+str2+str3)


# ===================================================================
# CustomRequestMSIDGenerator():
# custom handler for results key of 32 - Request Secure ID (SID)
# ===================================================================
def CustomRequestMSIDGenerator():
  # Determine the MSID
##  sidStatus,sid = getSID() #this actually gets a PSID, either derived or from FIS
  ## this then becomes the nonce for the XMLRPC to generate an MSID
  statMsg("SID  = %s" % lastInitiatorData)
##  nonce = binascii.b2a_hex(lastInitiatorData[0:32])
##  statMsg("Nonce  = %s" % nonce)
  sidStatus = "1"

  if tdcitool == 0:
    msid = CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),56)
  else:
    msid = CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),56)
  statMsg("Derived MSID (from Serial Number) = %s" % msid)

  if testHardware == 1:
    # Set up frame of data to send to initiator
    frame = sidStatus + msid + HDASerialNumber
    # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

    print("sending frame of data w/ MSID to the initiator")
    SendBuffer(frame)



# ===================================================================
# CustomRequestSecureIDHandler():
# custom handler for results key of 32 - Request Secure ID (SID)
# ===================================================================
def CustomRequestSecureIDHandler():
  # Determine the MSID
  sidStatus,sid = getSID()
  if len(sid) != 32:
    raise "No PSID available"
  else:
    statMsg("xSID  = %s" % sid)

  if testHardware == 1:
    # Set up frame of data to send to initiator
    frame = sidStatus + sid + HDASerialNumber
    # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

    print("sending frame of data w/ SID to the initiator")
    SendBuffer(frame)

# ===================================================================
# CustomRequestSecureIDHandlerCPC():
# custom handler for results key of 43 - Request Secure ID (SID)
# ===================================================================
def CustomRequestSecureIDHandlerCPC():  ##
  # Determine the MSID
  sidStatus,sid = getSID()   #Always save to FIS
  statMsg("43 SID  = %s" % sid)

  if testHardware == 1:
    # Set up frame of data to send to initiator
    frame = struct.pack(">H",len(sidStatus + sid + HDASerialNumber)) + sidStatus + sid + HDASerialNumber
    # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

    print("sending frame of data w/ SID to the initiator")
    SendBuffer(frame,expect=('_INPROGRESS',),tag='MSG')
# ===================================================================
# CustomRequestRandom32CharString():
# custom handler for results key of 56 - Request for random 32 char string
# ===================================================================
def CustomRequestRandom32CharString() :
  global lastInitiatorData
  tMsg("Random Number = %s" % lastInitiatorData)
##  this is where the value needs to be loaded into the parameter table
##  the random value is in the lastInitiatorData global
  frame = "\x22\x00\x00\x00"
  SendBuffer(frame)
  print ("Leaving handler for Random string generator")
  print(" ")

# ===================================================================
# CustomRequestSecureIDHandlerGenerator():
# custom handler for results key of 44- Request Secure ID (SID)
# ===================================================================
def CustomRequestSecureIDGenerator():
  # Determine the PSID
  sidStatus,sid = getMSIDfromAttributeMSID()
  statMsg("MSID retrieved from MSID attribute = %s" % sid)

  if testHardware == 1:
    # Set up frame of data to send to initiator
    frame = sidStatus + sid + HDASerialNumber
    # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

    print("sending frame of data w/ SID to the initiator")
    SendBuffer(frame,expect=('_INPROGRESS',),tag='MSG')
##  statMsg("LeavingCustomRequestSecureIDGenerator")

# ===================================================================
# CustomRequestSecureIDHandlerGeneratorCPC():
# custom handler for results key of 45 - Request Secure ID (SID)
# ===================================================================
def CustomRequestSecureHandlerGeneratorCPC():
  # Determine the MSID

  sidStatus,sid = generateSID() #sidType 1 = MSID(default) 2 = PSID #Always Save PSID to FIS
  statMsg("Generated SID = %s" % sid)

  if testHardware == 1:
    # Set up frame of data to send to initiator
    frame = struct.pack(">H",len(sidStatus + sid + HDASerialNumber)) + sidStatus + sid + HDASerialNumber
    # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

    print("sending frame of data w/ SID to the initiator")
    SendBuffer(frame,expect=('_INPROGRESS',),tag='MSG')

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.4
# kjb @ 09/26/07
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def CustomRequestSerialPortEnableKeyHandler():  ## this is a legacy call to to
                                                ## get a unique makersymk key
  print ("*** Request SerialPort Enable Key")
  stat = 1 # default = FAIL
  print("Entering Custom Request Mfg Key Auth handler - 34 - unique key")

  print("RequestService('ReqSPEKey',(", HDASerialNumber, "))")
  if tdcitool == 0:
    method,prms = RequestService('ReqSPEKey',(HDASerialNumber)) # requestSerialPortEnableKey

##  ScriptComment("method: %s; prms: %s"%(method,prms,))
##  statMsg("method: %s; prms: %s"%(method,prms,))

  if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
    if 'serialPortEnableKey' in prms:
      statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
      print("serialPortEnableKey found in key dictionary")
      responseString = prms['serialPortEnableKey']
      print("hex response string:  ", binascii.hexlify(base64.decodestring(responseString)))
      print("response from server  ", responseString)
      print("base64 decoded        ", base64.b64decode(responseString))
      spEnableKeyString = binascii.b2a_hex(base64.b64decode(responseString))
      print("Unique Key length =  ", len(spEnableKeyString))
      print("sPort Enable Key = ", spEnableKeyString)
      spEnableKey = binascii.a2b_hex(spEnableKeyString)
      stat = 0 # PASS
##      if len(spEnableKeyString) != 32: # 32 chars = 16 bin-nibble-bytes
##        statMsg("SP Enable Key = %i bytes, not 16 bytes" % len(spEnableKeyString))
##      else:
##        tMsg("spEnableKeyString = %s" % spEnableKeyString)
##        spEnableKey = binascii.a2b_hex(spEnableKeyString)
##        tMsg("spEnableKey = %s" % spEnableKey)
##        stat = 0 # PASS
    else:
      ScriptComment("method: %s; prms: %s"%(method,prms,))
      statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
      statMsg('[34] ' + method + '"uniqueKey" not found in data from server')
##      statMsg('[34]' + __name__ + '"srialPortEnableKey" not found in data from server')
  else:
    ScriptComment("method: %s; prms: %s"%(method,prms,))
    ScriptComment("Exception from TDCI Server during authentication ")
##    statMsg('[34]' + __name__ + "data from server is garbled")

  if testHardware:
    if not stat:
      frame = "\x22\x10\x00\x00" + spEnableKey
      tMsg("Frame = %s" % frame)
    else:
      # If we could not get a key, the data length is 0 & no key is sent
      frame = "\x22\x00\x00\x00"

    print("sending frame of data w/ spEnableKey to the initiator")
    SendBuffer(frame)
    print("Leaving Custom Request Mfg Key Auth handler - 34 - unique key")
    print(" ")


# ===================================================================
# CustomRequestKeyHandler():
# customer handler for results key of 46,47 and 48 - Request uniqueKey
# ===================================================================
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.4
# kjb @ 09/26/07
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def CustomRequestKeyHandler(transfer_type):
  stat = 1 # default = FAIL
  if transfer_type == 46:
    if tdcitool == 0:
        method,prms = RequestService("TDCIServerRequest", ('GetUniqueKey',HDASerialNumber,'DiagKey','AES256','0',HOST_ID))
                     #RequestService("TDCIServerRequest", ('DoUniqueKeyAuthentication',('nonce',myNonce), HDASerialNumber,'DiagKey','AES256','0',HOST_ID))

  if transfer_type == 47:
    if tdcitool == 0:
        method,prms = RequestService("TDCIServerRequest", ('GetUniqueKey',HDASerialNumber,'MaintKey','AES256','0',HOST_ID))
  if transfer_type == 48:
    if tdcitool == 0:
        method,prms = RequestService("TDCIServerRequest", ('GetUniqueKey',HDASerialNumber,'DiagKey','3DES','0',HOST_ID))  ## Was MfgKey but issues may dictate that it should be diagkey

  ScriptComment("method: %s; prms: %s"%(method,prms,))
  statMsg("method: %s; prms: %s"%(method,prms,))

  if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
    if 'uniqueKey' in prms:
      statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
      print("uniqueKey found in key dictionary")
      responseString = prms['uniqueKey']
      print("hex response string:  ", binascii.hexlify(base64.decodestring(responseString)))
      print("response from server  ", responseString)
      print("base64 decoded        ", base64.b64decode(responseString))
      uniqueKeyString = binascii.b2a_hex(base64.b64decode(responseString))
      print("Unique Key length =  ", len(uniqueKeyString))
      print("sPort Enable Key = ", uniqueKeyString)
      iuniqueKey = binascii.a2b_hex(uniqueKeyString)
      print("sPort Enable Key = ", iuniqueKey)
##      spEnableKey = binascii.a2b_hex(spEnableKeyString)
      stat = 0

    else:
      statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
      statMsg('[34] ' + method + '"uniqueKey" not found in data from server')

  else:
    ScriptComment("method: %s; prms: %s"%(method,prms,))
    ScriptComment("Exception from TDCI Server during authentication ")
##    statMsg('[34]' + method + "data from server is garbled")
  if testHardware:
    if not stat:
      frame = "\x22\x10\x00\x00" + iuniqueKey
    else:
      # If we could not get a key, the data length is 0 & no key is sent
      frame = "\x22\x00\x00\x00"

    print("sending frame of data w/ uniqueKey to the initiator")
    SendBuffer(frame)
    print("Leaving Custom Request Mfg Key Auth handler - 46,47,48 - unique key")
    print(" ")

# ===================================================================
# CustomRequestGetTDCertifiedKeyPairHandler():
# customer handler for results key of 3X - Request Certified Key Pair
# ===================================================================
def CustomRequestGetTDCertifiedKeyPairHandler(cert_type):
  print("*** Request TD Certified Key Pair")
  print("Entering Custom Request Mfg Key Auth handler - 38 - get certified TD key pair")

  d = ['primeExponentP','primeExponentQ','crtCoefficient','montModulus','pubExp','montPrimeQ','montPrimeP','primeQ',
       'primeP','privExp','modulus','RSAPrivateKey','Certificate']
  if cert_type == 0:
    print ("RequestService('GetCertifiedKeyPair',('HDASerialNumber','SIGN','1.2.3.4.5.6.7.8.9.0))")
    if tdcitool == 0:
        method,prms = RequestService("TDCIServerRequest", ("GetCertifiedKeyPair",HDASerialNumber,'SIGN','1.2.3.4.5.6.7.8.9.0'))
  else:
    if cert_type == 1:
      key_type = 'RSA1024PubExp17'
    else:
      key_type = 'RSA2048PubExp65537'
#    print ("RequestService('`',('ser no.','SIGN','1.2.3.4.5.6.7.8.9.0))")

    if tdcitool == 0:
        name, prms = RequestService("TDCIServerRequest", ('requestTDCertKeyPair',HDASerialNumber,'SIGN',2 ,key_type, '0',HOST_ID))

  ScriptComment("name: %s; prms: %s"%(name,prms,))
  statMsg("name: %s; prms: %s"%(name,prms,))

  frame = "\x25\x00\x00\x00"
#  print "sending answer to get_pc_file to the initiator"
  SendBuffer(frame)

  if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
    print (prms)

    for x in d:
      if x in prms:
#        print ("field: %s"%x )
        responseString = prms[x]
        spEnableKeyString = binascii.b2a_hex(base64.b64decode(responseString))  #binary to ascii decoded string
#        print("x = %s" % spEnableKeyString)                                      #print the ascii string
        spEnableKey = binascii.a2b_hex(spEnableKeyString)
#        print("x = %i bytes" % len(spEnableKey))                           #print the length of the ascii string
        overall_len = len(spEnableKey)
        done = 0            #initialize done flag
        if overall_len > 512:
          frame = "\x01" + spEnableKey[:512]
          overall_len = overall_len - 512
          done = 0
        else:
          frame = "\x00" + spEnableKey[:512]
          done = 1
        SendBuffer(frame)

        if done == 0:  ##not done
          if overall_len > 512:
            frame = "\x01" + spEnableKey[512:1024] #change index
            overall_len = overall_len - 512
            done = 0
          else:
            frame = "\x00" + spEnableKey[512:] #change index
            done = 1
          SendBuffer(frame)
          if done == 0:  ##not done
            frame = "\x00" + spEnableKey[1024:]
            done = 1
            SendBuffer(frame)
      else:
        print("key doesn't exist")                           #print the ascii string
  else:
    ScriptComment("method: %s; prms: %s"%(method,prms,))
    ScriptComment("Exception from TDCI Server during authentication ")
##    print('[34]' + __name__ + "data from server is garbled")

    print("Leaving Custom Request Certified Key Pair")
    print(" ")


# ===================================================================
# CustomRequestDefaultManufacturingKeyAuthenticationHandler(...):
# INPUTS:
# * rcvData         : Random Challenge Value Data (from drive via initiator)
# * HDASerialNumber : HDASerialNumber
# RETURN(S):
# * mfgAuthKey      : Manufacturing Autentication Key
# custom handler for results key of 33 - Request Mfg. Key. Auth.
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.3
# ===================================================================
def CustomRequestDefaultManufacturingKeyAuthenticationHandler(rcvData, transfer_type): # RandomChallengeValueData
  stat = 1 # default = FAIL
  index = 0
  displayBuffer(rcvData)
  randomChallengeValue =  rcvData[index:]

  if transfer_type == 33:
    print("transfer type = 33")
    if tdcitool == 0:
        method,prms = RequestService('ReqMfgAuth',(randomChallengeValue))
  elif transfer_type == 49:
    print("transfer type = 49")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doDefaultKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','3DES','0',HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoDefaultKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','3DES','0',HOST_ID))  ##was mfgkey but maybe shouldn't have been
    TraceMessage("method: %s; prms: %s"%(method,prms,))
    TraceMessage("entire return prms from XML-RPC Server (dictionary) %s" % (prms))


  elif transfer_type == 50:
    print("transfer type = 50")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doDefaultKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','AES256','0',HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoDefaultKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','AES256','0',HOST_ID))
  elif transfer_type == 51:
    print("transfer type = 51")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doDefaultKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'MaintKey','AES256','0',HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoDefaultKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'MaintKey','AES256','0',HOST_ID))
            ## Nonce, serial number, (MfgKey,DiagKey,MaintKey),(3DES,AES256),0

  ScriptComment("method: %s; prms: %s"%(method,prms,))
##  statMsg("method: %s; prms: %s"%(method,prms,))

  if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
    if 'AuthenticationResponse' in prms:
      responseString = base64.b64decode(prms['AuthenticationResponse'])
      # tMsg("response from server    = %s" % responseString)
      mfgAuthKeyString = binascii.b2a_hex(responseString)
      tMsg("HDA Serial Number = %s" % HDASerialNumber)
      tMsg("Mfg.Auth.Key = %s" % mfgAuthKeyString)
      if len(mfgAuthKeyString) != 64: # 64 chars = 32 bin-nibble-bytes
        statMsg("Mfg. Auth. Key = %i bytes, not 32 bytes" % len(mfgAuthKeyString))
      else:
        mfgAuthKey = binascii.a2b_hex(mfgAuthKeyString)
        stat = 0 # PASS
    else:
      statMsg('[33]' + __name__ + '"AuthenticationResponse" not found in data from server')
  else:
    ScriptComment("method: %s; prms: %s"%(method,prms,))
    ScriptComment("Exception from TDCI Server during authentication ")

##    statMsg('[33]' + __name__ + "data from server is garbled")

  if testHardware == 1:
    if not stat:
      frame = "\x21\x20\x00\x00"  + mfgAuthKey
    else:
      # If we could not get a key, the data length is 0 & no key is sent
      frame = "\x21\x00\x00\x00"

    print("sending frame of data w/ mfgAuthKey to the initiator")
    SendBuffer(frame)
##    print"Leaving Custom Request Mfg Key Auth handler - 33 - default key"
    print(" ")


# ===================================================================
# CustomRequestSerialPortEnableKeyAuthenticationHandler(...):
# customer handler for results key of 35 - SP Enable Key Authentication
# ===================================================================
def CustomRequestSerialPortEnableKeyAuthenticationHandler(rcvData):
  stat = 1 # default = FAIL

  print("Entering handler for unique key authentication - get key")
  print("DATA IN-> from serial port enable key ")
  print(rcvData)
  print(" ")

  ### # Jump over the 25 bytes of (binary) header information
  ### index = 25
  index = 0

  # Grab the Random Challenge Value (RCV) sent to us
  randomChallengeValue =  rcvData[index:]

  if tdcitool == 0:
    method,prms = RequestService('ReqSPEAuth',(randomChallengeValue, HDASerialNumber))

  ScriptComment("method: %s; prms: %s"%(method,prms,))
  statMsg("method: %s; prms: %s"%(method,prms,))

  if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
    if 'AuthenticationResponse' in prms:
      responseString = prms['AuthenticationResponse']
      spEnableAuthKeyString = binascii.b2a_hex(base64.b64decode(responseString))
      if len(spEnableAuthKeyString) != 64: # 64 chars = 32 bin-nibble-bytes
        statMsg("SP Enable Auth. Key = %i bytes, not 32 bytes" % len(spEnableAuthKeyString))
      else:
        tMsg("sPort Enable Auth. Key = %s" % spEnableAuthKeyString)
        spEnableAuthKey = binascii.a2b_hex(spEnableAuthKeyString)
        stat = 0 # PASS
        tMsg("HDA serial number = %s" % HDASerialNumber)
    else:
      statMsg('[35]' + __name__ + '"serialPortEnableAuthKey" not found in data from server')
  else:
    ScriptComment("method: %s; prms: %s"%(method,prms,))
    ScriptComment("Exception from TDCI Server during authentication ")
##    statMsg('[35]' + __name__ + "data from server is garbled")

  if testHardware == 1:
    if not stat:
      frame = "\x22\x10\x00\x00" + spEnableAuthKey
    else:
      # If we could not get a key, the data length is 0 & no key is sent
      frame = "\x22\x00\x00\x00"

    print("sending frame of data w/ spEnableAuthKey to the initiator")
    SendBuffer(frame)
    print("Leaving handler for unique key authentication - get key")
    print(" ")


# ===================================================================
# CustomRequestUniqueManufacturingKeyAuthenticationHandler(...):
# customer handler for results key of 35 - SP Enable Key Authentication
# ===================================================================
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.5
# kjb @ 10/04/07
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def CustomRequestUniqueManufacturingKeyAuthenticationHandler(rcvData,transfer_type):
  #print "*** Request SerialPort Enable Key Authentication"
  stat = 1 # default = FAIL

  print("Entering handler for unique key authentication - get key")
  print("DATA IN-> from serial port enable key ")
  print(rcvData)
  print(" ")

  ### # Jump over the 25 bytes of (binary) header information
  ### index = 25
  index = 0

  # Grab the Random Challenge Value (RCV) sent to us
  randomChallengeValue =  rcvData[index:]
  tMsg("randomChallengeValue = %s" %randomChallengeValue )
  if transfer_type == 52:
    print("transfer type = 52")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','3DES','0',HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','3DES','0',HOST_ID))
  elif transfer_type == 53:
    print("transfer type = 53")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','AES256','0',HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'DiagKey','AES256','0',HOST_ID))
  elif transfer_type == 54:
    print("transfer type = 54")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'MaintKey','AES256','0',HOST_ID))
#        name,data =    RequestService("TDCIToolRequest",('doUniqueKeyAuthentication',('nonce',myNonce),'3SE003B4',keyID, keyType, keyProfileID, HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'MaintKey','AES256','0',HOST_ID))
#        method,prms = RequestService("TDCIServerRequest", ('DoUniqueKeyAuthentication',randomChallengeValue, HDASerialNumber,'MaintKey','AES256','0'))
  elif transfer_type == 56:
    print("transfer type = 56")
    if tdcitool == 1:
        method,prms = RequestService("TDCIToolRequest",('doUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'MaintKey','AES256','0',HOST_ID))
    else:
        method,prms = RequestService("TDCIServerRequest", ('DoUniqueKeyAuthentication',('nonce',randomChallengeValue), HDASerialNumber,'MaintKey','AES256','0',HOST_ID))

  ScriptComment("method: %s; prms: %s"%(method,prms,))
  statMsg("method: %s; prms: %s"%(method,prms,))

  if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
    if 'AuthenticationResponse' in prms:
      responseString = prms['AuthenticationResponse']
      spEnableAuthKeyString = binascii.b2a_hex(base64.b64decode(responseString))
      if len(spEnableAuthKeyString) != 64: # 64 chars = 32 bin-nibble-bytes
        statMsg("SP Enable Auth. Key = %i bytesCustomRequestKeyHandler, not 32 bytes" % len(spEnableAuthKeyString))
      else:
        tMsg("sPort Enable Auth. Key = %s" % spEnableAuthKeyString)
        spEnableAuthKey = binascii.a2b_hex(spEnableAuthKeyString)
        stat = 0 # PASS
    else:
      statMsg('[35]' + method + '"serialPortEnableAuthKey" not found in data from server')

  else:
    ScriptComment("method: %s; prms: %s"%(method,prms,))
    ScriptComment("Exception from TDCI Server during authentication ")
##    statMsg('[35]' + prms + "data from server is garbled")

  if testHardware == 1:
    if not stat:
      frame = "\x22\x10\x00\x00" + spEnableAuthKey
    else:
      # If we could not get a key, the data length is 0 & no key is sent
      frame = "\x22\x00\x00\x00"

    if transfer_type == 56:
      return spEnableAuthKey
    else:
      print("sending frame of data w/ spEnableAuthKey to the initiator")
      SendBuffer(frame)
      print("Leaving handler for unique key authentication")
      print(" ")



# ===================================================================
# Definition of the generic "top-level" customer handler
# * add defaults so we can pass only data (in manual, non-initiator mode)
# ===================================================================
def customHandler(data,currentTemp=0,drive5=0,drive12=0,collectParametric=0):
  stat = 1 # default= FAIL

  # Get the resultsKey
  resultsKey = ord(data[0])
  statMsg("xfer type = %i" % resultsKey)

  if resultsKey == 32:
    CustomRequestSecureIDHandler() ## request MSID
  elif resultsKey == 33:    ## default request for random challenge encryption by server
    CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
  elif resultsKey == 34:
    CustomRequestSerialPortEnableKeyHandler()   ## get unique makersymk credential to write to the IV
  elif resultsKey == 35:   ## unique request for random challenge encryption by server
#    CustomRequestSerialPortEnableKeyAuthenticationHandler  (binascii.a2b_hex(lastInitiatorData))
    CustomRequestSerialPortEnableKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData))
  elif resultsKey == 36:   ## this request sends the MSID in the FIS for later use by the call to authenticate the secure boot loader
    CustomRequestMsidWriteHandler()
  elif resultsKey == 37:
    CustomRequestGetTDCertifiedKeyPairHandler(0)## legacy key pair - deprecated
  elif resultsKey == 43:
    CustomRequestSecureIDHandlerCPC()
  elif resultsKey == 44:
    CustomRequestSecureIDGenerator()
  elif resultsKey == 45:
    CustomRequestSecureHandlerGeneratorCPC()

  ## The below Handlers are part of the XMLRPC changes that reduce the number of unique RPCs.

  elif resultsKey == 38:
    CustomRequestGetTDCertifiedKeyPairHandler(1)## 1024 byte version
  elif resultsKey == 39:
    CustomRequestGetTDCertifiedKeyPairHandler(2)## 2048 byte version
  elif resultsKey == 46:    # MakerSymK AES256 unique key request
    CustomRequestKeyHandler(resultsKey)
  elif resultsKey == 47:    # MaintSymK AES256 unique key request
    CustomRequestKeyHandler(resultsKey)
  elif resultsKey == 48:    # MakerS unique key request
    CustomRequestKeyHandler(resultsKey)

  elif resultsKey == 49:    # This will be the 3DES key for default auth
    if tdcitool == 0:
        CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
    else :
        CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
  elif resultsKey == 50:    # This will be the default maker AES256 auth
    if tdcitool == 0:
        CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
    else:
        CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
  elif resultsKey == 51:    # This will be the unique maintsymk AES256 auth
    if tdcitool == 0:
        CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
    else:
        CustomRequestDefaultManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)

  elif resultsKey == 52:    # This will be the unique maker 3DES auth
    if tdcitool == 0:
        CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
    else:
        CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)

  elif resultsKey == 53:    # This will be the unique AES256 maker auth
    if tdcitool == 0:
        CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
    else:
        CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
  elif resultsKey == 54:    # This will be the unique maintsymk AES256 auth
    if tdcitool == 0:
        CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
    else:
        CustomRequestUniqueManufacturingKeyAuthenticationHandler(binascii.a2b_hex(lastInitiatorData),resultsKey)
  elif resultsKey == 55:    # This is for the random string generator
    CustomRequestRandom32CharString()
  elif resultsKey == 56:
    CustomRequestMSIDGenerator() ## request MSID derived from PSID and Serial number

  else:
    tMsg("Unknown results key - resultsKey=" + resultsKey + "@" + __name__)


# ===================================================================
#
# data from initiator
#
# ===================================================================
def printInitiatorData(buf, *args, **kargs):
  import binascii
  print(" ===2> %s"%binascii.a2b_hex(buf))


# ===================================================================
# CustomInitiatorDataFileNameHandler(...):
# INPUTS:
# * data         : fileName
# custom handler for results key of 80 - fileName of data from initator
# ===================================================================
def customInitiatorDataFileNameHandler(iData):
  stat = 1 # default = FAIL

  # Jump over the 3 bytes of (binary) header information
  index = 2
  # Grab the Random Challenge Value (RCV) sent to us
  fileName = iData[index:]

  #print("===3> Initiator Data FileName = %s" % fileName)

  return fileName

# ===================================================================
# CustomInitiatorDataHandler(...):
# INPUTS:
# * data         : data
# custom handler for results key of 82 - data from initator
# ===================================================================
def customInitiatorDataHandler(iData):
  stat = 1 # default = FAIL

  # Jump over the 3 bytes of (binary) header information
  index = 3

  # Grab the Random Challenge Value (RCV) sent to us
  nonce = binascii.b2a_hex(iData[index:index+32])

  print(("===8> Nonce from initiator = %s" % nonce))

  return nonce

# ===================================================================
# Definition of the generic "top-level" customer handler
# resultsKeys 80-85
# * add defaults so we can pass only data (in manual, non-initiator mode)
# ===================================================================
def customIntiatorHandler(data, *args, **kargs):
  stat = 1 # default= FAIL

  global lastInitiatorData

  print("Entering File Handler ")
  print("===4> %s"%binascii.b2a_hex(data))

  # Get the resultsKey
  resultsKey = ord(data[0])
  print("===5> resultsKey: %s"%hex(resultsKey))

  if resultsKey == 80:
    lastInitiatorFileName = customInitiatorDataFileNameHandler(data)
  elif resultsKey == 82:
    lastInitiatorData = customInitiatorDataHandler(data)
  else:
    tMsg("Got resultsKey :%s"%resultsKey)
    #tMsg("Huh?  resultsKey=" + resultsKey + "@" + __name__)
##  print "Leaving File Handler "
##  print " "



prm_638_NvcInit = {
   'ATTRIBUTE_MODE' : (0x0000,),
   'BYPASS_WAIT_UNIT_RDY' : (0x0001,),
   'CMD_BYTE_GROUP_0' : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),
   'CMD_BYTE_GROUP_1' : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),
   'CMD_BYTE_GROUP_2' : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),
   'CMD_DFB_LENGTH' : (0x0000,),
   'LONG_COMMAND' : (0x0000,),
   'PARAMETER_0' : (0x7B01,),
   'PARAMETER_1' : (0x0000,),
   'PARAMETER_2' : (0x0000,),
   'PARAMETER_3' : (0x0200,),
   'PARAMETER_4' : (0x0000,),
   'PARAMETER_5' : (0x0000,),
   'PARAMETER_6' : (0x0000,),
   'PARAMETER_7' : (0x0000,),
   'PARAMETER_8' : (0x0000,),
   'REPORT_OPTION' : (0x0000,),
   'SCSI_COMMAND' : (0x0000,),
   'SECTOR_SIZE' : (0x0000,),
   'TEST_FUNCTION' : (0x0000,),
   'TRANSFER_LENGTH' : (0x0000,),
   'TRANSFER_MODE' : (0x0000,),
   'WRITE_SECTOR_CMD_ALL_HDS' : (0x0000,),
}

prm_535_InitiatorRevSATA = {
    "BAUD_RATE" : (0x0000,),
    "DRIVE_TYPE" : (0x0000,),
    "EXPECTED_FW_REV_1" : (0x0000,),
    "FC_SAS_TRANSFER_RATE" : (0x0000,),
    "REG_ADDR" : (0x0000,),
    "REG_VALUE" : (0x0000,),
    "TEST_FUNCTION" : (0x0800,),
    "TEST_OPERATING_MODE" : (0x0002,),
}


prm_575_FDE_StartOpalLockingSession = {
  "TEST_MODE" : (0x0002,),
  "UIDLSWL" : (0x0002,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_StartLockingSession = {
  "TEST_MODE" : (0x0002,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0001,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}


prm_575_FDE_CloseLockingSession = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0003,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0001,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_CreateNetAPPS_Band1 = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0044,),
  "UIDMSWU" : (0x0000,),           # 00 00 08 02 00 03 00 01
  "UIDMSWL" : (0x0802,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x0002,),
  "BANDMASTER" : (0x0001,),
}

prm_575_FDE_StartAdminSession = {
  "TEST_MODE" : (0x0002,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}


prm_575_FDE_CloseAdminSession = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0003,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_574_FDE_ClearSession = {

  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0001,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0000,),
  "WR_FUNCTION" : (0x0000,),
}

# ===================================================================
# This is the start of the parameters for the numbered tests
# ===================================================================

# ===================================================================
#Opal function calls
# ===================================================================
prm_575_FDE_GetMSIDFromFIS = {
  "TEST_MODE" : (0x0010,),
}
prm_575_activateSP = {
  "TEST_MODE" : (0x0025,),
  "UIDLSWL" : (0x0002,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_ActivateSED = {
  "TEST_MODE" : (0x0049,),
  "DRIVE_SECURITY_TYPE" : (0x0001,),
}

prm_575_ActivateSDD= {
  "TEST_MODE" : (0x0049,),
  "DRIVE_SECURITY_TYPE" : (0x0002,),
}

prm_575_ActivateISE = {
  "TEST_MODE" : (0x0049,),
  "DRIVE_SECURITY_TYPE" : (0x0003,),
}

prm_575_ActivateFIPS = {
  "TEST_MODE" : (0x0049,),
  "DRIVE_SECURITY_TYPE" : (0x0004,),
}


prm_575_enableFIPS = {
  "TEST_MODE" : (0x0035,),

#  "UIDMSWU" : (0x0000,),
#  "UIDMSWL" : (0x3632,),
#  "UIDLSWU" : (0x3131,),
#  "UIDLSWL" : (0x3147,), ## sb 0x31

#  "UIDMSWU" : (0x0000,),
#  "UIDMSWL" : (0x3236,),
#  "UIDLSWU" : (0x3131,),
#  "UIDLSWL" : (0x4731,), ## sb 0x31


  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x3147,),
  "UIDLSWU" : (0x3131,),
  "UIDLSWL" : (0x3632,),

}
prm_575_FDE_AuthOpalErasemasterDefault = {
  "PASSWORD_TYPE" : (0x0000,),## Default MSID in this case
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8401,),
  "WHICH_SP" : (0x0001,),
}
prm_575_FDE_AuthErasemasterMSID = {
  "PASSWORD_TYPE" : (0x0002,),## Default MSID in this case
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8401,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_SetOpalErasemasterCred = {
  "TEST_MODE" : (0x0004,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x000b,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8401,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_SetOpalBandmaster0Cred = {
  "TEST_MODE" : (0x0004,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x000b,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8001,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_SetOpalBandmaster1Cred = {
  "TEST_MODE" : (0x0004,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x000b,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8002,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_AuthAdmin_mmmm = {
  "PASSWORD_TYPE" : (0x0002,),
  "TEST_MODE" : (0x0001,),           #00 00 00 09 00 01 00 01
  "UIDMSWU" : (0x0000,),         # Admin 1 UID = 0000000900010001
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0001,),
  "UIDLSWL" : (0x0001,),          # mmmm > 1
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_EnableUser_mmmm = {
  "TEST_MODE" : (0x002A,),           #00 00 00 09 00 03 00 01
  "UIDMSWU" : (0x0000,),         # Admin 1 UID = 0000000900010001
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0003,),
  "UIDLSWL" : (0x0001,),     # mmmm > 1
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_ChangeUsermmmm_PW = {
  "TEST_MODE" : (0x0042,),       #00 00 00 09 00 01 00 01
  "UIDMSWU" : (0x0000,),         # Admin 1 UID = 0000000900010001
  "UIDMSWL" : (0x000b,),         # changes it to MSID value
  "UIDLSWU" : (0x0003,),         #C_PIN_USERmmmm
  "UIDLSWL" : (0x0001,),     # mmmm > 1
  "WHICH_SP" : (0x0002,),
}

prm_575_FDE_GetOpalLockingInfo = {
  "TEST_MODE"  :       (0x0048,),
  "REPORTING_MODE"  :  (0x0001,),     ##ReportingMode    (Prm[0] & 0x8000)
  "UIDMSWU"  :         (0x0000,),            ##UidLswu           Prm[4]
  "UIDMSWL"  :         (0x0802,),            ##UidLswu           Prm[5]
  "UIDLSWU"  :         (0x0000,),            ##UidLswu           Prm[6]
  "UIDLSWL"  :         (0x0001,),            ##UidLswl           Prm[7]
  "READ_LOCKED" :      (0x0003,),
  "WRITE_LOCKED" :     (0x0009,),

}


#End Opal function calls

# ===================================================================
# 575 function calls
# ===================================================================
################################## start of test 575  ###########################################
#################################################################################################

prm_575_OPAL_Create_and_configure_Band = {
  "BANDMASTER" : (0x0001,),
  "READ_LOCKED" : (0x001,),
  "WRITE_LOCKED" : (0x0001,),
  "READ_LOCK_ENABLED" : (0x0001,),
  "WRITE_LOCK_ENABLED" : (0x0001,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),       #Range_Start H
  "START_LBA_L" : (0x0000,),       #Range_Start L
  "BAND_SIZE_H"      : (0x0001,),  #BandSizeHi,
  "BAND_SIZE_L"      : (0x0000,),  #BandSizeLo,
  "TEST_MODE" : (0x0043,),         #Configure all bands
  "UIDMSWU" : (0x0000,),           # 00 00 08 02 00 03 00 01
  "UIDMSWL" : (0x0802,),
  "UIDLSWU" : (0x0003,),
  "UIDLSWL" : (0x0001,),
}
prm_575_Factory_configure_Band_1= {
  "TEST_MODE" : (0x0043,),         #Configure all bands
  "BANDMASTER" : (0x0001,),
  "READ_LOCKED" : (0x001,),
  "WRITE_LOCKED" : (0x0001,),
  "READ_LOCK_ENABLED" : (0x0001,),
  "WRITE_LOCK_ENABLED" : (0x0001,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),       #Range_Start H
  "START_LBA_L" : (0x1000,),       #Range_Start L
  "BAND_SIZE_H"      : (0x0001,),  #BandSizeHi,
  "BAND_SIZE_L"      : (0x0000,),  #BandSizeLo,
  "LOCK_ON_RESET"    : (0x0000,),
  "UIDMSWU" : (0x0000,),           # 00 00 08 02 00 03 00 01
  "UIDMSWL" : (0x0802,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x0002,),
}


prm_575_FDE_GetMSIDACL = {
  "TEST_MODE" : (0x0041,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_GetActivateMethodACL = {
  "TEST_MODE" : (0x0041,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_SendMsidToFIS = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x003E,),
}

prm_575_FDE_GetMSIDFromDrive = {
  "PASSWORD_TYPE" : (0x0000,),
  "TEST_MODE" : (0x0011,),
}
prm_575_GetMSIDFromISE_V1_Drive = {

  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0011,),
  "ISE_VERSION" : (0x0001,),
}
prm_575_GetMSIDFromISE_SDD_drive = {

  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0011,),
  "ISE_VERSION" : (0x0001,),
}
prm_575_GetMSIDFromISE_V2_Drive = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0011,),
  "ISE_VERSION" : (0x0002,),
}

prm_575_SetFDE = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0040,),
}

prm_575_BlockDITSCommands = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x003A,),
}

prm_575_UnBlockDITSCommands = {
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x003B,),
}


##/////*******//////****** Authentications  /////******/////*****
prm_575_AuthMakerSymK = {
  "PASSWORD_TYPE" : (0x0001,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_AuthMaintSymk = {
  "PASSWORD_TYPE" : (0x0010,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0001,),
  "UIDLSWL" : (0xff02,),
  "WHICH_SP" : (0x0000,),
}

prm_575_AuthSID = {
  "CERT_KEYTYPE" : (0x0000,),
  "CERT_TSTMODE" : (0x0002,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0006,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_AuthToSID = {
  "CERT_KEYTYPE" : (0x0000,),
  "CERT_TSTMODE" : (0x0002,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x8402,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}


prm_575_FDE_AuthOpalBandmaster0Default = {
  "PASSWORD_TYPE" : (0x0000,),## Default MSID in this case
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8001,),
  "WHICH_SP" : (0x0001,),
}


prm_575_FDE_AuthOpalBandmaster1Default = {
  "PASSWORD_TYPE" : (0x0000,),## Default MSID in this case
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x8002,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_AuthMakerSymKDefault3DES = {
  "PASSWORD_TYPE" : (0x000B,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthMakerSymKUnique3DES = {
  "PASSWORD_TYPE" : (0x000D,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
}

prm_575_FDE_AuthMakerSymKDefaultAES = {
  "PASSWORD_TYPE" : (0x000C,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthMakerSymKUniqueAES = {
  "PASSWORD_TYPE" : (0x000E,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
}
prm_575_FDE_AuthMSID = {
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x8402,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
}

prm_575_FDE_AuthDefaultMSID = {
  "REPORTING_MODE" : (0x0001,),
  "PASSWORD_TYPE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x8402,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
}

prm_575_FDE_AuthPSIDwithMSID = {
  "PASSWORD_TYPE"  : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0xFF01,),
  "UIDLSWU" : (0x0001,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthPSID = {
  "PASSWORD_TYPE"  : (0x0009,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0xFF01,),
  "UIDLSWU" : (0x0001,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthDefaultPSID = {
  "PASSWORD_TYPE" : (0x000A,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0xFF01,),
  "UIDLSWU" : (0x0001,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthSID = {
  "PASSWORD_TYPE" : (0x0002,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0006,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthDefaultSID = {
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0006,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_AuthMakerSymK3DESUnique = {
  "PASSWORD_TYPE" : (0x000D,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_AuthMakerSymAES256KUnique = {
  "PASSWORD_TYPE" : (0x000e,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_AuthMakerSymK3DESDefault = {
  "PASSWORD_TYPE" : (0x000b,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x0004,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
}

prm_575_FDE_AuthBM2 = {
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x8002,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}
prm_575_FDE_AuthBM1 = {
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x8002,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}
prm_575_FDE_AuthBM0 = {
  "PASSWORD_TYPE" : (0x0002,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "UIDLSWL" : (0x8001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0009,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}

prm_575_Get_MaintSymK_table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "UIDMSWU"  : (0x0009,),
  "UIDMSWL"  : (0x0000,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0xff02,),
}
prm_575_GetCertificateKeyPair = {
  "CERT_KEYTYPE" : (0x0040,),
  "CERT_TSTMODE" : (0x0007,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0007,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0018,),
  "UIDLSWL" : (0x0000,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0000,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_ReadCertificate = {
   'test_num' : 575,
   'prm_name' : 'prm_575_ReadCertificate',
   'timeout' : 30,
  "CERT_KEYTYPE" : (0x0000,),
  "CERT_TSTMODE" : (0x0000,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0014,),
  "UIDLSWL" : (0x0000,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0000,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_GetCertificate = {
   'test_num' : 575,
   'prm_name' : 'prm_575_GetCertificate',
   'timeout' : 30,
  "CERT_KEYTYPE" : (0x0000,),
  "CERT_TSTMODE" : (0x0000,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0014,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}

prm_575_FDE_EraseGlobalBand = {
  "TEST_MODE" : (0x000d,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0802,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x0001,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_EraseBand0 = {
  "TEST_MODE" : (0x000d,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0802,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x0002,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_EraseBand1 = {
  "TEST_MODE" : (0x000d,),
  "UIDMSWU" : (0x0000,),
  "UIDMSWL" : (0x0802,),
  "UIDLSWU" : (0x0000,),
  "UIDLSWL" : (0x0003,),
  "WHICH_SP" : (0x0001,),
}

prm_575_FDE_GetLockingInfo = {
  "TEST_MODE"  :       (0x05,),
  "REPORTING_MODE"  :  (0x0000,),     ##ReportingMode    (Prm[0] & 0x8000)
  "WHICH_SP"  :        (0x0001,),           ##WhichSP          (Prm[1] & 0xff)
  "PASSWORD_TYPE"  :   (0x0002,),      ##PasswordType     (Prm[2] & 0xff)
  "UIDMSWU"  :         (0x0000,),            ##UidLswu           Prm[4]
  "UIDMSWL"  :         (0x0802,),            ##UidLswu           Prm[5]
  "UIDLSWU"  :         (0x0000,),            ##UidLswu           Prm[6]
  "UIDLSWL"  :         (0x0001,),            ##UidLswl           Prm[7]
}

prm_575_FDE_GetPSIDfromFIS = {
  "TEST_MODE"  : (0x24,),
  "REPORTING_MODE"  : (0x0001,),
}

prm_575_FDE_GetMSIDfromFIS = {
  "TEST_MODE"  : (0x10,),
  "REPORTING_MODE"  : (0x0001,),
}

prm_575_FDE_GetFeatures = {
  "TEST_MODE"  : (0x07,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
}
prm_575_FDE_TestState =  {
  "TEST_MODE"  : (0x46,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
  "DRIVE_STATE"  : (0x0000,),
}

#define UNKNOWN_DRIVE_TYPE 0
#define SED_DRIVE  1
#define ISE_DRIVE  2
#define SDD_DRIVE  3
#define OPAL_DRIVE  4
#define OPAL_V2_DRIVE 5
#define OPAL_SU_DRIVE 6

prm_575_FDE_TestSecureDriveType =  {
  "TEST_MODE"  : (0x47,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
  "DRIVE_SECURITY_TYPE"  : (0x0001,),  #Default value - SED
}

prm_575_ForceDiscovery = {
  "TEST_MODE"  : (0x3f,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
}
prm_575_FDE_Discovery_ISE = {
  "TEST_MODE"  : (0x07,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
  "DRIVE_SECURITY_TYPE"  : (0x0002,),  #test for ISE drive
}
prm_575_FDE_Discovery_SDD = {
  "TEST_MODE"  : (0x07,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
  "DRIVE_SECURITY_TYPE"  : (0x0003,),  #test for SDD drive
}
prm_575_FDE_Discovery_SED = {
  "TEST_MODE"  : (0x07,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
  "DRIVE_SECURITY_TYPE"  : (0x0001,),  #test for SED drive
}

prm_575_FDE_GetSOM = {
  "TEST_MODE"  : (0x1B,),
  "REPORTING_MODE"  : (0x0001,),
}

prm_575_FDE_GetSOM = {
  "TEST_MODE"  : (0x1B,),
  "REPORTING_MODE"  : (0x0001,),
}

prm_575_FDE_TestSOM = {
  "TEST_MODE"  : (0x45,),
  "REPORTING_MODE"  : (0x0000,),
  "DRIVE_STATE"  : (0x0000,),
}

prm_575_FDE_SetSOM0 = {
  "TEST_MODE"  : (0x1A,),
  "DRIVE_STATE"  : (0x0000,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
}
prm_575_FDE_SetSOM1 = {
  "TEST_MODE"  : (0x1A,),
  "DRIVE_STATE"  : (0x0001,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
}

prm_575_FDE_SetSOM2 = {
  "TEST_MODE"  : (0x1A,),
  "DRIVE_STATE"  : (0x0002,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
}

prm_575_FDE_CapturePersistentData = {
  "TEST_MODE"  : (0x1D,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0000,),
}

prm_575_FDE_RevertSP = {
  "TEST_MODE"  : (0x1E,),
  "REPORTING_MODE"  : (0x0000,),
}
prm_575_FDE_GetProperties = {
  "TEST_MODE"  : (0x0006,),
  "REPORTING_MODE"  : (0x0001,),
}

prm_575_FDE_ReadCertificateFromDrive = {
  "CERT_KEYTYPE" : (0x0000,),
  "CERT_TSTMODE" : (0x0000,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0014,),
  "UIDLSWL" : (0x0000,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0000,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_Get2048CertificateKeyPair = {
  "CERT_KEYTYPE" : (0x0040,),
  "CERT_TSTMODE" : (0x0007,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0018,),
  "UIDLSWL" : (0x0000,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0000,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_Get1024CertificateKeyPair = {
  "CERT_KEYTYPE" : (0x0020,),
  "CERT_TSTMODE" : (0x0007,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0018,),
  "UIDLSWL" : (0x0000,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0000,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_SetCoreSpec_2 = {
  "TEST_MODE"  : (0x22,),
}
prm_575_SetCoreSpec_1 = {
  "TEST_MODE"  : (0x21,),
}


################################## ###########################################
## SetSSC xxxxxxxxxxxxxxxx
#################################################################################################



prm_575_SetSSCOpal = {

    "TEST_MODE"  : (0x23,),
    "MASTER_AUTHORITY" : (0x01,),    ##00 = MSID, 01 == PSID
    "CORE_SPEC"  : (0x02,),          ##01 = 1.0, 02 = 2.0
    "OPAL_SSC_SUPPORT" : (0x01,),    ## non zero = OPAL supported
    "SYMK_KEY_TYPE" : (0x02,),       ##01 = 3DES. 02 AES256.
    "MAINTSYMK_SUPP" : (0x01,),
    "REPORTING_MODE" : (0x0001,),

}

prm_575_SetSSCOpal_np = {

    "TEST_MODE"  : (0x23,),
    "MASTER_AUTHORITY" : (0x01,),    ##00 = MSID, 01 == PSID
    "CORE_SPEC"  : (0x02,),          ##01 = 1.0, 02 = 2.0
    "OPAL_SSC_SUPPORT" : (0x01,),    ## non zero = OPAL supported
    "SYMK_KEY_TYPE" : (0x01,),       ##01 = 3DES. 02 AES256.
    "MAINTSYMK_SUPP" : (0x01,),
    "REPORTING_MODE" : (0x0000,),

}

prm_575_SetSSC1MT = {
    "TEST_MODE"  : (0x23,),
    "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
    "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
    "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
    "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
    "MAINTSYMK_SUPP" : (0x01,),
    "REPORTING_MODE" : (0x0001,),

}
prm_575_SetSSC_Yosemite = {
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0001,),

}
prm_575_SetSSC1MT_np = {
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
        "REPORTING_MODE" : (0x0000,),

}
prm_575_SetSSC1MTbypassPSID_np = {
  "TEST_MODE"  : (0x39,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0000,),

}
prm_575_SetSSC1MTnp = {
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0001,),

}
prm_575_SetSSCDellaTCG1 = {
    ## Corespec 1.0, PSID is master authority, TCG mode
      "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
      "REPORTING_MODE" : (0x0001,),
        "TCG_VERSION"      : (0x0001,),

}
prm_575_SetSSCDella = {
    ## Corespec 1.0, PSID is master authority, TCG mode
        "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
        "REPORTING_MODE" : (0x0001,),

}

prm_575_SetSSCDella_np= {
    ## Corespec 1.0, PSID is master authority, TCG mode
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0000,),

}

prm_575_SetSSCDella_np_opal= {
    ## Corespec 1.0, PSID is master authority, TCG mode
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x02,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x01,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0000,),
  "TCG_VERSION"      : (0x0002,),
}


prm_575_SetSSCDellaTCG2 = {
    ## Corespec 1.0, PSID is master authority, TCG mode
        "TEST_MODE"        : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),
        "CORE_SPEC"        : (0x01,),
        "OPAL_SSC_SUPPORT" : (0x00,),
        "SYMK_KEY_TYPE"    : (0x02,),
        "MAINTSYMK_SUPP"   : (0x01,),
      "REPORTING_MODE"   : (0x0006,),
        "TCG_VERSION"      : (0x0002,),
}
prm_575_SetSSCDellaTCG2_np= {
    ## Corespec 1.0, PSID is master authority, TCG mode
      "TEST_MODE"        : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"        : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE"    : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP"   : (0x01,),
        "REPORTING_MODE"   : (0x0000,),
        "TCG_VERSION"      : (0x02,),
#      "CUSTOMER_OPTION"  : (0x0001,),


}




prm_575_SetSSCLightning_bug_np = {
    ## Corespec 1.0, PSID is master authority, TCG mode
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0000,),

}

prm_575_della_lightning_bug = {
    ## Corespec 1.0, PSID is master authority, TCG mode
  "TEST_MODE"  : (0x23,),
        "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
        "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
        "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
        "SYMK_KEY_TYPE" : (0x02,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
        "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0000,),

}

prm_575_SetSSCYosemite = {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
  "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
  "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
  "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
  "REPORTING_MODE" : (0x0001,),

}

prm_575_SetSSCYosemite_np = {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
  "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
  "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
  "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
  "REPORTING_MODE" : (0x0000,),

}

prm_575_SetSSC1MTKey1 = {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x00,),    ##00 = MSID, 01 == PSID
  "CORE_SPEC"  : (0x01,),          ##01 = 1.0, 02 = 2.0
  "OPAL_SSC_SUPPORT" : (0x00,),    ## non zero = OPAL supported
  "SYMK_KEY_TYPE" : (0x01,),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
  "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0000,),

}

prm_575_SetSSCGrenada = {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x01,),    ##00 = MSID, 01 == PSID
  "CORE_SPEC"  : (0x02,),          ##01 = 1.0, 02 = 2.0
##  "OPAL_SSC_SUPPORT" : (0x01,),    ## non zero = OPAL supported
  "SYMK_KEY_TYPE" : (0x01,),       ##01 = 3DES. 02 AES256.
  "MAINTSYMK_SUPP" : (0x01,),
  "REPORTING_MODE" : (0x0001,),
}

prm_575_SetSSC1MT_FA= {
  "TEST_MODE"  : (0x2f,),
  "MASTER_AUTHORITY" : (0x00,),
  "CORE_SPEC"  : (0x01,),
  "OPAL_SSC_SUPPORT" : (0x00,),
  "MSID_OFFSET" : (0x69,),
  "DEBUG_FLAG" :(0x01,),
  "SYMK_KEY_TYPE" : (0x00,),
  "MAINTSYMK_SUPP" : (0x00,),
  "REPORTING_MODE" : (0x0000,),
}

prm_575_SetSSC1MT_AirwalkerSATA= {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x00,),
  "CORE_SPEC"  : (0x01,),
  "OPAL_SSC_SUPPORT" : (0x00,),
  "SYMK_KEY_TYPE" : (0x00,),
  "MAINTSYMK_SUPP" : (0x00,),
  "REPORTING_MODE" : (0xffff,),
}
prm_575_SetSSC1MT_AirwalkerSATA_NP= {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x00,),
  "CORE_SPEC"  : (0x01,),
  "OPAL_SSC_SUPPORT" : (0x00,),
  "SYMK_KEY_TYPE" : (0x00,),
  "MAINTSYMK_SUPP" : (0x00,),
  "REPORTING_MODE" : (0x0000,),
}

prm_575_SetSSC1MTnoPSID = {
  "TEST_MODE"  : (0x23,),
  "MASTER_AUTHORITY" : (0x00,),
  "CORE_SPEC"  : (0x01,),
  "OPAL_SSC_SUPPORT" : (0x00,),
  "MSID_OFFSET" : (0x69,),
  "DEBUG_FLAG" :(0x00,),
  "REPORTING_MODE" : (0xffff,),
}


prm_575_FDE_GetTD_SIDFromFIS= {
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0024,),
}

#?############## Band checking functions ##################################

prm_575_FDE_Check_band_values = {
  "TEST_MODE"          : (0x36,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0001,),
    "WRITE_LOCKED"       : (0x0001,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),

}

prm_575_FDE_Check_band_valuesUL = {
  "TEST_MODE"          : (0x36,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0000,),
    "WRITE_LOCKED"       : (0x0000,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),

}

prm_575_FDE_Check_band1_values = {
  "TEST_MODE"          : (0x36,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0001,),
    "WRITE_LOCKED"       : (0x0001,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),
    "BAND_BIT_MASK"      : (0xfffd,),
    "CUSTOMER_OPTION"    : (0x30,),

}

prm_575_FDE_Check_bands0_9_values = {
  "TEST_MODE"          : (0x36,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0001,),
    "WRITE_LOCKED"       : (0x0001,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),
    "BAND_BIT_MASK"      : (0x0002,),
    "CUSTOMER_OPTION"    : (0x0000,),

}

prm_575_FDE_Check_TCG2_band_values = {
  "TEST_MODE"          : (0x36,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0000,),
    "WRITE_LOCKED"       : (0x0000,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),
    "BAND_BIT_MASK"      : (0x0000,),
    "CUSTOMER_OPTION"    : (0x0000,),

}

prm_575_FDE_Check_bands2_9_values = {
  "TEST_MODE"          : (0x36,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0001,),
    "WRITE_LOCKED"       : (0x0001,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),
    "BAND_BIT_MASK"      : (0x0003,),
    "CUSTOMER_OPTION"    : (0x00,),

}
prm_575_FDE_Check_band_enables = {
  "TEST_MODE"          : (0x38,),
  "REPORTING_MODE"     : (0x0000,),
  "WHICH_SP"           : (0x0001,),
  "PASSWORD_TYPE"      : (0x0002,),
  "UIDMSWU"            : (0x0000,),
  "UIDMSWL"            : (0x0802,),
  "UIDLSWU"            : (0x0000,),
  "UIDLSWL"            : (0x0002,),
    "RANGE_START"        : (0x0000,),
    "RANGE_LENGTH"       : (0x0000,),
    "READ_LOCKED"        : (0x0001,),
    "WRITE_LOCKED"       : (0x0001,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0x0000,),
    "BAND_ENABLED"       : (0x0000,),
    "LOCK_ON_RESET"      : (0x0001,),

}

prm_575_get_range_start = {
  "TEST_MODE" : (0x0030,),
  "UIDLSWL" : (0x0002,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0802,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}

prm_575_get_range_length = {
  "TEST_MODE" : (0x0031,),
  "UIDLSWL" : (0x0002,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0802,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0001,),
}

prm_575_configure_band_0 = {

  "TEST_MODE"    : (0x000b,),
  "UIDLSWL"      : (0x0001,),
  "UIDLSWU"      : (0x0000,),
  "UIDMSWL"      : (0x0802,),
  "UIDMSWU"      : (0x0000,),
  "WHICH_SP"     : (0x0001,),
    "READ_LOCK_ENABLED"  : (0x0000,),
    "WRITE_LOCK_ENABLED" : (0X0000,),
    "READ_LOCKED"  : (0x0001,),
    "WRITE_LOCKED" : (0X0001,),

}



##################### Port Checking functions ##############################


prm_575_FDE_GetCertificateFromDrive = {
  "CERT_KEYTYPE" : (0x0000,),
  "CERT_TSTMODE" : (0x0000,),
  "DRIVE_STATE" : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0014,),
  "UIDLSWL" : (0x0001,),
  "UIDLSWU" : (0x0000,),
  "UIDMSWL" : (0x0205,),
  "UIDMSWU" : (0x0000,),
  "WHICH_SP" : (0x0000,),
}
prm_575_FDE_Set_Mfg_State = {
  "DRIVE_STATE" : (0x0081,),      ##"Mfg" state
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0008,),
}

prm_575_FDE_Set_Use_State = {

  "DRIVE_STATE" : (0x0080,),      ##"use" state
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0008,),
}

prm_575_FDE_Set_Diag_State = {
  "DRIVE_STATE" : (0x0001,),      ##"diag" state
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0008,),
}

prm_575_FDE_Set_Setup_State = {
  "DRIVE_STATE" : (0x0000,),      ##"setup" state
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0008,),
}

prm_575_Get_maintsymk_Table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0002,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0000,),
  "UIDMSWL"  : (0x0009,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0xff02,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}

prm_575_Get_band_Table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0002,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0000,),
  "UIDMSWL"  : (0x0009,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0xff02,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}

prm_575_Enable_maintsymk = {
  "TEST_MODE"  : (0x2A,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0002,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0000,),
  "UIDMSWL"  : (0x0009,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0xff02,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}


#/*********************************************************************
# Port control functions #########################
#/*********************************************************************
prm_575_Enable_Band_0_LOR = {
  "TEST_MODE"  : (0x2C,),
  "WHICH_SP"     : (0x0001,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDLSWL"      : (0x0001,),
  "UIDLSWU"      : (0x0000,),
  "UIDMSWL"      : (0x0802,),
  "UIDMSWU"      : (0x0000,),
}

prm_575_Enable_FW_Port_LOR = {
  "TEST_MODE"  : (0x2C,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0002,),
}
prm_575_Disable_FW_Port_LOR = {
  "TEST_MODE"  : (0x15,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0002,),
}
prm_575_Get_FW_Port_Locking_Table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0002,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0002,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}
prm_575_Unlock_FW_Port = {
  "TEST_MODE"  : (0x13,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0000,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0002,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}
prm_575_Lock_FW_Port = {
  "TEST_MODE"  : (0x19,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0000,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
        "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0002,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}

prm_575_Enable_UDS_Port_LOR = {
  "TEST_MODE"  : (0x2C,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0003,),
}

prm_575_Disable_UDS_Port_LOR = {
  "TEST_MODE"  : (0x15,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0003,),
}
prm_575_Get_UDS_Port_Locking_Table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0003,),
}
prm_575_Unlock_UDS_Port = {
  "TEST_MODE"  : (0x13,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0003,),
}
prm_575_Lock_UDS_Port = {
  "TEST_MODE"  : (0x19,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0003,),
}
############# Diagnostic Port functions
prm_575_Enable_DIAG_Port_LOR = {
  "TEST_MODE"  : (0x2C,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0001),
}
prm_575_Disable_DIAG_Port_LOR = {
  "TEST_MODE"  : (0x15,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0001),
}
prm_575_Get_DIAG_Port_Locking_Table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0001,),
}
prm_575_Unlock_DIAG_Port = {
  "TEST_MODE"  : (0x13,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0001,),
}
prm_575_Lock_DIAG_Port = {
  "TEST_MODE"  : (0x19,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "PASSWORD_TYPE"  : (0x0000,),
  "DRIVE_STATE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
        "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x0001,),
  "CERT_TSTMODE" : (0x0000,),
  "CERT_KEYTYPE"    : (0x0000,),
}
############# Cross Segment Firmware Download Port functions
prm_575_Enable_CSFDL_Port_LOR = {
  "TEST_MODE"  : (0x2C,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x000E),
}
prm_575_Disable_CSFDL_Port_LOR = {
  "TEST_MODE"  : (0x15,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x000E),
}
prm_575_Get_CSFDL_Port_Locking_Table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x000E,),
}
prm_575_Unlock_CSFDL_Port = {
  "TEST_MODE"  : (0x13,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x000E,),
}
prm_575_Lock_CSFDL_Port = {
  "TEST_MODE"  : (0x19,),
  "REPORTING_MODE"  : (0x0000,),
  "UIDMSWU"  : (0x0001,),
  "UIDMSWL"  : (0x0002,),
  "UIDLSWU"  : (0x0001,),
  "UIDLSWL"  : (0x000E,),
}

prm_575_checkBandXRangeStart = {
  'TEST_MODE' : (0x0030,),
  'UIDMSWU' : (0x0000,),   #0000080200000001 = GLOBAL range
  'UIDMSWL' : (0x0802,),   #0000080200000002 = band 1
  'UIDLSWU' : (0x0000,),   #000008020000000x = band (x-1)
  'UIDLSWL' : (0x0001,),
  'DRIVE_STATE' : (0x0000,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
  'WHICH_SP' : (0x0001,),
        'BLOCK_SIZE' : (0x0000,),
}
prm_575_checkBandXRangeLength = {
  'TEST_MODE' : (0x0031,),
  'UIDMSWU' : (0x0000,),   #0000080200000001 = GLOBAL range
  'UIDMSWL' : (0x0802,),   #0000080200000002 = band 1
  'UIDLSWU' : (0x0000,),   #000008020000000x = band (x-1)
  'UIDLSWL' : (0x0001,),
  'DRIVE_STATE' : (0x0000,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
  'WHICH_SP' : (0x0001,),
        'BLOCK_SIZE' : (0x0000,),
}

prm_575_checkGlobalBandRangeStart = {
  'TEST_MODE' : (0x0030,),
  'UIDMSWU' : (0x0000,),   #0000080200000001 = GLOBAL range
  'UIDMSWL' : (0x0802,),   #0000080200000002 = band 1
  'UIDLSWU' : (0x0000,),   #000008020000000x = band (x-1)
  'UIDLSWL' : (0x0001,),
  'DRIVE_STATE' : (0x0000,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
  'WHICH_SP' : (0x0001,),
        'BLOCK_SIZE' : (0x0001,),
}
prm_575_checkGlobalBandRangeLength = {
  'TEST_MODE' : (0x0031,),
  'UIDMSWU' : (0x0000,),   #0000080200000001 = GLOBAL range
  'UIDMSWL' : (0x0802,),   #0000080200000002 = band 1
  'UIDLSWU' : (0x0000,),   #000008020000000x = band (x-1)
  'UIDLSWL' : (0x0001,),
  'DRIVE_STATE' : (0x0000,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
  'WHICH_SP' : (0x0001,),
        'BLOCK_SIZE' : (0x0001,),
}


prm_575_CheckFWPort_states = {
  'TEST_MODE' : (0x0037,),
  'REPORTING_MODE' : (0x0000,),
    'PORT_LOCKED' : (0x0000,),  ## port locked
    'LOCK_ON_RESET' : (0x0000,), ## lock on reset 00
  'UIDMSWU' : (0x0001,),
  'UIDMSWL' : (0x0002,),
  'UIDLSWU' : (0x0001,),
  'UIDLSWL' : (0x0002,),
}
prm_575_CheckUDSPort_states = {
  'TEST_MODE' : (0x0037,),
  'UIDMSWU' : (0x0001,),
  'UIDMSWL' : (0x0002,),
  'UIDLSWU' : (0x0001,),
  'UIDLSWL' : (0x0003,),
  'REPORTING_MODE' : (0x0000,),
  'PORT_LOCKED' : (0x0001,),
  'LOCK_ON_RESET' : (0x0001,),
}
prm_575_CheckDIAGPort_states = {
  'TEST_MODE' : (0x0037,),
  'UIDMSWU' : (0x0001,),
  'UIDMSWL' : (0x0002,),
  'UIDLSWU' : (0x0001,),
  'UIDLSWL' : (0x0001,),
  'REPORTING_MODE' : (0x0000,),
  'PORT_LOCKED' : (0x0001,),
  'LOCK_ON_RESET' : (0x0001,),
}
prm_575_CheckCrossSegmentDownloadPort_states = {
  'TEST_MODE' : (0x0037,),
  'UIDMSWU' : (0x0001,),
  'UIDMSWL' : (0x0002,),
  'UIDLSWU' : (0x0001,),
  'UIDLSWL' : (0x000E,),
  'REPORTING_MODE' : (0x0000,),
  'PORT_LOCKED' : (0x0001,),
  'LOCK_ON_RESET' : (0x0001,),
}

prm_575_SetFWPortLockOnReset = {
  'TEST_MODE' : (0x002C,),
  'UIDMSWU' : (0x0001,),
  'UIDMSWL' : (0x0002,),
  'UIDLSWU' : (0x0001,),
  'UIDLSWL' : (0x0002,),
  'DRIVE_STATE' : (0x0000,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
  'WHICH_SP' : (0x0000,),
}
prm_575_ClearFWPortLockOnReset = {
  'TEST_MODE' : (0x0015,),
  'UIDMSWU' : (0x0001,),
  'UIDMSWL' : (0x0002,),
  'UIDLSWU' : (0x0001,),
  'UIDLSWL' : (0x0002,),
  'DRIVE_STATE' : (0x0000,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
  'WHICH_SP' : (0x0000,),
}

prm_575_Authenticate_to_bootfwMSID = {
  'timeout':30,
  'TEST_MODE' : (0x002D,),
  'PASSWORD_TYPE' : (0x0002,),
  'REPORTING_MODE' : (0x0000,),
}

prm_575_Authenticate_to_bootfwDefault = {
  'timeout':30,
  'TEST_MODE' : (0x002D,),
  'PASSWORD_TYPE' : (0x0000,),
  'REPORTING_MODE' : (0x0000,),
}

prm_575_enter_bootfw = {
  'timeout':30,
  'TEST_MODE' : (0x002E,),
  'REPORTING_MODE' : (0x000,),
}
################## DITs Nuke command functions  ############################
prm_575_NukeFirmware_prep = {
  "PRE_NUKE_PREP" : (0x0622,),
  "TEST_MODE"  : (0x26,),
  "REPORTING_MODE"  : (0x0000,),
}
prm_575_NukeFirmware = {
  "TEST_MODE"  : (0x27,),
  "REPORTING_MODE"  : (0x0000,),
}

prm_575_ReadIV = {
  "TEST_MODE"  : (0x2b,),
  "REPORTING_MODE"  : (0x0000,),
}

prm_575_RandomMethod = {
  "TEST_MODE"  : (0x28,),
  "REPORTING_MODE"  : (0x0000,),
  "PASSWORD_TYPE" : (0x0002,),

}

prm_575_GenerateRandom32byteStrings = {
  "TEST_MODE"  : (0x28,),
  "REPORTING_MODE"  : (0x0000,),
  "PASSWORD_TYPE" : (0x0000,),
  "LOOP_COUNT"    : (0x0040,),

}
prm_575_FDE_set_SID = {
  "TEST_MODE"  : (0x04,),
  "REPORTING_MODE"  : (0x0000,),
  'UIDMSWU' : (0x0000,),
  'UIDMSWL' : (0x000B,),
  'UIDLSWU' : (0x0000,),
  'UIDLSWL' : (0x0001,),
}

prm_575_Get_Makers_table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "UIDMSWU"  : (0x0009,),
  "UIDMSWL"  : (0x0000,),
  "UIDLSWU"  : (0x0000,),
  "UIDLSWL"  : (0x0003,),
}

prm_575_Get_MakerSymK_table = {
  "TEST_MODE"  : (0x05,),
  "REPORTING_MODE"  : (0x0000,),
  "WHICH_SP"  : (0x0000,),
  "UIDMSWU"  : (0x0009,),
  "UIDMSWL"  : (0x0000,),
  "UIDLSWU"  : (0x0000,),
  "UIDLSWL"  : (0x0004,),
}


prm_638_Unlock_SDD_Drive = {
   'TEST_FUNCTION'   : (0x0000,),
   'CTRL_WORD1'      : (0x0019,),
   'DFB_WORD_0'      : (0x0100,),
   'DFB_WORD_1'      : (0x0100,),
}
prm_638_Old_Unlock_SDD_Drived = {
   'TEST_FUNCTION'   : (0x0000,),
   'CTRL_WORD1'      : (0x0008,),
   'DFB_WORD_0'      : (0x0100,),
   'DFB_WORD_1'      : (0x0100,),
   'DFB_WORD_2'      : (0x0000,),
   'DFB_WORD_3'      : (0x0000,),
}


######################################################
#******************FDE part *************************
# 574 tests
prm_574_FDE_WriteCompare = {
   ##'test_num' : 574,
   ##'prm_name' : 'prm_574_FDE_WriteCompare',
   ##'timeout' : 3600,

     "WR_FUNCTION"      : (0x0007,),
     "REPORTING_MODE"     : (0x0000,),
     "CLEAR_SESSION"      : (0x0000,),
     "TEST_MODE"      : (0x0000,),
     "BANDMASTER"      : (0x0000,),
     "START_LBA_H"      : (0x0000,),
     "START_LBA_L"      : (0x1FFA,),
     "BAND_SIZE_H"      : (0x0000,),
     "BAND_SIZE_L"      : (0x0000,),
     "LOCK_ENABLES"      : (0x0000,),
     "STATUS_MISCOM_EXP"         : (0x0004,),
     "TRANSFER_LENGTH"     : (0x0010,),
     "PATTERN_MSW"      : (0x0000,),
     "PATTERN_LSW"      : (0x0000,),
     "EXP_SENSE_BYTE2"     : (0x05,),
     "EXP_SENSE_BYTE12"          : (0x24,),
     "EXP_SENSE_BYTE13"          : (0x00,),
}

prm_574_FDE_Erasure = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0001,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0008,),
  "WR_FUNCTION" : (0x0000,),
}
prm_574_FDE_ReadCompare = {
  "BANDMASTER" : (0x0000,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0010,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0000,),
  "WR_FUNCTION" : (0x000E,),
}
prm_574_FDE_WrtReadBand = {
   "WR_FUNCTION"      : (0x07,),
   "REPORTING_MODE"     : (0x0000,),
   "CLEAR_SESSION"      : (0x0000,),
   "TEST_MODE"      : (0x0000,),
   "BANDMASTER"      : (0x0000,),
   "START_LBA_H"      : (0x0000,),
   "START_LBA_L"      : (0x2001,),
   "BAND_SIZE_H"      : (0x0000,),
   "BAND_SIZE_L"      : (0x0000,),
   "LOCK_ENABLES"      : (0x0000,),
   "STATUS_MISCOM_EXP"  : (0x0004,),
   "TRANSFER_LENGTH"     : (0x0010,),
   "PATTERN_MSW"      : (0x0000,),
   "PATTERN_LSW"      : (0x0000,),
   "EXP_SENSE_BYTE2"     : (0x07,),
   "EXP_SENSE_BYTE12"    : (0x20,),
   "EXP_SENSE_BYTE13"    : (0x02,),
}

prm_574_FDE_WriteBand_Pass= {
    "WR_FUNCTION"      : (0x05,),
    "REPORTING_MODE"     : (0x0000,),
    "CLEAR_SESSION"      : (0x0000,),
    "TEST_MODE"      : (0x0000,),
    "BANDMASTER"      : (0x0001,),
    "START_LBA_H"      : (0x0000,),
    "START_LBA_L"      : (0x0900,),
    "BAND_SIZE_H"      : (0x0000,),
    "BAND_SIZE_L"      : (0x0000,),
    "LOCK_ENABLES"      : (0x0000,),
    "TRANSFER_LENGTH"     : (0x0010,),
    "PATTERN_MSW"      : (0x0000,),
    "PATTERN_LSW"      : (0x0000,),
    "STATUS_MISCOM_EXP"  : (0x0000,),
    "EXP_SENSE_BYTE2"    : (0x00,),
    "EXP_SENSE_BYTE12"   : (0x00,),
    "EXP_SENSE_BYTE13"   : (0x00,),
}

prm_574_FDE_ReadBand = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0007,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0010,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0000,),
  "WR_FUNCTION" : (0x0006,),
}

prm_574_FDE_WriteBand = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0007,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0010,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0000,),
  "WR_FUNCTION" : (0x0005,),
}

prm_574_FDE_UnlockBand = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_FDE_LockBand = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x00FF,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_FDE_CreateBand_1000_0000 = {
   ## Band size is 1000h, starting LBA is 0h
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x2000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0001,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0002,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_FDE_CreateBand_1000_8000 = {
   ## Band size is 1000h, starting LBA is 0h
  "BANDMASTER" : (0x0000,), # was an 01
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x1000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x8000,),
  "TEST_MODE" : (0x0002,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_FDE_CreateBand_1234_0000 = {
  "TEST_MODE" : (0x0002,),
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x1234,),
  "LOCK_ENABLES" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x3456,),
}
###################  Test 577 variations ######################################


prm_577_FDE_Della_security_config = {
  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0014,),
}

prm_577_FDE_ResetSETUP_Opal = {
  "DRIVE_STATE" : (0x0000,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0008,),
}

prm_577_FDE_ResetSETUP_Della = {
  "DRIVE_STATE" : (0x0000,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0008,),
}
prm_577_FDE_Set_Della_USE = {
  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0004,),
}
prm_577_FDE_Set_Della_DIAG = {
  "DRIVE_STATE" : (0x0001,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0004,),
}

prm_577_FDE_Set_Della_MFG = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0004,),
}

prm_577_FDE_ResetSETUP_Yosemite = {
  "DRIVE_STATE" : (0x0000,),
  "FW_PLATFORM" : (0x0020,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0008,),
}

prm_577_FDE_ResetSETUP_Cannon = {
  "CERT_KEYTYPE" : (0x0000,),
  "DRIVE_STATE" : (0x0000,),
  "FW_PLATFORM" : (0x0010,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0008,),
}

###################  Test 577 variations ######################################

prm_577_FDE_Personalization_Cannon_MFG = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0010,),
  "MSID_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0005,),
}

prm_577_FDE_Personalization_Della_MFG = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0005,),
}

prm_577_FDE_Personalization_Della_ISE = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0008,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0005,),
##        "CUSTOMER_OPTION" : (0x0000,),
}

prm_577_FDE_Verification_Della_SDD_TCG2_USE = {

#  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x000C,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0002,),
  "CUSTOMER_OPTION" : (0x0002,), # SDD option
}
prm_577_FDE_Verification_Della_SDD_TCG2_DIAG = {

  "DRIVE_STATE" : (0x0001,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x000C,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
  "CUSTOMER_OPTION" : (0x0002,), # SDD option
}

prm_577_FDE_Verification_Della_SDD_TCG2_MFG = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
  "CUSTOMER_OPTION" : (0x0002,), # SDD option
}

prm_577_FDE_Personalization_Della_SDD = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
  "CUSTOMER_OPTION" : (0x0002,), # SDD option - this is correct so leave it alone
}

prm_577_FDE_Personalization_Della_SDD_IEEE = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
    "CUSTOMER_OPTION" : (0x0002,), # SDD option
    "FEATURE_OPTION"  :(0x0000,0x0000,0x0000,0x0000,),
}

prm_577_FDE_Personalization_Della_SED = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
    "CUSTOMER_OPTION" : (0x0001,), # SED option
}

prm_577_FDE_Personalization_Opal_SED = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
    "CUSTOMER_OPTION" : (0x0001,), # SED option
}

prm_577_FDE_Personalization_Opal_SDD= {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
    "CUSTOMER_OPTION" : (0x0002,), # SED option
}

prm_577_FDE_Personalization_Della_SDD_TCG2 = {

  "PORT_LOCKED" : (0x0000,),
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
  "CUSTOMER_OPTION" : (0x0002,), # SDD option
}

prm_577_FDE_Personalization_Della_NetApps = {

  "PORT_LOCKED" : (0x0000,),
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
  "CUSTOMER_OPTION" : (0x0030,), # NetApps band 1 option
}

prm_577_FDE_Personalization_Yosemite_NetApps = {

  "PORT_LOCKED" : (0x0000,),
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0020,),
  "MSID_TYPE"   : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0005,),
  "CUSTOMER_OPTION" : (0x0030,), # NetApps band 1 option
}

prm_577_FDE_Verification_Cannon_MFG = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0010,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}

prm_577_FDE_Verification_Cannon_USE = {
  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0010,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}

prm_577_FDE_Verification_Della_USE = {
  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}
prm_577_FDE_SET_USE_STATE_Della = {
  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0001,),
  "TEST_MODE" : (0x0004,),
}

prm_577_FDE_Verification_Della = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0002,),
}

prm_577_FDE_Verification_Della_MFG = {
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}

prm_577_FDE_Verification_Yosemite_NetApps_USE = {

  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0020,),
  "MSID_TYPE"   : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE"   : (0x0006,),
  "CUSTOMER_OPTION" : (0x0030,), # NetApps band 1 option
}

prm_577_FDE_Verification_Della_ISE_MFG = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x000C,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}

prm_577_FDE_Verification_Della_ISE_USE = {

  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0040,),
  "MSID_TYPE" : (0x000C,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}

prm_577_FDE_Personalization_Yosemite_ISE = {

  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0020,),
  "MSID_TYPE" : (0x0008,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0005,),
}

prm_577_FDE_Verification_Yosemite_ISE = {
  "DRIVE_STATE" : (0x0080,),
  "FW_PLATFORM" : (0x0020,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x0000,),
  "TEST_MODE" : (0x0006,),
}

prm_533_1_5GB = {
   "FC_SAS_TRANSFER_RATE" : (0x0001),
}


prm_508_Compare_Read_Buffer = {
   ##'test_num' : 508,
   ##'prm_name' : 'prm_508_Compare_Read_Buffer',
   ##'timeout' : 420,

  "PARAMETER_1" : (0x0009,),
  "PARAMETER_10" : (0x0000,),
  "PARAMETER_2" : (0x0000,),
  "PARAMETER_3" : (0x0000,),
  "PARAMETER_4" : (0x0000,),
  "PARAMETER_5" : (0x0000,),
  "PARAMETER_6" : (0x0000,),
  "PARAMETER_7" : (0x3831,),
  "PARAMETER_8" : (0x3831,),
  "PARAMETER_9" : (0x0000,),
}

prm_508_Display_ReadBuffer = {
   'test_num' : 508,
   'prm_name' : 'prm_508_Display_ReadBuffer',
   'timeout' : 420,

   "PARAMETER_1" : (0x0005,),
   "PARAMETER_10" : (0x0000,),
   "PARAMETER_2" : (0x0000,),
   "PARAMETER_3" : (0x0200,),
   "PARAMETER_4" : (0x0000,),
   "PARAMETER_5" : (0x0000,),
   "PARAMETER_6" : (0x0000,),
   "PARAMETER_7" : (0x0000,),
   "PARAMETER_8" : (0x0000,),
   "PARAMETER_9" : (0x0000,),
}
prm_508_Display_ReadBuffer = {
   ##'test_num' : 508,
   ##'prm_name' : 'prm_508_Display_ReadBuffer',
   ##'timeout' : 420,

  "PARAMETER_1" : (0x0005,),
  "PARAMETER_10" : (0x0000,),
  "PARAMETER_2" : (0x0000,),
  "PARAMETER_3" : (0x800,),
  "PARAMETER_4" : (0x0000,),
  "PARAMETER_5" : (0x0000,),
  "PARAMETER_6" : (0x0000,),
  "PARAMETER_7" : (0x0000,),
  "PARAMETER_8" : (0x0000,),
  "PARAMETER_9" : (0x0000,),
}

prm_508_Disp_ReadBuffer = {
  "CTRL_WORD1" :          (0x0005,),
##  "READ_BUFFER_OFFSET" :  (0x0000,),
##  "WRITE_BUFFER_OFFSET" : (0x0000,),
##  "BYTE_OFFSET" :         (0x0000,),
##  "PATTERN_TYPE" :        (0x0000,),
  "BUFFER_LENGTH" :       (0x0000,0x0f00,),
##  "BYTE_PATTERN_LENGTH" : (0x0000,),
##  "BIT_PATTERN_LENGTH" :  (0x0000,),
##  "DATA_PATTERN0" :       (0x0000,),
##  "DATA_PATTERN1" :       (0x0000,),
##  "RANDOM_SEED" :         (0x0000,),
  "OPTIONS" :             (0x0000,),
}


prm_510_FDE_SeqRead = {
   ##'test_num' : 510,
   ##'prm_name' : 'prm_510_FDE_SeqRead',
   ##'timeout' : 72000,
   "dlfile" : (CN, 'scsierr.txt'),

  "ACCESS_MODE" : (0x0000,),
  "BLOCKS_TO_TRANS" : (0x0000,0x0FA0,),
  "BUTTERFLY_ACCESS" : (0x0000,),
  "CACHE_MODE" : (0x0000,),
  "CHK_NONREC_ERR_PER_HD" : (0x0000,),
  "CRESCENDO_ACCESS" : (0x0000,),
  "DISABLE_ECC_ON_FLY" : (0x0000,),
  "DISABLE_FREE_RETRY" : (0x0000,),
  "DISCONNECT_MODE" : (0x0000,),
  "ECC_CONTROL" : (0x0000,),
  "ENBL_LOG10_BER_SPEC" : (0x0000,),
  "END_LBA" : (0x0000,0x0000,),
  "ERROR_REPORTING_MODE" : (0x0000,),
  "EXECUTE_HIDDEN_RETRY" : (0x0000,),
  "EXTENDED_LIMITS" : (0x0000,),
  "FAIL_ERROR_CODES_SCSIERR" : (0x0000,),
  "FILL_WRITE_BUFFER" : (0x0000,),
  "LBA_LSW" : (0x1388,),
  "LBA_MSW" : (0x0000,),
  "LOG10_BER_SPEC" : (0x0000,),
  "MAX_REC_ERRORS" : (0x0000,),
  "MAX_UNRECOVERABLE_ERR" : (0x0000,),
  "OPTIONS" : (0x0000,),
  "OPTIONS_WORD1" : (0x0000,),
  "OPTIONS_WORD2" : (0x0000,),
  "PATTERN_LENGTH_IN_BITS" : (0x0000,),
  "PATTERN_LSW" : (0x3039,),
  "PATTERN_MODE" : (0x0000,),
  "PATTERN_MSW" : (0x00C8,),
  "RECOVERED_ERR_LIMS" : (0x0010,),
  "REPORT_HIDDEN_RETRY" : (0x0001,),
  "SAVE_READ_ERR_TO_MEDIA" : (0x0001,),
  "START_LBA" : (0x0000,0x0000,),
  "TEST_FUNCTION" : (0x0000,),
  "TOTAL_BLKS_TO_TRANS_LSW" : (0x86A0,),
  "TOTAL_BLKS_TO_TRANS_MSW" : (0x0001,),
  "TRANSFER_MODE" : (0x0000,),
  "WRITE_AND_VERIFY" : (0x0000,),
  "WRITE_READ_MODE" : (0x0000,),
}

prm_578_FDE_DnldIV = {
   ##'test_num' : 578,
   ##'prm_name' : 'prm_578_FDE_DnldIV',
   ##'timeout' : 1200,
   "dlfile" : (CN, 'FB8_VolC1.trd'),

        "BYTE_COUNT" : (0x0000,),
        "FILE_LEN_LSW" : (0x0000,),
        "FILE_LEN_MSW" : (0x0000,),
        "FW_PLATFORM" : (0x0010,),
        "PASS_COUNT" : (0x0000,),
        "TEST_MODE" : (0x0001,),
 }


###################### Added CUT2 named params here ####################

prm_535_display_init_code = {
    ##'test_num' : 535,
    ##'prm_name' : 'prm_535_display_init_code',
    ##'timeout' : 1200,
    "BAUD_RATE" : (0x0000,),
    "DRIVE_TYPE" : (0x0000,),
    "EXPECTED_FW_REV_1" : (0x0000,),
    "FC_SAS_TRANSFER_RATE" : (0x0000,),
    "REG_ADDR" : (0x0000,),
    "REG_VALUE" : (0x0000,),
    "TEST_FUNCTION" : (0x0000,),
    "TEST_OPERATING_MODE" : (0x0002,),
}

prm_517_ReqSense0 = {
   ##'test_num' : 517,
   ##'prm_name' : 'prm_517_ReqSense_CUT',
   ##'timeout' : 300,

  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x001A,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0001,),     # was 0001
  "SENSE_DATA_1" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_2" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}
prm_517_ReqSense0_No_notify = {
   ##'test_num' : 517,
   ##'prm_name' : 'prm_517_ReqSense_CUT',
   ##'timeout' : 300,

  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x001A,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0000,),     # was 0001
  "SENSE_DATA_1" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_2" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}
prm_517_ReqSense_SAS = {
   ##'test_num' : 517,
   ##'prm_name' : 'prm_517_ReqSense_CUT',
   ##'timeout' : 300,

  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x001A,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0001,),
  "SENSE_DATA_1" : (0x0001,0x0000,0x00FF,0x005D,),
  "SENSE_DATA_2" : (0x0004,0x0000,0x00FF,0x0042,),
  "SENSE_DATA_3" : (0x0004,0x0000,0x00FF,0x0019,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}
prm_517_ReqSense_CUT = {
   ##'test_num' : 517,
   ##'prm_name' : 'prm_517_ReqSense_CUT',
   ##'timeout' : 300,

  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x000A,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0001,),
  "SENSE_DATA_1" : (0x0001,0x0000,0x00FF,0x005D,),
  "SENSE_DATA_2" : (0x0004,0x0000,0x00FF,0x0042,),
  "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}
prm_517_RequestSense3 = {
   ##'test_num' : 517,
   ##'prm_name' : 'prm_517_RequestSense3',
   ##'timeout' : 300,
  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x0003,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0000,),
  "SENSE_DATA_1" : (0x0002,0x0000,0x00FF,0x0004,),
  "SENSE_DATA_2" : (0x0004,0x0000,0x00FF,0x001C,),
  "SENSE_DATA_3" : (0x0004,0x0000,0x00FF,0x0042,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}

prm_517_MikeMagill = {
  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x00ff,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0001,),
  "RPT_SEL_SNS_DATA" : (0x0001,),
  "SEND_TUR_CMDS_ONLY" : (0x0001,),
  "SENSE_DATA_1" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_2" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}

prm_517_RequestSense5 = {
   ##'test_num' : 517,
   ##'prm_name' : 'prm_517_RequestSense5',
   ##'timeout' : 600,
  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x0005,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0000,),
  "SENSE_DATA_1" : (0x0002,0x0000,0x00FF,0x0004,),
  "SENSE_DATA_2" : (0x0004,0x0000,0x00FF,0x001C,),
  "SENSE_DATA_3" : (0x0004,0x0000,0x00FF,0x0042,),
  "SENSE_DATA_4" : (0x0001,0x0000,0x00FF,0x005D,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}
prm_518_read_saved_mode_sense = {
    ##'test_num' : 518,
    ##'prm_name' : 'prm_518_read_saved_mode_sense',
    ##'timeout' : 1800,
    "DATA_TO_CHANGE" : (0x0000,),
    "MODE_COMMAND" : (0x0000,),
    "MODE_SELECT_ALL_INITS" : (0x0000,),
    "MODE_SENSE_INITIATOR" : (0x0000,),
    "MODE_SENSE_OPTION" : (0x0003,),
    "MODIFICATION_MODE" : (0x0000,),
    "PAGE_BYTE_AND_DATA" : (0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,),
    "PAGE_CODE" : (0x003F,),
    "PAGE_FORMAT" : (0x0000,),
    "SAVE_MODE_PARAMETERS" : (0x0000,),
    "SUB_PAGE_CODE" : (0x0000,),
    "TEST_FUNCTION" : (0x0000,),
    "UNIT_READY" : (0x0000,),
    "VERIFY_MODE" : (0x0000,),
}

prm_506_io_timeout_5s = {
    ##'test_num' : 506,
    ##'prm_name' : 'prm_506_io_timeout_5s',
    ##'timeout' : 1200,
    "COMMAND_TIMEOUT_MS" : (0x0000,),
    "COMMAND_TIMEOUT_SECONDS" : (0x0005,),
    "FACTORY_CMD_TIMEOUT_SECS" : (0x0000,),
    "FORMAT_CMD_TIME_LSB" : (0x0000,),
    "FORMAT_CMD_TIME_MSB" : (0x0000,),
    "RESPONSE_TIME_MS" : (0x0000,),
    "TEST_EXE_TIME_SECONDS" : (0x0000,),
    "TEST_FUNCTION" : (0x0000,),
    "WAIT_READY_TIME" : (0x0064,),
}

prm_510_random_write = {
    ##'test_num' : 510,
    ##'prm_name' : 'prm_510_random_write',
    ##'timeout' : 36000,
    "ACCESS_MODE" : (0x0001,),
    "BLOCKS_TO_TRANS" : (0x0000,0x1388,),
    "BUTTERFLY_ACCESS" : (0x0000,),
    "CACHE_MODE" : (0x0000,),
    "CHK_NONREC_ERR_PER_HD" : (0x0000,),
    "CRESCENDO_ACCESS" : (0x0000,),
    "DISABLE_ECC_ON_FLY" : (0x0000,),
    "DISABLE_FREE_RETRY" : (0x0000,),
    "DISCONNECT_MODE" : (0x0000,),
    "ECC_CONTROL" : (0x0000,),
    "ENBL_LOG10_BER_SPEC" : (0x0000,),
    "END_LBA" : (0x0000,0x0000,),
    "ERROR_REPORTING_MODE" : (0x0000,),
    "EXECUTE_HIDDEN_RETRY" : (0x0001,),
    "EXTENDED_LIMITS" : (0x0000,),
    "FAIL_ERROR_CODES_SCSIERR" : (0x0000,),
    "FILL_WRITE_BUFFER" : (0x0000,),
    "LBA_LSW" : (0x0000,),
    "LBA_MSW" : (0x0000,),
    "LOG10_BER_SPEC" : (0x0000,),
    "MAX_REC_ERRORS" : (0x0000,),
    "MAX_UNRECOVERABLE_ERR" : (0x0000,),
    "OPTIONS" : (0x0000,),
    "OPTIONS_WORD1" : (0x0000,),
    "OPTIONS_WORD2" : (0x0000,),
    "PATTERN_LENGTH_IN_BITS" : (0x0000,),
    "PATTERN_LSW" : (0x3039,),
    "PATTERN_MODE" : (0x0001,),
    "PATTERN_MSW" : (0x00C8,),
    "RECOVERED_ERR_LIMS" : (0x0064,),
    "REPORT_HIDDEN_RETRY" : (0x0001,),
    "SAVE_READ_ERR_TO_MEDIA" : (0x0001,),
    "START_LBA" : (0x0000,0x0000,),
    "TEST_FUNCTION" : (0x0000,),
    "TOTAL_BLKS_TO_TRANS_LSW" : (0x0000,),
    "TOTAL_BLKS_TO_TRANS_MSW" : (0x0400,),
    "TRANSFER_MODE" : (0x0000,),
    "WRITE_AND_VERIFY" : (0x0000,),
    "WRITE_READ_MODE" : (0x0002,),
}

prm_506_cmd_timeout_60s = {
    ##'test_num' : 506,
    ##'prm_name' : 'prm_506_cmd_timeout_60s',
    ##'timeout' : 1200,
    "COMMAND_TIMEOUT_MS" : (0x0000,),
    "COMMAND_TIMEOUT_SECONDS" : (0x003C,),
    "FACTORY_CMD_TIMEOUT_SECS" : (0x0000,),
    "FORMAT_CMD_TIME_LSB" : (0x0000,),
    "FORMAT_CMD_TIME_MSB" : (0x0000,),
    "RESPONSE_TIME_MS" : (0x0000,),
    "TEST_EXE_TIME_SECONDS" : (0x0000,),
    "TEST_FUNCTION" : (0x0000,),
    "WAIT_READY_TIME" : (0x0000,),
}


prm_517_check_smart_trips = {
    ##'test_num' : 517,
    ##'prm_name' : 'prm_517_check_smart_trips',
    ##'timeout' : 300,
    "ACCEPTABLE_IF_MATCH" : (0x0000,),
    "ACCEPTABLE_SNS_DATA" : (0x0000,),
    "CHK_FRU_CODE" : (0x0000,),
    "CHK_SRVO_LOOP_CODE" : (0x0000,),
    "MAX_REQS_CMD_CNT" : (0x000A,),
    "OMIT_DUP_ENTRY" : (0x0000,),
    "RPT_REQS_CMD_CNT" : (0x0000,),
    "RPT_SEL_SNS_DATA" : (0x0000,),
    "SEND_TUR_CMDS_ONLY" : (0x0001,),
    "SENSE_DATA_1" : (0x0001,0x0000,0x00FF,0x005D,),
    "SENSE_DATA_2" : (0x0004,0x0000,0x00FF,0x0042,),
    "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
    "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
    "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
    "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
    "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
    "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
    "SRVO_LOOP_CODE" : (0x0000,),
    "TEST_FUNCTION" : (0x0000,),
}


prm_508_buffer = {
    ##'test_num' : 508,
    ##'prm_name' : 'prm_508_buffer',
    ##'timeout' : 800,
    "PARAMETER_1" : (0x0005,),
    "PARAMETER_10" : (0x0000,),
    "PARAMETER_2" : (0x0000,),
    "PARAMETER_3" : (0x0010,),
    "PARAMETER_4" : (0x0000,),
    "PARAMETER_5" : (0x0000,),
    "PARAMETER_6" : (0x0000,),
    "PARAMETER_7" : (0x0000,),
    "PARAMETER_8" : (0x0000,),
    "PARAMETER_9" : (0x0000,),
}

prm_574_WrtReadBand = {
   "WR_FUNCTION"      : (0x07,),          ##WriteReadFunction,
   "REPORTING_MODE"     : (0x0000,),  ##ReportingMode,
   "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
   "TEST_MODE"      : (0x0000,),  ##TestMode,
   "BANDMASTER"      : (0x0000,),  ##WhichBandMaster,
   "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
   "START_LBA_L"      : (0x2001,),  ##StartLBALo,
   "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
   "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
   "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
   "STATUS_MISCOM_EXP"  : (0x0004,),  ##,
   "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
   "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
   "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
   "EXP_SENSE_BYTE2"     : (0x07,),          ##ExpectedSenseByte2,
   "EXP_SENSE_BYTE12"    : (0x20,),          ##ExpectedSenseByte12,
   "EXP_SENSE_BYTE13"    : (0x02,),          ##ExpectedSenseByte13
}

prm_574_ReadBand = {
   'timeout' : 3600,
    "WR_FUNCTION"      : (0x02,),          ##WriteReadFunction,
    "REPORTING_MODE"     : (0x0000,),  ##ReportingMode,
    "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
    "TEST_MODE"      : (0x0000,),  ##TestMode,
    "BANDMASTER"      : (0x0000,),  ##WhichBandMaster,
    "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
    "START_LBA_L"      : (0x1001,),  ##StartLBALo,
    "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
    "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
    "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
##    "STATUS_MISCOM_EXP"         : (0x0004,),  ##ReportingMode,
    "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
    "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
    "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
##    "EXP_SENSE_BYTE2"     : (0x07,),          ##ExpectedSenseByte2,
##    "EXP_SENSE_BYTE12"          : (0x20,),          ##ExpectedSenseByte12,
##    "EXP_SENSE_BYTE13"          : (0x02,),          ##ExpectedSenseByte13
}

prm_574_ReadBand_Pass = {
   'timeout' : 3600,
    "WR_FUNCTION"      : (0x06,),          ##WriteReadFunction,
    "REPORTING_MODE"     : (0x0001,),  ##ReportingMode,
    "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
    "TEST_MODE"      : (0x0000,),  ##TestMode,
    "BANDMASTER"      : (0x0001,),  ##WhichBandMaster,
    "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
    "START_LBA_L"      : (0x1000,),  ##StartLBALo,
    "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
    "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
    "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
    "STATUS_MISCOM_EXP"         : (0x0000,),  ##ReportingMode,
    "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
    "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
    "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
    "EXP_SENSE_BYTE2"     : (0x00,),          ##ExpectedSenseByte2,
    "EXP_SENSE_BYTE12"          : (0x00,),          ##ExpectedSenseByte12,
    "EXP_SENSE_BYTE13"          : (0x00,),          ##ExpectedSenseByte13

}

prm_574_WriteBand = {
   'timeout' : 30,
    "WR_FUNCTION"      : (0x02,),          ##WriteReadFunction,
    "REPORTING_MODE"     : (0x0000,),  ##ReportingMode,
    "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
    "TEST_MODE"      : (0x0000,),  ##TestMode,
    "BANDMASTER"      : (0x0001,),  ##WhichBandMaster,
    "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
    "START_LBA_L"      : (0x1001,),  ##StartLBALo,
    "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
    "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
    "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
    "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
    "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
    "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
##    "STATUS_MISCOM_EXP"         : (0x0004,),  ##ReportingMode,
##    "EXP_SENSE_BYTE2"     : (0x07,),          ##ExpectedSenseByte2,
##    "EXP_SENSE_BYTE12"          : (0x20,),          ##ExpectedSenseByte12,
##    "EXP_SENSE_BYTE13"          : (0x02,),          ##ExpectedSenseByte13
}

prm_574_WriteBandPass= {
##   'timeout' : 3600,
    "WR_FUNCTION"      : (0x05,),          ##WriteReadFunction,
    "REPORTING_MODE"     : (0x0000,),  ##ReportingMode,
    "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
    "DIAG_MODE"      : (0x0000,),        ##DiagMode,
    "TEST_MODE"      : (0x0000,),  ##TestMode,
    "BANDMASTER"      : (0x0001,),  ##WhichBandMaster,
    "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
    "START_LBA_L"      : (0x0900,),  ##StartLBALo,
    "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
    "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
    "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
    "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
    "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
    "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
    "STATUS_MISCOM_EXP"         : (0x0000,),  ##ReportingMode,
    "EXP_SENSE_BYTE2"     : (0x00,),          ##ExpectedSenseByte2,
    "EXP_SENSE_BYTE12"          : (0x00,),          ##ExpectedSenseByte12,
    "EXP_SENSE_BYTE13"          : (0x00,),          ##ExpectedSenseByte13
}

prm_574_WriteBand_Pass= {
##   'timeout' : 3600,
    "WR_FUNCTION"      : (0x05,),          ##WriteReadFunction,
    "REPORTING_MODE"     : (0x0000,),  ##ReportingMode,
    "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
    "TEST_MODE"      : (0x0000,),  ##TestMode,
    "BANDMASTER"      : (0x0001,),  ##WhichBandMaster,
    "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
    "START_LBA_L"      : (0x0000,),  ##StartLBALo, was 900
    "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
    "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
    "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
    "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
    "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
    "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
    "STATUS_MISCOM_EXP"         : (0x0000,),  ##ReportingMode,
    "EXP_SENSE_BYTE2"     : (0x00,),          ##ExpectedSenseByte2,
    "EXP_SENSE_BYTE12"          : (0x00,),          ##ExpectedSenseByte12,
    "EXP_SENSE_BYTE13"          : (0x00,),          ##ExpectedSenseByte13
}

prm_574_UnlockBand1 = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0xffff,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}
prm_574_UnlockBand13 = {    ## 01 is configure
  "BANDMASTER" : (0x000d,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0xffff,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_disable_rlewle = {    ## 01 is configure
  "BANDMASTER" : (0x0013,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x00033,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_LockBand13 = {
  "BANDMASTER" : (0x000d,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x00ff,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_WriteCompare = {
   'timeout' : 3600,
   "WR_FUNCTION"      : (0x0007,),          ##WriteReadFunction,
   "REPORTING_MODE"     : (0x0000,),  ##ReportingMode,
   "CLEAR_SESSION"      : (0x0000,),  ##ClearSession,
   "TEST_MODE"      : (0x0000,),  ##TestMode,
   "BANDMASTER"      : (0x0000,),  ##WhichBandMaster,
   "START_LBA_H"      : (0x0000,),  ##StartLBAHi,
   "START_LBA_L"      : (0x1FFA,),  ##StartLBALo,
   "BAND_SIZE_H"      : (0x0000,),  ##BandSizeHi,
   "BAND_SIZE_L"      : (0x0000,),  ##BandSizeLo,
   "LOCK_ENABLES"      : (0x0000,),  ##LockingEnables
   "STATUS_MISCOM_EXP"         : (0x0004,),  ##ReportingMode,
   "TRANSFER_LENGTH"     : (0x0010,),  ##transferLength,
   "PATTERN_MSW"      : (0x0000,),  ##PatternHi,
   "PATTERN_LSW"      : (0x0000,),  ##PatternLo,
   "EXP_SENSE_BYTE2"     : (0x05,),          ##ExpectedSenseByte2,
   "EXP_SENSE_BYTE12"          : (0x24,),          ##ExpectedSenseByte12,
   "EXP_SENSE_BYTE13"          : (0x00,),          ##ExpectedSenseByte13
}

prm_574_ReadCompare = {
   'timeout' : 3600,
  "WR_FUNCTION"        : (0x0A,),
  "REPORTING_MODE"      : (0x0000,),
  "CLEAR_SESSION"        : (0x0000,),
  "TEST_MODE"        : (0x0000,),
  "BANDMASTER"        : (0x0000,),
  "START_LBA_H"        : (0x0000,),
  "START_LBA_L"        : (0x0000,),
  "BAND_SIZE_H"        : (0x0000,),
  "BAND_SIZE_L"        : (0x0000,),
  "LOCK_ENABLES"        : (0x0000,),
  "STATUS_MISCOM_EXP"         : (0x0004,),
  "TRANSFER_LENGTH"      : (0x0010,),
  "PATTERN_MSW"        : (0x0000,),
  "PATTERN_LSW"        : (0x0000,),
  "EXP_SENSE_BYTE2"      : (0x00,),
  "EXP_SENSE_BYTE12"          : (0x00,),
  "EXP_SENSE_BYTE13"          : (0x00,),
}


prm_574_Erasure = {
   'timeout' : 3600,
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0001,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0008,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_LockBand = {
   'timeout' : 3600,
  "BANDMASTER" : (0x0000,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x00FF,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0001,),
  "WR_FUNCTION" : (0x0000,),
}

prm_574_CreateBand1 = {
  "BANDMASTER" : (0x0001,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x2000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0002,),
  "WR_FUNCTION" : (0x0000,),
}
prm_574_CreateBand13 = {
  "BANDMASTER" : (0x000d,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x2000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0002,),
  "WR_FUNCTION" : (0x0000,),
}
prm_574_DeleteBand13 = {
  "BANDMASTER" : (0x000d,),
  "BAND_SIZE_H" : (0x0000,),
  "BAND_SIZE_L" : (0x0000,),
  "CLEAR_SESSION" : (0x0000,),
  "LOCK_ENABLES" : (0x0000,),
  "REPORTING_MODE" : (0x0000,),
  "START_LBA_H" : (0x0000,),
  "START_LBA_L" : (0x0000,),
  "TEST_MODE" : (0x0002,),
  "WR_FUNCTION" : (0x0000,),
}






##Brandon:  UnlockFactoryCmdsDETS_prm = {
##  'test_num'              : 638,
##  'prm_name'              : 'prm_638_Unlock_Seagate',
##  'timeout'               : 3600,
##  'spc_id'                : 1,
##  'CTRL_WORD1'            : 8,
##  'DFB_WORD_0'            : 0x0100,                     # DETS cmd ID (Unlock Diagnostics)
##  'DFB_WORD_1'            : 0x0100,                     # Rev ID
##  'DFB_WORD_2'            : 0x0,                     # Unlock Seagate Access Key LSW
##  'DFB_WORD_3'            : 0x0,                     # Unlock Seagate Access Key MSW
##  'retryECList'           : [14061, 14029],
##  'retryCount'            : 10,
##  'retryMode'             : HARD_RESET_RETRY,
##  }
## Sent at 2:04 PM on Mon
##


################################## start of test 577  ###########################################
#################################################################################################

prm_577_Personalization = {
   'test_num' : 577,
   'prm_name' : 'prm_577_Personalization',
   'timeout' : 3600,
  "CERT_KEYTYPE" : (0x0000,),
  "DRIVE_STATE" : (0x0081,),
  "FW_PLATFORM" : (0x0010,),
  "MSID_TYPE" : (0x0000,),
  "REPORTING_MODE" : (0x8000,),
  "TEST_MODE" : (0x0005,),
}

prm_577_Verification = {
   'test_num' : 577,
   'prm_name' : 'prm_577_Verification',
   'timeout' : 3600,
  "CERT_KEYTYPE" : (0x0000,),
  "DRIVE_STATE" : (0x0000,),
  "FW_PLATFORM" : (0x0010,),
  "MSID_TYPE" : (0x0004,),
  "REPORTING_MODE" : (0x8000,),
  "TEST_MODE" : (0x0002,),
}


# prm_578_DnldIV = {
#    'test_num' : 578,
#    'prm_name' : 'prm_578_DnldIV',
#    'timeout' : 1200,
#    "dlfile" : (CN, 'FB8_VolC1.trd'),
#    "BYTE_COUNT" : (0x0000,),
#    "FILE_LEN_LSW" : (0x0000,),
#    "FILE_LEN_MSW" : (0x0000,),
#    "FW_PLATFORM" : (0x0010,),
#    "PASS_COUNT" : (0x0000,),
#    "TEST_MODE" : (0x0001,),
# }

# --------------------  end old FDE ---------------------------------------#

###################################################################
## Special SATA 514 stuff
###################################################################


p514_cw1_report_identify_device_data                 = 0x1
p514_cw1_report_identify_device_data_range           = 0x2
p514_cw1_report_identify_device_data_driveVars       = 0x8001
p514_cw1_report_identify_device_data_range_driveVars = 0x8002

def Test514_Cw2_IdentifyRange( starting_word, ending_word ):
   starting_word = starting_word & 0xff
   ending_word = (ending_word & 0xff) << 8
   return ( ending_word | starting_word )

def Test514_Cw2_IdentifyWord( starting_ending_word):
   starting_ending_word = starting_ending_word & 0xff
   return ( (starting_ending_word << 8) | starting_ending_word )



prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA = {
  "CTRL_WORD1"           : (p514_cw1_report_identify_device_data),
}

prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA_DRIVEVARS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_driveVars ),
}

prm_514_REPORT_MAX_USER_48BIT_LBAS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
}

prm_514_REPORT_MAX_USER_48BIT_LBAS_DRIVEVARS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range_driveVars),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
}

prm_514_REPORT_SN = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange(  10,  19 )),
}

prm_514_REPORT_WWN = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 108, 111 )),
}

prm_514_REPORT_SERIAL_ATA_CAPABILITIES = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 76, 77 )),
}

prm_514_REPORT_NCQ_AND_SERIAL_ATA_CAPABILITIES = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 75, 78 )),
}

prm_514_REPORT_SCT_BIST = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 206, 206 )),
}

prm_514_REPORT_MODEL_NUMBER = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 26, 46 )),
}

prm_514_REPORT_COMMAND_FEATURES = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 82, 87 )),
}

prm_514_REPORT_CHS_NUMBER_OF_CYLINDERS_DEFAULT = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 1 )),
}

prm_514_REPORT_CHS_NUMBER_OF_HEADS_DEFAULT = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 3 )),
}

prm_514_REPORT_CHS_NUMBER_OF_SECTORS_DEFAULT = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 6 )),
}


prm_514_REPORT_CHS_CURRENT_NUMBER_OF_CYLINDERS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 54 )),
}

prm_514_REPORT_CHS_CURRENT_NUMBER_OF_HEADS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 55 )),
}

prm_514_REPORT_CHS_CURRENT_NUMBER_OF_SECTORS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 56 )),
}
####################################################################
## end of SATA special stuff
####################################################################


prm_514_StdData = {
  "PAGE_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x8000,),
}

prm_514_Firmware = {
   ##'test_num' : 514,
   ##'prm_name' : 'prm_514_Firmware',
   ##'timeout' : 80,
  "CHECK_MODE_NUMBER" : (0x0000,),
  "ENABLE_VPD" : (0x0001,),
  "EXPECTED_FW_REV_1" : (0x0000,),
  "EXPECTED_FW_REV_2" : (0x0000,),
  "EXPECTED_FW_REV_3" : (0x0000,),
  "EXPECTED_FW_REV_4" : (0x0000,),
  "GET_FW_REV_FROM_NETWORK" : (0x0000,),
  "PAGE_CODE" : (0x00C0,),
  "TEST_FUNCTION" : (0x0000,),
}












def ConvertNumberToTuple( value, numberOf16BitWords ):
   wordList = []                             # Create empty list
   for i in range( numberOf16BitWords ):
      wordList.append( value & 0xffff )      # Append each 16 bit word
      value >>= 16
   if( numberOf16BitWords > 1 ):
      wordList.reverse()                     # Need most significant words first
   return tuple( wordList )

def U16T( value ):
   return ConvertNumberToTuple( value, 1 )

def U32T( value ):
   return ConvertNumberToTuple( value, 2 )

def U64T( value ):
   return ConvertNumberToTuple( value, 4 )


# print U16T( 12816 )                   # 3210
# print U32T( 1985229328 )              # 7654 3210
# print U64T( 0xFEDCBA9876543210 )      # FEDC BA98 7654 3210





# ==================================================================
# start 504
# ==================================================================
prm_504_TASK_FILE_REGISTERS = {
   'TEST_FUNCTION'     : (0x0000)
}

prm_504_SOFTWARE_DEBUG_SI_REGISTER_DUMP = {
   'TEST_FUNCTION'       : (0x0000),
   'CONTROLLER_CHIP_REG' : (0x8000),
}
# ==================================================================
# stop 504
# ==================================================================


# ==================================================================
# start 506
# ==================================================================
prm_506_IO_COMMAND_TIMEOUT_100_mS = {
   'COMMAND_TIMEOUT_MS'     : (100)
}

prm_506_IO_COMMAND_TIMEOUT_500_mS = {
   'COMMAND_TIMEOUT_MS'     : (500)
}

prm_506_IO_COMMAND_TIMEOUT_1_S = {
   'COMMAND_TIMEOUT_MS'     : (1000)
}

prm_506_IO_COMMAND_TIMEOUT_10_S = {
   'COMMAND_TIMEOUT_SECONDS' : (10)
}

prm_506_IO_COMMAND_TIMEOUT_20_S = {
   'COMMAND_TIMEOUT'         : (0,20)
}

prm_506_BUFFER_LENGTH_00000100 = {
   'BUFFER_LENGTH'           : (0x0000,0x100)
}

prm_506_BUFFER_LENGTH_00010100 = {
   'BUFFER_LENGTH'           : (0x0001,0x100)
}

prm_506_TEST_TIME_510_10_SECONDS = {
   'TEST_RUN_TIME'           : (40)
}

prm_506_CTRL_WORD1_8000 = {
   'CTRL_WORD1'              : (0x8000)
}

prm_506_CTRL_WORD1_0001 = {
   'CTRL_WORD1'              : (0x0001)
}

prm_506_CTRL_WORD1_0002 = {
   'CTRL_WORD1'              : (0x0002)
}

prm_506_IO_COMMAND_TIMEOUT_ILLEGAL = {
   'COMMAND_TIMEOUT_MS'     : (500),
   'COMMAND_TIMEOUT_SECONDS' : (10)
}

prm_506_RUN_T510_FOR_10_SECONDS = {
   'TEST_RUN_TIME' : (10)
}

# ==================================================================
# stop 506
# ==================================================================

# ==================================================================
# start 507
# ==================================================================
p507_drive_active_led_enable                      = 0x2
p507_drive_active_led_off                         = 0x0
prm_507_SWITCH_SERIAL_PORT_TO_DRIVE = {
   'ACTIVE_LED_ON' : (p507_drive_active_led_enable | p507_drive_active_led_off)
}

p507_non_platform_drive                           = 0x1
p507_platform_drive                               = 0x0

prm_507_SwitchToNonPlatformDrive = {
   'DRIVE_TYPE' : (p507_non_platform_drive),
}


# ==================================================================
# stop 507
# ==================================================================

# ==================================================================
# start 508
# ==================================================================
p508_cw1_enable_drive_var_mask                    = 0x8000
p508_cw1_report_buffer_data_as_binary_mask        = 0x4000
p508_cw1_function_mask                            = 0x000f

p508_cw1_tf_write_pattern_to_write_buffer         =  0    # 0x0
p508_cw1_tf_write_pattern_to_read_buffer          =  1    # 0x1
p508_cw1_tf_write_parameters_to_write_buffer      =  2    # 0x2
p508_cw1_tf_write_parameters_to_read_buffer       =  3    # 0x3
p508_cw1_tf_read_and_display_write_buffer         =  4    # 0x4
p508_cw1_tf_read_and_display_read_buffer          =  5    # 0x5
p508_cw1_tf_copy_read_buffer_to_write_buffer      =  6    # 0x6
p508_cw1_tf_copy_write_buffer_to_read_buffer      =  7    # 0x7
p508_cw1_tf_compare_write_buffer_to_read_buffer   =  8    # 0x8
p508_cw1_tf_check_range_16bit_read_buffer         =  9    # 0x9
p508_cw1_tf_write_block_data_file_to_write_buffer = 10    # 0xa
p508_cw1_tf_write_block_data_file_to_read_buffer  = 11    # 0xb
p508_cw1_tf_write_1_64bit_pattern_to_write_buffer = 12    # 0xc
p508_cw1_tf_write_1_64bit_pattern_to_read_buffer  = 13    # 0xd
p508_cw1_tf_dump_write_buffer_to_file             = 14    # 0xe
p508_cw1_tf_dump_read_buffer_to_file              = 15    # 0xf

p508_pattern_type_fixed       = 0
p508_pattern_type_random      = 1
p508_pattern_type_incremental = 2
p508_pattern_type_decremental = 3

prm_508_PARAM_CHECK_WILL_FAIL = {
   'CTRL_WORD1'          : (p508_cw1_tf_write_pattern_to_write_buffer),
   'BYTE_OFFSET'         : (0x1234,0x5678),
   'BUFFER_LENGTH'       : (0x0001,0x0000),
   'BYTE_PATTERN_LENGTH' : (8),
   'RANDOM_SEED'         : (0x3145),
   'DATA_PATTERN0'       : (0x7654,0x4AB4),
   'DATA_PATTERN1'       : (0x8899,0xAACC),
   'BIT_PATTERN_LENGTH'  : (4),
   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
   'DEBUG_FLAG'          : (0x8000),
}

#prm_508_WRITE_FIXED_PATTERN_TO_WRITE_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'DATA_PATTERN0'       : (0x0123,0x4567),
#   'DATA_PATTERN1'       : (0x89ab,0xcdef),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_WRITE_FIXED_PATTERN_TO_WRITE_BUFFER_0100_0200 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0100),
#   'DATA_PATTERN0'       : (0x3333,0x4444),
#   'DATA_PATTERN1'       : (0x5555,0x6666),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_WRITE_FIXED_PATTERN_TO_READ_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'DATA_PATTERN0'       : (0x0123,0x4567),
#   'DATA_PATTERN1'       : (0x89ab,0xcdef),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_WRITE_FIXED_PATTERN_TO_READ_BUFFER_0200_0300 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0200),
#   'DATA_PATTERN0'       : (0xDDDD,0xCCCC),
#   'DATA_PATTERN1'       : (0xBBBB,0xAAAA),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#   'BYTE_PATTERN_LENGTH' : (8),
#   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
#}

#prm_508_DISPLAY_WRITE_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#}

#prm_508_DISPLAY_WRITE_BUFFER_0100_0200 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_write_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0100),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#}

#prm_508_DISPLAY_READ_BUFFER_0000_1000 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0000),
#   'BUFFER_LENGTH'       : (0x0000,0x1000),
#}

#prm_508_DISPLAY_READ_BUFFER_0100_0200 = {
#   "CTRL_WORD1"          : (p508_cw1_tf_read_and_display_read_buffer),
#   'BYTE_OFFSET'         : (0x0000,0x0100),
#   'BUFFER_LENGTH'       : (0x0000,0x0100),
#}

prm_508_WRITE_FIXED_FFFFFFFF_PATTERN_TO_READ_BUFFER_0000_2000 = {
   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_read_buffer),
   'BYTE_OFFSET'         : (0x0000,0x0000),
   'DATA_PATTERN0'       : (0xffff,0xffff),
   'BUFFER_LENGTH'       : (0x0000,0x2000),
   'BYTE_PATTERN_LENGTH' : (4),
   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
}

prm_508_WRITE_FIXED_FFFFFFFF_PATTERN_TO_WRITE_BUFFER_0000_2000 = {
   "CTRL_WORD1"          : (p508_cw1_tf_write_pattern_to_write_buffer),
   'BYTE_OFFSET'         : (0x0000,0x0000),
   'DATA_PATTERN0'       : (0xffff,0xffff),
   'BUFFER_LENGTH'       : (0x0000,0x2000),
   'BYTE_PATTERN_LENGTH' : (4),
   'PATTERN_TYPE'        : (p508_pattern_type_fixed),
}

def DisplayReadWriteBuffer( cmd508, address, length ):
   address_hw = (address >> 16) & 0xffff
   address_lw = address         & 0xffff

   length_hw = (length >> 16) & 0xffff
   length_lw = length         & 0xffff
   st(508, CTRL_WORD1            = cmd508,
           BYTE_OFFSET           = (address_hw,address_lw),
           BUFFER_LENGTH         = (length_hw,length_lw),
           timeout = 60)

def DisplayReadBuffer( address, length ):
   DisplayReadWriteBuffer( p508_cw1_tf_read_and_display_read_buffer, address, length )

def DisplayWriteBuffer( address, length ):
   DisplayReadWriteBuffer( p508_cw1_tf_read_and_display_write_buffer, address, length )


def DisplayReadBufferBase( length ):
   DisplayReadBuffer( 0, length )

def DisplayWriteBufferBase( length ):
   DisplayWriteBuffer( 0, length )



def DisplayReadBufferNSectors( sector, nSectors ):
   DisplayReadBuffer( sector * 0x200, nSectors )

def DisplayReadBufferFirstNSectors( n ):
   DisplayReadBufferBase( n * 0x200 )

def DisplayWriteBufferFirstNSectors( n ):
   DisplayWriteBufferBase( n * 0x200 )

def DisplayReadBufferFirstSector():
   DisplayReadBufferFirstNSectors( 1 )

def DisplayWriteBufferFirstSector():
   DisplayWriteBufferFirstNSectors( 1 )



def DisplayReadBufferFirstN4kSectors( n ):
   DisplayReadBufferBase( n * 0x1000 )

def DisplayWriteBufferFirstN4kSectors( n ):
   DisplayWriteBufferBase( n * 0x1000 )

def DisplayReadBufferFirst4kSector():
   DisplayReadBufferFirstN4kSectors( 1 )

def DisplayWriteBufferFirst4kSector():
   DisplayWriteBufferFirstN4kSectors( 1 )




def FillReadWriteBuffer( cmd508, address, length, data ):
   address_hw = (address >> 16) & 0xffff
   address_lw = address         & 0xffff

   length_hw  = (length >> 16)  & 0xffff
   length_lw  = length          & 0xffff

   data_hw    = (data >> 16)    & 0xffff
   data_lw    = data            & 0xffff

   st(508, CTRL_WORD1            = cmd508,
           BYTE_OFFSET           = (address_hw,address_lw),
           BUFFER_LENGTH         = (length_hw,length_lw),
           DATA_PATTERN0         = (data_hw,data_lw),
           BYTE_PATTERN_LENGTH   = (4),
           PATTERN_TYPE          = (0),
           timeout = 10)

def FillReadBuffer( address, length, data ):
   FillReadWriteBuffer( p508_cw1_tf_write_pattern_to_read_buffer, address, length, data )

def FillWriteBuffer( address, length, data ):
   FillReadWriteBuffer( p508_cw1_tf_write_pattern_to_write_buffer, address, length, data )


def FillReadBufferBase( length, data ):
   FillReadBuffer( 0, length, data )

def FillWriteBufferBase( length, data ):
   FillWriteBuffer( 0, length, data )


def FillReadBufferFirstSector( data ):
   FillReadBuffer( 0, 512, data )

def FillWriteBufferFirstSector( data ):
   FillWriteBuffer( 0, 512, data )

def FillReadBufferFirstSector_FFFFFFFF():
   FillReadBufferFirstSector( 0xffffffff )


def FillEntireReadBuffer( data ):
   FillReadBuffer( 0, 0, data )

def FillEntireWriteBuffer( data ):
   FillWriteBuffer( 0, 0, data )


def CopyReadBufferToWriteBuffer( ):
   st(508, CTRL_WORD1            = (p508_cw1_tf_copy_read_buffer_to_write_buffer),
           timeout = 10)

def CopyWriteBufferToReadBuffer( ):
   st(508, CTRL_WORD1            = (p508_cw1_tf_copy_write_buffer_to_read_buffer),
           timeout = 10)


# ==================================================================
# stop 508
# ==================================================================



# ==================================================================
# start 509
# ==================================================================
p509_write                    = 0x20
p509_read                     = 0x10
p509_write_read               = 0x00

p509_bit_error_rates          = 0x00
p509_sector_error_rates       = 0x01

#      ctrl_word2
p509_32bit_pattern            = 0x2000
p509_fixed                    = 0x0080
p509_bypass_filling_write_buf = 0x0004
p509_incrementing             = 0x0002
p509_random                   = 0x0001



# ==================================================================
# stop 509
# ==================================================================


# ==================================================================
# start 510
# ==================================================================
p510_read_write               = 3 << 4
p510_write                    = 2 << 4
p510_read                     = 1 << 4
p510_write_read               = 0 << 4

p510_display_errors           = 1 << 1

p510_sequential               = 0
p510_random                   = 1
p510_butterfly                = 1 << 10
p510_reverse_sequential       = 1 << 9

#      ctrl_word2
p510_save_read_errors         = 1 << 15
p510_cct                      = 1 << 14
p510_32bit_pattern            = 0x2000
p510_fixed                    = 0x0080
p510_bypass_filling_write_buf = 0x0004
p510_incrementing             = 0x0002
p510_random                   = 0x0001

p510_butterfly_converging     = 0x0
p510_butterfly_diverging      = 0x1

p510_buffer_compare           = 0x0001

# ==================================================================


# ==================================================================
# start 514
# ==================================================================
p514_cw1_report_identify_device_data                 = 0x1
p514_cw1_report_identify_device_data_range           = 0x2
p514_cw1_report_identify_device_data_driveVars       = 0x8001
p514_cw1_report_identify_device_data_range_driveVars = 0x8002

def Test514_Cw2_IdentifyRange( starting_word, ending_word ):
   starting_word = starting_word & 0xff
   ending_word = (ending_word & 0xff) << 8
   return ( ending_word | starting_word )

def Test514_Cw2_IdentifyWord( starting_ending_word):
   starting_ending_word = starting_ending_word & 0xff
   return ( (starting_ending_word << 8) | starting_ending_word )



prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA = {
  "CTRL_WORD1"           : (p514_cw1_report_identify_device_data),
}

prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA_DRIVEVARS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_driveVars ),
}

prm_514_REPORT_MAX_USER_48BIT_LBAS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
}

prm_514_REPORT_MAX_USER_48BIT_LBAS_DRIVEVARS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range_driveVars),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
}

prm_514_REPORT_SN = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange(  10,  19 )),
}

prm_514_REPORT_WWN = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 108, 111 )),
}

prm_514_REPORT_SERIAL_ATA_CAPABILITIES = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 76, 77 )),
}

prm_514_REPORT_NCQ_AND_SERIAL_ATA_CAPABILITIES = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 75, 78 )),
}

prm_514_REPORT_SCT_BIST = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 206, 206 )),
}

prm_514_REPORT_MODEL_NUMBER = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 26, 46 )),
}

prm_514_REPORT_COMMAND_FEATURES = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 82, 87 )),
}

prm_514_REPORT_CHS_NUMBER_OF_CYLINDERS_DEFAULT = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 1 )),
}

prm_514_REPORT_CHS_NUMBER_OF_HEADS_DEFAULT = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 3 )),
}

prm_514_REPORT_CHS_NUMBER_OF_SECTORS_DEFAULT = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 6 )),
}


prm_514_REPORT_CHS_CURRENT_NUMBER_OF_CYLINDERS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 54 )),
}

prm_514_REPORT_CHS_CURRENT_NUMBER_OF_HEADS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 55 )),
}

prm_514_REPORT_CHS_CURRENT_NUMBER_OF_SECTORS = {
   "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyWord( 56 )),
}

# ==================================================================
# stop 514
# ==================================================================

# ==================================================================
# start 528
# ==================================================================
p528_tf_WaitForReady                   = 1 << 0
p528_tf_IssueSetFeatures               = 1 << 1
p528_tf_FlushCache                     = 1 << 3
p528_tf_PhyDetect                      = 1 << 12

# ==================================================================
# end 528
# ==================================================================

# ==================================================================
# start 529
# ==================================================================
p529_cw1_Read_Resident_G_List           = 1 << 0
p529_cw1_Read_NonResident_G_List        = 1 << 1
p529_cw1_Read_Detailed_G_List           = 1 << 2
p529_cw1_driveVars                      = 1 << 15

p529_tf_Display_G_List                  = 0
p529_tf_Display_And_Transfer_G_List     = 1
p529_tf_Transfer_G_List                 = 2
p529_tf_Display_Entire_ASFT             = 3
p529_tf_Display_Grown_From_ASFT         = 4
p529_tf_Display_Primary_From_ASFT       = 5



# ==================================================================
# start 535
# ==================================================================
p535_report_initiator_code_version    = 2
p535_report_io_transfer_rate          = 3

p535_modify_host_controller_register  = 6
p535_display_host_controller_register = 7
p535_verify_expected_transfer_rate    = 9

p535_retry_phy_ready_and_hard_reset   = 10
p535_hard_reset                       = 11
p535_soft_reset                       = 12
p535_loop_hard_resets                 = 13

# ------Start - Not used for production testing -----------------------
# Not used for production testing
p535_phy_fep                          = 14
p535_phy_fes                          = 15

p535_Banshee_soc_outer_diag_mux       = 90
p535_Banshee_soc_inner_diag_mux       = 91
p535_Banshee_soc_sata_diag_mux        = 92
p535_Banshee_pbm_diag_mux             = 93
p535_Banshee_sata_vhdi_diag_mux       = 95
p535_Banshee_sata_phy_ctl_diag_mux    = 96
p535_Banshee_sata_transport_diag_mux  = 97
p535_Banshee_sata_top_levels_diag_mux = 98
p535_Banshee_sata_si_diag_mux         = 99
# ------End   - Not used for production testing -----------------------
p535_ChangeListBasedFileName          = 0x0800
p535_ChangeListBasedFileNameDriveVars = 0x8800

prm_535_ReportInitiatorCodeRevision = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
}

prm_535_CpcReportInitiatorCodeRevision = {
   "CTRL_WORD1"  : (0),
}

prm_535_CpcReportInterfaceSpeed = {
   "CTRL_WORD1"  : (3),
}

prm_535_ReportInitiatorCodeRevision_DriveVars = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
   "TEST_FUNCTION"        : (0x8000),
}

prm_535_ReportInitiatorChangeListCodeRevision = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
   "TEST_FUNCTION"        : (p535_ChangeListBasedFileName),
}

prm_535_ReportInitiatorChangeListCodeRevision_DriveVars = {
   "TEST_OPERATING_MODE"  : (p535_report_initiator_code_version),
   "TEST_FUNCTION"        : (p535_ChangeListBasedFileNameDriveVars),
}

prm_535_ReportTransferRate = {
   "TEST_OPERATING_MODE"  : (p535_report_io_transfer_rate),
}

prm_535_RetryPhyReadyAndSataHardReset = {
   "TEST_OPERATING_MODE"  : (p535_retry_phy_ready_and_hard_reset),
}

prm_535_SataHardReset = {
   "TEST_OPERATING_MODE"  : (p535_hard_reset),
}

prm_535_SataSoftReset = {
   "TEST_OPERATING_MODE"  : (p535_soft_reset),
}

prm_535_Verify_1_5GB_TransferRate = {
   "FC_SAS_TRANSFER_RATE" : (0x0001),
   "TEST_OPERATING_MODE"  : (p535_verify_expected_transfer_rate),
}

prm_535_Verify_3GB_TransferRate = {
   "FC_SAS_TRANSFER_RATE" : (0x0003),
   "TEST_OPERATING_MODE"  : (p535_verify_expected_transfer_rate),
}

prm_535_Verify_6GB_TransferRate = {
   "FC_SAS_TRANSFER_RATE" : (0x0006),
   "TEST_OPERATING_MODE"  : (p535_verify_expected_transfer_rate),
}

prm_535_Set_Phy_FEP = {
   "TEST_OPERATING_MODE"  : (p535_phy_fep),
}

prm_535_Set_Phy_FES = {
   "TEST_OPERATING_MODE"  : (p535_phy_fes),
}


# ==================================================================
# stop 535
# ==================================================================


# ==================================================================
# start 538
# ==================================================================
p538_CHS_Registers = 0x0000
p538_LBA_Registers = 0x2000
# ==================================================================
# start 538
# ==================================================================



