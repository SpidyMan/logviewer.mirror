FOFexecfile(("SDD\AutoSDD","SDDInitiatorManager.py"))
tempSDDDiag = SDDSetup()
tempSDDDiag.transistionToDiag()
del tempSDDDiag