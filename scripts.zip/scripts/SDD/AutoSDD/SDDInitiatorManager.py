
#####################################################################
#
# $RCSfile: SDDInitiatorManager.py,v $LightingBug_SAS_SED_regression.py
# $Revision$1.0.0
# $Date$11/11/07
# $Author$robert.stafki
#
#
# REFERENCES:
# * Hurricane FC FDE Drive Personalization Doc
# * TCG Storage Architecture Core Spec
# * M2TD Cryptographic Infrastructure - KCI Interface Spec
#
#####################################################################

# *** GLOBALS
global lastInitiatorData
lastInitiatorData = 0x0
global lastInitiatorFileName
lastInitiatorFileName = ""
CN = 'file_cfg'

try:
  del dblData['P575_DEVICE_DISC_DATA']
except: pass

try:
  del dblData['P535_INITIATOR_RELEASE']
except: pass

class SDDSetup:

  def __init__(self):

    # Prepare the drive
    # DriveOff(pauseTime=3)
    DriveOn(pauseTime = 5)
    SetESlipBaud(1228000)

    # Setup our dblData
    RegisterResultsCallback(parseTestResultsNewHeader)

    # Import our defines
    FOFexecfile(("SDD\AutoSDD", "Della_IOTest_parameter.py")),
    # Determine if we are running a SAS or SATA initiator
    try:
      st([535], [], {'TEST_OPERATING_MODE': 2, 'TEST_FUNCTION': 32768, 'timeout': 10})
    except:
      TraceMessage("Couldn't contact initiator!")
      raise
    if "SAS" in dblData['P535_INITIATOR_RELEASE']['DOWNLOAD_FILE_NAME'][0]:
      st(517, prm_517_ReqSense0, timeout = 300)
      st(517, prm_517_RequestSense5, timeout = 300)
      st(514, prm_514_Firmware, timeout = 60)
      st(514, prm_514_StdData, timeout = 60)
    else:  # SATA
      st(535, prm_535_InitiatorRevSATA, timeout = 60)

      st(514, prm_514_REPORT_MAX_USER_48BIT_LBAS, timeout = 30)

    # Get features and populate the dblData dictionary
    st(575, prm_575_FDE_GetFeatures)

    # Get our current state
    self.currentState = dblData['P575_DEVICE_DISC_DATA']['LIFE_CYCLE_STATE'][0]

    # Determine if we are enterprise or Opal
    self.getDriveType()
    # self.transistionToMFG()

  def getDriveType(self):

    """This method will determine if a drive is an enterprise or opal drive"""

    # Turn the Frame Data into a string we can process to determine drive type
    searchString = ' '.join([dblData['P57X_FRAME_DATA'][str(k)][j] for j in range(int(dblData['P57X_FRAME_DATA']['3'][0], 16) / 16) for k in range(16)])

    if '02 00' in searchString and '02 01' in searchString and'02 02' in searchString and'02 03' in searchString:
      self.driveType = 'opal'
    else:
      self.driveType = 'enterprise'

  def startAdmin(self):

    """General start session method. This works for both enterprise and opal drives"""

    RegisterResultsCallback(customHandler, [32, 33, 34, 35, 36, 37, 38, 39, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54], useCMLogic = 0)
    RegisterResultsCallback(customIntiatorHandler, list(range(80, 85)), useCMLogic = 1)

    if self.driveType == 'enterprise':
      st(575, prm_575_SetSSCDella_np, timeout = 300)
    else:  # OPAL
      if dblData['P57X_FRAME_DATA']['9'][1] != '00':
        # TCG 2
        st(575, prm_575_SetSSCDella_np_opal, timeout = 300)
      else:
        # TCG 1
        prm_575_SetSSCDella_np_opal['TCG_VERSION'] = (0x0001,)
        st(575, prm_575_SetSSCDella_np_opal, timeout = 300)

    TraceMessage("Get PSID from LSS")
    st(575, prm_575_FDE_GetPSIDfromFIS, timeout = 30)
    TraceMessage("Start Admin Session")
    st(575, prm_575_FDE_StartAdminSession, timeout = 30)

  def enterpriseSetup(self):

    """General setup method for enterprise drives. This will not work with opal drives"""

    try:
        st(575, prm_575_FDE_AuthPSID, timeout = 30)
    except:
        TraceMessage("Did you enter your drive SN?")
        raise
    st(575, prm_575_FDE_AuthMakerSymKUniqueAES, timeout = 30)
    TraceMessage("Get MSID from Drive")
    st(575, prm_575_FDE_GetMSIDFromDrive, timeout = 30)
    st(575, prm_575_FDE_AuthSID, timeout = 30)

  def closeAdmin(self):

    """General close session method. This works for both enterprise and opal drives"""

    st(575, prm_575_FDE_GetFeatures, timeout = 60)
    TraceMessage("Close Admin Session")
    st(575, prm_575_FDE_CloseAdminSession, timeout = 30)

  def setDiagStateEnterprise(self):

    """Set an enterprise drive to Diag state. Will work regardless of drive's current state"""

    if self.currentState == '80':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
    elif self.currentState == '81':
      st(575, prm_575_FDE_Set_Use_State, timeout = 60)
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
    elif self.currentState == '00':
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
      st(575, prm_575_FDE_Set_Use_State, timeout = 60)
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
    elif self.currentState == 'FF':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
    else:
      TraceMessage("Already in Diag state!")

  def setUseStateEnterprise(self):

    """Set an enterprise drive to Use state. Will work regardless of drive's current state"""

    if self.currentState == '81':
      st(575, prm_575_FDE_Set_Use_State, timeout = 60)
    elif self.currentState == '00':
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
      st(575, prm_575_FDE_Set_Use_State, timeout = 60)
    elif self.currentState == '01':
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
      st(575, prm_575_FDE_Set_Use_State, timeout = 60)
    elif self.currentState == 'FF':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
      st(575, prm_575_FDE_Set_Use_State, timeout = 60)
    else:
      TraceMessage("Already in Use state!")

  def setMFGStateEnterprise(self):

    """Set an enterprise drive to MFG state. Will work regardless of drive's current state"""

    if self.currentState == '80':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
    elif self.currentState == '00':
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
    elif self.currentState == '01':
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
    elif self.currentState == 'FF':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
      st(575, prm_575_FDE_Set_Mfg_State, timeout = 60)
    else:
      TraceMessage("Already in MFG state!")

  def setSetupStateEnterprise(self):

    """Set an enterprise drive to Setup state. Will work regardless of drive's current state"""

    if self.currentState == '80':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
    elif self.currentState == '81':
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
    elif self.currentState == '01':
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
    elif self.currentState == 'FF':
      st(575, prm_575_FDE_Set_Diag_State, timeout = 60)
      st(575, prm_575_FDE_Set_Setup_State, timeout = 60)
    else:
      TraceMessage("Already in Setup state!")

  def transistionToDiag(self):

    """Public facing method to move a drive to Diag state"""

    self.startAdmin()

    self.enterpriseSetup()
    self.setDiagStateEnterprise()

    self.closeAdmin()
    TraceMessage("The drive is in Diag state")

  def transistionToUse(self):

    """Public facing method to move a drive to Use state"""

    self.startAdmin()

    self.enterpriseSetup()
    self.setUseStateEnterprise()

    self.closeAdmin()
    TraceMessage("The drive is in Use state")

  def transistionToMFG(self):

    """Public facing method to move a drive to MFG state"""

    self.startAdmin()

    self.enterpriseSetup()
    self.setMFGStateEnterprise()

    self.closeAdmin()
    TraceMessage("The drive is in Manufacturing state")

  def transistionToSetup(self):
    """Public facing method to move a drive to Setup state"""

    self.startAdmin()

    self.enterpriseSetup()
    self.setSetupStateEnterprise()

    self.closeAdmin()
    TraceMessage("The drive is in Setup state")

