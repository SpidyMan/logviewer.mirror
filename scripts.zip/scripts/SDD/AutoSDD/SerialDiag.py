FOFexecfile(('SDD\AutoSDD', 'SDDSerialManager.py'))


# DriveOff(pauseTime=3)
DriveOn(pauseTime = 5)
SetBaudRate(38400)
CTRL_Z = '\x1A'
PChar(CTRL_Z)
TraceMessage("Waiting for the drive to spinup")
ScriptPause(18)

transferTypes = TransferTypes()
spCommandSet = SPcommands()
commonUnlockFuncs = SpIOCommon()
dblData = {}

TraceMessage("Setting to Diag state")
spCommandSet.SEDDriveVerify()
commonUnlockFuncs.findDiscovInfo(dataPacket = spCommandSet.SerialSEDDiscovery())
spCommandSet.serialStateToDiag()
TraceMessage("The drive is in Diag state")  # @UndefinedVariable
