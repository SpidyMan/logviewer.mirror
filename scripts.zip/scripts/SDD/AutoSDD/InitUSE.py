FOFexecfile(("SDD\AutoSDD","SDDInitiatorManager.py"))
tempSDDUSE = SDDSetup()
tempSDDUSE.transistionToUse()
del tempSDDUSE