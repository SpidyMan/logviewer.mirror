FOFexecfile(("SDD\AutoSDD","SDDInitiatorManager.py"))
tempSDDSetup = SDDSetup()
tempSDDSetup.transistionToSetup()
del tempSDDSetup