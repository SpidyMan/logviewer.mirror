FOFexecfile(("SDD\AutoSDD","SDDInitiatorManager.py"))
tempSDDMFG = SDDSetup()
tempSDDMFG.transistionToMFG()
del tempSDDMFG