# ####################################################################
#
# RCSfile:  unlockSATASerial.py
# Revision: 1.1.0
# Date:     02/25/2013
# Author:  brandon.haugrud
#
# ####################################################################

from time import localtime
import random, binascii, struct, base64, time, sys
#FOFexecfile(('', 'scriptfuncs.py'))
#FOFexecfile(('', 'hyperpower.py'))

def SetESlipBaud(finalBaud, FirstBaud="Current Baud"):
  UseESlip(1)
  baudList = ["Current Baud", Baud38400, Baud115200, Baud390000, Baud460800, Baud625000, Baud921600, Baud1228000]

  if not finalBaud in baudList:
     TraceMessage("Error: Unsupported baud rate: %s\nSupported Baud Rates: %s"%(finalBaud, baudList[1:],))
     raise Exception("Invalid Baud Rate")

  ### Register BaudRate and  UARTBaudList deprecated. No need to register any more
  #if DeviceType == "HYPERPORT" and  finalBaud not in UARTBaudList:
  #   msg1 = "##   USB-UART does not support %d. Going to %d !!! "%(finalBaud,Baud115200,)
  #   msg2 = "##   If this USB-UART supports %d, then first call RegisterBaudRate(%d) and then call SetESlipBaud(%d)   ##"%(finalBaud,finalBaud,finalBaud,)
  #   print  "#" * len(msg2)
  #   print msg1 + " " * (len(msg2) - len(msg1) - 2) + "##"
  #   print msg2
  #   print "#" * len(msg2)+ "\n"
  #   finalBaud = Baud115200

  sendData = "00000%s00"%(baudList.index(finalBaud),)
  sendData = binascii.unhexlify(sendData)
  logString =  "SetESlipBaud(%d)"%finalBaud

  if FirstBaud in baudList:
     baudList.remove(FirstBaud)
  baudList = [FirstBaud,] + baudList

  for baud in baudList:
     if baud != "Current Baud": SetBaudRate(baud)
     try:
        #print binascii.hexlify(sendData)
        #SendBuffer(sendData,fromAddress=0x8001,toAddress=0x8001,checkSRQ=0,maxRetries=1)
        SendBuffer(sendData,fromAddress=0x8001,toAddress=0x8002,checkSRQ=0,maxRetries=1)
     except:
      #  TraceMessage("%s:         Failed at %s"%(logString,baud,))
        if baud == baudList[-1]: raise        # raise exception, if fails at all baud rates
        continue
     else:
        #buf = ReceiveBuffer(fromAddress=0x8001,toAddress=0x8001,timeout=5,checkSRQ=2,maxRetries=1)
        buf = ReceiveBuffer(fromAddress=0x8002,toAddress=0x8001,timeout=5,maxRetries=1)
        TraceMessage("%s:         Passed at %s"%(logString,baud,))
        break
  ScriptPause(0.2)   # Without this delay, boards like DJTE1179 - have issues changing the baud rate.
  SetBaudRate(finalBaud)


def customHandler(data,currentTemp=0,drive5=0,drive12=0,collectParametric=0):
  stat = 1 # default= FAIL

  # Get the resultsKey
  resultsKey = ord(data[0])
  spCommandSet.statMsg("xfer type = %i" % resultsKey)

  if resultsKey == 32:
    transferTypes.CustomRequestSecureIDHandler() ## request MSID

  elif resultsKey == 33:    ## default request for random challenge encryption by server
    transferTypes.CustomRequestDefaultManufacturingKeyAuthenticationHandler(base64.b64encode(binascii.a2b_hex(unlockVar.lastInitiatorData)),resultsKey)

  elif resultsKey == 34:
    transferTypes.CustomRequestSerialPortEnableKeyHandler()   ## get unique makersymk credential to write to the IV

  elif resultsKey == 43:
    transferTypes.CustomRequestSecureIDHandlerCPC()

  elif resultsKey == 44:
    transferTypes.CustomRequestSecureIDGenerator()

  elif resultsKey == 45:
    transferTypes.CustomRequestSecureHandlerGeneratorCPC()

  ## The below Handlers are part of the XMLRPC changes that reduce the number of unique RPCs.
  elif resultsKey == 46:    # MakerSymK AES256 unique key request
    transferTypes.CustomRequestKeyHandler(resultsKey)

  elif resultsKey == 50:    # This will be the default maker AES256 auth
    transferTypes.CustomRequestDefaultManufacturingKeyAuthenticationHandler(base64.b64encode(binascii.a2b_hex(unlockVar.lastInitiatorData)),resultsKey)

  elif resultsKey == 53:    # This will be the unique AES256 maker auth
    transferTypes.CustomRequestUniqueManufacturingKeyAuthenticationHandler(base64.b64encode(binascii.a2b_hex(unlockVar.lastInitiatorData)),resultsKey)

  elif resultsKey == 55:    # This is for the random string generator
    transferTypes.CustomRequestRandom32CharString()

  elif resultsKey == 56:
    transferTypes.CustomRequestMSIDGenerator() ## request MSID derived from PSID and Serial number

  else:
    spCommandSet.statMsg("Unknown results key - resultsKey=" + resultsKey + "@" + __name__)

# ===================================================================
# Definition of the generic "top-level" customer handler
# resultsKeys 80-85
# * add defaults so we can pass only data (in manual, non-initiator mode)
# ===================================================================
def customIntiatorHandler(data, *args, **kargs):
  stat = 1 # default= FAIL

  print("Entering File Handler ")
  print("===4> %s"%binascii.b2a_hex(data))

  # Get the resultsKey
  resultsKey = ord(data[0])
  print("===5> resultsKey: %s"%hex(resultsKey))

  if resultsKey == 80:
    lastInitiatorFileName = transferTypes.customInitiatorDataFileNameHandler(data)
  elif resultsKey == 82:
    unlockVar.lastInitiatorData = transferTypes.customInitiatorDataHandler(data)
  else:
    spCommandSet.statMsg("Got resultsKey :%s"%resultsKey)
    #tMsg("Huh?  resultsKey=" + resultsKey + "@" + __name__)
##  print "Leaving File Handler "
##  print " "

RegisterResultsCallback(customHandler,[32,33,34,43,44,45,46,47,48,49,50,51,52,53,54,55,56],useCMLogic=0)
RegisterResultsCallback(customIntiatorHandler, [80,82], useCMLogic=1)


class Vars:
    tempColumn = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    comType = 'IO'   #Can Be IO or Serial
    discovPacket = ''
    driveTcgType = ''
    currentSEDState = 0

    enableDebugPrint = 0
    enableCM = 0
    coreSpec = 1          #Core Specs:   1 and 2
    masterSymKType = 2    #1: Triple Des     2:AES256
    opalSupport = 0

    lastInitiatorData = 0x0
    lastInitiatorFileName = ""
    sessionNumber = ''
    global_fisMSID = ''
    global_fisPSID = ''
    global_driveMSID = ''
    driveSN = ''

    preFrameLength = 0

    def initVars(self):
        self.tempColumn = {}
        self.enableDebugPrint = unlockVar.enableDebugPrint
        self.enableCM = unlockVar.enableCM
        self.coreSpec = unlockVar.coreSpec
        self.masterSymKType = unlockVar.masterSymKType
        self.opalSupport = unlockVar.opalSupport
        self.lastInitiatorFileName = ""
        self.sessionNumber = ''
        self.global_fisMSID = ''
        self.global_fisPSID = ''
        self.global_driveMSID = ''

unlockVar = Vars()



class TransferTypes:

# ===================================================================
# CustomInitiatorDataFileNameHandler(...):
# INPUTS:
# * data         : fileName
# custom handler for results key of 80 - fileName of data from initator
# ===================================================================
    def customInitiatorDataFileNameHandler(self,iData):

      # Jump over the 3 bytes of (binary) header information
      index = 2
      # Grab the Random Challenge Value (RCV) sent to us
      fileName = iData[index:]

      #print("===3> Initiator Data FileName = %s" % fileName)

      return fileName

# ===================================================================
# CustomInitiatorDataHandler(...):
# INPUTS:
# * data         : data
# custom handler for results key of 82 - data from initator
# ===================================================================
    def customInitiatorDataHandler(self,iData):

        # Jump over the 3 bytes of (binary) header information
        index = 3

        # Grab the Random Challenge Value (RCV) sent to us
        nonce = binascii.b2a_hex(iData[index:index+32])

        print(("===8> Nonce from initiator = %s" % nonce))

        return nonce

# ===================================================================
# CustomRequestDefaultManufacturingKeyAuthenticationHandler(...):
# INPUTS:
# * rcvData         : Random Challenge Value Data (from drive via initiator)
# * HDASerialNumber : HDASerialNumber
# RETURN(S):
# * mfgAuthKey      : Manufacturing Autentication Key
# custom handler for results key of 33 - Request Mfg. Key. Auth.
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.3
# ===================================================================
    def CustomRequestDefaultManufacturingKeyAuthenticationHandler(self,rcvData, transfer_type): # RandomChallengeValueData
      stat = 1 # default = FAIL
      index = 0
      displayBuffer(rcvData)
      randomChallengeValue =  rcvData[index:]

      if transfer_type == 33:
        print("transfer type = 33")
        method,prms = RequestService('ReqMfgAuth',(randomChallengeValue))

      elif transfer_type == 50:
        print("transfer type = 50")
    ##    method,prms = RequestService('DoDefaultKeyAuthentication',(randomChallengeValue, HDASerialNumber,'MfgKey','AES256','0'))
        method,prms = RequestService('DoDefaultKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'DiagKey','AES256','0'))

      ScriptComment("method: %s; prms: %s"%(method,prms,))
    ##  statMsg("method: %s; prms: %s"%(method,prms,))

      if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
        if 'AuthenticationResponse' in prms:
          responseString = base64.b64decode(prms['AuthenticationResponse'])
          # tMsg("response from server    = %s" % responseString)
          mfgAuthKeyString = binascii.b2a_hex(responseString)
          spCommandSet.statMsg("HDA Serial Number = %s" % unlockVar.driveSN)
          spCommandSet.statMsg("Mfg.Auth.Key = %s" % mfgAuthKeyString)
          if len(mfgAuthKeyString) != 64: # 64 chars = 32 bin-nibble-bytes
            spCommandSet.statMsg("Mfg. Auth. Key = %i bytes, not 32 bytes" % len(mfgAuthKeyString))
          else:
            mfgAuthKey = binascii.a2b_hex(mfgAuthKeyString)
            stat = 0 # PASS
        else:
          spCommandSet.statMsg('[33]' + __name__ + '"AuthenticationResponse" not found in data from server')
      else:
        ScriptComment("method: %s; prms: %s"%(method,prms,))
        ScriptComment("Exception from TDCI Server during authentication ")

    ##    statMsg('[33]' + __name__ + "data from server is garbled")

      if 1:
        if not stat:
          frame = "\x21\x20\x00\x00"  + mfgAuthKey
        else:
          # If we could not get a key, the data length is 0 & no key is sent
          frame = "\x21\x00\x00\x00"

        print("sending frame of data w/ mfgAuthKey to the initiator")
        SendBuffer(frame)
      ##    print"Leaving Custom Request Mfg Key Auth handler - 33 - default key"
        print(" ")


# ===================================================================
# CustomRequestKeyHandler():
# customer handler for results key of 46,47 and 48 - Request uniqueKey
# ===================================================================
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.4
# kjb @ 09/26/07
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def CustomRequestKeyHandler(self,transfer_type):
      stat = 1 # default = FAIL
      if transfer_type == 46:
        method,prms = RequestService('GetUniqueKey',(unlockVar.driveSN,'DiagKey','AES256','0'))

      ScriptComment("method: %s; prms: %s"%(method,prms,))
      spCommandSet.statMsg("method: %s; prms: %s"%(method,prms,))

      if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
        if 'uniqueKey' in prms:
          spCommandSet.statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
          print("uniqueKey found in key dictionary")
          responseString = prms['uniqueKey']
          print("hex response string:  ", binascii.hexlify(base64.decodestring(responseString)))
          print("response from server  ", responseString)
          print("base64 decoded        ", base64.b64decode(responseString))
          uniqueKeyString = binascii.b2a_hex(base64.b64decode(responseString))
          print("Unique Key length =  ", len(uniqueKeyString))
          print("sPort Enable Key = ", uniqueKeyString)
          iuniqueKey = binascii.a2b_hex(uniqueKeyString)
          print("sPort Enable Key = ", iuniqueKey)
    ##      spEnableKey = binascii.a2b_hex(spEnableKeyString)
          stat = 0

        else:
          spCommandSet.statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
          spCommandSet.statMsg('[34] ' + method + '"uniqueKey" not found in data from server')

      else:
        ScriptComment("method: %s; prms: %s"%(method,prms,))
        ScriptComment("Exception from TDCI Server during authentication ")
    ##    statMsg('[34]' + method + "data from server is garbled")
      if 1:
        if not stat:
          frame = "\x22\x10\x00\x00" + iuniqueKey
        else:
          # If we could not get a key, the data length is 0 & no key is sent
          frame = "\x22\x00\x00\x00"

        print("sending frame of data w/ uniqueKey to the initiator")
        SendBuffer(frame)
        print("Leaving Custom Request Mfg Key Auth handler - 46,47,48 - unique key")
        print(" ")


# ===================================================================
# CustomRequestMSIDGenerator():
# custom handler for results key of 32 - Request Secure ID (SID)
# ===================================================================
    def CustomRequestMSIDGenerator(self):
      # Determine the MSID
    ##  sidStatus,sid = getSID() #this actually gets a PSID, either derived or from FIS
      ## this then becomes the nonce for the XMLRPC to generate an MSID
      spCommandSet.statMsg("SID  = %s" % unlockVar.lastInitiatorData)
    ##  nonce = binascii.b2a_hex(lastInitiatorData[0:32])
    ##  statMsg("Nonce  = %s" % nonce)
      sidStatus = "1"

      msid = self.CustomRequestUniqueManufacturingKeyAuthenticationHandler(base64.b64encode(binascii.a2b_hex(unlockVar.lastInitiatorData)),56)
    ##  (base64.b64encode(binascii.a2b_hex(lastInitiatorData)),resultsKey)
      spCommandSet.statMsg("Derived MSID (from Serial Number) = %s" % msid)

      if 1:
        # Set up frame of data to send to initiator
        frame = sidStatus + msid + unlockVar.driveSN
        # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

        print("sending frame of data w/ MSID to the initiator")
        SendBuffer(frame)


# ===================================================================
# CustomRequestRandom32CharString():
# custom handler for results key of 56 - Request for random 32 char string
# ===================================================================
    def CustomRequestRandom32CharString(self) :
      spCommandSet.statMsg("Random Number = %s" % unlockVar.lastInitiatorData)
    ##  this is where the value needs to be loaded into the parameter table
    ##  the random value is in the lastInitiatorData global
      frame = "\x22\x00\x00\x00"
      SendBuffer(frame)
      print ("Leaving handler for Random string generator")
      print(" ")


# ===================================================================
# CustomRequestSecureIDHandlerGeneratorCPC():
# custom handler for results key of 45 - Request Secure ID (SID)
# ===================================================================
    def CustomRequestSecureHandlerGeneratorCPC(self):
      # Determine the MSID

      sidStatus,sid = self.generateSID() #sidType 1 = MSID(default) 2 = PSID #Always Save PSID to FIS
      spCommandSet.statMsg("Generated SID = %s" % sid)

      if 1:
        # Set up frame of data to send to initiator
        frame = struct.pack(">H",len(sidStatus + sid + unlockVar.driveSN)) + sidStatus + sid + unlockVar.driveSN
        # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

        print("sending frame of data w/ SID to the initiator")
        SendBuffer(frame,expect=('_INPROGRESS',),tag='MSG')


# ===================================================================
# CustomRequestSecureIDHandlerGenerator():
# custom handler for results key of 44- Request Secure ID (SID)
# ===================================================================
    def CustomRequestSecureIDGenerator(self):
      # Determine the PSID
      sidStatus,sid = self.getMSIDfromAttributeMSID()
      spCommandSet.statMsg("MSID retrieved from MSID attribute = %s" % sid)

      if 1:
        # Set up frame of data to send to initiator
        frame = sidStatus + sid + unlockVar.driveSN
        # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

        print("sending frame of data w/ SID to the initiator")
        SendBuffer(frame,expect=('_INPROGRESS',),tag='MSG')
    ##  statMsg("LeavingCustomRequestSecureIDGenerator")


# ===================================================================
# CustomRequestSecureIDHandler():
# custom handler for results key of 32 - Request Secure ID (SID)
# ===================================================================
    def CustomRequestSecureIDHandler(self):
      # Determine the MSID
      sidStatus,sid = self.getSID()
      spCommandSet.statMsg("32 SID  = %s" % sid)

      if 1:
        # Set up frame of data to send to initiator
        frame = sidStatus + sid + unlockVar.driveSN
        # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

        print("sending frame of data w/ SID to the initiator")
        SendBuffer(frame)


# ===================================================================
# CustomRequestSecureIDHandlerCPC():
# custom handler for results key of 43 - Request Secure ID (SID)
# ===================================================================
    def CustomRequestSecureIDHandlerCPC(self):  ##
      # Determine the MSID
      sidStatus,sid = self.getSID()   #Always save to FIS
      spCommandSet.statMsg("43 SID  = %s" % sid)

      if 1:
        # Set up frame of data to send to initiator
        frame = struct.pack(">H",len(sidStatus + sid + unlockVar.driveSN)) + sidStatus + sid + HDASerialNumber
        # frame = "\x22\x25\x00\x00" + sidStatus + sid + HDASerialNumber

        print("sending frame of data w/ SID to the initiator")
        SendBuffer(frame,expect=('_INPROGRESS',),tag='MSG')


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.4
# kjb @ 09/26/07
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def CustomRequestSerialPortEnableKeyHandler(self):  ## this is a legacy call to to
                                                    ## get a unique makersymk key
      print ("*** Request SerialPort Enable Key")
      stat = 1 # default = FAIL
      print("Entering Custom Request Mfg Key Auth handler - 34 - unique key")

      print("RequestService('ReqSPEKey',(", unlockVar.driveSN, "))")
      method,prms = RequestService('ReqSPEKey',(unlockVar.driveSN)) # requestSerialPortEnableKey

    ##  ScriptComment("method: %s; prms: %s"%(method,prms,))
    ##  statMsg("method: %s; prms: %s"%(method,prms,))

      if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
        if 'serialPortEnableKey' in prms:
          spCommandSet.statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
          print("serialPortEnableKey found in key dictionary")
          responseString = prms['serialPortEnableKey']
          print("hex response string:  ", binascii.hexlify(base64.decodestring(responseString)))
          print("response from server  ", responseString)
          print("base64 decoded        ", base64.b64decode(responseString))
          spEnableKeyString = binascii.b2a_hex(base64.b64decode(responseString))
          print("Unique Key length =  ", len(spEnableKeyString))
          print("sPort Enable Key = ", spEnableKeyString)
          spEnableKey = binascii.a2b_hex(spEnableKeyString)
          stat = 0 # PASS
    ##      if len(spEnableKeyString) != 32: # 32 chars = 16 bin-nibble-bytes
    ##        statMsg("SP Enable Key = %i bytes, not 16 bytes" % len(spEnableKeyString))
    ##      else:
    ##        tMsg("spEnableKeyString = %s" % spEnableKeyString)
    ##        spEnableKey = binascii.a2b_hex(spEnableKeyString)
    ##        tMsg("spEnableKey = %s" % spEnableKey)
    ##        stat = 0 # PASS
        else:
          ScriptComment("method: %s; prms: %s"%(method,prms,))
          spCommandSet.statMsg("entire return data from XML-RPC Server (dictionary) %s" % (prms))
          spCommandSet.statMsg('[34] ' + method + '"uniqueKey" not found in data from server')
    ##      statMsg('[34]' + __name__ + '"srialPortEnableKey" not found in data from server')
      else:
        ScriptComment("method: %s; prms: %s"%(method,prms,))
        ScriptComment("Exception from TDCI Server during authentication ")
    ##    statMsg('[34]' + __name__ + "data from server is garbled")

      if 1:
        if not stat:
          frame = "\x22\x10\x00\x00" + spEnableKey
          spCommandSet.statMsg("Frame = %s" % frame)
        else:
          # If we could not get a key, the data length is 0 & no key is sent
          frame = "\x22\x00\x00\x00"

        print("sending frame of data w/ spEnableKey to the initiator")
        SendBuffer(frame)
        print("Leaving Custom Request Mfg Key Auth handler - 34 - unique key")
        print(" ")


# ===================================================================
# CustomRequestUniqueManufacturingKeyAuthenticationHandler(...):
# customer handler for results key of 35 - SP Enable Key Authentication
# ===================================================================
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# M2TD Cryptographic Infrastructure - KCI Interface Spec: Section 2.5
# kjb @ 10/04/07
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def CustomRequestUniqueManufacturingKeyAuthenticationHandler(self,rcvData,transfer_type):
      #print "*** Request SerialPort Enable Key Authentication"
      stat = 1 # default = FAIL

      print("Entering handler for unique key authentication - get key")
      print("DATA IN-> from serial port enable key ")
      print(rcvData)
      print(" ")

      ### # Jump over the 25 bytes of (binary) header information
      ### index = 25
      index = 0

      # Grab the Random Challenge Value (RCV) sent to us
      randomChallengeValue =  rcvData[index:]
      spCommandSet.statMsg("randomChallengeValue = %s" %randomChallengeValue )
      if transfer_type == 53:
        print("transfer type = 53")
    ##    method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, HDASerialNumber,'MfgKey','AES256','0'))
        method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'DiagKey','AES256','0'))
      elif transfer_type == 56:
        print("transfer type = 56")
        method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'MaintKey','AES256','0'))

      ScriptComment("method: %s; prms: %s"%(method,prms,))
      spCommandSet.statMsg("method: %s; prms: %s"%(method,prms,))

      if len(prms) and prms.get('EC',(0,'NA'))[0] == 0:
        if 'AuthenticationResponse' in prms:
          responseString = prms['AuthenticationResponse']
          spEnableAuthKeyString = binascii.b2a_hex(base64.b64decode(responseString))
          if len(spEnableAuthKeyString) != 64: # 64 chars = 32 bin-nibble-bytes
            spCommandSet.statMsg("SP Enable Auth. Key = %i bytesCustomRequestKeyHandler, not 32 bytes" % len(spEnableAuthKeyString))
          else:
            spCommandSet.statMsg("sPort Enable Auth. Key = %s" % spEnableAuthKeyString)
            spEnableAuthKey = binascii.a2b_hex(spEnableAuthKeyString)
            stat = 0 # PASS
        else:
          spCommandSet.statMsg('[35]' + method + '"serialPortEnableAuthKey" not found in data from server')

      else:
        ScriptComment("method: %s; prms: %s"%(method,prms,))
        ScriptComment("Exception from TDCI Server during authentication ")
    ##    statMsg('[35]' + prms + "data from server is garbled")

      if 1:
        if not stat:
          frame = "\x22\x10\x00\x00" + spEnableAuthKey
        else:
          # If we could not get a key, the data length is 0 & no key is sent
          frame = "\x22\x00\x00\x00"

        if transfer_type == 56:
          return spEnableAuthKey
        else:
          print("sending frame of data w/ spEnableAuthKey to the initiator")
          SendBuffer(frame)
          print("Leaving handler for unique key authentication")
          print(" ")


# ===================================================================
# generateSID(...):
# Gets/generates a Secure ID (i.e. 'SID' or 'MSID' or 'PSID) that is printed
# on the drive label and stored internally on the drive in the EF_SID
# file.
# ===================================================================
    def generateSID(self):

      sidStatus = "1" # 0 = get exisiting SID from FIS
                      # 1 = calculate new SID

      #sidLength = 25  # =25, per TCG Storage Architecture Core Spec
      sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far

      # Possible SID characters:
      # random ordering of 24 uppercase letters (No 'I' and No 'O') and
      # numerals 0 through 9
      # per TCG Storage Architecture Core SpecHDASerialNumber
      charChoices = ['H','U','7','C','J','9','T','5','R','B',\
                     'G','M','E','0','F','Z','4','8','Y','K',\
                     '2','L','V','D','S','1','A','W','3','Q',\
                     'X','6','P','N']

      # Create an empty SID string to be filled with random characters
      sidStr = ''

      # statMsg("no SID found @ FIS - calculating virgin SID")

      # Shuffle the list prior to seeding the random number generator -
      # this ensures a unique SID even if the 'RandomSeed' value is the
      # same as a previous one.  Prevents duplicate SID's !!!
      random.shuffle(charChoices)
      # Seed the python random-number generator from an OS-specific
      # randomness source
      random.seed()

      # Generate a string of random characters
      for i in range(0, sidLength):
        # Generate a random number between 0 and 34, and use it to
        # select a character from the choices list
        # NOTE: random() generates a number between 0 and 1
        sidStr += charChoices[int(random.random() * 34)]

      return sidStatus,sidStr


# ===================================================================
# getMSIDfromAttributeMSID(...):
# ===================================================================
    def getMSIDfromAttributeMSID(self,updateAttrs=1):

      sidStatus = "1" # 0 = get exisiting SID from FIS
                      # 1 = calculate new SID
      sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far
      charChoices = ['H','U','7','C','J','9','T','5','R','B',\
                     'G','M','E','0','F','Z','4','8','Y','K',\
                     '2','L','V','D','S','1','A','W','3','Q',\
                     'X','6','P','N']
      sidStr = ''
      if 'MSID' in DriveAttributes:
        sidStr = DriveAttributes['MSID']
        spCommandSet.statMsg("FIS MSID from getSID    = %s" % sidStr)
        sidStatus = "0"
      else:
        random.shuffle(charChoices)
        random.seed()
        for i in range(0, sidLength):
          sidStr += charChoices[int(random.random() * 34)]
        if updateAttrs:
          DriveAttributes['MSID'] = sidStr
          RequestService("PutAttributes", ({"MSID": sidStr}, "FIN2")) #Was commented out for Serial Port Process  BJH

      return sidStatus,sidStr


# ===================================================================
# getSID(...):
# Gets/generates a Secure ID (i.e. 'PSID' or 'MSID') that is printed
# on the drive label and stored internally on the drive in the EF_SID
# file.  It will also create the appropriate drive attribute in FIS.
# ===================================================================
    def getSID(self,updateAttrs=1):  # actually is getMSID

      sidStatus = "1" # 0 = get exisiting SID from FIS
                      # 1 = calculate new SID
      sidLength = 32  # =32, per change to TCG Storage Architecture Core Spec for IBM only so far
      charChoices = ['H','U','7','C','J','9','T','5','R','B',\
                     'G','M','E','0','F','Z','4','8','Y','K',\
                     '2','L','V','D','S','1','A','W','3','Q',\
                     'X','6','P','N']
      sidStr = ''
      if 'TD_SID' in DriveAttributes:
        sidStr = DriveAttributes['TD_SID']
        spCommandSet.statMsg("FIS PSID from getSID    = %s" % sidStr)
        sidStatus = "0"
      else:
        random.shuffle(charChoices)
        random.seed()
        for i in range(0, sidLength):
          sidStr += charChoices[int(random.random() * 34)]
        if updateAttrs:
          DriveAttributes['TD_SID'] = sidStr
         # RequestService("PutAttributes", ({"TD_SID": sidStr}, "FIN2")) #Was commented out for Serial Port Process  BJH
      return sidStatus,sidStr


class IOcommands:

    p514_cw1_report_identify_device_data                 = 0x1
    prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA = {
      "CTRL_WORD1"           : (p514_cw1_report_identify_device_data),
    }

    p514_cw1_report_identify_device_data_range           = 0x2

    def Test514_Cw2_IdentifyRange( starting_word, ending_word ):
       starting_word = starting_word & 0xff
       ending_word = (ending_word & 0xff) << 8
       return ( ending_word | starting_word )

    prm_514_REPORT_MAX_USER_48BIT_LBAS = {
       "CTRL_WORD1"           : (p514_cw1_report_identify_device_data_range),
       "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
    }

    prm_517_ReqSense0 = {
        "ACCEPTABLE_IF_MATCH" : (0x0000,),
        "ACCEPTABLE_SNS_DATA" : (0x0000,),
        "CHK_FRU_CODE" : (0x0000,),
        "CHK_SRVO_LOOP_CODE" : (0x0000,),
        "MAX_REQS_CMD_CNT" : (0x000A,),
        "OMIT_DUP_ENTRY" : (0x0000,),
        "RPT_REQS_CMD_CNT" : (0x0000,),
        "RPT_SEL_SNS_DATA" : (0x0000,),
        "SEND_TUR_CMDS_ONLY" : (0x0001,),     # was 0001
        "SENSE_DATA_1" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_2" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
        "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
        "SRVO_LOOP_CODE" : (0x0000,),
        "TEST_FUNCTION" : (0x0000,),
    }

    prm_538_spinUp = {
                "COMMAND_WORD_1" : (0x1b01,),
                "COMMAND_WORD_3" : (0x0100,),
               "TRANSFER_OPTION" : (0x0001,),
    }

    prm_575_FDE_AuthMakerSymKUniqueAES = {
    	"TEST_MODE" : (0x0001,),
        "PASSWORD_TYPE" : (0x000E,),
      	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x0009,),
        "UIDLSWU" : (0x0000,),
        "UIDLSWL" : (0x0004,),
    }

    prm_575_FDE_AuthMSID = {
        "TEST_MODE" : (0x0001,),
    	"PASSWORD_TYPE" : (0x0002,),
     	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x0009,),
        "UIDLSWU" : (0x0000,),
        "UIDLSWL" : (0x8402,),
    }

    prm_575_FDE_AuthPSID = {
        "TEST_MODE" : (0x0001,),
        "PASSWORD_TYPE"  : (0x0009,),
    	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x0009,),
        "UIDLSWU" : (0x0001,),
        "UIDLSWL" : (0xFF01,),
    }

    prm_575_FDE_AuthSID = {
        "TEST_MODE" : (0x0001,),
    	"PASSWORD_TYPE" : (0x0002,),
       	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x0009,),
        "UIDLSWU" : (0x0000,),
        "UIDLSWL" : (0x0006,),
    }

    prm_575_FDE_CloseAdminSession = {
    	"TEST_MODE" : (0x0003,),
      	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x0205,),
        "UIDLSWU" : (0x0000,),
        "UIDLSWL" : (0x0001,),
    }

    prm_575_FDE_Disable_CSFW_Port_LOR = {
    	"TEST_MODE"  : (0x15,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x000e,),
    }

    prm_575_FDE_Disable_Diag_Port_LOR = {
    	"TEST_MODE"  : (0x15,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x0001,),
    }

    prm_575_Discovery_Print = {
    	"TEST_MODE"  : (0x07,),
    	"REPORTING_MODE"  : (0x0001,),
    }

    prm_575_FDE_Enable_CSFW_Port_LOR = {
    	"TEST_MODE"  : (0x2C,),
    	"REPORTING_MODE"  : (0x0000,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x000e,),
    }

    prm_575_FDE_Enable_Diag_Port_LOR = {
    	"TEST_MODE"  : (0x2C,),
    	"REPORTING_MODE"  : (0x0000,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x0001,),
    }

    prm_575_FDE_GetMSIDFromDrive = {
    	"TEST_MODE" : (0x0011,),
        "PASSWORD_TYPE" : (0x0000,),
    }

    prm_575_FDE_GetPSIDfromFIS = {
    	"TEST_MODE"  : (0x24,),
    }

    prm_575_FDE_Lock_CSFW_Port = {
    	"TEST_MODE"  : (0x19,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x000e,),
    }

    prm_575_FDE_Lock_Diag_Port = {
    	"TEST_MODE"  : (0x19,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x0001,),
    }

    prm_575_FDE_PersonalizePSID = {
    	"TEST_MODE" : (0x0042,),
        "PASSWORD_TYPE"  : (0x0009,),
       	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x000B,),
        "UIDLSWU" : (0x0001,),
        "UIDLSWL" : (0xFF01,),

    }

    prm_575_FDE_StartAdminSession = {
    	"TEST_MODE" : (0x0002,),
        "WHICH_SP" : (0x0000,),
      	"UIDMSWU" : (0x0000,),
        "UIDMSWL" : (0x0205,),
        "UIDLSWU" : (0x0000,),
        "UIDLSWL" : (0x0001,),
    }

##    prm_575_FDE_SetSSC = {
##    	"TEST_MODE"  : (0x23,),
##        "MASTER_AUTHORITY" : (0x01,),    ##00 = MSID, 01 == PSID
##        "CORE_SPEC"  : (unlockVar.coreSpec,),          ##01 = 1.0, 02 = 2.0
##        "OPAL_SSC_SUPPORT" : (unlockVar.opalSupport),    ## non zero = OPAL supported
##        "SYMK_KEY_TYPE" : (unlockVar.masterSymKType),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
##        "MAINTSYMK_SUPP" : (0x00,),
##    	"REPORTING_MODE" : (unlockVar.enableDebugPrint),
##    }

    prm_575_FDE_Unlock_CSFW_Port = {
    	"TEST_MODE"  : (0x13,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x000e,),
    }

    prm_575_FDE_Unlock_Diag_Port = {
    	"TEST_MODE"  : (0x13,),
    	"UIDMSWU"  : (0x0001,),
    	"UIDMSWL"  : (0x0002,),
    	"UIDLSWU"  : (0x0001,),
    	"UIDLSWL"  : (0x0001,),
    }

    def sasPwrCylSpinUp(self):
        #DriveOff(5)
        #DriveOn(5000, 12000, 5)
        SetESlipBaud(38400)
        ScriptPause(2)
        try:
            st(517,self.prm_517_ReqSense0, timeout=30)
            st(538,self.prm_538_spinUp, timeout=30)
        except:
            raise Exception("POWER CYCLE DRIVE AND RETRY UNLOCKING DRIVE")

    def sataPwrCylSpinUp(self):
        #DriveOff(5)
        #DriveOn(5000, 12000, 5)
        try:
          #  UseESlip(1)
            SetESlipBaud(1228000)
            time.sleep(10)

            st(514,self.prm_514_REPORT_ALL_IDENTIFY_DEVICE_DATA,timeout=30)
            st(514,self.prm_514_REPORT_MAX_USER_48BIT_LBAS,timeout=30)
        except:
            raise Exception("POWER CYCLE DRIVE AND RETRY UNLOCKING DRIVE")


    def sortData(self):
        for i in range(0,16):
            unlockVar.tempColumn[i] = dblData['P57X_FRAME_DATA'][str(i)]

    def IODiscovery(self):
        DBlogParserOn()
        unlockVar.tempColumn = {}
        dblData={}
        st(575,self.prm_575_Discovery_Print,timeout=60)
        #Extra all the data from the Discovery Table
        maxElements = 0
        self.sortData()

        #Build up string to parse out required data
        discoveryPacket = ''
        lastRow = len(unlockVar.tempColumn[0])
        for i in range(0,lastRow):
            for j in range(0,16):
                if i == (lastRow-1):
                    if(len(unlockVar.tempColumn[j]) < lastRow):
                        DBlogParserOff()
                        discoveryPacket = binascii.a2b_hex(discoveryPacket)
                        return discoveryPacket

                discoveryPacket = discoveryPacket + unlockVar.tempColumn[j][i]

        discoveryPacket = binascii.a2b_hex(discoveryPacket)
        DBlogParserOff()
        return discoveryPacket


#  ########################################################################################
#  ####################  MAIN FUNCTION TO LOCK/UNLOCK DRIVE WITH I/O   ####################
#  ########################################################################################

    def IODriveLockUnlock(self,activateLocking=1):

        prm_575_FDE_SetSSC = {
        	"TEST_MODE"  : (0x23,),
            "MASTER_AUTHORITY" : (0x01,),    ##00 = MSID, 01 == PSID
            "CORE_SPEC"  : (unlockVar.coreSpec,),          ##01 = 1.0, 02 = 2.0
            "OPAL_SSC_SUPPORT" : (unlockVar.opalSupport),    ## non zero = OPAL supported
            "SYMK_KEY_TYPE" : (unlockVar.masterSymKType),       ##00 = legacy 3DES, 01 = 3DES. 02 AES256.
            "MAINTSYMK_SUPP" : (0x00,),
        	"REPORTING_MODE" : (unlockVar.enableDebugPrint),
        }

#        print 'CS: %d, OS %d, MSKYTPE %d, debugprint %d' %(unlockVar.coreSpec,unlockVar.opalSupport,unlockVar.masterSymKType,unlockVar.enableDebugPrint)


       # commonUnlockFuncs.findDiscovInfo(dataPacket = self.IODiscovery())  #Determine the type of drive to find correct SSC settings
        st(575, prm_575_FDE_SetSSC, timeout = 15)
        if unlockVar.currentSEDState == '\x00':
            transferTypes.statMsg('DRIVE IS IN SETUP STATE, NO UNLOCK IS REQUIRED')
        else:
            st(575,self.prm_575_FDE_StartAdminSession,timeout=30)
            st(575,self.prm_575_FDE_AuthMakerSymKUniqueAES,timeout=30)
            st(575,self.prm_575_FDE_GetPSIDfromFIS,timeout=30)
            try:
                st(575,self.prm_575_FDE_AuthPSID,timeout=30)

            except:
                st(575,self.prm_575_FDE_PersonalizePSID,timeout=30)
                st(575,self.prm_575_FDE_AuthPSID,timeout=30)
            st(575,self.prm_575_FDE_GetMSIDFromDrive,timeout=30)
            if unlockVar.driveTcgType == 'tcgEnterprise':   #Opal doesn't support Authenicating to MSID
                st(575,self.prm_575_FDE_AuthMSID,timeout=30)
            st(575,self.prm_575_FDE_AuthSID,timeout=30)

            if activateLocking == 0:
                st(575,self.prm_575_FDE_Unlock_Diag_Port,timeout=30)
                st(575,self.prm_575_FDE_Disable_Diag_Port_LOR,timeout=30)
                try:
                    st(575,self.prm_575_FDE_Unlock_CSFW_Port,timeout=30)
                    st(575,self.prm_575_FDE_Disable_CSFW_Port_LOR,timeout=30)
                except:
                    dummyVar = 0  #Required so that we don't fail test if SDD not supported
            else:

                st(575,self.prm_575_FDE_Lock_Diag_Port,timeout=30)
                st(575,self.prm_575_FDE_Enable_Diag_Port_LOR,timeout=30)
                try:
                    st(575,self.prm_575_FDE_Lock_CSFW_Port,timeout=30)
                    st(575,self.prm_575_FDE_Enable_CSFW_Port_LOR,timeout=30)
                except:
                    dummyVar = 0  #Required so that we don't fail test if SDD not supported
            st(575,self.prm_575_FDE_CloseAdminSession,timeout=30)








# ################################################################# #
#          #############################################            #
#               START OF SERIAL PORT FUNCATIONLITY                  #
#          #############################################            #
# ################################################################# #
class SPcommands:


    trustedFuncID_ifSend = '\x01\x00'
    trustedFuncID_ifRecv = '\x02\x00'
    SP_packet = '\x01\x00'
    ComID_packet = '\xFF\x07'
    ComID_discovery = '\x01\x00'
    SDBP_headerSend = trustedFuncID_ifSend + SP_packet + ComID_packet
    FRAME_retrieve = trustedFuncID_ifRecv + SP_packet + ComID_packet
    SED_discovery = trustedFuncID_ifRecv + SP_packet + ComID_discovery
    SED_sendReceivePort = 0x08
    DITS_sendReceivePort = 0x01

    UIDmethod_CS1authenTable   = '\x00\x00\x00\x06\x00\x00\x00\x0C'
    UIDmethod_CS2authenTable   = '\x00\x00\x00\x06\x00\x00\x00\x1C'
    UIDmethod_CS1setTable      = '\x00\x00\x00\x06\x00\x00\x00\x07'
    UIDmethod_CS2setTable      = '\x00\x00\x00\x06\x00\x00\x00\x17'
    UIDmethod_CS1getTable      = '\x00\x00\x00\x06\x00\x00\x00\x06'
    UIDmethod_CS2getTable      = '\x00\x00\x00\x06\x00\x00\x00\x16'
    UIDmethod_smUID            = '\x00\x00\x00\x00\x00\x00\x00\xFF'

    comPacket_extended_TCG =  '\x07\xFF\x00\x00'
    comPacket_extended_OPAL = '\x07\xFF\x00\x00'
    com_fillers = '\x00\x00\x00\x00'
    min_Transfer = '\x00\x00\x00\x00'
    filler_8bytesZero = com_fillers + com_fillers

    sess_TCGsqNumber = '\x00\x00\x00\x01'
    sess_OPALsqNumber = '\x00\x00\x00\x00'
    #Used in function above to simplify packets
    sess_ack = '\x00\x00\x00\x00\x00\x00\x00\x00'
    endPacket = '\xF1\xF9\xF0\x00\x00\x00\xF1'   #Size 7

    UIDmethod_authenTable = UIDmethod_CS1authenTable
    UIDmethod_setTable = UIDmethod_CS1setTable
    UIDmethod_getTable = UIDmethod_CS1getTable
    comPacket_extended = comPacket_extended_TCG
    sess_sqNumber = sess_TCGsqNumber

    COMPacket = com_fillers + comPacket_extended + com_fillers + min_Transfer
    PacketHeader = SDBP_headerSend + COMPacket    #Size 22


    UID_startSession        =  '\x00\x00\x00\x00\x00\x00\xFF\x02'
    UID_adminSP             =  '\x00\x00\x02\x05\x00\x00\x00\x01'
    UID_lockingSP           =  '\x00\x00\x02\x05\x00\x01\x00\x01'
    UID_authPSID            = '\x00\x00\x00\x09\x00\x01\xFF\x01'
    UID_authMSID            = '\x00\x00\x00\x09\x00\x00\x84\x02'
    UID_authSID             = '\x00\x00\x00\x09\x00\x00\x00\x06'
    UID_authMkrSymK         = '\x00\x00\x00\x09\x00\x00\x00\x04'
    UID_authEraseMstr       = '\x00\x00\x00\x09\x00\x00\x84\x01'
    UID_prsnlzePSID         = '\x00\x00\x00\x0B\x00\x01\xFF\x01'
    UID_retrDrvMSID         = '\x00\x00\x00\x0B\x00\x00\x84\x02'
    UID_spUID               = '\x00\x00\x00\x00\x00\x00\x00\x01'
    UID_securityStateCtrl   = '\x00\x01\x00\x03\x00\x00\x00\x00'
    UID_makerSymK_AES256    = '\x00\x00\x00\x0F\x00\x01\x00\x01'
    UID_diagLockingPort     = '\x00\x01\x00\x02\x00\x01\x00\x01'
    UID_fwLockingPort       = '\x00\x01\x00\x02\x00\x01\x00\x02'
    UID_udsLockingPort      = '\x00\x01\x00\x02\x00\x01\x00\x03'
    UID_crossSegFwDnldPort  = '\x00\x01\x00\x02\x00\x01\x00\x0e'
    UID_SetSOM0             = '\x00\x01\x00\x07\x00\x00\x00\x00'
    UID_revertAdminSP       = '\x00\x00\x00\x06\x00\x00\x00\x11'
    UID_MSIDGet             = '\x00\x00\x00\x08\x00\x00\x8c\x04'

    TYPE_CS1Pin            = '\x50\x49\x4E'
    TYPE_CS1Key            = '\x4B\x65\x79'
    TYPE_CS2Pin           = '\x03'

    TYPE_pin = TYPE_CS1Pin
    TYPE_key = TYPE_CS1Key

    def updateVars(self):
        if unlockVar.coreSpec == 1:
            self.UIDmethod_authenTable = self.UIDmethod_CS1authenTable
            self.UIDmethod_setTable = self.UIDmethod_CS1setTable
            self.UIDmethod_getTable = self.UIDmethod_CS1getTable
            self.comPacket_extended = self.comPacket_extended_TCG
            self.sess_sqNumber = self.sess_TCGsqNumber
            self.TYPE_pin = self.TYPE_CS1Pin
            self.TYPE_key = self.TYPE_CS1Key
        elif unlockVar.coreSpec == 2:
            self.UIDmethod_authenTable = self.UIDmethod_CS2authenTable
            self.UIDmethod_setTable = self.UIDmethod_CS2setTable
            self.UIDmethod_getTable = self.UIDmethod_CS2getTable
            self.comPacket_extended = self.comPacket_extended_OPAL
            self.sess_sqNumber = self.sess_OPALsqNumber
            self.TYPE_pin = self.TYPE_CS2Pin
            self.TYPE_key = self.TYPE_CS2Pin



# ===============================================================================
#Certificate Constructors.  They include their token types atom as the first byte
# ===============================================================================

    startSndSession   = '\x00\x00\x00\x00'
    startLckSPSession = '\x00\x00\x00\x01'
    PSID_defaultPin = '\x56\x55\x54\x53\x52\x51\x50\x4F\x4E\x4D\x4C\x4B\x4A\x49\x48\x47\x46\x45\x44\x43\x42\x41\x39\x38\x37\x36\x35\x34\x33\x32\x31\x30'   #Size 32
    MSID_defaultPin = '\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F\x50\x51\x52\x53\x54\x55\x56'   # Size 32

    dictSEDStates = {'00':'SETUP','81':'MANUFACTURE','80':'USE',
                     '01':'DIAGNOSTIC','FF':'FAIL'}

########################################################
####################  ERROR TYPES   ####################
########################################################
    dictMethodFailCodes = {'01':'NOT_AUTHORIZED','02':'READ_ONLY','03':'SP_BUSY',
                           '04':'SP_FAILED','05':'SP_DISABLED','06':'SP_FROZEN',
                           '07':'NO_SESSIONS_AVAILABLE','08':'INDEX_CONFLICT','09':'INSUFFICIENT_SPACE',
                           '0a':'INSUFFICIENT_ROWS','0b':'INVALID_COMMAND','0c':'INVALID_PARAMETER',
                           '0d':'INVALID_REFERENCE','0e':'INVALID_SECMSG_PROPERTIES','0f':'TPER_MALFUNCTION',
                           '10':'TRANSACTION_FAILURE','11':'RESPONSE_OVERFLOW'}

#  ########################################################################################
#  ####################  MAIN FUNCTION TO SERIALLY LOCK/UNLOCK DRIVE   ####################
#  ########################################################################################

    def serialDriveLockUnlock(self,activateLocking=1):
       # commonUnlockFuncs.findDiscovInfo(dataPacket = self.SerialSEDDiscovery())
        self.authenStartSess()
        if unlockVar.currentSEDState == '\x00':   #Used to know if drive has been personalized or not
            self.closeSession()
            self.statMsg('DRIVE IS IN SETUP STATE, NO UNLOCK IS REQUIRED')
        else:
            self.authenSIDSMaker(default = 0, firstRun = 0)
            self.lockUnlockDiagPort(lockPort = activateLocking)
            self.lockUnlockCrossSegFWDnldPort(lockPort = activateLocking)
            self.enableDisableDiagLOR(lockPort = activateLocking)
            self.enableDisableCSFWLOR(lockPort = activateLocking)
            self.closeSession()  #closing session after updating States and personalizing SID's


# ===================================================================
# Print statment types
# ===================================================================
    def statMsg(self,msg,masterPrint = unlockVar.enableDebugPrint):
        if masterPrint == 1:
            print(msg)

##############################################################################
##########   Used to print response packets in an organized method  ##########
##############################################################################
    def printSedBin(self,binData,lineWidth=16,display=0):
        chars = [binascii.hexlify(ch) for ch in binData]
        self.__printSedBin(chars,lineWidth)
        if display == 1 or unlockVar.enableDebugPrint == 1:
            print("\n")

    def __printSedBin(self,chars,lineWidth):
        result = " "
        while chars:
            for group in range(lineWidth/8):
                charSet,chars = chars[:8],chars[8:]
                result = "%s%s " % (result," ".join(charSet),)
                if not chars: break
            result = "%s\n"%(result.strip(),)

        self.statMsg("%s"%result.strip())

    ####################################################################
    displayFrame = printSedBin
    ####################################################################

#######################################################
##########   Used to spin up the SAS Drive   ##########
#######################################################
    def sasPwrCylSpinUp(self,baudRate=1228000):
        CTRL_Z = '\x1A'
        #DriveOff(5)
        #DriveOn(5000, 12000,7)
        ScriptPause(3)
      #  UseESlip(1)
        try:
         #  SetBaudRate(baudRate)
           SetESlipBaud(1228000)
        except:
           ScriptPause(10) #Delay for specific case where drive spins up on power cycle and setting baud rate fails.
          # SetBaudRate(38400)
           SetESlipBaud(baudRate)

        PChar(CTRL_Z)
        time.sleep(15)

########################################################
##########   Used to spin up the SATA Drive   ##########
########################################################
    def sataPwrCylSpinUp(self,baudRate=38400):
        #DriveOff(5)
        #DriveOn(5000,12000,5)
       # UseESlip(1)
       # SetESlipBaud(baudRate)
       # ScriptPause(4)
        try:
            SetESlipBaud(baudRate)
        except:
            try:
                ScriptPause(8)
                SetESlipBaud(1228000)
            except:
                try:
                    ScriptPause(8)
                    SetESlipBaud(baudRate)
                except:
                    raise Exception('SETTING BAUD RATE FAILED. POWER CYCLE DRIVE AND RETRY')
        ScriptPause(15)


##################################################################
##########   Used to send packets/frames to the drive   ##########
##################################################################
    def sendPacket(self,frame, m_type, showFrame = 1, ditsCommand = 0):
        if ditsCommand == 1:
            SendBuffer(frame, toAddress=self.DITS_sendReceivePort, fromAddress=self.DITS_sendReceivePort, checkSRQ=0)
            dispFrame = frame[0:]
        else:
            SendBuffer(frame, toAddress=self.SED_sendReceivePort, fromAddress=self.SED_sendReceivePort, checkSRQ=0)
            dispFrame = frame[6:]
            #dispFrame = frame[0:]   #Used to show more data in packet for debug for Asif
        if showFrame == 1:
            self.statMsg("Sent %s" %m_type)
            self.displayFrame(dispFrame)
        time.sleep(.2)  #Keep Drive from hanging up

##############################################################################################
##########   Used to retrieve packets/frames from the drive after sending request   ##########
##############################################################################################
    def getPacket(self,m_type, showFrame = 1, checkRcvStat = 0, ditsCommand = 0, retrieveFrame = FRAME_retrieve, abortBadStatus = 1):
        if ditsCommand != 1:
            SendBuffer(retrieveFrame, toAddress=self.SED_sendReceivePort, fromAddress=self.SED_sendReceivePort, checkSRQ=0)
            responseFrame = ReceiveBuffer(checkSRQ=0, fromAddress=self.SED_sendReceivePort, toAddress=self.SED_sendReceivePort, timeout=15, ignMismatch=0)
            for i in range (0,12):   #Cycle through 12 times in case the drive hasn't processed the 'ReceiveBuffer()' with valid data yet
                if (binascii.hexlify(responseFrame[25:26])) != '00':
                    break
                else:
                    self.statMsg("data from drive\n%s" % (repr(responseFrame),))
                    SendBuffer(retrieveFrame, toAddress=self.SED_sendReceivePort, fromAddress=self.SED_sendReceivePort, checkSRQ=0)
                    time.sleep(i/2)
                    responseFrame = ReceiveBuffer(checkSRQ=0, fromAddress=self.SED_sendReceivePort, toAddress=self.SED_sendReceivePort, timeout=15, ignMismatch=0)
            else:
               #exhausted retries
               msg = 'Error occured in getPacket() when processing %s .  Response packet has a length of ZERO' % m_type
               self.statMsg(msg)
               raise Exception(msg)

        if ditsCommand == 1:
            responseFrame = ReceiveBuffer(checkSRQ=0, fromAddress=self.DITS_sendReceivePort, toAddress=self.DITS_sendReceivePort, timeout=15)
        if showFrame == 1:
            if ditsCommand == 1:
                self.displayFrame(responseFrame[0:])
            else:
                self.displayFrame(responseFrame[6:])
        if ditsCommand == 0:
            #Check used to Verify Method Status is correct
            frameLength = len(responseFrame)
            for i in range(0,frameLength):
                if binascii.hexlify(responseFrame[frameLength-i-1:frameLength-i]) == 'f1':
                    methodStatus = binascii.hexlify(responseFrame[frameLength-i-4:frameLength-i-3])
                    if methodStatus != '00':
                        if abortBadStatus == 0:
                            if(m_type == 'Authenticating Default PSID' or m_type == 'Authenticating FIS PSID'): #Use this return case so that we know if PSID is failing to authenicate
                                return 11223344 #'BadPSID'
                            elif(m_type == 'Authenticating MakerSymK Step One' or m_type == 'Authenticating SymK Step Two'):
                                return 112233 #'badMakers'
                            elif(m_type == 'Authenticating Default MSID' or m_type == 'Authenticating FIS MSID'):
                                return 112244 #'badMSID'
                            elif(m_type == 'Authenticating Default SID' or m_type == 'Authenticating FIS SID'):
                                return 112255 #'badSID'
                        else:
                            self.abort(failVal=10124,failStr=m_type)
                    else:
                        break
            if checkRcvStat == 1:  #can be used for authenticate bands, SIDS and final MakerSymK, and change states
                if responseFrame[63:64] == '\x00': #Should return \x01 for passing status
                    if abortBadStatus == 0: #Use this return case so that we know if PSID is failing to authenicate
                        if(m_type == 'Authenticating Default PSID' or m_type == 'Authenticating FIS PSID'): #Use this return case so that we know if PSID is failing to authenicate
                            return 11223344 #'BadPSID'
                        elif(m_type == 'Authenticating MakerSymK Step One' or m_type == 'Authenticating SymK Step Two'):
                            return 112233 #'badMakers'
                        elif(m_type == 'Authenticating Default MSID' or m_type == 'Authenticating FIS MSID'):
                            return 112244 #'badMSID'
                        elif(m_type == 'Authenticating Default SID' or m_type == 'Authenticating FIS SID'):
                            return 112255 #'badSID'
                    if showFrame == 0:     ##statMsg this if error occured and didn't statMsg frame to begin with so we can see the return
                        self.statMsg("Retrieved Bad %s Packet" %m_type)
                        self.displayFrame(responseFrame[6:])
                    if abortBadStatus == 1:  #Could be used to reroute process to try different SID value
                        self.abort(failStr='Last receive frame returned a non-passing status')
                    else:
                        return responseFrame[63:64]
        if ditsCommand == 1:
            senseData = binascii.b2a_hex(responseFrame[1:2]) + '/' + binascii.b2a_hex(responseFrame[2:3]) + '/' + binascii.b2a_hex(responseFrame[3:4]) + '/' + binascii.b2a_hex(responseFrame[11:12])
            if senseData != '00/00/00/00':
                if showFrame == 0:
                    self.statMsg("Retrieved This Bad %s Packet" %m_type)
                    self.displayFrame(responseFrame[0:])
                if senseData == '05/2c/00/03':
                    badSenseStr = 'Need to Unlock Dits Commands.  BAD SENSE DATA IS:' + senseData
                    spCommandSet.statMsg('%s')
                    self.abort(failVal=10124,failStr=badSenseStr)
                else:
                    badSenseStr = 'BAD SENSE DATA: ' + senseData
                if abortBadStatus == 1: #Used to handle error in seperate DITs command function
                    self.abort(failVal=10124,failStr=badSenseStr)
                else:
                    return senseData
            else:
                return senseData
        return responseFrame[0:]

#######################################################################
##########  Used to get the length values need for the frame ##########
#######################################################################

    def getFrameLengths(self,frame = ''):
        lengthTypes = {}
        framePad = '\x00'
        framePadNum = 0
        unlockVar.preFrameLength = len(frame) + 36
        if unlockVar.preFrameLength > 0:
            modTemp = (unlockVar.preFrameLength) % 4
            if modTemp != 0:
                unlockVar.preFrameLength = (unlockVar.preFrameLength / 4)  #Rounds number down to whole number first
                unlockVar.preFrameLength = ((unlockVar.preFrameLength*4) + 4)
                framePadNum = 4 - modTemp
                for y in range(1,framePadNum):
                    framePad = framePad + '\x00'

            #Finding length of string and prepending zeros so it's 4 bytes long.  tempLen = unlockVar.preFrameLength
            lengthTypes['comPacketLength'] = str(hex(unlockVar.preFrameLength)[2:]).zfill(8)
            lengthTypes['packetLength'] = str(hex(unlockVar.preFrameLength - 24)[2:]).zfill(8)
            lengthTypes['subPacketLength'] = str(hex(unlockVar.preFrameLength - 36 - framePadNum)[2:]).zfill(8)

            for x in lengthTypes:
                strCalc = lengthTypes[x]
                binStrLen = binascii.unhexlify(strCalc)
                lengthTypes[x] = binStrLen
            return lengthTypes, framePad

        else:
            raise Exception('Frame length is not long enough.  Missing frame while constructing packet')

###########################################################################
##########  Used to prepend correct Atom Type before information ##########
###########################################################################
    def prependAtom(self,preDictionary = {},cont = 0, preString = ''):
        newRSADict = {}
        if preString == '':
            for x in preDictionary:
                dataLength = len(preDictionary[x])
                if dataLength <= 15:  #Short Atom
                    if dataLength <= 2:
                        tempData, = struct.unpack('B',preDictionary[x])
                        if tempData <= 63:
                            return preDictionary[x]
                    if cont == 0:
                        addAtom = (0x80 | (dataLength & 0x0F))
                    else:
                        addAtom = (0xA0 | (dataLength & 0x0F))
                elif dataLength <= 2047: # Medium Atom
                    if cont == 0:
                        addAtom = ((0xC0 | ((dataLength >> 8) & 0x0F)) << 8)
                    else:
                        addAtom = ((0xD0 | ((dataLength >> 8) & 0x0F)) << 8)
                    addAtom = addAtom + (dataLength & 0xFF)
                else: #Long Atom
                    addAtom = (0xE2) << 24
                    addAtom = addAtom + (dataLength & 0xFFFFFF)
                convertAtom = binascii.unhexlify(str(hex(addAtom)[2:]))
                newRSADict[x] = convertAtom + preDictionary[x]
            return newRSADict
        else:
            dataLength = len(preString)
            if dataLength <= 15:
                if dataLength <= 1:
                    tempData, = struct.unpack('B',preString)
                    if tempData <= 63:
                        return preString
                if cont == 0:
                    addAtom = (0x80 | (dataLength & 0x0F))
                else:
                    addAtom = (0xA0 | (dataLength & 0x0F))
            elif dataLength <= 2047: # Medium Atom
                if cont == 0:
                    addAtom = ((0xC0 | ((dataLength >> 8) & 0x0F)) << 8)
                else:
                    addAtom = ((0xD0 | ((dataLength >> 8) & 0x0F)) << 8)
                addAtom = addAtom + (dataLength & 0xFF)
            else: #Long Atom
                addAtom = (0xE2) << 24
                addAtom = addAtom + (dataLength & 0xFFFFFF)
            convertAtom = binascii.unhexlify(str(hex(addAtom)[2:]))
            dataString = str(convertAtom + preString)
            return dataString


#####################################################
##########   Used to discover SED drive    ##########
#####################################################
    def SerialSEDDiscovery(self):
        discoveryPacket = self.getPacket(m_type = 'Discovery',retrieveFrame = self.SED_discovery)
        return discoveryPacket[6:]


#####################################################
##########   Verify SED type of Drive      ##########
#####################################################
    def SEDDriveVerify(self):
        self.ditsLockUnlock(lockPort = 0, abortBadStat = 0)
        setFDEPacket = '\x2F\x01\x01\x00\x00\x00\x00\x00'
        sessionType = 'Verify SED/non-SED Drive'
        self.sendPacket(frame = setFDEPacket, m_type = sessionType, ditsCommand = 1)
        ditsResponse = self.getPacket(m_type = sessionType, ditsCommand = 1,abortBadStatus = 0)
        if ditsResponse in ['00/00/00/00','07/20/02/00']:
            return 'SED Drive'
        elif ditsResponse in ['05/26/02/13','05/26/02/14']:  #Sense data for not support cmd
            return 'non-SED Drive'
        else:
            response = 'Failed with unknown Error Type %s' %ditsResponse
            self.abort(failStr=response)

####################################################################################
##########   Gets PSID value from FIS if it hasn't already retrieved it   ##########
####################################################################################
    def retrPsid(self,display = 1,forceUpdate = 0):   #Similar to Test 575, Mode:0x24
        if(unlockVar.global_fisPSID == '') or forceUpdate ==1:
            sidStatus,unlockVar.global_fisPSID = transferTypes.getSID()
            if display == 1:
                self.statMsg('PSID value = %s' % unlockVar.global_fisPSID)

##############################################################################################
##########    Gets MSID value from Drive or FIS if it hasn't already retrieved it   ##########
##############################################################################################
    def retrMsid(self,fromFIS = 1, display = 1):  #Similar to Test 575, Mode:0x10, 0x11
        if fromFIS ==1:
            if(unlockVar.global_fisMSID == ''):
                sidStatus, unlockVar.global_fisMSID = transferTypes.getMSIDfromAttributeMSID(updateAttrs = 1)
                if display == 1:
                    self.statMsg('MSID retrieved from MSID attribute = %s' % unlockVar.global_fisMSID)
            return unlockVar.global_fisMSID
        else:
            if unlockVar.global_driveMSID == '':
                sessionType = 'Get MSID from the Drive' #Need to be authenicate start session
                packet = self.createPacket(type = 'getDrvMsid', UID = self.UID_retrDrvMSID, mthdUID = self.UIDmethod_getTable)
                self.sendPacket(frame = packet, m_type = sessionType, showFrame = 1)
                tempPacket = self.getPacket(m_type = sessionType, showFrame = 1,checkRcvStat = 1)
                if unlockVar.coreSpec == 1:
                    unlockVar.global_driveMSID = tempPacket[72:104]
                else:
                    unlockVar.global_driveMSID = tempPacket[68:100]
                if display == 1:
                    self.statMsg('Drive MSID Value is: %s' %unlockVar.global_driveMSID)
            return unlockVar.global_driveMSID

###########################################
##########  Dits Unlock command  ##########
###########################################
    def ditsLockUnlock(self,lockPort = 1,abortBadStat = 1):
        if lockPort == 1:
            packet = "\xFF\xFF\x01\x00\x9a\x32\x4f\x83"
            sessionType = 'Lock the Dits Port'
        else:
            packet = "\xFF\xFF\x01\x00\x9a\x32\x4f\x03"
            sessionType = 'Unlock the Dits Port'
        self.sendPacket(frame = packet, m_type = sessionType, ditsCommand = 1)
        self.getPacket(m_type = sessionType, ditsCommand = 1,checkRcvStat = 1,abortBadStatus = abortBadStat)

##########################################################################################
##########   Used to Authenitcate both Standard and Locking SP Start Sessions   ##########
##########################################################################################
    def authenStartSess(self,lockingSP = 0): #Similar to Test 575, Mode:0x02
        if lockingSP == 0:
            sessionType = 'Authenticate Start Session'
            packet = self.createPacket(type = 'authSess', srtSessType = self.startSndSession, UID = self.UID_adminSP)
        else:
            sessionType = 'Authenticate Locking SP Start Session'
            packet = self.createPacket(type = 'authSess', srtSessType = self.startLckSPSession, UID = self.UID_lockingSP)
        self.sendPacket(frame = packet, m_type = sessionType)
        sessNumPacket = self.getPacket(m_type = sessionType)
        if unlockVar.coreSpec == 1:
            unlockVar.sessionNumber = sessNumPacket[91:92]
        elif unlockVar.coreSpec == 2:
            unlockVar.sessionNumber = sessNumPacket[87:88]

################################################
##########   Closes an open session   ##########
################################################
    def closeSession(self):  #Similar to Test 575, Mode:0x03
        sessionType = 'Closing Session'
        packet = self.createPacket(type = 'closeSession')
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType)

####################################################
##########   Used to authenicate a PSID   ##########
####################################################
    def authenPSID(self,fromDefValue = 1, handleFail = 1):  #Similar to Test 575, Mode:0x01
        if fromDefValue == 1:
            sessionType = 'Authenticating Default PSID'
            psidPin = self.prependAtom(preString = self.PSID_defaultPin, cont = 1)
        else:
            sessionType = 'Authenticating FIS PSID'
            self.retrPsid()
            psidPin = self.prependAtom(preString = unlockVar.global_fisPSID, cont = 1)
        packet = self.createPacket(type = 'authSymK2_Ers_Bnd_SIDS',UID = self.UID_authPSID, credential = psidPin, mthdUID = self.UIDmethod_authenTable)
        self.sendPacket(frame = packet,m_type = sessionType)
        if handleFail == 0:
            self.getPacket(m_type = sessionType,checkRcvStat = 1,abortBadStatus = 1)
        else:
            failCode = self.getPacket(m_type = sessionType,checkRcvStat = 1,abortBadStatus = 0)

            if failCode == 11223344:   #BadPSID
                self.personalizePSID(toDefValue = 0, requireUpdate=1)
                sidStatus,unlockVar.global_fisPSID = transferTypes.getSID(updateAttrs = 1)
                sessionType = 'Authenticating New FIS PSID'
                psidPin = self.prependAtom(preString = unlockVar.global_fisPSID, cont = 1)
                packet = self.createPacket(type = 'authSymK2_Ers_Bnd_SIDS',UID = self.UID_authPSID, credential = psidPin, mthdUID = self.UIDmethod_authenTable)
                self.sendPacket(frame = packet,m_type = sessionType)
                self.getPacket(m_type = sessionType,checkRcvStat = 1,abortBadStatus = 1)

####################################################
##########   Used to authenicate a MSID   ##########
####################################################
    def authenMSID(self,fromDefValue = 1):   #Similar to Test 575, Mode:0x01
        if unlockVar.driveTcgType == 'tcgEnterprise':
            if fromDefValue == 1:
                sessionType = 'Authenticating Default MSID'
                msidPin = self.prependAtom(preString = self.MSID_defaultPin, cont = 1)
            else:
                sessionType = 'Authenticating FIS MSID'
                msid = self.retrMsid(fromFIS = 0)
                msidPin = self.prependAtom(preString = msid, cont = 1)
            packet = self.createPacket(type = 'authSymK2_Ers_Bnd_SIDS',UID = self.UID_authMSID, credential = msidPin, mthdUID = self.UIDmethod_authenTable)
            self.sendPacket(frame = packet,m_type = sessionType)
            self.getPacket(m_type = sessionType,checkRcvStat = 1)

###################################################
##########   Used to authenicate a SID   ##########
###################################################
    def authenSID(self,fromDefValue = 1):    #Similar to Test 575, Mode:0x01
        if fromDefValue == 1:
            sessionType = 'Authenticating Default SID'
            sidPin = self.prependAtom(preString = self.MSID_defaultPin, cont = 1)
        else:
            sessionType = 'Authenticating FIS SID'
            sid = self.retrMsid(fromFIS=0)
            sidPin = self.prependAtom(preString = sid, cont = 1)
        packet = self.createPacket(type = 'authSymK2_Ers_Bnd_SIDS',UID = self.UID_authSID, credential = sidPin, mthdUID = self.UIDmethod_authenTable)
        self.sendPacket(frame = packet,m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)

#########################################################
##########   Used to authenicate to MakerSymK  ##########
#########################################################
    def authenSymK(self,firstRunDef = 0, symKType = 2,handleFail=0):  #Similar to Test 575, Mode:0x01
        tempUID = self.UID_authMkrSymK
        sessionType = 'Authenticating MakerSymK Step One'

        packet = self.createPacket(type = 'authSymKAmp1', UID = tempUID, mthdUID = self.UIDmethod_authenTable)
        self.sendPacket(frame = packet, m_type = sessionType)
        responseFrame = self.getPacket(m_type = sessionType)

        responseFrame = responseFrame[65:97]
        self.statMsg("Hex Challange Value")
        self.displayFrame(responseFrame)
        self.statMsg("Challange Value = %s" %responseFrame)
        randomChallengeValue = base64.b64encode(responseFrame)
        self.statMsg("Confirm Send Challange Value %s" %randomChallengeValue)
        keyType = 'DiagKey'

        if (firstRunDef  == 1):
            if symKType == 2:
                method,prms = RequestService('DoDefaultKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,keyType,'AES256','0'))
            elif symKType == 1:
                method,prms = RequestService('DoDefaultKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'DiagKey','3DES','0'))
        else:
            if symKType == 2:
                method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,keyType,'AES256','0'))
            elif symKType == 1:
                 method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'DiagKey','3DES','0'))

        responseString = base64.b64decode(prms['AuthenticationResponse'])
        mfgAuthKeyString = binascii.b2a_hex(responseString)
        self.statMsg("HDA Serial Number = %s" % unlockVar.driveSN)
        self.statMsg("Mfg.Auth.Key = %s" %mfgAuthKeyString)

        sessionType = 'Authenticating SymK Step Two'
        makerString = self.prependAtom(preString = responseString,cont=1)
        packet = self.createPacket(type = 'authSymK2_Ers_Bnd_SIDS', UID = tempUID, credential = makerString, mthdUID = self.UIDmethod_authenTable)
        self.sendPacket(frame = packet, m_type = sessionType)


        if handleFail == 0:
            responseFrame =self.getPacket(m_type = sessionType,checkRcvStat = 1, abortBadStatus = 1)
        else:
            firstRunDef = not firstRunDef    #Switch so we use different type of authenicate for either default or unique makerSymK
            responseFrame = self.getPacket(m_type = sessionType,checkRcvStat = 1, abortBadStatus = 0)

            if responseFrame == 112233:
                tempUID = self.UID_authMkrSymK
                sessionType = 'Authenticating MakerSymK Step One'

                packet = self.createPacket(type = 'authSymKAmp1', UID = tempUID, mthdUID = self.UIDmethod_authenTable)
                self.sendPacket(frame = packet, m_type = sessionType)
                responseFrame = self.getPacket(m_type = sessionType)

                responseFrame = responseFrame[65:97]
                self.statMsg("Hex Challange Value")
                self.displayFrame(responseFrame)
                self.statMsg("Challange Value = %s" %responseFrame)
                randomChallengeValue = base64.b64encode(responseFrame)
                self.statMsg("Confirm Send Challange Value %s" %randomChallengeValue)
                keyType = 'DiagKey'

                if (firstRunDef  == 1):
                    if symKType == 2:
                        method,prms = RequestService('DoDefaultKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,keyType,'AES256','0'))
                    elif symKType == 1:
                        method,prms = RequestService('DoDefaultKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'DiagKey','3DES','0'))
                else:
                    if symKType == 2:
                        method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,keyType,'AES256','0'))
                    elif symKType == 1:
                         method,prms = RequestService('DoUniqueKeyAuthentication',(randomChallengeValue, unlockVar.driveSN,'DiagKey','3DES','0'))

                ScriptComment("method: %s; prms: %s"%(method,prms,))
                responseString = base64.b64decode(prms['AuthenticationResponse'])
                mfgAuthKeyString = binascii.b2a_hex(responseString)
                self.statMsg("HDA Serial Number = %s" % unlockVar.driveSN)
                self.statMsg("Mfg.Auth.Key = %s" %mfgAuthKeyString)

                sessionType = 'Authenticating SymK Step Two'
                makerString = self.prependAtom(preString = responseString,cont=1)
                packet = self.createPacket(type = 'authSymK2_Ers_Bnd_SIDS', UID = tempUID, credential = makerString, mthdUID = self.UIDmethod_authenTable)
                self.sendPacket(frame = packet, m_type = sessionType)
                responseFrame = self.getPacket(m_type = sessionType,checkRcvStat = 1, abortBadStatus = 1)

##############################################################
##########   Used to authnicate to all SID Values   ##########
##############################################################
    def authenSIDSMaker(self,default = 0, firstRun = 0):   #Similar to Test 575, Mode:0x01
        self.authenSymK(firstRunDef = firstRun, symKType = unlockVar.masterSymKType,handleFail=1) #firstRunDef should = 1 only on the very first personalization of the drive
        self.authenPSID(fromDefValue = default)
        if unlockVar.driveTcgType == 'tcgEnterprise':
            self.authenMSID(fromDefValue = default)
        self.authenSID(fromDefValue = default)


####################################################################
##########   Used to verify which state the Drive is in   ##########
####################################################################
    def getStateTable(self,dispFrames = 0, displayState = 1):    #Similar to Test 575, Mode:0x09
        sessionType = 'Get State Table'
        packet = self.createPacket(type = 'getStateTbl', mthdUID = self.UIDmethod_getTable)
        self.sendPacket(frame = packet, m_type = sessionType, showFrame = dispFrames)
        table = self.getPacket(m_type = sessionType, showFrame = dispFrames)
        if displayState == 1:
            self.statMsg("Drive is in %s State" %dictSEDStates[binascii.hexlify(table[64:65])])
        return table[64:65]

#############################################################
##########   Used to change drive to a new state   ##########
#############################################################
    def changeStates(self,newState):     #Similar to Test 575, Mode:0x08
        time.sleep(1)
        sessionType = ''
        currentState = self.getStateTable()
        if(newState == 00):
            sessionType = 'Change to Setup State'
            newState = '\x00'
            if(currentState == '\xFF' or currentState == '\x80'):
                raise Exception("Can't change from current state to Setup State")
        if(newState == 0o1):
            sessionType = 'Change to Diag State'
            newState = '\x01'
            if(currentState == '\x00' or currentState == '\x81'):
                raise Exception("Can't change from current state to Diag State")
        if(newState == 80):
            sessionType = 'Change to Use State'
            newState = '\x80'
            if(currentState == '\x00' or currentState == '\xFF' or currentState == '\x01'):
                raise Exception("Can only change to Use State from Manufacture State")
        if(newState == 81):
            sessionType = 'Change to Manufacture State'
            newState = '\x81'
            if(currentState == '\x80' or currentState == '\xFF' or currentState == '\x01'):
                raise Exception("Can only change to Manufacture State from Setup State")
        if(newState == 99):
            sessionType = 'Change to Fail State'
            newState = '\xFF'
            if(currentState == '\x00'):
                raise Exception("Can't change to Fail State from Setup State")
        if currentState == newState:
            currentState = self.displayFrame(currentState)
            self.statMsg("Set State ( %s )is the Same as Current State" %dictSEDStates[newState])
            return
        packet = self.createPacket(type = 'setStateTbl_SOM0', state = newState, mthdUID = self.UIDmethod_setTable, UID = self.UID_securityStateCtrl)
        self.sendPacket(frame = packet, m_type = sessionType)
        time.sleep(6)     #Need to pause for a moment if changing states or drive will timeout
        self.getPacket(m_type = sessionType,checkRcvStat = 1)

##################################################################################
##########  Change state to Setup no matter what state the dirve is in  ##########
##################################################################################
    def changeToSetupState(self):    #Similar to Test 577
        self.authenStartSess()
        currState = self.getStateTable()
        if currState != '\x00':
            defaultMSID = 0
        if currState != '\x00':
            self.authenSIDSMaker(default = defaultMSID, firstRun = defaultMSID)
            if currState == '\x81':  #need to cycle through states drive can only get to Manufature State from Setup State
                self.changeStates(00)
                currState = self.getStateTable()
            if currState == '\x80' or currState == '\xFF':  # if wasn't in Diag state it is now and needs to go to Setup State
                self.changeStates(0o1)
                currState = self.getStateTable()
            if currState == '\x01':
                self.changeStates(00)
                currState = self.getStateTable()
        self.closeSession()

#####################################################################
##########   Used to personalize a PSID with a new value   ##########
#####################################################################
    def personalizePSID(self,toDefValue = 0,requireUpdate = 0):    #Similar to Test 575, Mode:0x04
        if toDefValue == 1:
            psidPin = self.prependAtom(preString = self.PSID_defaultPin, cont = 1)

        else:
            self.retrPsid(forceUpdate = requireUpdate)
            psidPin = self.prependAtom(preString = unlockVar.global_fisPSID, cont = 1)
        packet = self.createPacket(type='psnlzeSIDS_Bands_SymK2',UID=self.UID_prsnlzePSID,credential=psidPin,mthdUID=self.UIDmethod_setTable, dataType = self.TYPE_pin)
        sessionType = 'Personalize PSID'
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)


################################################################
##########   Enables/Disables Firmware Lock on Reset  ##########
################################################################
    def enableDisableFwLOR(self,lockPort = 1):   #Similar to Test 575, Mode:0x15,0x2C
        if lockPort == 1:
            sessionType = 'Enable Lock FW Port on Reset'
            packet = self.createPacket(type = 'portLORLockingFW_Bnd', UID = self.UID_fwLockingPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state=0 means Set LOR
        else:
            sessionType = 'Disable Lock FW Port on Reset'
            packet = self.createPacket(type = 'portLORLockingFW_Bnd', UID = self.UID_fwLockingPort, mthdUID = self.UIDmethod_setTable) #state = null means Not Set LOR
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)


################################################################
##########   Enables/Disables Firmware Port Locking   ##########
################################################################
    def lockUnlockFwPort(self,lockPort = 1):     #Similar to Test 575, Mode:0x13,0x19
        if lockPort == 1:
            sessionType = 'Enable Lock FW Port'
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_fwLockingPort, state = '\x01', mthdUID = self.UIDmethod_setTable) #state=1  means lock
        else:
            sessionType = 'Disable Lock FW Port '
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_fwLockingPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state = 0 means unlock
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)

################################################################
##########   Enables/Disables DITS Lock on Reset  ##############
################################################################
    def enableDisableDiagLOR(self,lockPort = 1):   #Similar to Test 575, Mode:0x15,0x2C
        if lockPort == 1:
            sessionType = 'Enable Lock Diag Port on Reset'
            packet = self.createPacket(type = 'portLORLockingFW_Bnd', UID = self.UID_diagLockingPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state=0 means Set LOR
        else:
            sessionType = 'Disable Lock Diag Port on Reset'
            packet = self.createPacket(type = 'portLORLockingFW_Bnd', UID = self.UID_diagLockingPort, mthdUID = self.UIDmethod_setTable) #state = null means Not Set LOR
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)


################################################################
##########   Enables/Disables DITS Port Locking   ##############
################################################################
    def lockUnlockDiagPort(self,lockPort = 1):
        if lockPort == 1:
            sessionType = 'Enable Lock Diag Port'
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_diagLockingPort, state = '\x01', mthdUID = self.UIDmethod_setTable) #state=1  means lock
        else:
            sessionType = 'Disable Lock Diag Port '
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_diagLockingPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state = 0 means unlock
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)

################################################################
##########   Enables/Disables UDS Port Locking   ###############
################################################################
    def lockUnlockUDSPort(self,lockPort = 1):
        if lockPort == 1:
            sessionType = 'Enable Lock UDS Port'
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_udsLockingPort, state = '\x01', mthdUID = self.UIDmethod_setTable) #state=1  means lock
        else:
            sessionType = 'Disable Lock UDS Port '
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_udsLockingPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state = 0 means unlock
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType,checkRcvStat = 1)

########################################################################
##########   Enables/Disables Cross Seament FW Lock on Reset  ##########
########################################################################
    def enableDisableCSFWLOR(self,lockPort = 1):   #Similar to Test 575, Mode:0x15,0x2C
        if lockPort == 1:
            sessionType = 'Enable Lock CSFW Port on Reset'
            packet = self.createPacket(type = 'portLORLockingFW_Bnd', UID = self.UID_crossSegFwDnldPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state=0 means Set LOR
        else:
            sessionType = 'Disable Lock CSFW Port on Reset'
            packet = self.createPacket(type = 'portLORLockingFW_Bnd', UID = self.UID_crossSegFwDnldPort, mthdUID = self.UIDmethod_setTable) #state = null means Not Set LOR
        self.sendPacket(frame = packet, m_type = sessionType)
        try:
            self.getPacket(m_type = sessionType,checkRcvStat = 1)
        except:
            spCommandSet.statMsg("%s doesn't exist" %sessionType)

########################################################################
##########   Enables/Disables Cross Seament FW Port Locking   ##########
########################################################################
    def lockUnlockCrossSegFWDnldPort(self,lockPort = 1):
        if lockPort == 1:
            sessionType = 'Enable Lock CSFW RW Port'
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_crossSegFwDnldPort, state = '\x01', mthdUID = self.UIDmethod_setTable) #state=1  means lock
        else:
            sessionType = 'Disable Lock CSFW RW Port '
            packet = self.createPacket(type = 'fwPortLocking', UID = self.UID_crossSegFwDnldPort, state = '\x00', mthdUID = self.UIDmethod_setTable) #state = 0 means unlock
        self.sendPacket(frame = packet, m_type = sessionType)
        try:
            self.getPacket(m_type = sessionType,checkRcvStat = 1)
        except:
            spCommandSet.statMsg("%s doesn't exist" %sessionType)

###########################################################################
##########   Set to SOM 0 State    ########################################
###########################################################################
    def setSOM0(self):  #Similar to Test 575, Mode:0x1A
        sessionType = 'Set SOM State to SOM 0'
        packet = self.createPacket(type = 'setStateTbl_SOM0', UID = self.UID_SetSOM0, mthdUID = self.UIDmethod_setTable, state = '\x00')
        self.sendPacket(frame = packet, m_type = sessionType)
        self.getPacket(m_type = sessionType, checkRcvStat = 0)


###########################################################################
##########   Revert Drive/Set Opal ATA Master Password    #################
###########################################################################
    def revertAdminSP(self):      #Note: After performing revertAdminSP() session is automatically closed.
        sessionType = 'Revert Admin SP'
        packet = self.createPacket(type = 'capturePersistData_revert', UID =self.UID_spUID, mthdUID = self.UID_revertAdminSP)
        self.sendPacket(frame = packet, m_type = sessionType)
        time.sleep(12)  #Required so drive won't fail
        self.getPacket(m_type = sessionType, checkRcvStat = 0)


######################################################################
##########  Defined Functions to be used for  F3 Diag Cmds  ##########
######################################################################
    def get(self,size=0):
        data = GChar(readSize = size)
        return data

    def put(self,data, timeout=3):
        PBlock(data)
        size = len(data)
        return size


    def asciiToEslipMode(self):
        CTRL_T = '\x14'
        PChar(CTRL_T);
        ScriptPause(1);
        self.readme();   # to get command prompt


    def GetSN(self):
       CTRL_Z  = '\x1A'
       PChar(CTRL_Z);             # spin up drive
       ScriptPause(10);           # allow drive to spin up
       PChar(CTRL_Z); self.readme();   # to get command prompt
       PBlock('C34F329A\r');      # unlock

       PBlock('J,1\r'); self.readme(); # read HDA SN

    def abort(self,IVFileXfr=0,failVal=11044,failStr=''):
        CAN = chr(0x18) #Used to send 'cancel' to drive for YMODEM protocol on abort
        if IVFileXfr == 1:
            for counter in range(0, 2):
                put(CAN)

        failString = 'Fail Code:' + str(failVal)+ '-' + failStr
        raise Exception(failString)

    def readme(self):
       data=''
       loopStartTime = time.time()
       while True:
          charIn=GChar(readSize=1)
          data+= charIn
          loopTime = time.time() - loopStartTime
          if loopTime > 2: break
          #if loopTime > 5: break
       self.statMsg(data) #.replace("\r", "")

####################################################################################
##########   Used to create all of the packets being send to the drive.   ##########
####################################################################################
    def createPacket(self,type, credential = '', UID = '', mthdUID = '',  rsaType = '',state = '', band = '', srtSessType = '', location = '', dataType = ''):
        #displayFrame(credential)
        packet = ''
        padding = '\x00\x00\x00'
        dictLen = {}
        comPacketLength = '\x00\x00\x00\x00'
        packetLength = '\x00\x00\x00\x00'
        subPacketLength = '\x00\x00\x00\x00'
        sessionPacket = '\xFF\xFF\xFC' + unlockVar.sessionNumber + '\x31\x32\x33\x34' + self.sess_sqNumber + self.sess_ack  # Size 20
        if unlockVar.coreSpec == 1:
            if type == 'closeSession':
                packet = '\xFA'
            if type == 'authSymK2_Ers_Bnd_SIDS':
                packet = '\xF8\xA8' + self.UID_spUID + '\xA8' + mthdUID + '\xF0\xA8' + UID + '\xF2\xA9\x43\x68\x61\x6C\x6C\x65\x6E\x67\x65' + credential + '\xF3' + self.endPacket
            if type == 'psnlzeSIDS_Bands_SymK2':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF0\xF2\xAB\x73\x74\x61\x72\x74\x43\x6F\x6C\x75\x6D\x6E\xA3' + dataType + '\xF3\xF2\xA9\x65\x6E\x64\x43\x6F\x6C\x75\x6D\x6E\xA3' + dataType + '\xF3\xF1\xF0\xF0\xF2\xA3' + dataType + credential + '\xF3\xF1\xF1' + self.endPacket
            if type == 'authSymKAmp1':
                packet = '\xF8\xA8' + self.UID_spUID + '\xA8' + mthdUID + '\xF0\xA8' + UID + self.endPacket
            if type == 'getStateTbl':
                packet = '\xF8\xA8' + self.UID_securityStateCtrl + '\xA8' + mthdUID + '\xF0\xF0\xF1' + self.endPacket
            if type == 'setStateTbl_SOM0':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF0\xF1\xA1' + state + self.endPacket
            if type == 'authSess':
                sessionPacket = self.filler_8bytesZero + srtSessType + self.filler_8bytesZero  # Size 20
                packet = '\xF8\xA8' + self.UIDmethod_smUID + '\xA8' + self.UID_startSession + '\xF0\x84\x31\x32\x33\x34\xA8' + UID + '\x01' + self.endPacket
            if type == 'getDrvMsid':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF0\xF2\xAB\x73\x74\x61\x72\x74\x43\x6F\x6C\x75\x6D\x6E\xA3\x50\x49\x4E\xF3\xF2\xA9\x65\x6E\x64\x43\x6F\x6C\x75\x6D\x6E\xA3\x50\x49\x4E\xF3\xF1' + self.endPacket
            if type == 'portLORLockingFW_Bnd':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF0\xF1\xF0\xF0\xF2\xAB\x4C\x6F\x63\x6B\x4F\x6E\x52\x65\x73\x65\x74\xF0' + state + '\xF1\xF3\xF1\xF1' + self.endPacket
            if type == 'fwPortLocking':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF0\xF2\xAB\x73\x74\x61\x72\x74\x43\x6F\x6C\x75\x6D\x6E\xAA\x50\x6F\x72\x74\x4C\x6F\x63\x6B\x65\x64\xF3\xF2\xA9\x65\x6E\x64\x43\x6F\x6C\x75\x6D\x6E\xAA\x50\x6F\x72\x74\x4C\x6F\x63\x6B\x65\x64\xF3\xF1\xF0\xF0\xF2\xAA\x50\x6F\x72\x74\x4C\x6F\x63\x6B\x65\x64' + state + '\xF3\xF1\xF1' + self.endPacket
            if type == 'capturePersistData_revert':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0' + self.endPacket
            if packet == '':
                raise Exception('Inital Send Packet was unable to be created.  Double check the session type is specified in the function, createPacket(). ')
        elif unlockVar.coreSpec == 2:
            if type == 'closeSession':
                packet = '\xFA'
            if type == 'authSymK2_Ers_Bnd_SIDS':
                packet = '\xF8\xA8' + self.UID_spUID + '\xA8' + mthdUID + '\xF0\xA8' + UID + '\xF2\x00' + credential + '\xF3' + self.endPacket
            if type == 'psnlzeSIDS_Bands_SymK2':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF2\x01\xF0\xF2\x03' + credential + '\xF3\xF1\xF3' + self.endPacket
            if type == 'authSymKAmp1':
                packet = '\xF8\xA8' + self.UID_spUID + '\xA8' + mthdUID + '\xF0\xA8' + UID + self.endPacket
            if type == 'getStateTbl':
                packet = '\xF8\xA8' + self.UID_securityStateCtrl + '\xA8' + mthdUID + '\xF0\xF0\xF1' + self.endPacket
            if type == 'setStateTbl_SOM0':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF2\x01\xA1' + state + '\xF3' +self.endPacket
            if type == 'authSess':
                sessionPacket = self.filler_8bytesZero + srtSessType + self.filler_8bytesZero  # Size 20
                packet = '\xF8\xA8' + self.UIDmethod_smUID + '\xA8' + self.UID_startSession + '\xF0\x01\xA8' + UID + '\x01' + self.endPacket
            if type == 'getDrvMsid':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF0\xF2\x03\x03\xF3\xF2\x04\x03\xF3\xF1' + self.endPacket
            if type == 'portLORLockingFW_Bnd':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF2\x01\xF0\xF2\x02\xF0' + state + '\xF1\xF3\xF1\xF3' + self.endPacket
            if type == 'fwPortLocking':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0\xF2\x01\xF0\xF2\x03' + state + '\xF3\xF1\xF3' + self.endPacket
            if type == 'capturePersistData_revert':
                packet = '\xF8\xA8' + UID + '\xA8' + mthdUID + '\xF0' + self.endPacket
            if packet == '':
                raise Exception('Inital Send Packet was unable to be created.  Double check the session type is specified in the function, createPacket(). ')

        dictLen, calcPadding = self.getFrameLengths(frame = packet)
        packetFinal = self.PacketHeader + dictLen['comPacketLength'] + sessionPacket + dictLen['packetLength'] + self.filler_8bytesZero + dictLen['subPacketLength'] + packet + calcPadding
        return packetFinal


class SpIOCommon:
    tcgTypes = {0x0100:'tcgEnterprise',  #'Enterprise'
            0x0200:'tcgOpal',  #'Opal SCC',
            0x0201:'tcgOpal',  #'Opal SU',
            0x0202:'tcgOpal',  #'Opal 202',
            0x0203:'tcgOpal',  #:'Opal 203'
            0xc002: 'tcgEnterprise', #ISE Enterprise
            0xc003: 'tcgEnterprise' # SDD Enterprise
            }

    #Search through discovery packet to find Opal/Enterprise Type and CoreSpec
    def findDiscovInfo(self,dataPacket):
        spCommandSet.displayFrame(dataPacket)
        discovPacketLen = int(binascii.b2a_hex(dataPacket[3:4]),16)
        unlockVar.currentSEDState = int(binascii.b2a_hex(dataPacket[17:18]),16)

     #   if unlockVar.currentSEDState != 0x80:
     #       raise Exception('DRIVE IS NOT IN USE STATE, PORT LOCKING IS NOT ENFORCED')

        indexLocation = 0
        while indexLocation in range(0,discovPacketLen):
            if indexLocation == 0:
                indexLocation = 0x30
               # subPackLen = int(binascii.b2a_hex(dataPacket[indexLocation:indexLocation+1]),16)
               # indexLocation = indexLocation + subPackLen + 2

            featureDesc = int(binascii.b2a_hex(dataPacket[indexLocation:indexLocation+2]),16)


            if featureDesc in self.tcgTypes:
                unlockVar.driveTcgType = self.tcgTypes[featureDesc]
                indexLocation = discovPacketLen
                break
            else:
                subPackLen = int(binascii.b2a_hex(dataPacket[indexLocation+3:indexLocation+4]),16)
                indexLocation = indexLocation + subPackLen + 4

        if unlockVar.driveTcgType == '':
            raise Exception('NOT ABLE TO DETERMINE DRIVES SECURITY SUBSYSTEM')
        if unlockVar.driveTcgType == 'tcgEnterprise':
            unlockVar.coreSpec = 1
            unlockVar.opalSupport = 0
            unlockVar.masterSymKType = 2
        else:
            unlockVar.coreSpec = 2
            unlockVar.opalSupport = 1
            unlockVar.masterSymKType = 2

        spCommandSet.updateVars()
        unlockVar.initVars()

transferTypes = TransferTypes()
ioCommandSet = IOcommands()
spCommandSet = SPcommands()
commonUnlockFuncs = SpIOCommon()
dblData={}
# ############################################################### #
# ############################################################### #
# ###############  START OF MAIN FUNCTIONALITY   ################ #
# ############################################################### #
# ############################################################### #
def lockUnlockDrive(comType = 'IO', lockDrive = 'LOCK'):  #comType = IO or SP

    if lockDrive == 'LOCK': lockDrive = 1
    else: lockDrive = 0

    unlockVar.driveSN = HDASerialNumber

    if lockDrive == 1:
        TraceMessage("BEGIN DRIVE LOCKING")
    else:
        TraceMessage("BEGIN DRIVE UNLOCKING")

    global dblData
    dblData={}
    if comType == 'IO':
        commonUnlockFuncs.findDiscovInfo(dataPacket=ioCommandSet.IODiscovery())
        ioCommandSet.IODriveLockUnlock(activateLocking = lockDrive)

    else:
        spCommandSet.SEDDriveVerify()
        commonUnlockFuncs.findDiscovInfo(dataPacket=spCommandSet.SerialSEDDiscovery())
        spCommandSet.serialDriveLockUnlock(activateLocking = lockDrive)

    if lockDrive == 1:
        TraceMessage("DRIVE LOCKED SUCESSFUL")
    else:
        TraceMessage("DRIVE UNLOCKED SUCESSFUL")

lockUnlockDrive(comType = 'SP', lockDrive = 'LOCK')


