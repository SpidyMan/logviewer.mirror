def Test514_Cw2_IdentifyRange( starting_word, ending_word ):
  starting_word = starting_word & 0xff
  ending_word = (ending_word & 0xff) << 8
  return ( ending_word | starting_word )


prm_575_FDE_GetFeatures = {
  "TEST_MODE"  : (0x07,),
  "REPORTING_MODE"  : (0x0001,),       #sets local display mode
}

prm_517_ReqSense0 = {
  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x001A,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0001,),     # was 0001
  "SENSE_DATA_1" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_2" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_3" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_4" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}

prm_517_RequestSense5 = {
  "ACCEPTABLE_IF_MATCH" : (0x0000,),
  "ACCEPTABLE_SNS_DATA" : (0x0000,),
  "CHK_FRU_CODE" : (0x0000,),
  "CHK_SRVO_LOOP_CODE" : (0x0000,),
  "MAX_REQS_CMD_CNT" : (0x0005,),
  "OMIT_DUP_ENTRY" : (0x0000,),
  "RPT_REQS_CMD_CNT" : (0x0000,),
  "RPT_SEL_SNS_DATA" : (0x0000,),
  "SEND_TUR_CMDS_ONLY" : (0x0000,),
  "SENSE_DATA_1" : (0x0002,0x0000,0x00FF,0x0004,),
  "SENSE_DATA_2" : (0x0004,0x0000,0x00FF,0x001C,),
  "SENSE_DATA_3" : (0x0004,0x0000,0x00FF,0x0042,),
  "SENSE_DATA_4" : (0x0001,0x0000,0x00FF,0x005D,),
  "SENSE_DATA_5" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_6" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_7" : (0x0000,0x0000,0x0000,0x0000,),
  "SENSE_DATA_8" : (0x0000,0x0000,0x0000,0x0000,),
  "SRVO_LOOP_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x0000,),
}

prm_514_Firmware = {
  "CHECK_MODE_NUMBER" : (0x0000,),
  "ENABLE_VPD" : (0x0001,),
  "EXPECTED_FW_REV_1" : (0x0000,),
  "EXPECTED_FW_REV_2" : (0x0000,),
  "EXPECTED_FW_REV_3" : (0x0000,),
  "EXPECTED_FW_REV_4" : (0x0000,),
  "GET_FW_REV_FROM_NETWORK" : (0x0000,),
  "PAGE_CODE" : (0x00C0,),
  "TEST_FUNCTION" : (0x0000,),
}

prm_514_StdData = {
  "PAGE_CODE" : (0x0000,),
  "TEST_FUNCTION" : (0x8000,),
}

prm_514_REPORT_MAX_USER_48BIT_LBAS = {
   "CTRL_WORD1"           : (0x2),
   "CTRL_WORD2"           : ( Test514_Cw2_IdentifyRange( 100, 103 )),
}

prm_535_InitiatorRevSATA = {
    "BAUD_RATE" : (0x0000,),
    "DRIVE_TYPE" : (0x0000,),
    "EXPECTED_FW_REV_1" : (0x0000,),
    "FC_SAS_TRANSFER_RATE" : (0x0000,),
    "REG_ADDR" : (0x0000,),
    "REG_VALUE" : (0x0000,),
    "TEST_FUNCTION" : (0x0800,),
    "TEST_OPERATING_MODE" : (0x0002,),
}

try:
  del dblData['P535_INITIATOR_RELEASE']
except: pass

try:
  st([535], [], {'TEST_OPERATING_MODE': 2, 'TEST_FUNCTION': 32768, 'timeout': 10})
except:
  TraceMessage("Couldn't contact initiator!")
  raise
if "SAS" in dblData['P535_INITIATOR_RELEASE']['DOWNLOAD_FILE_NAME'][0]:
  st(517,prm_517_ReqSense0,timeout=300)
  st(517,prm_517_RequestSense5,timeout=300)
  st(514,prm_514_Firmware,timeout=60)
  st(514,prm_514_StdData,timeout=60)
else: #SATA
  st(535,prm_535_InitiatorRevSATA,timeout=60)

  st(514,prm_514_REPORT_MAX_USER_48BIT_LBAS,timeout=30)

  # Get features and populate the dblData dictionary
  st(575,prm_575_FDE_GetFeatures)