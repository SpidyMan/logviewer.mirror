

if RestrictedMode:
   print("""
ERROR: UserGUI cannot run under restricted mode.
Go to the 'Configure' tab, select 'Yes' for 'Disable Restricted Mode' and click on the 'Update' button.
You'll have to restart WinFOF for this change to take affect.
""")

else:
 from tkinter import *
 import Pmw
 import tkinter.filedialog, string
 from tkinter.messagebox  import  showerror, showinfo, askokcancel

 class UserGUIs:
   def __init__(self):
     self.root = ""
     self.newPageFrame = ""

   def __centerWindow(self, winName):
     #winName.update_idletasks() # Make sure window is mapped
     winName.update()
     w = winName.winfo_width()
     h = winName.winfo_height()
     extraW = winName.winfo_screenwidth() - w
     extraH = winName.winfo_screenheight() - h
     winName.geometry("%dx%d%+d%+d" % (w, h, extraW / 2, extraH / 2))

   def destroyNewPageFrame(self, event = 0):
     self.newPageFrame.destroy()
     self.newPageFrame = ""
     self.root.destroy()

   def comboValidate(self, text, varName = None, optionList = []):
       if text.upper() not in optionList:
          return -1
       else:
         #varName.component("entryfield").setvalue(text.upper())
         return 1

   def validateHexInt(self, text):
      text = text.upper()
      if text.startswith("0X"):
        if text == '0X' : return 1
        try:
            string.atol(text, 16)
            return 1
        except: return 0
      else:
        try:
            int(text)
            return 1
        except:
            if len(text) == 0: return -1
            else: return 0

   def getHexIntValue(self, widget):
     try:
        value = widget.get()
        value = value.upper()
        if value.startswith("0X"): value = string.atol(value, 16)
        else:                      value = int(value)
        return 0, value
     except: return -1, 0

   def quickBER(self):
     if self.newPageFrame == "":
        self.root = Tk()
        self.root.withdraw()

        self.newPageFrame = Toplevel(height = 600)
        self.newPageFrame.title("Quick BER")
        self.newPageFrame.protocol('WM_DELETE_WINDOW', self.destroyNewPageFrame)
        self.newPageFrame.bind("<Escape>", self.destroyNewPageFrame)

        cFrame = Frame(self.newPageFrame, relief = RIDGE, bd = 2)
        cFrame.grid(row = 0, column = 0, sticky = W)

        row = 1
        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        Label(cFrame, text = "Target Track (dec): ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        self.tgtTrack = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '1000',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                validate = {'validator' : 'integer'}
                                )
        self.tgtTrack.grid(row = row, column = 1, pady = 5, sticky = E)

        bt = Button(cFrame, text = "OK", font = "arial 10 bold", width = 10, command = self.onOKQuickBER)
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 2); row += 1

        self.label1 = Label(cFrame, text = "Target Head (dec): ", font = "arial 10")
        self.label1.grid(row = row, column = 0, sticky = W)
        self.tgtHead = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '0',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                validate = {'validator' : 'integer'}
                                )
        self.tgtHead.grid(row = row, column = 1, pady = 5, sticky = E)

        bt = Button(cFrame, text = "Cancel", font = "arial 10 bold", width = 10, command = self.destroyNewPageFrame)
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 2); row += 1

        #self.label2 = Label(cFrame, text="Max Head (dec): ",font = "arial 10")
        #self.label2.grid(row=row,column=0,sticky=W)
        #self.maxHead=Pmw.EntryField(cFrame,
        #                        labelpos = 'w',
        #                        value = '8',
        #                        label_text = "",
        #                        entry_font = "arial 10",
        #                        entry_fg = "MediumBlue",
        #                        validate = {'validator' : 'integer'}
        #                        )
        #self.maxHead.grid(row=row,column=1,padx=5,pady=5, sticky=E)


        self.allHeads = IntVar()
        self.allHeads.set(1)
        chkButton = Checkbutton(cFrame, text = " All Heads", font = "arial 10", variable = self.allHeads, command = self.updateTrackEntry)
        chkButton.grid(row = row, column = 0, sticky = W)

        #self.label3 = Label(cFrame, text="Iterations (dec): ",font = "arial 10")
        #self.label3.grid(row=row,column=0,sticky=W)
        #self.iterations=Pmw.EntryField(cFrame,
        #                        labelpos = 'w',
        #                        value = '0',
        #                        label_text = "",
        #                        entry_font = "arial 10",
        #                        entry_fg = "MediumBlue",
        #                        validate = {'validator' : 'integer'}
        #                        )
        #self.iterations.grid(row=row,column=1,padx=5,pady=5, sticky=E)

        self.iterChanel = IntVar()
        self.iterChanel.set(1)
        chkButton = Checkbutton(cFrame, text = " Iterative Channel", font = "arial 10", variable = self.iterChanel, command = self.updateIterChannel)
        chkButton.grid(row = row, column = 1, sticky = W)

        self.writeTrack = IntVar()
        chkButton = Checkbutton(cFrame, text = " Write Target Track First", font = "arial 10", variable = self.writeTrack)
        chkButton.grid(row = row, column = 2, sticky = W); row += 1

        Label(cFrame, text = "").grid(row = row, column = 0)

        self.tgtHead.configure(entry_state = DISABLED)
        self.label1.config(state = DISABLED)
        #self.maxHead.configure(entry_state=DISABLED)
        #self.label2.config(state=DISABLED)

        self.__centerWindow(self.newPageFrame)
        self.newPageFrame.withdraw()
        self.newPageFrame.deiconify()
        self.tgtTrack.focus_set()
        self.newPageFrame.grab_set()

        #root.destroy()
        self.root.mainloop()

   def updateTrackEntry(self):
       if self.allHeads.get():
          self.tgtHead.configure(entry_state = DISABLED)
          self.label1.config(state = DISABLED)
          #self.maxHead.configure(entry_state=DISABLED)
          #self.label2.config(state=DISABLED)
       else:
          self.tgtHead.configure(entry_state = NORMAL)
          self.label1.config(state = NORMAL)
          #self.maxHead.configure(entry_state=NORMAL)
          #self.label2.config(state=NORMAL)

   def updateIterChannel(self):
       pass
       #if self.iterChanel.get():
       #   self.iterations.configure(entry_state=NORMAL)
       #   self.label3.config(state=NORMAL)
       #else:
       #   self.iterations.configure(entry_state=DISABLED)
       #   self.label3.config(state=DISABLED)

   def onOKQuickBER(self):
      ldpc = 0
      tgtHead = 0
      try: tgtTrack = int(self.tgtTrack.get())
      except:
          showerror("QuickBER", "Invalid value for Target Track. Must be an integer.")
          return
      if not self.allHeads.get():
        try: tgtHead = int(self.tgtHead.get())
        except:
          showerror("QuickBER", "Invalid value for Target Head. Must be an integer.")
          return
      if self.iterChanel.get():
        ldpc = 1

      if ldpc:  # Iterative Channel
          listRange = (0, 1, 2, 3, 4)  # Iterations
      else:
          listRange = (0, 4, 8, 12, 16)  # TLevels

      self.destroyNewPageFrame()

      #RegisterOvCall('')
      # SpinUp and Load OverLay
      print("="*80, '\nRun dummy test to spinup the drive and download overlay\n', "="*80)
      try: st(301, timeout = 300)
      except: pass

      if self.allHeads.get():
        print('\n', "="*80, '\nRun test 172 to find Number of Heads\n', "="*80)
        ShowResponse(None, [2, 3])
        if not UPSEnabled: st(172, CWORD1 = 2)
        else:              st(172, Cwrd1 = 2)
        try: numHeads = DriveVars.get('Num_Heads', 4)
        except: numHeads = 4
        dexParserOn()
        headList = list(range(numHeads))
        print('Number of Heads = %d\n' % (numHeads,), "="*80)
      else: headList = [tgtHead]

      berInfo = {}
      for head in headList:
        for val in listRange:
          mCylinder, lCylinder = lwords(tgtTrack)
          buf, errorCode = fn(1243, lCylinder, mCylinder, head, 0x25)  #wsk

          if self.writeTrack.get(): twrite(echo = 0)

          if ldpc: ecc, iter = 0, val
          else:    ecc, iter = val, 0
          #print head,ecc,iter

          buf, errorCode = fn(1342, 0, 10, ecc, 0, iter, 0)  #ber
          if ldpc != 0:   result = struct.unpack("fLLLLHHLL", buf)
          else:           result = struct.unpack("fLLLHHLLL", buf)
          berInfo.setdefault(head, []).append(result[0:1])

      print("="*48)
      if ldpc:   print("        ITR%d \t ITR%d \t ITR%d \t ITR%d \t ITR%d" % (listRange))
      else:      print("        ECC%d \t ECC%d \t ECC%d \t ECC%d \t ECC%d" % (listRange))
      print("="*48)
      for hds in berInfo:
         print("HD%d | " % hds, end=' ')
         for val in berInfo[hds]:  print("%.2f\t" % val, end=' ')
         print()
      print("="*48)
   ##########################################

   def ReadServoSymbol(self):
     if self.newPageFrame == "":
        self.root = Tk()
        self.root.withdraw()

        self.newPageFrame = Toplevel(height = 600)
        self.newPageFrame.title("Read Servo Symbol")
        self.newPageFrame.protocol('WM_DELETE_WINDOW', self.destroyNewPageFrame)
        self.newPageFrame.bind("<Escape>", self.destroyNewPageFrame)

        cFrame = Frame(self.newPageFrame, relief = RIDGE, bd = 2)
        cFrame.grid(row = 0, column = 0, sticky = W)

        row = 1
        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        Label(cFrame, text = "Symbol Offset: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        self.servoOffset = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '0',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                command = self.onOKReadServoSym,
                                #validate = {'validator' : 'hexadecimal'}
                                validate = self.validateHexInt,
                                )
        self.servoOffset.grid(row = row, column = 1, padx = 5, pady = 5, sticky = E)

        bt = Button(cFrame, text = "OK", font = "arial 10 bold", width = 10, command = self.onOKReadServoSym)
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 2, sticky = W); row += 1

        bt = Button(cFrame, text = "Cancel", font = "arial 10 bold", width = 10, command = self.destroyNewPageFrame)
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 2, sticky = W); row += 1

        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        self.__centerWindow(self.newPageFrame)
        self.newPageFrame.withdraw()
        self.newPageFrame.deiconify()
        self.servoOffset.focus_set()
        self.newPageFrame.grab_set()

        #root.destroy()
        self.root.mainloop()

   def onOKReadServoSym(self):
     stat, servoSym = self.getHexIntValue(self.servoOffset)
     if stat:
       showerror("Read Servo Symbol", "Invalid value for Target Track. Must be an integer or hexadecimal.")
       return

     self.destroyNewPageFrame()

     if not UPSEnabled: st(11, CWORD1 = 0x200, SYM_OFFSET = servoSym, timeout = 10)
     else:              st(11, Cwrd1 = 0x200, SymblOfst = servoSym, timeout = 10)

   def raise_above_all(self, window):
     window.attributes('-topmost', 1)
     window.attributes('-topmost', 0)

   def SaveRestoreFiles(self):
     if self.newPageFrame == "":
        self.root = Tk()
        self.root.withdraw()

        self.newPageFrame = Toplevel(height = 600)
        self.newPageFrame.title("Save & Restore")
        self.newPageFrame.protocol('WM_DELETE_WINDOW', self.destroyNewPageFrame)
        self.newPageFrame.bind("<Escape>", self.destroyNewPageFrame)

        cFrame = Frame(self.newPageFrame, relief = RIDGE, bd = 2)
        cFrame.grid(row = 0, column = 0, sticky = W)

        row = 1
        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        Label(cFrame, text = "Operation: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        self.operType = IntVar()
        rb = Radiobutton(cFrame, text = "Store to PC", font = "arial 10", variable = self.operType, value = 0)
        rb.grid(row = row, column = 1, sticky = W)
        rb = Radiobutton(cFrame, text = "Restore from PC", font = "arial 10", variable = self.operType, value = 1)
        rb.grid(row = row, column = 2, columnspan = 2, padx = 5, sticky = EW);row += 1

        Label(cFrame, text = "File Type: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        optionList = ["CAP", "RAP", "SAP", "BIN", "ALL"]
        self.fileType = Pmw.ComboBox(cFrame,
                                  label_text = "",
                                  labelpos = 'w',
                                  label_font = 'arial 10',
                                  entry_width = 8,
                                  scrolledlist_items = optionList,
                                  history = 0,
                                  listheight = 100,
                                  listbox_height = 50,
                                  listbox_width = 8,
                                  listbox_font = "arial 10",
                                  entry_font = "arial 10",
                                  entry_fg = "MediumBlue",
                                  entryfield_validate = lambda text, optionList = optionList : self.comboValidate(text, optionList = optionList),
                                  dropdown = 1)
        self.fileType.component("entryfield").setvalue(optionList[0])
        self.fileType.grid(row = row, column = 1, sticky = W, padx = 2, pady = 2,)

        bt = Button(cFrame, text = "OK", font = "arial 10 bold", width = 8, command = lambda optionList = optionList : self.onOKSaveRestoreFiles(optionList = optionList))
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 3, padx = 2, pady = 2, sticky = W); row += 1

        Label(cFrame, text = "Target File: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        self.tgtFile = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                entry_width = 16,
                                )
        self.tgtFile.grid(row = row, column = 1, columnspan = 2, padx = 2, pady = 2, sticky = W)

        bt = Button(cFrame, text = "Cancel", font = "arial 10 bold", width = 8, command = self.destroyNewPageFrame)
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 3, padx = 2, pady = 2, sticky = W); row += 1

        Label(cFrame, text = "").grid(row = row, column = 0);row += 1
        str = """
Saves to 'targetfile' under C:\\var\\merlin3\\results folder. 
Please enable the "Retain Generic files" option under 
"Command-Menu" to prevent WinFOF from deleting all the 
saved files at startup. 

Extension (.bin, .cap, .sap or .bin) is automatically attached
to the target file name.

C:\\var\\merlin3\\results folder is searched for the saved 
RAP,SAP,CAP files in order to restore the RAP,SAP,CAP 
tables on the drive."""

        for msg in str.split("\n"):
          Label(cFrame, text = msg).grid(row = row, column = 0, columnspan = 4, sticky = W);row += 1
        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        self.__centerWindow(self.newPageFrame)
        self.newPageFrame.withdraw()
        self.newPageFrame.deiconify()
        self.fileType.focus_set()
        self.raise_above_all(self.newPageFrame)
        self.newPageFrame.grab_set()

        #root.destroy()
        self.root.mainloop()

   def onOKSaveRestoreFiles(self, event = 0, optionList = []):
     operation = self.operType.get()
     tgtFile = self.tgtFile.get()
     if not tgtFile:
       showerror("Save & Restore", "Valid Name required for Target file.")
       return

     fileType = self.fileType.get()
     fileType = fileType.upper()
     if fileType not in optionList:
       showerror("Save & Restore", "Valid File Type required -- %s" % repr(optionList))
       return

     if fileType == 'ALL': fileList = ["CAP", "RAP", "SAP"]
     else:                 fileList = [fileType, ]
     for ext in fileList:
       fileName = r'C:\var\merlin3\results\%s-%s\%s\%s.%s' % (CellIndex, TrayIndex, str(PortIndex), tgtFile, ext,)
       if operation == 0 and os.path.exists(fileName):
          showerror("Save to File", "Target File already exists: '%s'" % fileName)
          return
       elif operation == 1 and not os.path.exists(fileName):
          showerror("Restore from File", "Target File does not exists: '%s'" % fileName)
          return
     self.destroyNewPageFrame()

     # Store Files:
     if operation == 0:
        if   fileType == 'CAP': saveCap(tgtFile)
        elif fileType == 'RAP': saveRap(tgtFile)
        elif fileType == 'SAP': saveSap(tgtFile)
        elif fileType == 'BIN': saveFlash(tgtFile)
        elif fileType == 'ALL':
          print('\n-------------- Save CAP, RAP and SAP  --------------')
          saveAll(tgtFile)

     else:
        if   fileType == 'CAP': restoreCap(tgtFile)
        elif fileType == 'RAP': restoreRap(tgtFile)
        elif fileType == 'SAP': restoreSap(tgtFile)
        elif fileType == 'BIN':
            showinfo("Restore BIN", " Please use Sea-Serial to restore the BIN file")
        elif fileType == 'ALL':
          print('\n-------------- Restore CAP, RAP and SAP  --------------')
          restoreAll(tgtFile)

#################################################

   def AccessSVRAM(self):
     if self.newPageFrame == "":
        self.root = Tk()
        self.root.withdraw()

        self.newPageFrame = Toplevel(height = 600)
        self.newPageFrame.title("Read / Write to Servo RAM")
        self.newPageFrame.protocol('WM_DELETE_WINDOW', self.destroyNewPageFrame)
        self.newPageFrame.bind("<Escape>", self.destroyNewPageFrame)

        cFrame = Frame(self.newPageFrame, relief = RIDGE, bd = 2)
        cFrame.grid(row = 0, column = 0, sticky = W)

        row = 1
        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        Label(cFrame, text = "Operation: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        optionList1 = ["READ", "WRITE"]
        self.operType = Pmw.ComboBox(cFrame,
                                  label_text = "",
                                  labelpos = 'w',
                                  label_font = 'arial 10',
                                  entry_width = 8,
                                  scrolledlist_items = optionList1,
                                  history = 0,
                                  listheight = 100,
                                  listbox_height = 50,
                                  listbox_width = 8,
                                  listbox_font = "arial 10",
                                  entry_font = "arial 10",
                                  entry_fg = "MediumBlue",
                                  entryfield_validate = lambda text, optionList = optionList1 : self.comboValidate(text, optionList = optionList),
                                  dropdown = 1)
        self.operType.component("entryfield").setvalue(optionList1[0])
        self.operType.grid(row = row, column = 1, sticky = W, pady = 2,)

        Label(cFrame, text = "").grid(row = row, column = 2, padx = 5)

        Label(cFrame, text = "Address Mode: ", font = "arial 10").grid(row = row, column = 3, sticky = W)
        optionList2 = ["DIRECT", "INDIRECT"]
        self.addrMode = Pmw.ComboBox(cFrame,
                                  label_text = "",
                                  labelpos = 'w',
                                  label_font = 'arial 10',
                                  entry_width = 8,
                                  scrolledlist_items = optionList2,
                                  history = 0,
                                  listheight = 100,
                                  listbox_height = 50,
                                  listbox_width = 8,
                                  listbox_font = "arial 10",
                                  entry_font = "arial 10",
                                  entry_fg = "MediumBlue",
                                  entryfield_validate = lambda text, optionList = optionList2 : self.comboValidate(text, optionList = optionList),
                                  dropdown = 1)
        self.addrMode.component("entryfield").setvalue(optionList2[0])
        self.addrMode.grid(row = row, column = 4, sticky = W, pady = 2,); row += 1


        Label(cFrame, text = "Servo Addr Index: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        self.svArrIndex = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '0',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                entry_width = 8,
                                #validate = {'validator' : 'integer'}
                                validate = self.validateHexInt
                                )
        self.svArrIndex.grid(row = row, column = 1, pady = 2, sticky = W)

        Label(cFrame, text = "Offset: ", font = "arial 10").grid(row = row, column = 3, sticky = W)
        self.svOffset = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '0',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                entry_width = 8,
                                #validate = {'validator' : 'integer'}
                                validate = self.validateHexInt,
                                )
        self.svOffset.grid(row = row, column = 4, pady = 2, sticky = W); row += 1


        Label(cFrame, text = "Data: ", font = "arial 10").grid(row = row, column = 0, sticky = W)
        self.svData = Pmw.EntryField(cFrame,
                                labelpos = 'w',
                                value = '0',
                                label_text = "",
                                entry_font = "arial 10",
                                entry_fg = "MediumBlue",
                                entry_width = 8,
                                #validate = {'validator' : 'integer'}
                                validate = self.validateHexInt,
                                )
        self.svData.grid(row = row, column = 1, pady = 2, sticky = W)

        Label(cFrame, text = "Data Size: ", font = "arial 10").grid(row = row, column = 3, sticky = W)
        optionList3 = ["8", "16", "32"]
        self.svDataSize = Pmw.ComboBox(cFrame,
                                  label_text = "",
                                  labelpos = 'w',
                                  label_font = 'arial 10',
                                  entry_width = 8,
                                  scrolledlist_items = optionList3,
                                  history = 0,
                                  listheight = 100,
                                  listbox_height = 50,
                                  listbox_width = 8,
                                  listbox_font = "arial 10",
                                  entry_font = "arial 10",
                                  entry_fg = "MediumBlue",
                                  entryfield_validate = lambda text, optionList = optionList3 : self.comboValidate(text, optionList = optionList),
                                  dropdown = 1)
        self.svDataSize.component("entryfield").setvalue(optionList3[0])
        self.svDataSize.grid(row = row, column = 4, sticky = W, pady = 2,); row += 1

        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        bt = Button(cFrame, text = "OK", font = "arial 10 bold", width = 8, command = lambda optionList1 = optionList1, optionList2 = optionList2, optionList3 = optionList3: \
                                                          self.onOKAccessSVRAM(optionList1 = optionList1, optionList2 = optionList2, optionList3 = optionList3))
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 0, columnspan = 2, padx = 2, pady = 7)

        bt = Button(cFrame, text = "Cancel", font = "arial 10 bold", width = 8, command = self.destroyNewPageFrame)
        bt.bind("<Return>", func = lambda event, bt = bt:bt.flash() or bt.invoke())
        bt.grid(row = row, column = 3, columnspan = 2, padx = 2, pady = 7); row += 1

        Label(cFrame, text = "").grid(row = row, column = 0);row += 1

        self.__centerWindow(self.newPageFrame)
        self.newPageFrame.withdraw()
        self.newPageFrame.deiconify()
        self.operType.focus_set()
        self.newPageFrame.grab_set()

        #root.destroy()
        self.root.mainloop()

   def onOKAccessSVRAM(self, optionList1 = [], optionList2 = [], optionList3 = []):
     operType = self.operType.get()
     operType = operType.upper()
     if operType not in optionList1:
       showerror("Access Servo RAM", "Valid Operation Type required -- %s" % repr(optionList1))
       return

     addrMode = self.addrMode.get()
     addrMode = addrMode.upper()
     if addrMode not in optionList2:
       showerror("Access Servo RAM", "Valid Address Mode required -- %s" % repr(optionList2))
       return

     svDataSize = self.svDataSize.get()
     svDataSize = svDataSize.upper()
     if svDataSize not in optionList3:
       showerror("Access Servo RAM", "Valid Data Size required -- %s" % repr(optionList3))
       return
     svDataSize = int(svDataSize)

     stat, svArrIndex = self.getHexIntValue(self.svArrIndex)
     if stat:
       showerror("Access Servo RAM", "Invalid value for Servo Addr Index. Must be an integer or hexadecimal.")
       return

     stat, svOffset = self.getHexIntValue(self.svOffset)
     if stat:
       showerror("Access Servo RAM", "Invalid value for Offset. Must be an integer or hexadecimal.")
       return

     if operType != 'READ':
       stat, svData = self.getHexIntValue(self.svData)
       if stat:
         showerror("Access Servo RAM", "Invalid value for Data. Must be an integer or hexadecimal.")
         return

     else: svData = 0

     if operType != 'READ' and addrMode != 'INDIRECT':
       showerror("Access Servo RAM", "Cannot use DIRECT mode with WRITE operation")
       return

     self.destroyNewPageFrame()

     print("=====  Servo Address Index: %d; Offset: %d; Size: %d; Address Mode: '%s';  Operation: '%s'; Data: %d  ======\n" % (svArrIndex, svOffset, svDataSize, addrMode, operType, svData,))
     svram(svArrIndex, svOffset, svDataSize, addrMode, operType, svData)
#################################################


 def quickBER():
   obj = UserGUIs()
   obj.quickBER()

 def readServoSymbol():
   obj = UserGUIs()
   obj.ReadServoSymbol()

 def saveRestoreFile():
   obj = UserGUIs()
   obj.SaveRestoreFiles()

 def accessSVRAM():
   obj = UserGUIs()
   obj.AccessSVRAM()

