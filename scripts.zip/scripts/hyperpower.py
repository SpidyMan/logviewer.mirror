 
if  RackType != "KODIAK4X":
  import time,types
  
  def HyperPowerDriveOn(levelFor5V=5000,levelFor12V=12000,pauseTime=30,levelFor3V=3000,controlSerialIO=0,**kwargs):  
    #  Look for the parameters that ask us to send '\x1b' escape characters before and after applying drive power.
    preEscapes  = kwargs.get("preEscapes")
    postEscapes = kwargs.get("postEscapes")  
      
    # Send a bunch of escapes just before we turn on drive power
    if isinstance(preEscapes,int) and preEscapes > 0:
       Send(preEscapes*'\x1b')
    
    if (SetDTRPin(1) == 0):  
       # Send a bunch of escapes just after we turn on drive power
       if isinstance(postEscapes,int) and postEscapes > 0:
          Send(postEscapes*'\x1b')
        
       print("%s: DriveOn: pause --> %s seconds"%(time.asctime(), pauseTime,))
       ScriptPause(pauseTime)
  
  
  def HyperPowerDriveOff(pauseTime=30,controlSerialIO=0):
    
    if (SetDTRPin(0) == 0):
      print("%s: DriveOff: pause --> %s seconds"%(time.asctime(), pauseTime,))
      ScriptPause(pauseTime)
  ####################################################################
  ####################################################################
  
  DriveOn  = HyperPowerDriveOn
  DriveOff = HyperPowerDriveOff
  #RimOn    = HyperPowerDriveOn
  #RimOff   = HyperPowerDriveOff
  ####################################################################
  #     Request Handler for Drive On and Drive Off request           #
  ####################################################################
  def processDriveOnOff(buf, *args, **kargs):
    requestKey = buf[0]
    # code 6 typically requests a block of data from the download file;  get_data_file()
    if requestKey == 13:
        DriveOff()
    elif requestKey == 14:
        DriveOn()
    elif requestKey == 85:    # Power off after a delay - used in data integrity tests T520
        delay = (int(buf[1])<<8) + int(buf[2])
        ScriptPause(delay/1000)
        DriveOff(pauseTime=0)
    else:
      str = "Unsupported requestKey in processDriveOnOff ==>",requestKey
      raise FOFParameterError(str)    
      
  RegisterResultsCallback(processDriveOnOff, [13,14,85], 0)


###############################################################
### Code to control Device power using DJTE1159, when using ###
### Mirkwood or any other USB-UART for communication        ###
###############################################################
BYTE = ctypes.c_ubyte
CHAR = ctypes.c_char
LPVOID = ctypes.c_void_p
LPCWSTR = ctypes.c_wchar_p
WORD = ctypes.c_ushort
DWORD = ctypes.c_uint
HANDLE = DWORD

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
OPEN_EXISTING = 3
SETDTR = 5
CLRDTR = 6
###############################################################
class DCB(ctypes.Structure):
   FLAG_BINARY = 0x1
   FLAG_PARITY = 0x2
   FLAG_OUTXCTSFLOW = 0x4
   FLAG_OUTXDSRFLOW = 0x8
   MASK_DTRCONTROL = 0x30
   DTR_CONTROL_ENABLE = 0x10
   FLAG_DSRSENSITIVITY = 0x40
   FLAG_TXCONTINUEONXOFF = 0x80
   FLAG_OUTX = 0x100
   FLAG_INX = 0x200
   FLAG_ERROR_CHAR = 0x400
   FLAG_NULL = 0x800
   MASK_RTS_CONTROL = 0x3000
   RTS_CONTROL_ENABLE = 0x1000 
   NOPARITY = 0
   ODDPARITY = 1
   EVENPARITY = 2
   MARKPARITY = 3
   SPACEPARITY = 4             
   ONESTOPBIT = 0
   ONE5STOPBITS = 1
   TWOSTOPBITS = 2

   _fields_ = [
       ('DCBlength', DWORD),
       ('BaudRate', DWORD),
       ('flags', DWORD),
       ('wReserved', WORD),
       ('XonLim', WORD),
       ('XoffLim', WORD),
       ('ByteSize', BYTE),
       ('Parity', BYTE),
       ('StopBits', BYTE), # 0=1, 1=1.5, 2=2
       ('XonChar', CHAR),
       ('XoffChar', CHAR),
       ('ErrorChar', CHAR),
       ('EofChar', CHAR),
       ('EvtChar', CHAR),
       ('wReserved1', WORD),
       ]

   def __init__(self):
       ctypes.Structure.__init__(self)
       self.DCBlength = ctypes.sizeof(self)
###############################################################


# Note: open and close calls, lowers the DTR line and thus turns off the drive
class Hnd1159:
    def __init__(self, port):
       self.usbPortHnd = 0
       self.port       = port
       # open the port
       self.open()
       # Redefine DriveOn and DriveOff
       global DriveOn,DriveOff
       DriveOn  = self.PwrOn
       DriveOff = self.PwrOff
    
    def open(self):
       self.usbPortHnd = ctypes.windll.kernel32.CreateFileW("\\\\.\\%s"%self.port,GENERIC_READ | GENERIC_WRITE, 0,None,OPEN_EXISTING,0,None)
       if self.usbPortHnd > 0:
          dcb = DCB()
          ctypes.windll.kernel32.GetCommState(self.usbPortHnd, ctypes.byref(dcb))
          #print "got flags: %s"%dcb.flags
          #dcb.flags &=  0xffaf         # Set DTR_CONTROL_DISABLE, which lowers the DTR Pin and turns the drive off.
          dcb.flags &=  0xffcf         # Set DTR_CONTROL_DISABLE, which lowers the DTR Pin and turns the drive off.
          #print "setting flags: %s"%dcb.flags
          ctypes.windll.kernel32.SetCommState(self.usbPortHnd, ctypes.byref(dcb)) 
       
       else:
           raise Exception("Open failed: Cannot open port '%s' (error code: %d)\n"%(self.port, ctypes.windll.kernel32.GetLastError(),))

    def setPwr(self,flag):
       if self.usbPortHnd > 0:           
          dcb = DCB()
          ctypes.windll.kernel32.GetCommState(self.usbPortHnd, ctypes.byref(dcb))
          #print "got flags: %s"%dcb.flags
          if flag == 0: 
            #ret = ctypes.windll.kernel32.EscapeCommFunction(self.usbPortHnd, CLRDTR)     # CLRDTR = 6
            dcb.flags &=  0xffcf
          else:
            #ret = ctypes.windll.kernel32.EscapeCommFunction(self.usbPortHnd, SETDTR)     # SETDTR = 5  
            dcb.flags |=  0x10
          #print "setting flags: %s"%dcb.flags  
          ctypes.windll.kernel32.SetCommState(self.usbPortHnd, ctypes.byref(dcb))  
            
          dcb = DCB()
          ctypes.windll.kernel32.GetCommState(self.usbPortHnd, ctypes.byref(dcb))
          #print "got flags: %s"%dcb.flags
       else:
           raise Exception("setPwr call can only be used after a successful open call")   

    def setBaud(self, baud):
        if self.usbPortHnd > 0:
           dcb = DCB()
           ctypes.windll.kernel32.GetCommState(self.usbPortHnd, ctypes.byref(dcb))
           #print "flags: %s"%dcb.flags
           dcb.BaudRate = baud
           ctypes.windll.kernel32.SetCommState(self.usbPortHnd, ctypes.byref(dcb))
        else:
           raise Exception("setBaud call can only be used after a successful open call") 
    
    def PwrOn(self,levelFor5V=5000,levelFor12V=12000,pauseTime=30,levelFor3V=3000,controlSerialIO=0,**kwargs):
      hnd.setPwr(1)
      print("%s: DriveOn: pause --> %s seconds"%(time.asctime(), pauseTime,))
      ScriptPause(pauseTime)

    def PwrOff(self,pauseTime=30,controlSerialIO=0):  
      hnd.setPwr(0)
      print("%s: DriveOff: pause --> %s seconds"%(time.asctime(), pauseTime,))
      ScriptPause(pauseTime)
      
    def close(self):
      if self.usbPortHnd > 0: ctypes.windll.kernel32.CloseHandle(self.usbPortHnd)
      self.usbPortHnd = 0
      # Redefine DriveOn and DriveOff
      global DriveOn,DriveOff
      DriveOn  = HyperPowerDriveOn
      DriveOff = HyperPowerDriveOff
###############################################################


  
#obj = Hnd1159("COm27")
#obj.open()
#obj.setPwr(1)
#obj.close()
