
#FOFexecfile(('', 'scriptfuncs.py'))
#FOFexecfile(('', 'hyperpower.py'))
#DriveOn(pauseTime=5)

RegisterBaudRate(1228000)
SetESlipBaud(1228000)


