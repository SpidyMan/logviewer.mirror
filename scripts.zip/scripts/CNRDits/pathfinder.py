import sys, os

class Error(Exception): pass

def _find(path, return_dir = False, matchFunc=os.path.isfile):
    for dirname in sys.path:
        candidate = os.path.join(dirname, path)
        if matchFunc(candidate):
			if return_dir == True:
				return dirname
			else:
				return candidate
    raise Error("Can't find file %s" % path)

def find(path, return_dir = False):
		return _find(path, return_dir, matchFunc=os.path.isfile)
		
def findDir(path):
    return _find(path, False, matchFunc=os.path.isdir)

