import array

def parseUDS( Packet ):
	#parse a uds packet into it's components
	return array.array('B', Packet )
	