# this module has routines to save and use types read from a given axf file.
# it will save the file to a pickle file that can be later read back to reconstitute
# the types ( i.e. don't require an axf file to use the type info )
import dwarfdll
#*** import gui
import os, glob
import pathfinder
#*** import pickle
import pickle
import struct

Version = 102
#*** LibFileName = "TypeLib\\typelib.pk1"
LibFileName = r"C:\var\merlin3\scripts\CNRDits\TypeLib\\typelib.pk1"
TypeLib  = {}

TypeListToGenerate =                                    \
[                                                        \
    'capture_header',                                    \
    'trace_content_header',                              \
    'diag_common_return_block',                          \
    'packet_footer',                                     \
    'diag_status_block',                                 \
    'sdbp_packet_header',                                \
    'control_sdbp_dfb',                                  \
    'control_sdbp_dsb',                                  \
    'diag_mode_sdbp_dfb',                                \
    'diag_mode_sdbp_dsb',                                \
    'lock_unlock_dfb',                                   \
    'sdbp_control_status_packet',                        \
    'online_sdbp_dfb',                                   \
    'online_sdbp_dsb',                                   \
    'packet_header_and_fw_info',                         \
    'backdoor_debug_request_packet',                     \
    'backdoor_debug_addr_range_request_packet',          \
    'rev1_set_rap_sdbp_dfb',                             \
    'read_wedge_dfb_data_rev1',                          \
    'read_system_files_dfb',                             \
    'rev1_rw_target_addr_sdbp_dfb',                       \
    'read_channel_write_ret',
    'get_temperature_dfb',
    'get_temperature_ret',
    'data_scrubbing_dfb',
    'get_drive_information_dfb',
    'read_lba_dfb',
    'read_lba_ret_value',
    'write_lba_dfb',
    'write_lba_ret_value',
    'report_track_attrib_dfb',
    'report_track_attrib_return',
    'dii_retry_dfb',
    'ecc_dfb',
    'error_recovery_step_dfb',
    'factory_process_dfb',
    'force_next_reset_cold_dfb',
    'free_retry_dfb',
    'hidden_retry_dfb',
    'inter_command_activity_dfb',
    'map_rd_offst_servo_flws_during_format_dfb',
    'map_wt_offst_servo_flws_during_format_dfb',
    'set_power_management_control_dfb',
    'set_power_on_self_test_dfb',
    'enable_spinup_dfb',
    'report_hidden_retry_dfb',
    'stir_dfb',
    'system_table_recovery_dfb',
    'tcc_dfb',
    'clear_format_corrupt_dfb',
    'voltage_margin_control_dfb',
    'write_current_offset_dfb',
    'zap_control_dfb',
    'continuous_heat_to_writer_dfb',
    'mr_bias_chop_dfb',
    'p_fast_dfb',
    'disable_cert_of_reserved_defect_table_dfb',
    'data_ecc_on_the_fly_dfb',
    'set_data_integrity_check_dfb',
    'set_write_protect_dfb',
    'set_uds_control_dfb',
    'fast_format_dfb',
#    'set_randomizer_seed_dfb', #unable to find in .axf file
    'set_servo_coast_dfb',
    'induce_self_test_error_dfb',
    'set_fde_dfb',
    'translate_pchs_to_lba_dfb',
    'translate_user_lba_to_pchs_dfb',
#    'translate_system_lba_to_pchs_dfb', #unable to find in .axf file
    'read_channel_write_dfb',
    'smart_command_dfb',
    'smart_command_ret_value',
    'force_memory_ecc_errors_dfb',
    'manufacturecontrol_dfb',
    'modify_active_servo_fault_mask_dfb',
    'physical_seek_dfb',
    'physical_seek_ret_value',
    'logical_seek_dfb',
    'logical_seek_ret_value',
    'read_physical_sector_dfb',
    'read_physical_sector_ret_value',
    'write_physical_sector_dfb',
    'write_physical_sector_ret_value',
    'read_long_lba_dfb',
    'read_long_lba_ret_value',
    'write_long_lba_dfb',
    'write_long_lba_ret_value',
    'read_track_dfb',
    'read_track_ret',
    'write_track_dfb',
    'write_track_ret',
    'erase_track_dfb',
    'erase_track_ret',
    'head_spike_screen_dfb',
    'coe_read_track_dfb',
    'coe_read_track_ret',
    'read_wedge_ret_value',
    'read_wedge_dfb',
    'write_wedge_dfb',
    'write_wedge_ret_value',
    'write_system_files_dfb',
#    'format_sector_good_bad_dfb',              #unable to find in .axf file
#    'format_sector_good_bad_ret_value',        #unable to find in .axf file
    'format_track_dfb',
    'process_plist_dfb',
    'read_drive_memory_dfb',
    'write_drive_memory_dfb',
    'write_drive_tables_dfb',
    'send_servo_cmd_dfb',
    'spin_up_or_down_dfb',
    'get_servo_error_fifo_dfb',
    'format_system_area_dfb',
    'write_congen_dfb',
    'raw_swd_features_dfb',
    'reload_rap_dfb',
    'reload_rap_ret',
    'full_retry_dfb',
#    'bips_control_dfb',            #unable to find in .axf file
#    'write_bips_lba_dfb',          #unable to find in .axf file
#    'write_bips_lba_ret_value',
#    'set_protection_information_type_dfb',         #unable to find in .axf file
    'get_skews_dfb',
    'get_skews_ret',
    'set_skews_dfb',
    'diag_function_block',
    'get_servo_config_ret',
    'enh_workload_mgmt_log_dfb',
    'enh_workload_mgmt_log_ret_value',
#    'backplane_bypass_dfb',        #unable to find in .axf file
    'read_channel_bci_logs_dfb',
    'read_channel_bci_logs_status_return',
    'read_channel_bci_logs_addr_return',
    'set_channel_bci_logging_offline_dfb',
    'set_channel_bci_logging_offline_return',
    'set_channel_bci_logging_dfb',
    'set_ldpc_iteration_dfb',
    'read_channel_read_dfb',
    'read_channel_read_ret',
    'read_drive_tables_dfb',
]

EnumsToSave =                                           \
[                                                       \
   'trace_content_index',                               \
   'diag_function_id',                                  \
   'diag_data_type_id',                                 \
   'diag_error_code',                                   \
   'diag_seek_type',                                    \
   'target_addr_mode',                                  \
   'update_target_addr_option',                         \
   'set_target_addr_option',                            \
]

def __saveEnum( CurrentType, Elf, MyLib ):
    TypeString = Elf.GetTypeString( CurrentType )

    MemberList = []
    index = 0
    while True:
        SubType = Elf.GetSubType ( CurrentType, index )
        index = index + 1
        if SubType != None:
            MemberList = MemberList + [(SubType.Name,SubType.Address)]
        else:
            break

    MyLib['Enums'][ CurrentType.Name ] = MemberList



def __saveType ( CurrentType, Elf, CurrentLib  ):
    TypeString = Elf.GetTypeString( CurrentType )
    TypeIndex = CurrentType.TypeLocation

    NewType = {}
    NewType['Type'] = TypeString
    NewType['TypeName'] = CurrentType.TypeName
    NewType['Size']     = CurrentType.Size
    NewType['NumElements'] = CurrentType.NumElements

    if TypeString in [ 'STRUCT', 'UNION' ]:
        MemberList = []
        index = 0
        while True:
            SubType = Elf.GetSubType ( CurrentType, index )
            index = index + 1
            if SubType != None:
                Member = {}
                Member['Name'] = SubType.Name
                Member['Offset'] = SubType.Address
                Member['Next' ] = __saveType( SubType, Elf, CurrentLib )
                MemberList = MemberList + [ Member ]
            else:
                break
        NewType['Members'] = MemberList;
    elif TypeString in ['ARRAY', 'TYPEDEF', 'CONSTANT', 'VOLATILE']:
        SubType = Elf.GetSubType ( CurrentType, 0 )
        NewType['Next'] = __saveType( SubType, Elf, CurrentLib )


    CurrentLib[ 'TypeTable'][ TypeIndex ] = NewType
    CurrentLib[ 'SymbolTable'][ CurrentType.TypeName ] = TypeIndex
    return TypeIndex

def getEnum ( EnumName ):
    if EnumName in list(TypeLib['Enums'].keys()):
        EnumList = TypeLib['Enums'][ EnumName ]
        ReturnType = dwarfdll.mycstruct( 0 )
        for i in EnumList:
            setattr( ReturnType, i[0], i[1] )
        ReturnType.structureFinalized()
        return ReturnType
    else:
        raise Exception('Enum Name not Found "%s"' % EnumName)
def __variablelize( TypeIndex, Content, MemberName = '', ParentStruct=None ):
    LastBitFieldOffset = -1
    Type = TypeLib['TypeTable'][TypeIndex]
    #print len(Content), Type
    if Type['Type'] in ['STRUCT', 'UNION']:
        ReturnType = dwarfdll.mycstruct( Type['Size'], MemberName, ParentStruct )
        for Member in Type['Members']:
            MemberType = TypeLib['TypeTable'][ Member['Next']]
            SubContent = Content[ Member['Offset']:Member['Offset']+MemberType['Size']*MemberType['NumElements']]
            #print Member
            NextElement = TypeLib['TypeTable'][Member['Next']]
            #print NextElement
            if NextElement['Type'] == 'BITFIELD' and LastBitFieldOffset != Member['Offset'] :
                LastBitFieldOffset = Member['Offset']
                setattr( ReturnType,  "_Internal_Offset_BitField" + Member['Name'], Member['Offset'] )
                setattr( ReturnType,  "_Internal_Size_BitField" + Member['Name'], MemberType['Size']*MemberType['NumElements']  )
                setattr( ReturnType,  "BitField"+Member['Name'], __variablelize( Member['Next'], SubContent,  Member['Name'], ReturnType ) )
            elif NextElement['Type'] == 'BITFIELD' and LastBitFieldOffset == Member['Offset'] :
                pass
            else:
                setattr( ReturnType,  "_Internal_Offset" + Member['Name'], Member['Offset'] )
                setattr( ReturnType,  "_Internal_Size" + Member['Name'], MemberType['Size']*MemberType['NumElements']  )
                setattr( ReturnType,  Member['Name'], __variablelize( Member['Next'], SubContent,  Member['Name'], ReturnType ) )

        ReturnType.structureFinalized()
        #print 'Reuturing ' 
        #print type( ReturnType )
        return ReturnType    

    if Type['Type'] in [ 'BASE', 'POINTER', 'ENUM', 'BITFIELD']:
        if Type['Size'] == 1:
            return struct.unpack( 'B', Content )[0]
        elif Type['Size'] == 2:
            return struct.unpack( 'H', Content )[0]
        elif Type['Size'] == 4:
            return struct.unpack( 'L', Content )[0]
        elif Type['Size'] == 8:
            return struct.unpack( 'Q', Content )[0]


    if Type['Type'] in [ 'TYPEDEF', 'VOLATILE', 'CONSTANT']:
        SubTypeIndex = Type['Next']
        return __variablelize( SubTypeIndex, Content, MemberName, ParentStruct )

    if Type['Type'] in [ 'ARRAY' ]:
        SubTypeIndex = Type['Next']
        SubType = TypeLib['TypeTable'][ SubTypeIndex ]
        SizeOfElement = Type['Size'] 
        ReturnList = dwarfdll.mycarray( Type['NumElements'], SizeOfElement, MemberName, ParentStruct  )
        CurrentPos = 0
        #print 'Size Of Element = %d, Num Elements = %d, len = %d' % ( SizeOfElement, Type['NumElements'], len( Content ) )
        for i in range( Type['NumElements'] ):
            #print '-'*50
            ReturnList[i] = __variablelize( SubTypeIndex, Content[ CurrentPos:CurrentPos+SizeOfElement], str(i), ReturnList)
            #print type( ReturnList[i] )
            #print ReturnList[i]
            #print '-'*50
            CurrentPos = CurrentPos + SizeOfElement
        ReturnList.structureFinalized()
        return ReturnList

    print("Error - unhandled type")
    print(Type)
    raise Exception('unhandled type')
    
def __mergeStruct( StructList ):
    ReturnStruct = StructList[0];
    for EachStruct in StructList[1:]:
        ReturnStruct.merge( EachStruct )

    return ReturnStruct

def printLib ( Libby ):
    MyLib = Libby['SymbolTable']
    for i in list(MyLib.keys()):
        print(i, MyLib[ i ])


    MyLib = Libby['TypeTable']
    for i in list(MyLib.keys()):
        print(i, MyLib[ i ])



# generate the library from an axf file that the user will be asked to select
def generateTypes ():
    '''FileName = gui.getAXFOpenFilename()
    if FileName == None:
        return
    print FileName'''
    
    cur_dir = pathfinder.find('pathfinder.py', True) #get the directory of pathfinder.py
    cur_dir = os.path.join(cur_dir, '../typelib')
    axf_list = []
    for file in glob.glob( os.path.join(cur_dir, '*axf') ):
         axf_list.append(file)
         
    MyLib = {}
    MyLib['SymbolTable'] = {}
    MyLib['TypeTable'] = {}
    MyLib['Enums'] = {}
    
    total_types_to_go = TypeListToGenerate
    total_enums_to_go = EnumsToSave
    
    for axf_file in axf_list:
        print('Building pickle file from %s' % axf_file)
        print('-' * 80)
        
        Elf = dwarfdll.dwarfdll()
        Elf.LoadDwarfFile( axf_file )
        
        types_yet_to_be_found = []
        enums_yet_to_be_found = []
        
        for TypeToSave in total_types_to_go:           
            try:
                CurrentType = Elf.GetType( TypeToSave )
                __saveType( CurrentType, Elf, MyLib )
                print('Saved type %s' % TypeToSave)
            except:
                types_yet_to_be_found .append(TypeToSave)
                print('    Failed to save type %s' % TypeToSave)

        for EnumToSave in total_enums_to_go:           
            try:
                CurrentType = Elf.GetType( EnumToSave )
                __saveEnum( CurrentType, Elf, MyLib )
                print('Saving Enum %s' % EnumToSave)
            except:
                enums_yet_to_be_found .append(EnumToSave)
                print('    Failed to save enum %s' % EnumToSave)
                
        if len(types_yet_to_be_found):
            total_types_to_go = types_yet_to_be_found 
        else:
            total_types_to_go = []
            
        if len(enums_yet_to_be_found):
            total_enums_to_go = enums_yet_to_be_found
        else:
            total_enums_to_go = []

    if len(total_types_to_go) or len(total_enums_to_go):
        print('-----------------WARNING!-----------------')
        print('There were left over types and/or enums that were not found in the .axf file set')
        print() 
        print('Types remaining: ')
        print(total_types_to_go)
        print()
        print('Enums remaining: ')
        print(total_enums_to_go)

    MyLib[ 'Version' ] = Version
 
    #printLib( MyLib )
    ( LibPath, LibFilename ) = os.path.split( LibFileName )
    if not os.path.exists( LibPath ):
        os.mkdir( LibPath )

    outfile = open( LibFileName, 'wb')
    pickle.dump( MyLib, outfile)
    outfile.close()
    #printLib( MyLib )   
    load()
    print('Done.')
    return MyLib

# loads the saved type library from disk
def load():
    global TypeLib
    infile = open( LibFileName, 'rb')
    TypeLib = pickle.load( infile )
    infile.close()
        
# retrieve all the type names from the library            
def getTypeList ():
    return list(TypeLib['SymbolTable'].keys())

def getTypeSize ( TypeName ):
    TypeIndex = TypeLib['SymbolTable'][ TypeName ]
    Type = TypeLib['TypeTable'][ TypeIndex ]
    return Type['Size'] * Type['NumElements']


# return a variable of the type TypeName filled in with Content
def variablelize ( TypeName, Content ):
    if TypeName in list(TypeLib['SymbolTable'].keys()):
        TypeIndex = TypeLib['SymbolTable'][ TypeName ]
        return __variablelize( TypeIndex, Content )
    else:
        raise Exception('Type Name not Found "%s"' % TypeName)

# creates a packet from the structure type. 
#
def createPacket( Structure ):
    if not isinstance(Structure, list):
        StructureList = [ Structure ]
    else:
        StructureList = Structure

    ReturnList = []
    for EachStructure in StructureList:
        ReturnList = ReturnList + [ variablelize( EachStructure, '\x00' * getTypeSize( EachStructure )) ]

    if len( ReturnList ) == 1:
        return ReturnList[0]

    return __mergeStruct(ReturnList)
        

        



if __name__ == "__main__":
    generateTypes()





       