################################################################################
#sdbp.py contains python wrappers for the DITS/DETS function set
#All wrappers accept arbitrary arguments. the reason for the choice of arbitrary arguments is because some DITS/DETS 
#functions have multiple revisions that take a variable # and type of input parameter
################################################################################

import cnrserial
#import RWIntDLL
import typelib
typelib.load()



#----------global variables----------#

#takes the form of:[TransportAccess, TransportType, DriveIndex, SessionPointer]
InitializedSessions = []

#this si the size of the sector as expressed to the host
BlockSizeInBytes = 0

#these buffers are used to store data going to and from the drive. They are of type string.
ReadBuffer = ''
WriteBuffer = ''

class driveMemoryContent:
    def __init__ (self):
        self.MemoryRegions = []

    def addMemoryRegion ( self, StartAddress, Size, Content ):
        self.MemoryRegions = self.MemoryRegions + [ ( StartAddress, StartAddress + Size, Content ) ]

    def getContent ( self, Address, Size ):
        AddressEnd  = Address + Size
        #print 'Looking for %x - %x' % ( Address, AddressEnd )
        for ( RegionAddStart, RegionAddEnd, RegionContent ) in self.MemoryRegions:
            #print 'Is it in %x - %x' % ( RegionAddStart, RegionAddEnd )
            if (Address >= RegionAddStart ) and ( AddressEnd <= RegionAddEnd ):
                Offset = Address - RegionAddStart
                Content = RegionContent[Offset:Offset+Size]
                return Content
        raise Exception('Address %08x not found in memory regions' % Address )
        

    def __str__ ( self ):
        ReturnStr =  'Drive Memory with  %d Regions\n' % len( self.MemoryRegions )
        for i in self.MemoryRegions:
            ReturnStr = ReturnStr + ( "\tAddress %08X - %08X\n" % ( i[0], i[1] ))
        return ReturnStr

class bidef(object):
    """
    A generic container object that offers access to members by dot syntax and also lookup by value
    """
    def __init__(self, inidict=None):
        """
        Create an object optionally using a dictionary for initalization
        """
        if inidict != None:
            self.__dict__.update(inidict)
    
    def __repr__(self):
        """
        Return a string representation of the contents of the object
        """
        rstr = ''
        for ikey in list(self.__dict__.keys()):
            ival = self.__dict__[ikey]
            rstr += '    %20s = %s\n' % (ikey, ival.__repr__())
        return rstr
            
    def lookup(self, val ):
        """
        Find a key that has the specified value, or return None
        """
        key = None
        for ikey in list(self.__dict__.keys()):
            ival = self.__dict__[ikey]
            if ival == val:
                key = ikey
                break
        return key

#----------enumerations----------#
#Values for enum eTransportAccess
eTransportAccess = bidef()
eTransportAccess.CNR_SERIAL = 0
eTransportAccess.RWINT = 1        
        
#----------Utility Functions----------#        
def processUDSBDResponse( ResponsePacket ):
    #http://col-web.am.ad.seagate.com/cgi-bin/ProductFirmwareEngineering/index.pl?rpc=getCodes&s=AA0700
    ResponsePacket = removeSerialPortProgramHeader( ResponsePacket )

    #print repr( ResponsePacket[:20])

    MinPacketSize = typelib.getTypeSize('packet_header_and_fw_info')
    ReturnData = [typelib.variablelize ( 'packet_header_and_fw_info', ResponsePacket[:MinPacketSize] )]
    ReturnData[0] = processDriveAndFWInfo( ReturnData[0].DriveAndFWInfo )
    #print MinPacketSize

    RestOfResponse = ResponsePacket[MinPacketSize:]
    while True:
        TraceContentHeaderSize = typelib.getTypeSize( 'trace_content_header')
        #print 'TCH %d, %d' %(TraceContentHeaderSize, len( RestOfResponse ))
        if  len( RestOfResponse) == 0 :
            break
        Content = typelib.variablelize( 'trace_content_header', RestOfResponse[:TraceContentHeaderSize] )

        #print 'Content  : 0x%X' % Content.TraceContentID
        #print 'Revision : 0x%X' % Content.Revision
        #print 'Size     : 0x%X' % Content.TraceContentSizeInBytes

        if  Content.TraceContentID == 0xffff: # footer... were'done
            SizeOfFooter = typelib.getTypeSize('packet_footer')
            #print 'Footer %d, %d' % (len( RestOfResponse ), SizeOfFooter)
            if ( len( RestOfResponse ) < SizeOfFooter ):
                return ReturnData
            Footer = typelib.variablelize( 'packet_footer', RestOfResponse[:SizeOfFooter] )

            RestOfResponse = RestOfResponse[ SizeOfFooter:]
            #print 'Footer'
            #print Footer
            ReturnData =  ReturnData + [Footer]
            if len(RestOfResponse) == 0 :
                return ReturnData

            RestOfResponse = removeSerialPortProgramHeader( RestOfResponse )
            MinPacketSize = typelib.getTypeSize('packet_header_and_fw_info')
            #print 'MPS %d, %d' %( MinPacketSize, len( RestOfResponse ))

            NewHeader = typelib.variablelize ( 'packet_header_and_fw_info', RestOfResponse[:MinPacketSize] )
            ReturnData = ReturnData + [processDriveAndFWInfo( NewHeader.DriveAndFWInfo )]
            RestOfResponse = RestOfResponse[MinPacketSize:]
            


        elif Content.TraceContentID == 0x48:
            ReturnData = ReturnData + [ parseBackdoorStandardCaptureContent( RestOfResponse[TraceContentHeaderSize:Content.TraceContentSizeInBytes ] ) ]
            RestOfResponse = RestOfResponse[ Content.TraceContentSizeInBytes+TraceContentHeaderSize:]
        else:
            ReturnData = ReturnData + [ (Content, RestOfResponse[TraceContentHeaderSize:Content.TraceContentSizeInBytes ])]
            RestOfResponse = RestOfResponse[ Content.TraceContentSizeInBytes+TraceContentHeaderSize:]

    return ReturnData
        
def SendReceiveSDBP( Packet, TimeoutValue, WaitValue, **kwargs ):
    """
    Description:
        Send and receive sdbp packets.
    @param Packet
        type: null terminated binary string
        default: none
        description:
            The packet to be sent to the drive
    @param TimeoutValue
        type: int
        default: none
        description:
            The time in seconds to allow process interrupt for the transport layer to send or receive
    @param WaitValue
        type: int
        default: none
        description:
            The amount of time in seconds to wait between polls of the receive buffer. This is to ease the workload on the host machine. Set to 0 to poll 'continuously'
    @param Session
        type: array of type [TransportAccess, TransportType, DriveIndex, SessionPointer]
        default: the element in the sdbp.InitializedConnections array
        description: an array consisting of [TransportAccess type, TransportType, DeviceIndex, Pointer to the connection]
    """    
    global InitializedSessions
    #print 'Session = ', `kwargs`
    InitializedSessions = [[0,],]
    if 'Session' not in kwargs and not len(InitializedSessions):
        print('A session has not yet been initialized. No packet sent/received.')
        return
    elif 'Session' not in kwargs and len(InitializedSessions):
        Session = InitializedSessions[len(InitializedSessions) - 1]
    else:
        Session = kwargs['Session']
        
    if Session[0] == eTransportAccess.CNR_SERIAL:
        #print 'type: %s, packet: %s'%(type(Packet), `Packet`,)
        cnrserial.sendPacket( Packet )
        return cnrserial.waitForAPacket( TimeoutValue,WaitValue )
        
    if Session[0] == eTransportAccess.RWINT:
        MaxTransferLen = RWIntDLL.GetMaximumTransferLen( Session[3] )        
        receive_buffer = '\x00' * MaxTransferLen
        
        RWIntDLL.SetSessionTimeout(Session[3], TimeoutValue)
        
        RWIntDLL.PutBuffer(Session[3], Packet, RWIntDLL.eSelBuffer.WRITE_BUFFER, 0, len(Packet))
        RWIntDLL.SendSDBPPacket(Session[3], len(Packet))
        RWIntDLL.RetrieveSDBPPacket( Session[3], MaxTransferLen )
        RWIntDLL.GetBuffer(Session[3], receive_buffer, RWIntDLL.eSelBuffer.READ_BUFFER, 0, MaxTransferLen)
        return receive_buffer[:MaxTransferLen]
        
        
#----------DETS wrappers----------#
def EnableOnlineModeRequests( **kwargs ):
    """
    Function ID: 0x0001
    Note: DETS control function
    Description:
        This control mode diagnostic function enables the Diagnostic Test Service so
        that it can process online requests.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
        
    if Revision == 1:
        Packet = typelib.createPacket(  'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.ToPort   = 7
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')        
        Packet.Dfb.Header.FunctionId = 0x0001
        Packet.Dfb.Header.RevisionId = 1
           
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)  
        
def DisableOnlineModeRequests( **kwargs ):
    """
    Function ID: 0x0002
    Note: DETS control function
    Description:
        This control mode diagnostic function disables the Diagnostic Test Service so
        that it can no longer process online requests.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
        
    if Revision == 1:
        Packet = typelib.createPacket(  'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.ToPort   = 7
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')        
        Packet.Dfb.Header.FunctionId = 0x0002
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')        
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)
        
def EnableDiagnosticModeRequests( **kwargs ):
    """
    Function ID: 0x0003
    Note: DETS control function
    Description:
        This control mode diagnostic function enables the Diagnostic Test Service so
        that it can process diagnostic mode requests.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
        
    if Revision == 1:
        Packet = typelib.createPacket(  'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.ToPort   = 7
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')        
        Packet.Dfb.Header.FunctionId = 0x0003
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)

def DisableDiagnosticModeRequests( **kwargs ):
    """
    Function ID: 0x0004
    Note: DETS control function
    Description:
        This control mode diagnostic function disables the Diagnostic Test Service so
        that it can no longer process diagnostic mode requests.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
        
    if Revision == 1:
        Packet = typelib.createPacket(  'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.ToPort   = 7
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')        
        Packet.Dfb.Header.FunctionId = 0x0004
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)

def AbortDiagnosticActivity( **kwargs ):
    """
    Function ID: 0x0005
    Note: DETS control function
    Description:
        This control mode diagnostic function attempts to abort any diagnostic that is
        currently being executed.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
        
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.ToPort   = 7
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')        
        Packet.Dfb.Header.FunctionId = 0x0005
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)        

def GetActiveStatus( **kwargs ):
    """
    Function ID: 0x0006
    Note: DETS online function
    Description:
         This online mode diagnostic function collects the drive's active status information.
        This information gives an indication of what partition, LBA, track, and head are being
        accessed and whether the drive is currently "ready".
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
        
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.ToPort   = 7
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')        
        Packet.Dfb.Header.FunctionId = 0x0006
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_active_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)        
def GetDiagnosticBufferFileInformation( **kwargs ):
    """
    Function ID: 0x0007
    Note: DETS online function
    Description:
        This function gets information about the buffer files used to process diagnostic requests.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'get_diag_buffer_file_info_sdbp_dfb' )
        Packet.Rev1.SdbpHeader.FromPort  = 7
        Packet.Rev1.SdbpHeader.ToPort  = 7
        Packet.Rev1.SdbpHeader.Length  = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Rev1.Dfb.Header.FunctionId  = 0x0007
        Packet.Rev1.Dfb.Header.RevisionId  = 0x1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'get_diag_buffer_file_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)
        

def SetReadWriteScopeSync( **kwargs ): 
    """
    Function ID: 0x0008
    Note: DETS online function
    Description:
        This Online Mode diagnostic function sets the scope sync signal.  It allows setting it
        to the specified servo wedge and incrementing or decrementing it.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    @param Operation
        type: int
        default: 0x01
        description:
            Operation specifies how the Scope Sync Wedge number is to be updated.
            0x00: SET_SCOPE_SYNC_WEDGE - Sets the Scope Sync Wedge number to the specified value.
            0x01: INCREMENT_SCOPE_SYNC_WEDGE - Increments the current Scope Sync Wedge number.
            0x02: DECREMENT_SCOPE_SYNC_WEDGE - Decrements the current Scope Sync Wedge number.            
    @param Wedge
        type: int
        default: none
        description:
            Wedge is the value to which the Scope Sync Wedge number is be set, if the
            SET_SCOPE_SYNC_WEDGE operation is selected.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if 'Operation' in kwargs:
        Operation = kwargs['Operation']
    else:
        Operation = 0x01        
        
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_rw_scope_sync_sdbp_dfb' )
        Packet.SdbpHeader.FromPort  = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0008
        Packet.Dfb.Header.RevisionId = 0x1
        Packet.Dfb.Operation = Operation
        if 'Wedge' in kwargs:
            Packet.Dfb.Wedge = kwargs['Wedge']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_rw_scope_sync_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def GetNativeInterfaceReadWriteCommandHistory( **kwargs ):
    """
    Function ID: 0x0009
    Note: DETS online function
    Description:
        This function gets the command history of the Native Interface and Read/Write subsystem.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort  = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0009
        Packet.Dfb.Header.RevisionId = 0x1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_native_interface_and_rw_cmd_history_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    

def GetNativeInterfaceCommandState( **kwargs ):
    """
    Function ID: 0x000A
    Note: DETS online function
    Description:
        This function gets the state of the Native Interface command.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort  = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x000A
        Packet.Dfb.Header.RevisionId = 0x1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_native_interface_cmd_state_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def GetNativeInterfaceConfiguration( **kwargs ):
    """
    Function ID: 0x000B
    Note: DETS online function
    Description:
        This function gets the Native Interface configuration.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """
    
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort  = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x000B
        Packet.Dfb.Header.RevisionId = 0x1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_native_interface_config_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def BufferDLLTune( **kwargs ):
    """
    Function ID: 0x000C
    Note: DETS diagnostic function
    Description:
        This function executes the Buffer DLL Tune diagnostic.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    @param Action
    type:
    default: none
    description:
        Not able to find documentation for this parameter
    @param NewDllValue
    type: 
    default: None
    description
        Not able to find documentation for this parameter
    """
    
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'buffer_dll_tune_sdbp_dfb' )       
        Packet.Rev1.SdbpHeader.FromPort = 7
        Packet.Rev1.SdbpHeader.ToPort = 7
        Packet.Rev1.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Rev1.Dfb.Header.FunctionId = 0x000C
        Packet.Rev1.Dfb.Header.RevisionId = 1
        if 'Action' in kwargs:
            Packet.Rev1.Dfb.Action = kwargs['action']
        if 'NewDllValue' in kwargs:
            Packet.Rev1.Dfb.NewDllValue = kwargs['NewDllValue']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'buffer_dll_tune_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
def GetNativeInterfaceReadCacheInfo( **kwargs ):
    """
    Function ID: 0x000D
    Note: DETS online function
    Description:
        This function gets the Native Interface's read cache information.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet received.
    -----revision 1 parameters-----
    None
    """

    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )                  
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x000D
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_native_interface_rd_cache_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def GetFirmwareRevision( **kwargs ):
    """
    Function ID: 0x000F
    Note: DETS online function
    Description:
        This online mode diagnostic function will report firmware revision information.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet will be returned.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )                  
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x000F
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_firmware_rev_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def ReadReadChannelRegister( **kwargs ):
    """
    Function ID: 0x0010
    Note: DETS online function
    Description:
        This Online Mode diagnostic function will read the specified Read Channel register.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet will be returned.
    -----revision 1 parameters-----
    @param RegAddr
        type: 16 bit int
        default: none, but user input is required for this parameter
        description: RegAddr contains the address of the first Read Channel register to be read.
    @param NumOfRegsToRd
        type: 16 bit int
        default: 1
        description: NumOfRegsToRd specifies the number of consecutive Read Channel registers to read.
    @param DirectRegAccess
        type: boolean
        default: 1
        description: DirectRegAccess, if TRUE, indicates that the channel register should be read directly.
                        If DirectRegAccess is FALSE, the channel register should be read using the appropriate
                        Read/Write subsystem API function.
   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rd_read_channel_reg_sdbp_dfb' )                  
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0010
        Packet.Dfb.Header.RevisionId = 1        
        Packet.Dfb.RegAddr = kwargs['RegAddr']
        if 'NumOfRegsToRd' in kwargs:
            Packet.Dfb.NumOfRegsToRd = kwargs['NumOfRegsToRd']
        else:
            Packet.Dfb.NumOfRegsToRd = 1
        if 'DirectRegAccess' in kwargs:
            Packet.Dfb.DirectRegAccess = kwargs['DirectRegAccess']
        else:
            Packet.Dfb.DirectRegAccess = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rd_read_channel_reg_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    

def GetCongen( **kwargs ):
    """
    Function ID: 0x0011
    Note: DETS online function
    Description:
        This function gets the Congen information.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. The appropriate revision return packet will be returned.
    -----revision 1 parameters-----
    None
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0011
        Packet.Dfb.Header.RevisionId = 1        
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_congen_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def SetReadWriteTracingState( **kwargs ):
    """
    Function ID: 0x0012
    Note: DETS online function
    Description:
        This Online Mode diagnostic function will set the R/W Tracing State to the state
        specified by the input.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. The appropriate revision return packet will be returned.
    -----revision 2 parameters-----
    @param RwTracingState
        type: 32bit bitfield
        default: 0x0080
        description:
            RwTracingState is a bit-significant value that indicates the new R/W Tracing State.
            R/W Tracing State bits are defined as follows.  The Query bit overrides all the other bits.
            The Advance bit overrides the state bits.
                Bit 7 (0x80): Advance      - If set, the R/W tracing state will iterate to the next state.
                Bit 6 (0x40): Query        - If set, the R/W tracing state will be queried only.
                Bit 2 (0x04): R/W Retry    - If set, R/W retry tracing will be enabled.
                Bit 1 (0x02): R/W Command  - If set, R/W command tracing will be enabled.
                Bit 0 (0x01): R/W Error    - If set, R/W error tracing will be enabled.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_set_rw_tracing_state_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0012
        Packet.Dfb.Header.RevisionId = 2
        if 'RwTracingState' in kwargs:
            Packet.Dfb.RwTracingState = kwargs['RwTracingState']
        else: 
            Packet.Dfb.RwTracingState = 0x0080
         
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_set_rw_tracing_state_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def ReadModifySAP( **kwargs ):
    """
    Function ID: 0x0013
    Note: DETS diagnostic function
    Description:
        This diagnostic mode function reads and/or writes the values of the specified servo
        adaptive parameters.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. The appropriate revision return packet will be returned.
    -----revision 2 parameters-----
    @param MaxHeadData_SapOperation
        type: 8bit int
        default: none
        description: 
            SapOperation is a bit-significant value that indicates whether the Max Head should be
            read from or written to the SAP.
    @param MaxHeadData_MaxHead
        type: 8 bit int
        default: none
        description: 
            MaxHead is the maximum number of heads supported by the servo.
    @param MrBiasData_SapOperation
        type: 8bit bitfield
        default: none
        description:
            SapOperation is a bit-significant value that indicates whether one, none, or all of the
            SAP data values are valid and whether or not the values should be read from or written to
            the SAP.
            Bit 0: If set, then a write operation will be performed and the written values will be
                   mirrored in the Diagnostic Status Block.  (Setting this bit overrides the state of
                   bit 1.)
            Bit 1: If set, then a read operation will be performed.  (This bit is meaningful only if
                   bit 0 is not set.)
            Bit 2: If set, a read or write operation will be performed for all values.  If not set, then
                   the operation will be performed on the specified value only.  (This bit is only
                   meaningful if either bit 0 or bit 1 is also set.)
    @param MrBiasData_Head
        type: 8bit int
        default: none
        description:
            Head is the index into the table of data values.  When used in either the DFB or DSB and
            if it makes sense according to the value in SapOperation, it indicates which head the
            data value is valid for.
    @param MrBiasData_MaxHead
        type: 8bit int
        default: none
        description:
            MaxHead is the maximum number of heads supported by the servo.  NOTE: This value is
            only valid when used in the DSB.  The diagnostic function ignores it in the DFB.
    @param MrBiasData_Data
        type: array of 16 bit values of max length 12
        default: none
        description:
            Data is an array of 16-bit values indexed by head that represents MR bias information.
                Where:
                i = 0 to 11
    @param MaxMrBiasData_SapOperation
        type: 8bit bitfield
        default: none
        description:
            SapOperation is a bit-significant value that indicates whether one, none, or all of the
            SAP data values are valid and whether or not the values should be read from or written to
            the SAP.
            Bit 0: If set, then a write operation will be performed and the written values will be
                   mirrored in the Diagnostic Status Block.  (Setting this bit overrides the state of
                   bit 1.)
            Bit 1: If set, then a read operation will be performed.  (This bit is meaningful only if
                   bit 0 is not set.)
            Bit 2: If set, a read or write operation will be performed for all values.  If not set, then
                   the operation will be performed on the specified value only.  (This bit is only
                   meaningful if either bit 0 or bit 1 is also set.)
    @param MaxMrBiasData_Head
        type: 8bit int
        default: none
        description:
            Head is the index into the table of data values.  When used in either the DFB or DSB and
            if it makes sense according to the value in SapOperation, it indicates which head the
            data value is valid for.
    @param MaxMrBiasData_MaxHead
        type: 8bit int
        default: none
        description:
            MaxHead is the maximum number of heads supported by the servo.  NOTE: This value is
            only valid when used in the DSB.  The diagnostic function ignores it in the DFB.
    @param MaxMrBiasData_Data
        type: array of 16 bit values of max length 12
        default: none
        description:
            Data is an array of 16-bit values indexed by head that represents MR bias information.
                Where:
                i = 0 to 11
    @param BiasTableSapData_SapOperation
        type: 8bit bitfield
        default: none
        description:
            SapOperation is a bit-significant value that indicates whether one, none, or all of the
            SAP data values are valid and whether or not the values should be read from or written to
            the SAP.
            Bit 0: If set, then a write operation will be performed and the written values will be
                   mirrored in the Diagnostic Status Block.  (Setting this bit overrides the state of
                   bit 1.)
            Bit 1: If set, then a read operation will be performed.  (This bit is meaningful only if
                   bit 0 is not set.)
            Bit 2: If set, a read or write operation will be performed for all values.  If not set, then
                   the operation will be performed on the specified value only.  (This bit is only
                   meaningful if either bit 0 or bit 1 is also set.)
    @param BiasTableSapData_NumberOfValues
        type: 16bit int
        default: none
        description:
            NumberOfValues is the number of table entries that will be returned by the diagnostic.
            NOTE: This value is only valid when used in the DSB, the diagnostic function ignores it in
            the DFB.
    @param BiasTableSapData_Offset
        type: 32bit int
        default: none
        description:
            Offset is the index into the table of data values.  When used in either the DFB or DSB and
            if it makes sense according to the value in SapOperation, it indicates which table value
            the data value is valid for.
    @param BiasTableSapData_Data
        type: array of 16 bit values of max length 1030
        default: none
        description: 
            Data is an array of 16-bit values indexed by Offset that represents Bias Table
            information.
                Where:
                k = 0 to 1029
    @param BiasHysteresisTableSapData_SapOperation
        type: 8bit bitfield
        default: none
        description:
            SapOperation is a bit-significant value that indicates whether one, none, or all of the
            SAP data values are valid and whether or not the values should be read from or written to
            the SAP.
            Bit 0: If set, then a write operation will be performed and the written values will be
                   mirrored in the Diagnostic Status Block.  (Setting this bit overrides the state of
                   bit 1.)
            Bit 1: If set, then a read operation will be performed.  (This bit is meaningful only if
                   bit 0 is not set.)
            Bit 2: If set, a read or write operation will be performed for all values.  If not set, then
                   the operation will be performed on the specified value only.  (This bit is only
                   meaningful if either bit 0 or bit 1 is also set.)            
    @param BiasHysteresisTableSapData_NumberOfValues
        type: 16bit int
        default: none
        description:
            NumberOfValues is the number of table entries that will be returned by the diagnostic.
            NOTE: This value is only valid when used in the DSB, the diagnostic function ignores it in
            the DFB.    
    @param BiasHysteresisTableSapData_Offset
        type: 32bit int
        default: none
        description:
            Offset is the index into the table of data values.  When used in either the DFB or DSB and
            if it makes sense according to the value in SapOperation, it indicates which table value
            the data value is valid for.    
    @param BiasHysteresisTableSapData_Data
        type: arrray of 16 bit values of max length 48
        default: none
        description:
            Data is an array of 16-bit values indexed by Offset that represents Bias Hysteresis Table
            information.
            Where:
            m = 0 to 47   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_read_modify_sap_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0013
        Packet.Dfb.Header.RevisionId = 2
        if 'MaxHeadData_SapOperation' in kwargs:
            Packet.Dfb.MaxHeadData.SapOperation = kwargs['MaxHeadData_SapOperation']
        if 'MaxHeadData_MaxHead' in kwargs:
            Packet.Dfb.MaxHeadData.MaxHead = kwargs['MaxHeadData_MaxHead']
        if 'MrBiasData_SapOperation' in kwargs:
            Packet.Dfb.MrBiasData.SapOperation = kwargs['MrBiasData_SapOperation']
        if 'MrBiasData_Head' in kwargs:
            Packet.Dfb.MrBiasData.Head = kwargs['MrBiasData_Head']
        if 'MrBiasData_MaxHead' in kwargs:
            Packet.Dfb.MrBiasData.MaxHead = kwargs['MrBiasData_MaxHead']
        if 'MrBiasData_Data' in kwargs:
            for i in range( len(kwargs['MrBiasData_Data'])):
                Packet.Dfb.MrBiasData.Data = kwargs['MrBiasData_Data'][i]
        if 'MaxMrBiasData_SapOperation' in kwargs:
            Packet.Dfb.MaxMrBiasData.SapOperation = kwargs['MaxMrBiasData_SapOperation']
        if 'MaxMrBiasData_Head' in kwargs:
            Packet.Dfb.MaxMrBiasData.Head = kwargs['MaxMrBiasData_Head']
        if 'MaxMrBiasData_MaxHead' in kwargs:
            Packet.Dfb.MaxMrBiasData.MaxHead = kwargs['MaxMrBiasData_MaxHead']
        if 'MaxMrBiasData_Data' in kwargs:
            for i in range( len(kwargs['MaxMrBiasData_Data'])):
                Packet.Dfb.MaxMrBiasData.Data = kwargs['MaxMrBiasData_Data'][i]
        if 'BiasTableSapData_SapOperation' in kwargs:
            Packet.Dfb.BiasTableSapData.SapOperation = kwargs['BiasTableSapData_SapOperation']
        if 'BiasTableSapData_NumberOfValues' in kwargs:
            Packet.Dfb.BiasTableSapData.NumberOfValues = kwargs['BiasTableSapData_NumberOfValues']
        if 'BiasTableSapData_Offset' in kwargs:
            Packet.Dfb.BiasTableSapData.Offset = kwargs['BiasTableSapData_Offset']
        if 'MaxMrBiasData_Data' in kwargs:
            for i in range( len(kwargs['MaxMrBiasData_Data'])):
                Packet.Dfb.MaxMrBiasData.Data = kwargs['MaxMrBiasData_Data'][i]
        if 'BiasTableSapData_SapOperation' in kwargs:
            Packet.Dfb.BiasTableSapData.SapOperation = kwargs['BiasTableSapData_SapOperation']
        if 'BiasTableSapData_NumberOfValues' in kwargs:
            Packet.Dfb.BiasTableSapData.NumberOfValues = kwargs['BiasTableSapData_NumberOfValues']
        if 'BiasTableSapData_Offset' in kwargs:
            Packet.Dfb.BiasTableSapData.Offset = kwargs['BiasTableSapData_Offset']
        if 'BiasTableSapData_Data' in kwargs:
            for i in range( len(kwargs['BiasTableSapData_Data'])):
                Packet.Dfb.BiasTableSapData.Data = kwargs['BiasTableSapData_Data'][i]
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_read_modify_sap_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def GetCAPParameter( **kwargs ):
    """
    Function ID: 0x0015
    Note: DETS diagnostic function
    Description:
        This Diagnostic Mode diagnostic function will retrieve the value of the specified
        Controller Adaptive Parameter (CAP).        
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Currently, revision 1 DFB results in revision 3 DSB
    -----revision 1 parameters-----
    @param ParmId
        type: 8bit int
        default: 0x01
        description:
            ParmId is the ID of the CAP Parameter whose value is to be retrieved. It is
            defined as follows:
            00 = Validation Key
            01 = HDA Serial Number
            02 = PCBA Serial Number
            03 = PCBA Part Number
            04 = Head Count
            05 = Node Name Validation Key
            06 = Node Name
            07 = Product Family ID
            08 = Product Family Member ID
            09 = PCBA Build Code
            0A = ASIC Information
            0B = Firmware Key
            0C = Firmware Key Checksum
            0D = Date of Manufacture
            0E = Destroked Buf Size Index
            0F = Final Mfg Op
            10 = Final Mfg Error Code
            11 = System Area Prep State
            12 = SPT Auto Run Delay
            13 = Reserved Bytes
            14 = Checksum
            15 = External Model Number
            16 = Internal Model Number
            17 = IDEMA Capacity
            18 = Reserved Bytes 1
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_cap_parm_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0015
        Packet.Dfb.Header.RevisionId = 1
        if 'ParmId' in kwargs:
            Packet.Dfb.ParmId = kwargs['ParmId']
        else: 
            Packet.Dfb.ParmId = 0x01
         
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev3_get_cap_parm_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def SetSelectedDERPRetryState( **kwargs ):
    """
    Function ID: 0x0016
    Note: DETS diagnostic function
    Description:
        This diagnostic mode function will set the Selected DERP Retry State that will be used
        for subsequent diagnostic operations.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param EnableDerpRetryState
        type: 8bit int
        default: none
        description: EnableDerpRetryState, if TRUE, will enable the Selected DERP Retry State and the new
                            values are required in DerpRetryState.  If FALSE, it will disable the Selected DERP Retry
                            State.
    @param Type:
        type: 8bit int
        default: none
        description: Type specifies the type of error that the DERP Error Recovery system will assume
                            for disc access operations.  (Only valid if the drive supports DERP.)
                            0 = UNDETERMINED
                            1 = DATA_ERROR
                            2 = SYNC
                            3 = TA
                            4 = DATAORTA
                            5 = SYNCTA
                            6 = SYNCORDATA
    @param PathState
        type: 8bit int
        default: none
        description: DerpPathState specifies the path count from the current retry sequence that the DERP Error
                            Recovery system will assume for disc access operations.  The meaning of the Path State
                            is dependent on the Error Type (parameter 0).  (Only valid if the drive supports DERP.)
    @param RetryStateCnt
        type: 8bit int
        default: none
        description: DerpRetryStateCnt specifies the retry path count from the current retry sequence that the
                            DERP Error Recovery system will assume for disc access operations.  (Only valid if the
                            drive supports DERP.)
    @param LoopCntr1
        type: 8bit int
        default: none
        description: DerpLoopCntr1 specifies the first loop counter that the DERP Error Recovery system will
                            assume for disc access operations.  (Only valid if the drive supports DERP.)
    @param LoopCntr2
        type: 8bit int
        default: none
        description: DerpLoopCntr2 specifies the second loop counter that the DERP Error Recovery system will
                            assume for disc access operations.  (Only valid if the drive supports DERP.)    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_derp_retry_state_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0016
        Packet.Dfb.Header.RevisionId = 1
        if 'EnableDerpRetryState' in kwargs:
            Packet.Dfb.EnableDerpRetryState = kwargs['EnableDerpRetryState']
        if 'Type' in kwargs:
            Packet.Dfb.DerpRetryState.Type = kwargs['Type']
        if 'PathState' in kwargs:
            Packet.Dfb.DerpRetryState.PathState = kwargs['PathState']
        if 'RetryStateCnt' in kwargs:
            Packet.Dfb.DerpRetryState.RetryStateCnt = kwargs['RetryStateCnt']
        if 'LoopCntr1' in kwargs:
            Packet.Dfb.DerpRetryState.LoopCntr1 = kwargs['LoopCntr1']
        if 'LoopCntr2' in kwargs:
            Packet.Dfb.DerpRetryState.LoopCntr2 = kwargs['LoopCntr2']
            
         
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_derp_retry_state_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    
        
def ReadWriteMemory( **kwargs ):
    """
    Function ID: 0x0017
    Note: DETS diagnostic function
    Description: This diagnostic mode function reads or writes a specified memory location that is
                        addressable by the drive's controller microprocessor.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param WriteMemory
        type: boolean
        default: False
        description: WriteMemory, if TRUE, indicates that the specified memory locations should be
                            written with the specified data.  If FALSE, the specified memory locations will
                            be read and their values returned.
    @param MemoryType
        type: 8 bit int
        default: none
        description:  Specifies the type of memory to be read or written. Within ExtrinsicDiag_RwMemory, this parameter is compared against variables
                            PROCESSOR_DATA_RAM and BUFFER_RAM. Unsure what the actual values of these variables is.
    @param NumberOfBytes
        type: 32 bit int
        default: none
        description: specifies the size in bytes of the memory location to be read or written.
                            It must be equal to 1, 2, 4 or 8.     
    @param ByteOffset
        type: 32 bit int
        default: none
        description:  the offset, in bytes, from the start of the specified memory to the
                            first byte to be read or written.
    @param Data
        type: up to 64bit int (1,2,4 or 8 bytes of data supported)
        default: none
        description: payload data   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_memory_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0017
        Packet.Dfb.Header.RevisionId = 1
        if 'WriteMemory' in kwargs:
            Packet.Dfb.WriteMemory = kwargs['WriteMemory']
        else:
            Packet.Dfb.WriteMemory = False
        if 'MemoryType' in kwargs:
            Packet.Dfb.MemoryType = kwargs['MemoryType']
        if 'NumberOfBytes' in kwargs:
            Packet.Dfb.NumberOfBytes = kwargs['NumberOfBytes']
        if 'ByteOffset' in kwargs:
            Packet.Dfb.ByteOffset = kwargs['ByteOffset']
        if 'Data' in kwargs:
            Packet.Dfb.MemoryData = kwargs['Data']
         
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_memory_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    

def BufferCopy( **kwargs ):
    """
    Function ID: 0x0018
    Note: DETS diagnostic function
    Description: This function copies data from the specified source buffer blocks to the specified
                        destination buffer blocks.        
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SourceBufferBlockValid
        type: unknown
        default: none
        description: no documentation available
    @param SourceBufferBlock
        type: unknown
        default: none
        description: no documentation available
    @param DestinationBufferBlockValid
        type: unknown
        default: none
        description: no documentation available
    @param DestinationBufferBlock
        type: unknown
        default: none
        description: no documentation available
    @param BlocksToCopyValid
        type: unknown
        default: none
        description: no documentation available
    @param BlocksToCopy
        type: unknown
        default: none
        description: no documentation available
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_buffer_copy_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0018
        Packet.Dfb.Header.RevisionId = 1
        if 'SourceBufferBlockValid' in kwargs:
            Packet.Dfb.SourceBufferBlockValid = kwargs['SourceBufferBlockValid']
        if 'SourceBufferBlock' in kwargs:
            Packet.Dfb.SourceBufferBlock = kwargs['SourceBufferBlock']
        if 'DestinationBufferBlockValid' in kwargs:
            Packet.Dfb.DestinationBufferBlockValid = kwargs['DestinationBufferBlockValid']
        if 'DestinationBufferBlock' in kwargs:
            Packet.Dfb.DestinationBufferBlock = kwargs['DestinationBufferBlock']
        if 'BlocksToCopyValid' in kwargs:
            Packet.Dfb.BlocksToCopyValid = kwargs['BlocksToCopyValid']
        if 'BlocksToCopy' in kwargs:
            Packet.Dfb.BlocksToCopy = kwargs['BlocksToCopy']

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)    

def BufferCompare( **kwargs ):
    """
    Function ID: 0x0019
    Note: DETS diagnostic function
    Description: This function compares data from the specified source buffer blocks to the specified
                        reference buffer blocks.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SourceBufferBlockValid
        type: unknown
        default: none
        description: no documentation available
    @param SourceBufferBlock
        type: unknown
        default: none
        description: no documentation available
    @param ReferenceBufferBlockValid
        type: unknown
        default: none
        description: no documentation available    
    @param ReferenceBufferBlock
        type: unknown
        default: none
        description: no documentation available    
    @param BlocksToCompareValid
        type: unknown
        default: none
        description: no documentation available    
    @param BlocksToCompare
        type: unknown
        default: none
        description: no documentation available    
    @param ContinueOnError
        type: unknown
        default: none
        description: no documentation available    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_buffer_compare_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0019
        Packet.Dfb.Header.RevisionId = 1
        if 'SourceBufferBlockValid' in kwargs:
            Packet.Dfb.SourceBufferBlockValid = kwargs['SourceBufferBlockValid']
        if 'SourceBufferBlock' in kwargs:
            Packet.Dfb.SourceBufferBlock = kwargs['SourceBufferBlock']
        if 'ReferenceBufferBlockValid' in kwargs:
            Packet.Dfb.ReferenceBufferBlockValid = kwargs['ReferenceBufferBlockValid']
        if 'ReferenceBufferBlock' in kwargs:
            Packet.Dfb.ReferenceBufferBlock = kwargs['ReferenceBufferBlock']
        if 'BlocksToCompareValid' in kwargs:
            Packet.Dfb.BlocksToCompareValid = kwargs['BlocksToCompareValid']
        if 'BlocksToCompare' in kwargs:
            Packet.Dfb.BlocksToCompare = kwargs['BlocksToCompare']
        if 'ContinueOnError' in kwargs:
            Packet.Dfb.ContinueOnError = kwargs['ContinueOnError']

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_buffer_compare_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ParticleSweep( **kwargs ):
    """
    Function ID: 0x001A
    Note: DETS diagnostic function
    Description: This diagnostic mode function execute the Particle Sweep R/W request operation.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartCylinder
        type: 32bit in
        default: 0
        description: starting cylinder of sweep
    @param EndCylinder
        type: 32 bit int
        default: 1
        description: ending cylinder of sweep   
    @param DurationInMilliseconds
        type: 32bit int
        default: 1000
        description:  timespan of the sweep in milliseconds   
    @param DwellTimeInMilliseconds
        type: 32bit int
        default: 15
        description: dwell time (on track) in milliseconds
    @param ServoSeekSpeed
        type: 8bit int
        default: 1
        description: servo seek speed during sweep
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_particle_sweep_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x001A
        Packet.Dfb.Header.RevisionId = 1
        if 'StartCylinder' in kwargs:
            Packet.Dfb.SweepRequest.StartCylinder = kwargs['StartCylinder']
        else:
            Packet.Dfb.SweepRequest.StartCylinder = 0
        if 'EndCylinder' in kwargs:            
            Packet.Dfb.SweepRequest.EndCylinder = kwargs['EndCylinder']
        else:
            Packet.Dfb.SweepRequest.EndCylinder = 1            
        if 'DurationInMilliseconds' in kwargs:            
            Packet.Dfb.SweepRequest.DurationInMilliseconds = kwargs['DurationInMilliseconds']
        else:
            Packet.Dfb.SweepRequest.DurationInMilliseconds = 1000            
        if 'DwellTimeInMilliseconds' in kwargs:            
            Packet.Dfb.SweepRequest.DwellTimeInMilliseconds = kwargs['DwellTimeInMilliseconds']
        else:
            Packet.Dfb.SweepRequest.DwellTimeInMilliseconds = 15            
        if 'ServoSeekSpeed' in kwargs:            
            Packet.Dfb.SweepRequest.ServoSeekSpeed = kwargs['ServoSeekSpeed']
        else:
            Packet.Dfb.SweepRequest.ServoSeekSpeed = 1            
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_particle_sweep_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SpinDownDrive( **kwargs ):
    """
    Function ID: 0x001B
    Note: DETS diagnostic function
    Description: spin down the drive
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 30
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 30
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_spin_down_drive_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x001B
        Packet.Dfb.Header.RevisionId = 1
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_spin_up_or_down_drive_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SpinUpDrive( **kwargs ):
    """
    Function ID: 0x001C
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will spin the drive up.  It gives options to
                        cause the drive to hold certain states during the spin up, including unlatching or
                        loading off a ramp, acquiring AMs (aka Demod Sync), and track following.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 30
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SpinUpHoldState
        type: 8bit int
        default: 0x00
        description: SpinUpHoldState specifies the state in which the spin up operation will be held.
                            0x00: SPIN_UP_NO_HOLD - Drive should spin up normally.
                            0x01: ADVANCE_HOLD_STATE - Drive should advance to the next hold state.
                            0x02: RELEASE_HOLD - Drive should spin up normally from current state.
                            0x03: HOLD_BEFORE_UNLATCH - Drive should hold before unlatching or loading.
                            0x04: HOLD_BEFORE_DEMOD_SYNC - Drive should hold before acquiring AMs.
                            0x05: HOLD_BEFORE_TRACK_FOLLOW - Drive should hold before tracking.
    @param PhysicalCylValid
        type: boolean
        default: False
        description: if TRUE, and SpinUpHoldState is not equal to SPIN_UP_NO_HOLD,
                            indicates that the PhysicalCyl is valid and specifies the address of the physical
                            cylinder on which the servo will attempt to track follow after spinning up.  If
                            PhysicalCylValid is FALSE or the SpinUpHoldState is equal to SPIN_UP_NO_HOLD,
                            the servo will attempt to track follow on the default physical cylinder after
                            spinning up.         
    @param PhysicalCyl
        type: 32bit int
        default: 0
        description: PhysicalCyl is the address of the physical cylinder on which the servo will attempt
                            to track follow after spinning up.  It is only used when PhysicalCylValid is TRUE and
                            SpinUpHoldState is not equal to SPIN_UP_NO_HOLD.
    @param LogicalHdValid
        type: boolean
        default: False
        description: LogicalHdValid, if TRUE, and SpinUpHoldState is not equal to SPIN_UP_NO_HOLD,
                            indicates that the LogicalHd is valid and specifies the address of the logical
                            head on which the servo will attempt to synchronize the demodulator and / or
                            track follow after spinning up.  If LogicalHdValid is FALSE or the SpinUpHoldState
                            is equal to SPIN_UP_NO_HOLD, the servo will attempt synchronize the demodulator
                            and / or track follow on the default logical head after spinning up.
    @param LogicalHd
        type: 8bit int
        default: 0
        description: LogicalHd is the address of the logical head on which the servo will attempt to
            synchronize the demodulator and / or track follow after spinning up.  It is only used
            when LogicalHdValid is TRUE and SpinUpHoldState is not equal to SPIN_UP_NO_HOLD.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 30
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_spin_up_drive_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x001C
        Packet.Dfb.Header.RevisionId = 1
        if 'SpinUpHoldState' in kwargs:        
            Packet.Dfb.SpinUpHoldState = kwargs['SpinUpHoldState']
        else:
            Packet.Dfb.SpinUpHoldState = 0x00
        if 'PhysicalCylValid' in kwargs:            
            Packet.Dfb.PhysicalCylValid = kwargs['PhysicalCylValid']
        else:
            Packet.Dfb.PhysicalCylValid = False
        if 'PhysicalCyl' in kwargs:            
            Packet.Dfb.PhysicalCyl = kwargs['PhysicalCyl']
        else:
            Packet.Dfb.PhysicalCyl = 0
        if 'LogicalHdValid' in kwargs:            
            Packet.Dfb.LogicalHdValid = kwargs['LogicalHdValid']
        else:
            Packet.Dfb.LogicalHdValid = False
        if 'LogicalHd' in kwargs:            
            Packet.Dfb.LogicalHd = kwargs['LogicalHd']
        else:
            Packet.Dfb.LogicalHd = 0

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_spin_up_or_down_drive_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ConvertTrackPercentageToOffsetCount( **kwargs ):
    """
    Function ID: 0x001D
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function computes the servo offset count that is
                        required to move the heads to the specified data track offset on the current track.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DataTrackPercentage
        type: 16bit int
        default: 0
        description: DataTrackPercentage is the percent offset from data track center (in tenths of a
                            percent, i.e. 1000d counts per data track) for which the Servo Offset Count is to
                            be calculated.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_convert_track_percentage_to_offset_count_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x001D
        Packet.Dfb.Header.RevisionId = 1
        if 'DataTrackPercentage' in kwargs:            
            Packet.Dfb.DataTrackPercentage = kwargs['DataTrackPercentage']
        else:
            Packet.Dfb.DataTrackPercentage = 0
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_convert_track_percentage_to_offset_count_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SetTrackingOffset( **kwargs ):
    """
    Function ID: 0x001E
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function sets the tracking offset to be applied to the
                         current track.  This function will set the offset and then perform a seek on the current
                         track to that offset.  It supports an option to make the applied offset persistent.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TrackFollowOffset
        type: 8bit int
        default: 0
        description: TrackFollowOffset specifies the Track Follow Offset to be applied.
    @param OffsetIsPersistent
        type: boolean
        default: False
        description: OffsetIsPersistent, if TRUE, indicates that the specified offset is persistent
                            and should be used for the next seek and all subsequent seeks until reset.  If
                            OffsetIsPersistent is FALSE, the specified offset is temporary and will only be
                            used on the next seek and will be reset to zero for all subsequent seeks.     
    @param OffsetIsInPercentUnit
        type: boolean
        default: False
        description: if TRUE, indicates that the specified offset is in
                            units of 0.1% of the servo or data track width.  If OffsetIsInPercentUnit is FALSE,
                            the specified offset is in units of 1/256th of the servo or data track width.    
    @param OffsetIsInServoCounts
        type: boolean
        default: True
        description:  if TRUE, indicates that the specified offset is in
                            the amount of servo track.  If OffsetIsInServoCounts is FALSE,
                            the specified offset is in the amount of data track   
    @param EnableReloadChannelParameters
        type: boolean
        default: True
        description: if TRUE, indicates that the channel parameters
                            will be reloaded into the channel registers after the track offset is set.  If
                            EnableReloadChannelParameters is FALSE, the channel parameters will not be
                            reloaded into the channel registers.      
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_tracking_offset_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x001E
        Packet.Dfb.Header.RevisionId = 1       
        if 'TrackFollowOffset' in kwargs:        
            Packet.Dfb.TrackFollowOffset = kwargs['TrackFollowOffset']
        else:
            Packet.Dfb.TrackFollowOffset = 0
        if 'OffsetIsPersistent' in kwargs:
            Packet.Dfb.OffsetIsPersistent = kwargs['OffsetIsPersistent']
        else:
            Packet.Dfb.OffsetIsPersistent = False
        if 'OffsetIsInPercentUnit' in kwargs:
            Packet.Dfb.OffsetIsInPercentUnit = kwargs['OffsetIsInPercentUnit']
        else:
            Packet.Dfb.OffsetIsInPercentUnit = False
        if 'OffsetIsInServoCounts' in kwargs:
            Packet.Dfb.OffsetIsInServoCounts = kwargs['OffsetIsInServoCounts']
        else:
            Packet.Dfb.OffsetIsInServoCounts = True
        if 'EnableReloadChannelParameters' in kwargs:
            Packet.Dfb.EnableReloadChannelParameters = kwargs['EnableReloadChannelParameters']
        else:
            Packet.Dfb.EnableReloadChannelParameters = True
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
                                                
def ReadServoRAMAtAddress( **kwargs ):
    """
    Function ID: 0x001F
    Note: DETS diagnostic function
    Description: This Diagnostic Mode Diagnostic Function will read and return the contents of the
                         specified servo memory location.  It allows reading 8-bit, 16-bit, and 32-bit servo
                         memory locations.  This function supports both single and dual processor environments.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ServoRamAddr
        type: 32bit int
        default: none
        description: ServoRamAddr specifies the address of the Servo Data RAM location to be read.
                            NOTE! Because of memory boundary requirements, reading 2-byte or 4-byte servo memory
                            locations requires that this address by evenly divisiable by 2 or by 4, respectively.
                            If it is not, then the function will fail with an error code.
    @param NumberOfBytes
        type: 8bit int
        default: none
        description: NumberOfBytes specifies the size in bytes of the servo memory location to be read.
                            Valid values are "1", "2", and "4".  Any other value in this field will be interpreted
                            by the diagnostic function as a "1".  See the note above for the special consideration
                            that must be made if the reading 2-byte or 4-byte servo memory locations.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_servo_ram_at_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x001F
        Packet.Dfb.Header.RevisionId = 1       
        if 'ServoRamAddr' in kwargs:        
            Packet.Dfb.ServoRamAddr = kwargs['ServoRamAddr']
        if 'NumberOfBytes' in kwargs:
            Packet.Dfb.NumberOfBytes = kwargs['NumberOfBytes']
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_servo_ram_at_addr_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadServoRAMAtIndex( **kwargs ):
    """
    Function ID: 0x0020
    Note: DETS diagnostic function
    Description: This diagnostic mode function reads the contents of Servo RAM located at the address
                         obtained from the Servo Symbol Table at the specified index.
                     
                         WARNING: this function does NOT check whether the contents of the Servo Symbol Table
                         located at the specified index is a valid memory location since servo does not make
                         this information available to the firmware.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ServoSymbolTableIndex
        type: 16bit int
        default: none
        description: ServoSymbolTableIndex is the index of the Servo Symbol Table entry containing the
                            base address that will be used to compute the address of the Servo RAM location to be
                            read.
    @param NumberOfBytes
        type: 8bit int
        default: none
        description: NumberOfBytes specifies the size in bytes of the Servo RAM location to be read.  Valid
                            values are "1", "2", and "4".  Any other value in this field will be interpreted by the
                            diagnostic function as a "1".
    @param ByteOffset
        type:32bit int
        default: none
        description: an offset which will be added to the base address of the servo RAM location
                            to be read.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_servo_ram_at_index_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0020
        Packet.Dfb.Header.RevisionId = 1       
        if 'ServoSymbolTableIndex' in kwargs:            
            Packet.Dfb.ServoSymbolTableIndex = kwargs['ServoSymbolTableIndex']
        if 'NumberOfBytes' in kwargs:            
            Packet.Dfb.NumberOfBytes = kwargs['NumberOfBytes']
        if 'ByteOffset' in kwargs:            
            Packet.Dfb.ByteOffset = kwargs['ByteOffset']
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_servo_ram_at_index_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def WriteServoRAMAtAddress( **kwargs ):
    """
    Function ID: 0x0021
    Note: DETS diagnostic function
    Description: This Diagnostic Mode Diagnostic Function will write the contents of the specified servo
                         memory location with the specified data.  It allows writing 8-bit, 16-bit, and 32-bit
                         servo memory locations.  This function supports both single and dual processor
                         environments.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ServoRamAddr
        type: 32bit int
        default: none
        description: ServoRamAddr specifies the address of the Servo memory location to be written.
                            NOTE! Because of memory boundary requirements, writing 2-byte or 4-byte servo memory
                            locations requires that this address by evenly divisiable by 2 or by 4, respectively.
                            If it is not, then the function will fail with an error code.
    @param NumberOfBytes
        type: 8bit int
        default: none
        description: NumberOfBytes specifies the size in bytes of the servo memory location to be written.
                            Valid values are "1", "2", and "4".  Any other value in this field will be interpreted
                            by the diagnostic function as a "1".  See the note above for the special consideration
                            that must be made if the reading 2-byte or 4-byte servo memory locations.
    @param Data
        type: up to 64bit int
        default: none
        description: payload data   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_write_servo_ram_at_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0021
        Packet.Dfb.Header.RevisionId = 1              
        if 'ServoRamAddr' in kwargs:        
            Packet.Dfb.ServoRamAddr = kwargs['ServoRamAddr']
        if 'NumberOfBytes' in kwargs:
            Packet.Dfb.NumberOfBytes = kwargs['NumberOfBytes']
        if 'Data' in kwargs:
            Packet.Dfb.Data = kwargs['Data']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
   
def WriteServoRAMAtIndex( **kwargs):
    """
    Function ID: 0x0022
    Note: DETS diagnostic function
    Description: This diagnostic mode function writes the servo memory address specified by the contents
                         located at the specified index of the internal servo symbol table.
                     
                         WARNING: this function does NOT check whether the contents of the Servo Symbol Table
                         located at the specified index is a valid memory location since servo does not make
                         this information available to the firmware.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ServoSymbolTableIndex
        type: 16bit int
        default: none
        description: ServoSymbolTableIndex is the index of the Servo Symbol Table entry containing the
                            base address that will be used to compute the address of the Servo RAM location to be
                            written.
    @param NumberOfBytes
        type: 8bit int
        default: none
        description: specifies the size in bytes of the Servo RAM location to be written.  Valid
                            values are "1", "2", and "4".  Any other value in this field will be interpreted by the
                            diagnostic function as a "1".   
    @param Data
        type: up to 64bit int
        default: none
        description: payload data   
    @param ByteOffset
        type: 32bit int
        default: none
        description: ByteOffset is an offset which will be added to the base address of the servo RAM location
                            to be written.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_write_servo_ram_at_index_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0022
        Packet.Dfb.Header.RevisionId = 1              
        if 'ServoSymbolTableIndex' in kwargs:
            Packet.Dfb.ServoSymbolTableIndex = kwargs['ServoSymbolTableIndex']
        if 'NumberOfBytes' in kwargs:
            Packet.Dfb.NumberOfBytes = kwargs['NumberOfBytes']
        if 'Data' in kwargs:
            Packet.Dfb.Data = kwargs['Data']
        if 'ByteOffset' in kwargs:
            Packet.Dfb.ByteOffset = kwargs['ByteOffset']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadServoSymbolTableAtIndex( **kwargs ):
    """
    Function ID: 0x0023
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function reads the value located at the specified index
                        of the internal servo symbol table.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ServoSymbolTableIndex
        type: 16bit int
        default: none   
        description: ServoSymbolTableIndex specifies the index of the Servo Symbol Table entry to be read.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_servo_symbol_table_at_index_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0023
        Packet.Dfb.Header.RevisionId = 1              
        if 'ServoSymbolTableIndex' in kwargs:
            Packet.Dfb.ServoSymbolTableIndex = kwargs['ServoSymbolTableIndex']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_servo_symbol_table_at_index_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetTestSpace( **kwargs ):
    """
    Function ID: 0x0024
    Note: DETS diagnostic function
    Description: Set the accessible test space
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ParmType
        type: 8bit int
        default: none
        description: ParmType specifies the Test Space Parameter to be modified.
                            0x00: NO_TEST_SPACE_PARM - indicates that no Test Space parameter is to be modified.
                            0x01: SET_DEFAULT_TEST_SPACE - indicates that the Test Space parameters should be set
                            to = 0x01 their default values.
                            0x02: SET_TARGET_ADDR_MODE - indicates that a new Address Mode (User LBA, User LLL
                            CHS, User LLP CHW, System LBA, System LLL CHS, System LLP CHW, PLP CHS or PLP CHW) is
                            being specified.
                            0x03: SET_TEST_SPACE_OPTIONS - indicates that new Test Space Options are being
                            specified.
                            0x04: SET_TEST_SPACE_MIN_USER_LLL_CHS_CYL - indicates that a new Test Space Minimum
                            Logical Cylinder Address is being specified for User LLL CHS address mode.
                            0x05: SET_TEST_SPACE_MIN_SYSTEM_LLL_CHS_CYL - indicates that a new Test Space Minimum
                            Logical Cylinder Address is being specified for System LLL CHS address mode.
                            0x06: SET_TEST_SPACE_MIN_PLP_CHS_CYL - indicates that a new Test Space Minimum Physical
                            Cylinder Address is being specified for PLP CHS address mode.
                            0x07: SET_TEST_SPACE_MAX_USER_LLL_CHS_CYL - indicates that a new Test Space Maximum
                            Logical Cylinder Address is being specified for User LLL CHS address mode.
                            0x08: SET_TEST_SPACE_MAX_SYSTEM_LLL_CHS_CYL - indicates that a new Test Space Maximum
                            Logical Cylinder Address is being specified for System LLL CHS address mode.
                            0x09: SET_TEST_SPACE_MAX_PLP_CHS_CYL - indicates that a new Test Space Maximum Physical
                            Cylinder Address is being specified for PLP CHS address mode.
                            0x0A: SET_TEST_SPACE_MIN_USER_LLL_CHS_HD - indicates that a new Test Space Minimum
                            Logical Head Address is being specified for User LLL CHS address mode.
                            0x0B: SET_TEST_SPACE_MIN_SYSTEM_LLL_CHS_HD - indicates that a new Test Space Minimum
                            Logical Head Address is being specified for System LLL CHS address mode.
                            0x0C: SET_TEST_SPACE_MIN_PLP_CHS_HD - indicates that a new Test Space Minimum Logical
                            Head Address is being specified for PLP CHS address mode.
                            0x0D: SET_TEST_SPACE_MAX_USER_LLL_CHS_HD - indicates that a new Test Space Maximum
                            Logical Head Address is being specified for User LLL CHS address mode.
                            0x0E: SET_TEST_SPACE_MAX_SYSTEM_LLL_CHS_HD - indicates that a new Test Space Maximum
                            Logical Head Address is being specified for System LLL CHS address mode.
                            0x0F: SET_TEST_SPACE_MAX_PLP_CHS_HD - indicates that a new Test Space Maximum Logical
                            Head Address is being specified for PLP CHS address mode.
                            0x10: SET_TEST_SPACE_MIN_USER_LBA - indicates that a new Test Space Minimum LBA is
                            being specified for User LBA address mode.
                            0x11: SET_TEST_SPACE_MIN_SYSTEM_LBA - indicates that a new Test Space Minimum LBA is
                            being specified for System LBA address mode.
                            0x12: SET_TEST_SPACE_MAX_USER_LBA - indicates that a new Test Space Maximum LBA is
                            being specified for User LBA address mode.
                            0x13: SET_TEST_SPACE_MAX_SYSTEM_LBA - indicates that a new Test Space Maximum LBA is
                            being specified for System LBA address mode.
                            0x14: SET_TARGET_BUFFER_SECTOR_OFFSET - indicates that a new Buffer Sector Offset is
                            being specified.   
    @param TargetAddrMode
        type: 8bit int
        default: none
        description:  TargetAddrMode specifies a new Target Address Mode.
                            0x00: USER_LBA_ADDR_MODE specifies that the User Area will be accessed in LBA mode.
                            0x01: USER_LLL_CHS_ADDR_MODE specifies that the User Area will be accessed in Logical
                            Cylinder, Logical Head and Logical Sector mode.
                            0x02: USER_LLP_CHW_ADDR_MODE specifies that the User Area will be accessed in Logical
                            Cylinder, Logical Head and Physical Wedge mode.
                            0x03: SYSTEM_LBA_ADDR_MODE specifies that the System Area will be accessed in LBA mode.
                            0x04: SYSTEM_LLL_CHS_ADDR_MODE specifies that the System Area will be accessed in Logical
                            Cylinder, Logical Head and Logical Sector mode.
                            0x05: SYSTEM_LLP_CHW_ADDR_MODE specifies that the System Area will be accessed in Logical
                            Cylinder, Logical Head and Physical Wedge mode.
                            0x06: PLP_CHS_ADDR_MODE specifies that the full drive will be accessed in Physical Cylinder,
                            Logical Head and Physical Sector mode.
                            0x07: PLP_CHW_ADDR_MODE specifies that the full drive will be accessed in Physical Cylinder,
                            Logical Head and Physical Wedge mode.   
    @param BitFieldAllHds
        type: 32bit bitfield
        default: none
        description:  
                            Bits 12-31:
                            spare2 is a collection of unused bits.

                            Bit 11:
                            Sequential80Random20, if TRUE, the cylinder and head address will be updated
                            sequentially 80% of the time and randomly 20% of the time.

                            Bit 10:
                            spare1 is an unused bit.

                            Bit 9:
                            RandomTransferLength, if TRUE, a random transfer length will be used for read/write
                            operations.

                            Bit 8:
                            RandomStartingSector, if TRUE, a random starting sector will be used for read/write
                            operations.  If FALSE, read/write operations will start at sector 0.

                            Bit 7:
                            RandomData, if TRUE, random data will be used for disk write operations.  If FALSE,
                            the existing buffer data will be used for write operations.

                            Bit 6:
                            SequentialOut, if TRUE, the cylinder and head address will be updated sequentially
                            from the Inner Diameter to the Outer Diameter.  If FALSE, the cylinder and head
                            address will be updated sequentially from the Outer Diameter to the Inner Diameter.

                            Bit 5:
                            OddCyls, if TRUE, only odd numbered cylinders will be accessed.

                            Bit 4:
                            EvenCyls, if TRUE, only even numbered cylinders will be accessed.

                            Bit 3:
                            spare0 is an unused bit.

                            Bit 2:
                            RandomCylAndHd, if TRUE, the cylinder and head address will be updated randomly.
                            If FALSE, the cylinder and head address will be updated sequentially.

                            Bit 1:
                            AllCyls, if TRUE, all cylinders (Minimum Cylinder to Maximum Cylinder) will be
                            accessed.  If FALSE, only the current cylinder will be accessed.

                            Bit 0:
                            AllHds, if TRUE, all heads (Minimum Head to Maximum Head) will be accessed.  If
                            FALSE, only the current head will be accessed.  
    @param LbaLimit
        type: 32bit int
        default: none
        description:  LbaLimit specifies a new Test Space Minimum or Maximum LBA.   
    @param Cyl
        type: 32bit int
        default: none
        description:  Cyl specifies a new Test Space Minimum or Maximum Cylinder Address.   
    @param Hd
        type: 8bit int
        default: none
        description: Hd specifies the head address for which the new cylinder limit applies.
    @param HdLimit
        type: 8bit int
        default: none
        description:  HdLimit specifies a new Test Space Minimum or Maximum Head Address.   
    @param TargetBufferSectorOffset
        type: 32bit int
        default: none
        description:  TargetBufferSectorOffset specifies a new Target Buffer Sector Offset.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_test_space_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0024
        Packet.Dfb.Header.RevisionId = 1                     
        if 'ParmType' in kwargs:        
            Packet.Dfb.ParmType = kwargs['ParmType']
        if 'TargetAddrMode' in kwargs:            
            Packet.Dfb.ParmValue.TargetAddrMode = kwargs['TargetAddrMode']
        if 'BitFieldAllHds' in kwargs:            
            #Packet.Dfb.ParmValue.Options.BitFieldAllHds = kwargs['BitFieldAllHds'] #due to messed up print of unions by typelib
            Packet.Dfb.ParmValue.Options = kwargs['BitFieldAllHds']
        if 'LbaLimit' in kwargs:            
            Packet.Dfb.ParmValue.LbaLimit = kwargs['LbaLimit']
        if 'Cyl' in kwargs:            
            #Packet.Dfb.ParmValue.CylLimit.Cyl = kwargs['Cyl'] #due to messed up print of unions
            Packet.Dfb.ParmValue.CylLimit = kwargs['Cyl']
        if 'Hd' in kwargs:            
            Packet.Dfb.ParmValue.CylLimit.Hd = kwargs['Hd']
        if 'HdLimit' in kwargs:            
            Packet.Dfb.ParmValue.HdLimit = kwargs['HdLimit']
        if 'TargetBufferSectorOffset' in kwargs:            
            Packet.Dfb.ParmValue.TargetBufferSectorOffset = kwargs['TargetBufferSectorOffset']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_test_space_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetTargetAddress( **kwargs ):
    """
    Function ID: 0x0025
    Note: DETS diagnostic function
    Description: This diagnostic mode function sets the Test Space's target address based on the values
     specified in the Diagnostic Function Block.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TargetAddrMode
        type: 8bit int
        deafult: none
        description: TargetAddrMode specifies the Address Mode to be selected:

                            0x00: USER_LBA_ADDR_MODE specifies that the User Area will be accessed in LBA mode.
                            0x01: USER_LLL_CHS_ADDR_MODE specifies that the User Area will be accessed in Logical
                            Cylinder, Logical Head and Logical Sector mode.
                            0x02: USER_LLP_CHW_ADDR_MODE specifies that the User Area will be accessed in Logical
                            Cylinder, Logical Head and Physical Wedge mode.
                            0x03: SYSTEM_LBA_ADDR_MODE specifies that the System Area will be accessed in LBA mode.
                            0x04: SYSTEM_LLL_CHS_ADDR_MODE specifies that the System Area will be accessed in Logical
                            Cylinder, Logical Head and Logical Sector mode.
                            0x05: SYSTEM_LLP_CHW_ADDR_MODE specifies that the System Area will be accessed in Logical
                            Cylinder, Logical Head and Physical Wedge mode.
                            0x06: PLP_CHS_ADDR_MODE specifies that the full drive will be accessed in Physical Cylinder,
                            Logical Head and Physical Sector mode.
                            0x07: PLP_CHW_ADDR_MODE specifies that the full drive will be accessed in Physical Cylinder,
                            Logical Head and Physical Wedge mode.
    @param UpdateTargetAddrOption
        type: 8bit int
        deafult: none
        description:  UpdateTargetAddrOption specifies the option selected for updating the Target Address:

                            0x00: DO_NOT_UPDATE_TARGET_ADDR - Indicates that the Target Address is not to be updated.
                            0x01: UPDATE_TARGET_ADDR - Indicates that the Target Address is to be updated based on
                            the Test Space that is selected.
                            0x02: UPDATE_TARGET_HD - Indicates that the Target Head Address is to be updated based
                            on the Test Space that is selected.  This option is only valid for the following Address
                            Modes: USER_LLL_CHS_ADDR_MODE, USER_LLP_CHW_ADDR_MODE, SYSTEM_LLL_CHS_ADDR_MODE,
                            SYSTEM_LLP_CHW_ADDR_MODE, PLP_CHS_ADDR_MODE, PLP_CHW_ADDR_MODE.   
    @param SetTargetAddrOption
        type: 8bit int
        deafult: none
        description:  SetTargetAddrOption specifies the option selected for setting the Target Address:

                        0x00: DO_NOT_SET_TARGET_ADDR indicates that the Target Address is not to be modified.
                        0x01: SET_TARGET_LBA indicates that a new Target LBA is being specified.
                        0x02: SET_TARGET_CHS_OR_CHW indicates that a new Target Cylinder, Head and Sector (or
                        Wedge) address are being specified.
                        0x03: SET_TARGET_CYL indicates that a new Target Cylinder address is being specified.
                        0x04: SET_TARGET_HD indicates that a new Target Head address is being specified.
                        0x05: SET_TARGET_SECTOR_OR_WEDGE indicates that a new Target Sector or Wedge address is
                        being specified.
                        0x06: SET_TARGET_ADDR_TO_CURRENT_RW_ADDR indicates that the Target Address should be
                        set to the current R/W Address.   
    @param Lba
        type: 32bit int
        deafult: none
        description:  Lba is used to specify a new Target LBA.   
    @param ChsOrChw_Cylinder
        type: 32bit int
        deafult: none
        description:  Cylinder is the cylinder address of the sector or wedge.   
    @param ChsOrChw_Head
        type: 8bit int
        deafult: none
        description:  Head is the head address of the sector or wedge.      
    @param ChsOrChw_Sector
        type: 16bit int
        deafult: none
        description:  Sector is the sector or wedge address of the sector or wedge.   
    @param Cyl
        type: 32bit int
        deafult: none
        description:  Cyl is used to specify a new Target Cylinder address.      
    @param Hd
        type: 8bit int
        deafult: none
        description: Hd is used to specify a new Target Head address.      
    @param SectorOrWedge
        type: 16bit int
        deafult: none
        description:  SectorOrWedge is used to specify a new Target Sector or Wedge address   
    @param SetTargetTransferLengthOption
        type: 8bit int
        deafult: none
        description:  SetTargetTransferLengthOption specifies the option selected for setting the Target
                            Transfer Length:

                            0x00: DO_NOT_SET_TARGET_TRANSFER_LENGTH - Indicates that the Target Transfer Length is
                            not to be modified.
                            0x01: SET_TARGET_TRANSFER_LENGTH - Indicates that a new Target Transfer Length is being
                            specified.   
    @param TargetTransferLength
        type: 32bit int
        deafult: none
        description: TargetTransferLength specifies the value, if any, to which the Target Transfer Length
                            is to be set.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_target_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0025
        Packet.Dfb.Header.RevisionId = 1              
        if 'TargetAddrMode' in kwargs:            
            Packet.Dfb.TargetAddrMode = kwargs['TargetAddrMode']
        if 'UpdateTargetAddrOption' in kwargs:
            Packet.Dfb.UpdateTargetAddrOption = kwargs['UpdateTargetAddrOption']
        if 'SetTargetAddrOption' in kwargs:
            Packet.Dfb.SetTargetAddrOption = kwargs['SetTargetAddrOption']
        if 'Lba' in kwargs:
            Packet.Dfb.TargetAddr.Lba = kwargs['Lba']
        if 'ChsOrChw_Cylinder' in kwargs:
            Packet.Dfb.TargetAddr.ChsOrChw.Cylinder = kwargs['ChsOrChw_Cylinder']
        if 'ChsOrChw_Head' in kwargs:
            Packet.Dfb.TargetAddr.ChsOrChw.Head = kwargs['ChsOrChw_Head']
        if 'ChsOrChw_Sector' in kwargs:
            Packet.Dfb.TargetAddr.ChsOrChw.Sector = kwargs['ChsOrChw_Sector']
        if 'Cyl' in kwargs:
            Packet.Dfb.TargetAddr.Cyl = kwargs['Cyl']
        if 'Hd' in kwargs:
            Packet.Dfb.TargetAddr.Hd = kwargs['Hd']
        if 'SectorOrWedge' in kwargs:
            Packet.Dfb.TargetAddr.SectorOrWedge = kwargs['SectorOrWedge']
        if 'SetTargetTransferLengthOption' in kwargs:
            Packet.Dfb.SetTargetTransferLengthOption = kwargs['SetTargetTransferLengthOption']
        if 'TargetTransferLength' in kwargs:
            Packet.Dfb.TargetTransferLength = kwargs['TargetTransferLength']
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_target_addr_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SeekToTargetAddress( **kwargs ):
    """
    Function ID: 0x0026
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will seek to the target address that is
                         specified by the Test Space.  (Use "Set Target Address" to set up the target address
                         for this function.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SeekType
        type: 8bit int
        default: 0x00
        description: SeekType specifies the type of seek to be performed.
                            0x00: DIAG_READ_SEEK - Indicates a seek to the read track follow position.
                            0x01: DIAG_WRITE_SEEK - Indicates a seek to the write track follow position.
                            0x02: DIAG_WRITE_HEADER_SEEK - Indicates a seek to the write header track follow position.
    @param TrackFollowOffset
        type: 16bit int
        default: 0
        description: TrackFollowOffset is the track follow offset to be applied for the target track.
                            This offset will be added to any peristent offset that is currently if affect.
                            (See below for information about the units of this parameter.)   
    @param OffsetIsInPercentOfDataTrack
        type: boolean   
        default: False
        description: OffsetIsInPercentOfDataTrack, if TRUE, indicates that the specified offset is in
                            units of 0.1% of the data track width.  If OffsetIsInPercentOfDataTrack is FALSE,
                            the specified offset is in units of 1/256th of the servo track width.
    @param EnableReloadChannelParameters
        type: boolean
        default: True
        description: EnableReloadChannelParameters, if TRUE, indicates that the channel parameters
                            will be reloaded into the channel registers with the seek operation.  If
                            EnableReloadChannelParameters is FALSE, the channel parameters will not be
                            reloaded into the channel registers.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_seek_to_target_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0026
        Packet.Dfb.Header.RevisionId = 1              
        if 'SeekType' in kwargs:
            Packet.Dfb.SeekType = kwargs['SeekType']
        else:
            Packet.Dfb.SeekType = 0x00
        if 'TrackFollowOffset' in kwargs:
            Packet.Dfb.TrackFollowOffset = kwargs['TrackFollowOffset']
        else:
            Packet.Dfb.TrackFollowOffset = 0
        if 'OffsetIsInPercentOfDataTrack' in kwargs:
            Packet.Dfb.OffsetIsInPercentOfDataTrack = kwargs['OffsetIsInPercentOfDataTrack']
        else:
            Packet.Dfb.OffsetIsInPercentOfDataTrack = False
        if 'EnableReloadChannelParameters' in kwargs:
            Packet.Dfb.EnableReloadChannelParameters = kwargs['EnableReloadChannelParameters']
        else:
            Packet.Dfb.EnableReloadChannelParameters = True
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ReadWriteTargetAddress( **kwargs ):
    """
    Function ID: 0x0027
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will perform a specified sequence reads,
                         writes, and read comparisons.  A number of these operations can be performed with a
                         single invocation of this function.
                     
                         This function may return different status blocks depending on the operation performed.
                         These two possible status blocks are defined below.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB. There is some
                            ambiguity indicated in the description about the return packet, but I have yet to run into any
                            trouble. Seems pretty consistent.
    -----revision 1 parameters-----
    @param Operation
        type: 8bit int
        default: none
        description: Operation specifies the type of Read / Write operation to be performed.
                            0x00: RW_SEQUENCE_COMPLETE specifies that the Read / Write sequence is completed.
                            0x01: RW_SEQUENCE_READ specifies to start a read sequence.
                            0x02: RW_SEQUENCE_WRITE specifies to start a write sequence.
                            0x03: RW_SEQUENCE_READ_AND_COMPARE specifies to start a read and compare sequence.
    @param BitFieldRwEntireTestSpace
        type: 32bit bitfield
        default: none
        description: 
                        Bit 6:
                        ContinueOnSyncError, if TRUE, indicates that sync mark timeout error should be
                        ignored and sync error count and sync error secotr/wedge list should be provided
                        at the end of the transfer.  If ContinueOnECCError is FALSE, sequence execution
                        will stop when a sync timeout error occurs and a single status packet will
                        be returned for the sector in error.

                        Bit 5:
                        ContinueOnECCError, if TRUE, indicates that ECC errors should not halt disc transfer
                        and an attempt should be made to read or write all of the requested sectors.
                        If ContinueOnECCError is FALSE, sequence execution will stop when an ECC
                        error occurs and a single status packet will be returned for the sector in error.

                        Bit 4:
                        ContinueOnError, if TRUE, indicates that an attempt should be made to read or write
                        all of the requested sectors and a status packet should be returned for each sector
                        in error.  If ContinueOnError is FALSE, sequence execution will stop when an error
                        occurs and a single status packet will be returned for the sector in error.

                        Bit 3:
                        EnableDynamicSparing, if TRUE, indicates that sectors containing media defects that
                        meet the failure criteria should by spared.

                        Bit 2:
                        UnusedBit2 is an unused bit.

                        Bit 1:
                        RotateBufferSectorOffset, if TRUE, indicates that the target buffer sector offset
                        will be rotated for every read/write target address diagnostic function. This bit
                        was originally created to help reduce time when writing random data pattern.
                        By rotating the target buffer sector offset, re-filling up the diagnostic buffer with
                        new random data won't be necessary since re-using existing random data pattern at
                        the differenct buffer sector offset will give similar effect in term of read channel
                        point of view.

                        Bit 0:
                        RwEntireTestSpace, if TRUE, indicates that the specified operation should be
                        performed on the entire Test Space.  If FALSE, the specified operation should
                        only be performed on the sectors / wedges specified by the Target Address and
                        Transfer Length.
    @param RWArray
        type: array of 2 element array of max length 63.
        default: none
        description: This array holds up to 63 read write sequences to be executed completely within the drive.
                            The form is as follows: sdbp.ReadWriteTargetAddress(RWArray = [[Operation,BitFieldRwEntireTestSpace],
                                                                                                                            [Operation,BitFieldRwEntireTestSpace],
                                                                                                                            [Operation,BitFieldRwEntireTestSpace]])
                                                                                                                            
        @example: sdbp.ReadWriteTargetAddress(RWArray = [[0x01,0x01],[0x01,0x01],[0x02,0x01],[0x02,0x01]])
                            This will perform 2 read operations, followed by two write operations at the target address.
                                
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_target_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0027
        Packet.Dfb.Header.RevisionId = 1              
        if 'BitFieldRwEntireTestSpace' in kwargs:
            Packet.Dfb.SeekType = kwargs['BitFieldRwEntireTestSpace']
        
        for op in range(len(kwargs['RWArray'])):
            Packet.Dfb.RwSequence[op].Operation = kwargs['RWArray'][op][0]
            Packet.Dfb.RwSequence[op].Options.BitFieldRwEntireTestSpace = kwargs['RWArray'][op][1]        
            
        Packet.Dfb.RwSequence[len(kwargs['RWArray']) + 1].Operation = 0x00
        Packet.Dfb.RwSequence[len(kwargs['RWArray']) + 1].Options.BitFieldRwEntireTestSpace = 0x00
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def BufferSetPattern( **kwargs ):
    """
    Function ID: 0x0028
    Note: DETS diagnostic function
    Description: This function loads the specified Data Buffer blocks with the specified pattern.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param PatternType
        type: int
        default: none
        description: no documentation available
    @param Pattern
        type: array of ints of max length 16
        default: none
        description: no documentation available
    @param PatternBitLength
        type: int
        default: none
        description: no documentation available
    @param BufferBlockNumberValid
        type: int
        default: none
        description: no documentation availablev
    @param BufferBlockNumber
        type: int
        default: none
        description: no documentation available
    @param NumberOfBlocksValid
        type: int
        default: none
        description: no documentation available
    @param NumberOfBlocks
        type: int
        default: none
        description: no documentation available
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_buffer_set_pattern_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0028
        Packet.Dfb.Header.RevisionId = 1              
        if 'PatternType' in kwargs:            
            Packet.Dfb.PatternType = kwargs['PatternType']
        for i in range(len(kwargs['Pattern'])):
            Packet.Dfb.Pattern[i] = kwargs['Pattern'][i]
        if 'PatternBitLength' in kwargs:
            Packet.Dfb.PatternBitLength = kwargs['PatternBitLength']
        if 'BufferBlockNumberValid' in kwargs:
            Packet.Dfb.BufferBlockNumberValid = kwargs['BufferBlockNumberValid']
        if 'BufferBlockNumber' in kwargs:
            Packet.Dfb.BufferBlockNumber = kwargs['BufferBlockNumber']
        if 'NumberOfBlocksValid' in kwargs:
            Packet.Dfb.NumberOfBlocksValid = kwargs['NumberOfBlocksValid']
        if 'NumberOfBlocks' in kwargs:
            Packet.Dfb.NumberOfBlocks = kwargs['NumberOfBlocks']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SelectWriteBuffer( **kwargs ):
    """
    Function ID: 0x002B
    Note: DETS diagnostic function
    Description: This function selects the specified buffer blocks to be used as the source for data
                        written to the disk by the diagnostics.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartingBufferBlockNumber
        type: int
        default: none
        description: no documentation available
    @param BufferBlocks
        type: int
        default: none
        description: no documentation available
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_select_write_buffer_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x002B
        Packet.Dfb.Header.RevisionId = 1
        if 'StartingBufferBlockNumber' in kwargs:
            Packet.Dfb.StartingBufferBlockNumber = kwargs['StartingBufferBlockNumber']
        if 'BufferBlocks' in kwargs:            
            Packet.Dfb.BufferBlocks = kwargs['BufferBlocks']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def DeselectWriteBuffer( **kwargs ):
    """
    Function ID: 0x002C
    Note: DETS diagnostic function
    Description: No documentation found
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x002C
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GenericReadWriteRequest( **kwargs ):
    """
    Function ID: 0x002D
    Note: DETS diagnostic function
    Description: This function provides a pass through to the Read/Write subsystem.  The Diagnostic
                        Function Block (DFB) parameters are passed directly to the Read/Write subsystem
                        without interpretation. 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Parm
        type: array of max length 10
        default: none
        description: None found.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_rw_request_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x002D
        Packet.Dfb.Header.RevisionId = 1

        for i in range( len(kwargs['Parm'])):
            Packet.Dfb.Parm[i] = kwargs['Parm'][i]
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetRetries( **kwargs ): 
    """
    Function ID: 0x002E
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function sets the error recovery parameters that are to
                        be used for subsequent diagnostic disk access.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param flag_Mode
        type: boolean
        default: False
        description: indicates the Mode parameter will be updated
    @param flag_Options
        type: boolean
        default: False
        description: indicates the Options parameter will be updated
    @param flag_MaxReadRetryLevelAllowed
        type: boolean
        default: False
        description: indicates the MaxReadRetryLevelAllowed parameter will be updated
    @param flag_MaxWriteRetryLevelAllowed
        type: boolean
        default: False
        description: indicates the MaxWriteRetryLevelAllowed parameter will be updated
    @param flag_SelectedRetryStep
        type: boolean
        default: False
        description: indicates the SelectedRetryStep parameter will be updated
    @param flag_SelectedOtfEccSetting
        type: boolean
        default: False
        description: indicates the SelectedOtfEccSetting parameter will be updated
    @param flag_MaxReadRetryCount
        type: boolean
        default: False
        description: indicates the MaxReadRetryCount parameter will be updated
    @param flag_MaxWriteRetryCount
        type: boolean
        default: False
        description: indicates the MaxWriteRetryCount parameter will be updated
    @param Config
        type: 8bit int
        default: none
        description: Config specifies the Error Recovery Config.  (Note: This parameter is derived from
                            the Mode by the Diagnostic External Test Service.  This value will be ignored.)
    @param Mode
        type: 8bit int
        default: none
        description: Mode specifies the Error Recovery Mode.
                            0 = Maximum Normal
                            1 = Maximum Full
                            2 = Default Normal
                            3 = Default Full
                            4 = Minimum Normal
                            5 = Minimum Full
                            6 = Simple Retries
                            7 = Mini-Cert / Data Scrub
    @param Options
        type: 32bit int
        default: none
        description: Options specifies the Error Recovery Options for the specified Error Recovery Mode.
    @param MaxReadRetryLevelAllowed
        type: 8bit int
        default: none
        description: MaxReadRetryLevelAllowed specifies the Maximum Read Retry Level Allowed for the
                            specified Error Recovery Mode.   
    @param MaxWriteRetryLevelAllowed
        type: 8bit int
        default: none
        description: MaxWriteRetryLevelAllowed specifies the Maximum Write Retry Level Allowed for the
                            specified Error Recovery Mode.   
    @param SelectedRetryStep
        type: 16bit int
        default: none
        description: SelectedRetryStep specifies the Selected Retry Step for the specified Error Recovery
                            Mode.   
    @param SelectedOtfEccSetting
        type: 8bit int
        default: none
        description: SelectedOtfEccSetting specifies the Selected OTF ECC Setting for the specified Error
                            Recovery Mode.
    @param MaxReadRetryCount
        type: 16bit int
        default: none
        description: MaxReadRetryCount specifies the maximum number of read retry counts that will be
                            allowed for the specified Error Recovery Mode.
    @param MaxWriteRetryCount
        type: 16bit int
        default: none
        description: MaxWriteRetryCount specifies the maximum number of write retry counts that will be
                            allowed for the specified Error Recovery Mode.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_retries_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x002E
        Packet.Dfb.Header.RevisionId = 1
        if 'flag_Mode' in kwargs:
            Packet.Dfb.ErrorRecoveryParmValidFlags.Mode = kwargs['flag_Mode']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.Mode = False
        if 'flag_Options' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.Options = kwargs['flag_Options']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.Options = Falsee
        if 'flag_MaxReadRetryLevelAllowed' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxReadRetryLevelAllowed = kwargs['flag_MaxReadRetryLevelAllowed']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxReadRetryLevelAllowed = False            
        if 'flag_MaxWriteRetryLevelAllowed' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxWriteRetryLevelAllowed = kwargs['flag_MaxWriteRetryLevelAllowed']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxWriteRetryLevelAllowed = False            
        if 'flag_SelectedRetryStep' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.SelectedRetryStep = kwargs['flag_SelectedRetryStep']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.SelectedRetryStep = False            
        if 'flag_SelectedOtfEccSetting' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.SelectedOtfEccSetting = kwargs['flag_SelectedOtfEccSetting']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.SelectedOtfEccSetting = False            
        if 'flag_MaxReadRetryCount' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxReadRetryCount = kwargs['flag_MaxReadRetryCount']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxReadRetryCount = False            
        if 'flag_MaxWriteRetryCount' in kwargs:            
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxWriteRetryCount = kwargs['flag_MaxWriteRetryCount']
        else:
            Packet.Dfb.ErrorRecoveryParmValidFlags.MaxWriteRetryCount = False
        if 'Config' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.Config = kwargs['Config']
        if 'Mode' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.Mode = kwargs['Mode']
        if 'Options' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.Options = kwargs['Options']
        if 'MaxReadRetryLevelAllowed' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.MaxReadRetryLevelAllowed = kwargs['MaxReadRetryLevelAllowed']
        if 'MaxWriteRetryLevelAllowed' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.MaxWriteRetryLevelAllowed = kwargs['MaxWriteRetryLevelAllowed']
        if 'SelectedRetryStep' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.SelectedRetryStep = kwargs['SelectedRetryStep']
        if 'SelectedOtfEccSetting' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.SelectedOtfEccSetting = kwargs['SelectedOtfEccSetting']
        if 'MaxReadRetryCount' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.MaxReadRetryCount = kwargs['MaxReadRetryCount']
        if 'MaxWriteRetryCount' in kwargs:            
            Packet.Dfb.ErrorRecoveryParms.MaxWriteRetryCount = kwargs['MaxWriteRetryCount']
        
        
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_retries_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadWriteZAPTable( **kwargs ):
    """
    Function ID: 0x002F
    Note: DETS diagnostic function
    Description: This function reads the ZAP table or modifies a ZAP table entry.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ModifyZapTableEntry
        type: int
        default: none
        description: none found
    @param ZapTableEntryNumber
        type: int
        default: none
        description: none found    
    @param ZapTableEntryData
        type: int
        default: none
        description: none found    
    """
    # Input Parameter :       rev1_rw_zap_table_sdbp_dfb
# Output Parameter :      rev1_rw_zap_table_sdbp_dsb
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_zap_table_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x002F
        Packet.Dfb.Header.RevisionId = 1
        if 'ModifyZapTableEntry' in kwargs:        
            Packet.Dfb.ModifyZapTableEntry = kwargs['ModifyZapTableEntry']
        if 'ZapTableEntryNumber' in kwargs:
            Packet.Dfb.ZapTableEntryNumber = kwargs['ZapTableEntryNumber']
        if 'ZapTableEntryData' in kwargs:
            Packet.Dfb.ZapTableEntryData = kwargs['ZapTableEntryData']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_zap_table_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def TranslateAddress( **kwargs ):
    """
    Function ID: 0x0030
    Note: DETS diagnostic function
    Description: This diagnostic mode function performs the specified sector address translation.  This
                         function will translate a single specified address into all other possible representations
                         of an address.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TranslationType
        type: 8bit int
        default: none
        description: TranslationType specifies the type of address to be translated.
                            0x00: TRANSLATE_USER_LBA
                            0x01: TRANSLATE_SYSTEM_LBA
                            0x02: TRANSLATE_USER_LLL_CHS
                            0x03: TRANSLATE_SYSTEM_LLL_CHS
                            0x04: TRANSLATE_PLP_CHS
                            0x05: TRANSLATE_USER_LOGICAL_CYL
                            0x06: TRANSLATE_SYSTEM_LOGICAL_CYL
                            0x07: TRANSLATE_PHYSICAL_CYL
                            0x08: TRANSLATE_LOGICAL_SECTOR
                            0x09: TRANSLATE_PHYSICAL_SECTOR
                            0x0A: TRANSLATE_PLP_CHW
                            0x0B: TRANSLATE_WEDGE
                            0x0C: TRANSLATE_NRZ_SYMBOL_EXTENT_ADDR
                            0x0D: TRANSLATE_USER_PBA
                            0x0E: TRANSLATE_USER_NOMINAL_POSITION
                            0x0F: TRANSLATE_SYSTEM_NOMINAL_POSITION
    @param Lba
        type: 32bit int
        default: none
        description: Lba specifies a System or User Area Disk Logical Block Address.
    @param Pba
        type: 32bit int
        default: none
        description: Pba specifies a Physical Block Address.
    @param Cylinder
        type: 32bit int
        default: none
        description: Cylinder is the cylinder address of the sector or wedge.   
    @param Head
        type: 8bit int
        default: none
        description: Head is the head address of the sector or wedge.
    @param Sector
        type: 16bit int
        default: none
        description: Sector is the sector or wedge address of the sector or wedge.   
    @param Wedge
        type: 16bit int
        default: none
        description: Wedge specifies a Physical Wedge address.
    @param SymbolsFromIndex
        type: 32bit int
        default: none
        description: SymbolsFromIndex is the offset from index of the first NRZ symbol.
    @param LengthInSymbols
        type: 32bit int
        default: none
        description: LengthInSymbols is the number of consecutive NRZ symbols.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_translate_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0030
        Packet.Dfb.Header.RevisionId = 1      
        if 'TranslationType' in kwargs:        
            Packet.Dfb.TranslationType = kwargs['TranslationType']
        if 'Lba' in kwargs:
            Packet.Dfb.TranslationAddr.Lba = kwargs['Lba']
        if 'Pba' in kwargs:
            Packet.Dfb.TranslationAddr.Pba = kwargs['Pba']
        if 'Cylinder' in kwargs:
            Packet.Dfb.TranslationAddr.Cyl = kwargs['Cylinder']
        if 'Head' in kwargs:
            Packet.Dfb.TranslationAddr.Chs.Head = kwargs['Head']
        if 'Sector' in kwargs:
            Packet.Dfb.TranslationAddr.Chs.Sector = kwargs['Sector']
        if 'Wedge' in kwargs:
            Packet.Dfb.TranslationAddr.Wedge = kwargs['Wedge']
        if 'SymbolsFromIndex' in kwargs:
            Packet.Dfb.TranslationAddr.SymbolExtentAddr.SymbolsFromIndex = kwargs['SymbolsFromIndex']
        if 'LengthInSymbols' in kwargs:
            Packet.Dfb.TranslationAddr.SymbolExtentAddr.LengthInSymbols = kwargs['LengthInSymbols']
        
        print(Packet)
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_translate_addr_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetDriveGeometry( **kwargs ):
    """
    Function ID: 0x0031
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 6 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0031
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev6_get_drive_geometry_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetReadWriteControl( **kwargs ):
    """
    Function ID: 0x0032
    Note: DETS diagnostic function
    Description: This function sets the mode and parameters for the read and write operations in the diagnostics.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Options
        type: int
        default: none
        description: none found
    @param EnableDirectWriteMode
        type: int
        default: none
        description: none found    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_rw_control_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0032
        Packet.Dfb.Header.RevisionId = 1
        if 'Options' in kwargs:    
            Packet.Dfb.DiagRwControlParms.DirectWriteMode.Options = kwargs['Options']
        if 'EnableDirectWriteMode' in kwargs:
            Packet.Dfb.DiagRwControlParms.DirectWriteMode.EnableDirectWriteMode = kwargs['EnableDirectWriteMode']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
       
def GetDeviceTemperature( **kwargs ):
    """
    Function ID: 0x0033
    Note: DETS diagnostic function
    Description: This Online Mode diagnostic function will retrieve a temperature measurement that is
                        sensed from the specified temperature measurement device.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param DeviceSelect
        type: int
        default: 0x00
        description: DeviceSelect selects the device from which the temperature is to be retrieved.
                            0x00: THERMISTOR_TEMPERATURE - Specifies thermistor temperature.
                            0x01: PREAMP_TEMPERATURE - Specifies preamp temperature.
                            0x02: CHANNEL_TEMPERATURE - Specifies channel temperature          
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_device_temperature_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0033
        Packet.Dfb.Header.RevisionId = 1
        if 'DeviceSelect' in kwargs:
            Packet.Dfb.DeviceSelect = kwargs['DeviceSelect']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_device_temperature_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
def GetMicrojogAtTargetAddress( **kwargs ): 
    """
    Function ID: 0x0034
    Note: DETS diagnostic function
    Description: This function gets the Micro Jog value for the current target track.  In order to 
                        retrieve the Micro Jog value a seek to the target track is performed. 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0034
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_micro_jog_at_target_addr_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadLongTargetAddress( **kwargs ):
    """
    Function ID: 0x0035
    Note: DETS diagnostic function
    Description: This function performs a Read Long of the Target Sector.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param EnableEccCorrection
        type: int
        default: none
        description: none found
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_long_target_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0035
        Packet.Dfb.Header.RevisionId = 1
        if 'EnableEccCorrection' in kwargs:
            Packet.Dfb.EnableEccCorrection = kwargs['EnableEccCorrection']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
def WriteLongTargetAddress( **kwargs ):
    """
    Function ID: 0x0036
    Note: DETS diagnostic function
    Description: This function performs a Write Long of the Target Sector.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0036
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)
        
def MeasureDiscEccentricity( **kwargs ):
    """
    Function ID: 0x0037
    Note: DETS diagnostic function
    Description: This diagnostic mode function will measure the disc eccentricity. The measurement will be
                         done for all heads at a cylinder location called the zero-skew cylinder. The zero-skew
                         cylinder is calculated to be two-thirds of the stroke from the disc OD.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_measure_disc_eccentricity_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0037
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_measure_disc_eccentricity_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)
        
def SetDiagnosticIdleMode( **kwargs ):
    """
    Function ID: 0x0038
    Note: DETS diagnostic function
    Description: This Online Mode diagnostic function will enable or disable the specified idle mode
                        tasks.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param IdleMode
        type: 32bit int
        default: none
        description: IdleMode specifies the desired state of the Idle Mode features
                    0x00000001: DIAG_STIR
                    0x00000002: DIAG_TCC
                    0x00000004: DIAG_CONTINUOUS_WRITER_HEAT
                    0x00000008: DIAG_MR_BIAS_CHOP
                    0x00000010: DIAG_PFAST
                    0x00000020: DIAG_SELF_SEEK
                    0x00000040: DIAG_CHANNEL_CONT_POWER
                    0x00004000: DIAG_GET_IDLE_STATE
                    0x000000FF: DIAG_POWER_ALL                    
    @param IdleModeMask
        type: 32bit int
        default: none
        description: IdleModeMask is a mask of which idle features are to be altered
                            0x00000001: DIAG_STIR
                            0x00000002: DIAG_TCC
                            0x00000004: DIAG_CONTINUOUS_WRITER_HEAT
                            0x00000008: DIAG_MR_BIAS_CHOP
                            0x00000010: DIAG_PFAST
                            0x00000020: DIAG_SELF_SEEK
                            0x00000040: DIAG_CHANNEL_CONT_POWER
                            0x00004000: DIAG_GET_IDLE_STATE
                            0x000000FF: DIAG_POWER_ALL
    @param Toggle
        type: 8bit int
        default: none
        description: Toggle overrides IdleModeMask when set.  Set indicates to turn everything off
                            if anything is on, or else restore the previous state.
    @param ResetToPowerOnState
        type: boiolean
        default: False
        description: ResetToPowerOnState when TRUE indicates that the idle mode should
                            be restored to the power on default.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_diag_idle_mode_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0038
        Packet.Dfb.Header.RevisionId = 1
        if 'IdleMode' in kwargs:
            Packet.Dfb.IdleMode = kwargs['IdleMode']
        if 'IdleModeMask' in kwargs:
            Packet.Dfb.IdleModeMask = kwargs['IdleModeMask']
        if 'Toggle' in kwargs:
            Packet.Dfb.Toggle = kwargs['Toggle']
        if 'ResetToPowerOnState' in kwargs:
            Packet.Dfb.ResetToPowerOnState = kwargs['ResetToPowerOnState']
        else:
            Packet.Dfb.ResetToPowerOnState = False
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_diag_idle_mode_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetVGAData( **kwargs ):
    """
    Function ID: 0x0039
    Note: DETS diagnostic function
    Description: Execute corresponding operation and read VGA data for all wedges of a revolution.
                         Read Heat, Write Heat and Write Preheat are incremented on each revolution. Increment
                         heater DACs according to step size specified.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param OpType
        type: 8bit int
        default: none
        description:  OpType is used to select one of the supported operation types.
                            0x00: VGAS_READ_SEEK - Indicates read seek and read VGAS to be executed
                            0x01: VGAS_READ_OPERATION - Indicates read operation and read VGAS to be executed
                            0x02: VGAS_WRITE_SEEK - Indicates write seek and read VGAS to be executed
                            0x03: VGAS_WRITE_OPERATION - Indicates write operation and read VGAS to be executed
                            0x04: VGAR_READ_OPERATION - Indicates read operation and read VGAR to be executed
                                  This option is currently not supported for products using dual processors       
    @param StartHt
        type: 16bit int
        default: none
        description:  StartHt specifies the start heater DAC of the data collection operation
    @param EndHt
        type: 16bit int
        default: none
        description:  EndHt specifies the end heater DAC of the data collection operation   
    @param HtInc
        type: 16bit int
        default: none
        description:  HtInc specifies the heater DAC increment step size of the data collection operation   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_vga_data_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0039
        Packet.Dfb.Header.RevisionId = 1
        if 'OpType' in kwargs:
            Packet.Dfb.OpType = kwargs['OpType']
        if 'StartHt' in kwargs:
            Packet.Dfb.StartHt = kwargs['StartHt']
        if 'EndHt' in kwargs:
            Packet.Dfb.EndHt = kwargs['EndHt']
        if 'HtInc' in kwargs:
            Packet.Dfb.HtInc = kwargs['HtInc'] 

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_vga_data_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                    

def GetMemoryBlocks( **kwargs ):
    """
    Function ID: 0x003A
    Note: DETS diagnostic function
    Description: This function gets the specified number of bytes of data from the specified memory 
                        locations.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param MemoryByteOffset
        type: int
        default: none
        description: none found
    @param MemoryBytes
        type: int
        default: none
        description: none found    
    @param NumberOfBytes
        type: int
        default: none
        description: none found
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_memory_blocks_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x003A
        Packet.Dfb.Header.RevisionId = 1
        if 'MemoryByteOffset' in kwargs:
            Packet.Dfb.MemoryByteOffset = kwargs['MemoryByteOffset']
        if 'MemoryBytes' in kwargs:
            Packet.Dfb.MemoryBytes = kwargs['MemoryBytes']
        if 'NumberOfBytes' in kwargs:
            Packet.Dfb.NumberOfBytes = kwargs['NumberOfBytes']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_memory_blocks_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ModifyTrackDefectList( **kwargs ):
    """
    Function ID: 0x003B
    Note: DETS diagnostic function
    Description: This diagnostic mode function will modify the track defect list for the target address
                         or for all sectors on the target track based in the input.  The track can be modified to
                         show that the specified sector is alternated, is in the pending defect list, is defect-
                         free, is in the user area slip list, is in the reserved area slip list, or is removed
                         from the alternate list.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param PhysicalSector
        type: 16bit int
        default: none
        description: PhysicalSector in the physical sector number of the block to be modified.  The cylinder
                            and head come from the target address.
    @param Lba
        type: 32bit int
        default: none
        description: Lba is the logical block address of the block to be modified.
    @param ModificationType
        type: 8bit int
        default: none
        description: ModificationType specifies the type of defect list modification to be
                            performed.

                            0x0A: ADD_TO_ALT_LIST - The given CHS should be added to the alt list.
                            0x0B: ADD_TO_PENDING_LIST - The given CHS should be added to the pending list.
                            0xA1: ADD_LBA_TO_ALT_LIST - The given LBA should be added to the alt list.
                            0xB1: ADD_LBA_TO_PENDING_LIST - The given CHS should be added to the pending list.
                            0xC1: REMOVE_LBA_FROM_ALL - The given LBA should be removed from all defect lists.
                            0xF1: REMOVE_LBA_FROM_ALT_LIST - The given LBA should be removed from the alt list.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_modify_track_defect_list_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x003B
        Packet.Dfb.Header.RevisionId = 2
        if 'PhysicalSector' in kwargs:
            #Packet.Dfb.BlockAddress.PhysicalSector = kwargs['PhysicalSector'] #due to typelib misprint of unions
            Packet.Dfb.BlockAddress = kwargs['PhysicalSector'] #due to typelib misprint of unions
        if 'Lba' in kwargs:
            #Packet.Dfb.BlockAddress.Lba = kwargs['Lba'] #due to typelib misprint of unions
            Packet.Dfb.BlockAddress = kwargs['Lba'] #due to typelib misprint of unions
        if 'ModificationType' in kwargs:
            Packet.Dfb.ModificationType = kwargs['ModificationType']

        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def GetTargetTrackInformation( **kwargs ):
    """
    Function ID: 0x003C
    Note: DETS diagnostic function
    Description: This diagnostic mode function gets information about the current target track.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x003C
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_target_track_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)
        
def GetTargetTrackAndSectorInformation( **kwargs ):
    """
    Function ID: 0x003D
    Note: DETS diagnostic function
    Description: This diagnostic mode function gets information about the current target track and the
                        sectors on the track.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    # Input Parameter :       rev1_generic_sdbp_dfb
# Output Parameter :      rev1_get_target_track_and_sector_info_sdbp_dsb
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x003D
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_target_track_and_sector_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            



def MergeListIntoSlipList( **kwargs ):
    """
    Function ID: 0x003E
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will merge the Alt-List (aka "reassigned sectors
                        list") into the Slip List.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    none
    """
    # Input Parameter :       rev1_generic_sdbp_dfb
# Output Parameter :      rev2_merge_alt_list_into_slip_list_sdbp_dsb
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x003E
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_merge_alt_list_into_slip_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def EraseTargetTrack( **kwargs ):
    """
    Function ID: 0x0040
    Note: DETS diagnostic function
    Description: This function erases the target track and the specified number of tracks on either 
                        side of the target track.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param AdjacentTracksToErase
        type: int
        default: none
        description: NA
    @param EraseCountPerTrack
        type: int
        default: none
        description: NA    
    @param EnableAcErase
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_erase_target_track_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0040
        Packet.Dfb.Header.RevisionId = 1
	    
        if 'AdjacentTracksToErase' in kwargs:            
            Packet.Dfb.AdjacentTracksToErase = kwargs['AdjacentTracksToErase']
        if 'EraseCountPerTrack' in kwargs:
            Packet.Dfb.EraseCountPerTrack = kwargs['EraseCountPerTrack']
        if 'EnableAcErase' in kwargs:
            Packet.Dfb.EnableAcErase = kwargs['EnableAcErase']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SymbolErrorMap( **kwargs ):
    """
    Function ID: 0x004D
    Note: DETS diagnostic function
    Description: This diagnostic mode function will generate and present data on the unreadable symbols
                        on a track.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 1 DSB
    -----revision 1 parameters-----

    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_symbol_error_map_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x004D
        Packet.Dfb.Header.RevisionId = 2

	    #unable to build packet....
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_symbol_error_map_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def GetServoSectorErrorCount( **kwargs ):
    """
    Function ID: 0x004E
    Note: DETS diagnostic function
    Description: This diagnostic mode function will return the sector error count data from servo.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x004E
        Packet.Dfb.Header.RevisionId = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_servo_sector_error_count_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ResetDrive( **kwargs ):
    """
    Function ID: 0x004F
    Note: DETS online function
    Description: This Online Mode diagnostic function will either reset the drive or jump to the Boot
                         Strap Loader.  NOTE: Once invoked, this function will not return and the host-side test
                         environment will have to accommodate this.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 1
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param JumpToBootStrapLoader
        type: boolean
        default: 0
        description: JumpToBootStrapLoader, if TRUE, indicates that the code should jump to the Boot
                            Strap Loader.  If JumpToBootStrapLoader is FALSE, the code will jump to the Power
                            On Reset function.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 1
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_reset_drive_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x004F
        Packet.Dfb.Header.RevisionId = 1
        if 'JumpToBootStrapLoader' in kwargs:
            Packet.Dfb.JumpToBootStrapLoader = kwargs['JumpToBootStrapLoader']
        else:
            Packet.Dfb.JumpToBootStrapLoader = 0
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        print('\nThis is diag does not have a return packet, the drive should be reseting though.')
    else: 
        print('Revision %d is not defined' % Revision)            

def GetServoSectorErrorLog( **kwargs ):
    """
    Function ID: 0x0050
    Note: DETS diagnostic function
    Description: This diagnostic mode function will return the sector error log data from servo.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0050
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_servo_sector_error_log_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def GetServoEventLog( **kwargs ):
    """
    Function ID: 0x0051
    Note: DETS diagnostic function
    Description: This diagnostic mode function will return the event log data from servo.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0051
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_servo_event_log_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def GetPreampHeadResistance( **kwargs ):
    """
    Function ID: 0x0051
    Note: DETS diagnostic function
    Description: This function measures the resistance of the specified heads.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0052
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_preamp_head_resistance_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ButterflySeekTest( **kwargs ):
    """
    Function ID: 0x0053
    Note: DETS diagnostic function
    Description: This diagnostic performs a butterfly seek test as follows:
                        1) Seek to OD cyl, increment OD cyl.  When OD cyl == ID cyl, then
                        begin decrementing OD cyl.
                        2) Seek to ID cyl, decrement ID cyl. When ID cyl == OD cyl, then
                        begin incrementing ID cyl.
                        3) Repeat Steps 1 and 2 until test duration or number of desired
                            seeks is complete.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ParmFirstPhysicalCyl
        type: int
        default: none
        description: NA
    @param ParmSecondPhysicalCyl
        type: int
        default: none
        description: NA
    @param SeekPairTestType
        type: int
        default: none
        description: NA
    @param SeekPairRunType
        type: int
        default: none
        description: NA
    @param NumSeekPairs
        type: int
        default: none
        description: NA
    @param SecsToSeek
        type: int
        default: none
        description: NA
    @param ForceUseOfMinPhysCyl
        type: int
        default: none
        description: NA
    @param ForceUseOfMaxPhysCyl
        type: int
        default: none
        description: NA
    @param LogicalHead
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_butterfly_seek_test_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0053
        Packet.Dfb.Header.RevisionId = 1
        if 'ParmFirstPhysicalCyl' in kwargs:            
            Packet.Dfb.ParmFirstPhysicalCyl = kwargs['ParmFirstPhysicalCyl']
        if 'ParmSecondPhysicalCyl' in kwargs:            
            Packet.Dfb.ParmSecondPhysicalCyl = kwargs['ParmSecondPhysicalCyl']
        if 'SeekPairTestType' in kwargs:            
            Packet.Dfb.SeekPairTestType = kwargs['SeekPairTestType']
        if 'SeekPairRunType' in kwargs:            
            Packet.Dfb.SeekPairRunType = kwargs['SeekPairRunType']
        if 'NumSeekPairs' in kwargs:            
            Packet.Dfb.NumSeekPairs = kwargs['NumSeekPairs']
        if 'SecsToSeek' in kwargs:            
            Packet.Dfb.SecsToSeek = kwargs['SecsToSeek']
        if 'ForceUseOfMinPhysCyl' in kwargs:            
            Packet.Dfb.ForceUseOfMinPhysCyl = kwargs['ForceUseOfMinPhysCyl']
        if 'ForceUseOfMaxPhysCyl' in kwargs:            
            Packet.Dfb.ForceUseOfMaxPhysCyl = kwargs['ForceUseOfMaxPhysCyl']
        if 'LogicalHead' in kwargs:            
            Packet.Dfb.LogicalHead = kwargs['LogicalHead']

        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ModifyReadChannelLock( **kwargs ):
    """
    Function ID: 0x0054
    Note: DETS diagnostic function
    Description: This function modifies the Read Channel lock as specified.  Locking the Read Channel 
                        registers disables them from being updated.  Unlocking the Read Channel registers
                        enables them to be updated.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Operation
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_modify_read_channel_lock_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0054
        Packet.Dfb.Header.RevisionId = 1

        if 'Operation' in kwargs:
            Packet.Dfb.Operation = kwargs['Operation']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_modify_read_channel_lock_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def WriteChannelRegister( **kwargs ):
    """
    Function ID: 0x0055
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RegAddr
        type: int
        default: none
        description: NA
    @param RegData
        type: int
        default: none
        description: NA    
    @param DirectRegAccess
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_wr_read_channel_reg_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0055
        Packet.Dfb.Header.RevisionId = 1
        if 'RegAddr' in kwargs:            
            Packet.Dfb.RegAddr = kwargs['RegAddr']
        if 'RegData' in kwargs:
            Packet.Dfb.RegData = kwargs['RegData']
        if 'DirectRegAccess' in kwargs:
            Packet.Dfb.DirectRegAccess = kwargs['DirectRegAccess']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_wr_read_channel_reg_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ModifyPreampLock( **kwargs ):
    """
    Function ID: 0x0056
    Note: DETS diagnostic function
    Description: This function modifies the Preamp lock as specified.  Locking the Preamp registers
                        disables them from being updated.  Unlocking the Preamp registers enables them to be
                        updated.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----

    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_modify_preamp_lock_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0056
        Packet.Dfb.Header.RevisionId = 1
        if 'Operation' in kwargs:
            Packet.Dfb.Operation = kwargs['Operation']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_modify_preamp_lock_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

        
def ReadPreampRegister( **kwargs ):
    """
    Function ID: 0x0057
    Note: DETS online function
    Description: This Diagnostic Mode diagnostic function reads the specified preamp registers.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param RegPage
        type: int
        default: none
        description: NA
    @param RegAddrOffset
        type: int
        default: none
        description: NA    
    @param NumOfRegsToRd
        type: int
        default: none
        description: NA    
    @param RegBitMask
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rd_preamp_reg_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0057
        Packet.Dfb.Header.RevisionId = 1
        if 'RegPage' in kwargs:
            Packet.Dfb.RegPage = kwargs['RegPage']
        if 'RegAddrOffset' in kwargs:
            Packet.Dfb.RegAddrOffset = kwargs['RegAddrOffset']
        if 'NumOfRegsToRd' in kwargs:
            Packet.Dfb.NumOfRegsToRd = kwargs['NumOfRegsToRd']
        if 'RegBitMask' in kwargs:
            Packet.Dfb.RegBitMask = kwargs['RegBitMask']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_rd_preamp_reg_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def WritePreampRegister( **kwargs ):
    """
    Function ID: 0x0058
    Note: DETS diagnostic function
    Description: This function writes the specified preamp register with the specified value.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RegPage
        type: int
        default: none
        description: NA
    @param RegAddrOffset
        type: int
        default: none
        description: NA    
    @param RegData
        type: int
        default: none
        description: NA    
    @param RegBitMask
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_wr_preamp_reg_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0058
        Packet.Dfb.Header.RevisionId = 1
        if 'RegPage' in kwargs:            
            Packet.Dfb.RegPage = kwargs['RegPage']
        if 'RegAddrOffset' in kwargs:
            Packet.Dfb.RegAddrOffset = kwargs['RegAddrOffset']
        if 'RegData' in kwargs:
            Packet.Dfb.RegData = kwargs['RegData']
        if 'RegBitMask' in kwargs:
            Packet.Dfb.RegBitMask = kwargs['RegBitMask']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_wr_preamp_reg_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                    

def ReadPowerASICRegister( **kwargs ):
    """
    Function ID: 0x0059
    Note: DETS diagnostic function
    Description: This diagnostic mode function reads the specified Power ASIC register addresses from the
                        Servo's Power ASIC using the Servo's own diagnostic commands.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RegAddr
        type: 8bit int
        default: none
        description: RegAddr is the address of the first Power ASIC register to be read.
    @param NumOfRegsToRd
        type: 16bit int
        default: none
        description: NumOfRegsToRd specifies the number of consecutive Power ASIC registers to read.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rd_power_asic_reg_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0059
        Packet.Dfb.Header.RevisionId = 1
        if 'RegAddr' in kwargs:
            Packet.Dfb.RegAddr = kwargs['RegAddr']
        if 'NumOfRegsToRd' in kwargs:
            Packet.Dfb.NumOfRegsToRd = kwargs['NumOfRegsToRd']
            
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rd_power_asic_reg_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def WritePowerASICRegister( **kwargs ):
    """
    Function ID: 0x005A
    Note: DETS diagnostic function
    Description: This diagnostic mode function writes the specified data to the specified register.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RegAddr
        type: 8bit int
        default: none
        description: RegAddr is the address of the Power ASIC register to be written.
    @param RegData
        type: 32bit int
        default: none
        description: RegData is the data with which the Power ASIC register is to be written.  (The
                            diagnostic function handles the register size automatically and will treat the
                            specified value as an 8-bit, 16-bit, or 32-bit value.)
    """

    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_wr_power_asic_reg_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x005A
        Packet.Dfb.Header.RevisionId = 1
        if 'RegAddr' in kwargs:            
            Packet.Dfb.RegAddr = kwargs['RegAddr']
        if 'RegData' in kwargs:
            Packet.Dfb.RegData = kwargs['RegData'] 
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_wr_power_asic_reg_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)
           
def WriteFile( **kwargs ):
    """
    Function ID: 0x005B
    Note: DETS diagnostic function
    Description: This SDBP Diagnostic writes the file data received from the host to the specified file
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FileVolume
        type: 16bit int
        default: none
        description: FileVolume specifies the volume number of the file.
    @param FileId
        type:16bit int
        default: none
        description: FileId specifies the File ID of the file.
    @param FileSelectCopy
        type: 16bit int
        default: none
        description: FileSelectCopy specifies the copy number of the file.
    @param ByteOffset
        type: 32bit int
        default: none
        description: ByteOffset specifies the starting byte address in the file.
    @param BytesToWrite
        type:32bit int
        default: none
        description: BytesToWrite specifies the number of bytes to write
    @param FileData
        type: array of max length 32768 where each element is an 8bit int
        default: none
        description: FileData is the data to write to the file.
                            Where:
                            i = 0 to 32767
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_write_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x005B
        Packet.Dfb.Header.RevisionId = 1
        if 'FileVolume' in kwargs:
            Packet.Dfb.Input.FileVolume = kwargs['FileVolume']
        if 'FileId' in kwargs:            
            Packet.Dfb.Input.FileId = kwargs['FileId']
        if 'FileSelectCopy' in kwargs:            
            Packet.Dfb.Input.FileSelectCopy = kwargs['FileSelectCopy']
        if 'ByteOffset' in kwargs:            
            Packet.Dfb.Input.ByteOffset = kwargs['ByteOffset']
        if 'BytesToWrite' in kwargs:            
            Packet.Dfb.Input.BytesToWrite = kwargs['BytesToWrite']
        
        for i in range( len(kwargs['FileData']) ):
            Packet.Dfb.FileData[i]  = kwargs['FileData'][i]
              
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_write_file_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def DisableEnableServoZAP( **kwargs ):
    """
    Function ID: 0x005C
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function allows control over servo's use of ZAP data.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ChangeZAPControl
        type: boolean
        default: 0
        description: ChangeZAPControl, if TRUE, the ZAP control will be changed to the mode specified by user.
                            If FALSE, ZAP control mode is not changed.
    @param ZAPControlMode
        type: 8bit int
        default: none
        description: ZAPControlMode is the ZAP control mode specified by user.
                            0x00: NO_RRO_CORRECTION
                            0x01: RRO1_FROM_DISC
                            0x02: RRO_FROM_TABLE
                            0x03: RRO_STATE_3
                            0x04: RRO2_FROM_DISC
                            0x05: RRO1_AND_2_FROM_DISC
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_disable_enable_servo_zap_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x005C
        Packet.Dfb.Header.RevisionId = 1
        if 'ChangeZAPControl' in kwargs:            
            Packet.Dfb.ChangeZAPControl = kwargs['ChangeZAPControl']
        else:
            Packet.Dfb.ChangeZAPControl = 0
        if 'ZAPControlMode' in kwargs:
            Packet.Dfb.ZAPControlMode = kwargs['ZAPControlMode']

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_disable_enable_servo_zap_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetServoTracingState( **kwargs ):
    """
    Function ID: 0x005D
    Note: DETS online function
    Description: This Online Mode diagnostic function will set the Servo Tracing State or it will iterate
                        to the next possible Servo Tracing State.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ServoTracingState
        type: 32bit bitfield
        default: none
        description: ServoTracingState is a bit-significant value that specifies how the Servo Tracing State
                            should be updated.

                            Servo Tracing State bits are defined as follows.  The Query bit overrides all the other bits.
                            The Advance bit overrides the state bits.
                               Bit 7 (0x80): Advance         - If set, the Servo tracing state will iterate to the next state.
                               Bit 6 (0x40): Query           - If set, the Servo tracing state will be queried only.
                               Bit 2 (0x04): Servo Command   - If set, servo command tracing will be enabled.
                               Bit 1 (0x02): Servo Response  - If set, servo response tracing will be enabled.
                               Bit 0 (0x01): Servo Error     - If set, servo error tracing will be enabled.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_servo_tracing_state_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x005D
        Packet.Dfb.Header.RevisionId = 1
        if 'ServoTracingState' in kwargs:            
            Packet.Dfb.ServoTracingState = kwargs['ServoTracingState']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_servo_tracing_state_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def ScanTrackForServoDefectsAndZAP( **kwargs ):
    """
    Function ID: 0x005E
    Note: DETS diagnostic function
    Description: This function scans the target track for servo defects and ZAPs. 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ScanReadPosition
        type: int
        default: none
        description: NA
    """
    # Input Parameter :       rev1_scan_track_for_servo_defects_and_zap_sdbp_dfb
# Output Parameter :      rev1_generic_sdbp_dsb
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_scan_track_for_servo_defects_and_zap_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x005E
        Packet.Dfb.Header.RevisionId = 1
        if 'ScanReadPosition' in kwargs:            
            Packet.Dfb.ScanReadPosition = kwargs['ScanReadPosition']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def CreateLogFile( **kwargs ):
    """
    Function ID: 0x005F
    Note: DETS diagnostic function
    Description: This diagnostic function creates the specified log. 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LogId
        type: int
        default: none
        description: NA
    @param LogType
        type: int
        default: none
        description: NA    
    @param LogLocation
        type: int
        default: none
        description: NA    
    @param LogNamePtr
        type: int
        default: none
        description: NA    
    @param LogBytes
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_create_log_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x005F
        Packet.Dfb.Header.RevisionId = 1
        if 'LogId' in kwargs:            
            Packet.Dfb.LogId = kwargs['LogId']
        if 'LogType' in kwargs:
            Packet.Dfb.LogType = kwargs['LogType']
        if 'LogLocation' in kwargs:
            Packet.Dfb.LogLocation = kwargs['LogLocation']
        if 'LogNamePtr' in kwargs:
            Packet.Dfb.LogNamePtr = kwargs['LogNamePtr']
        if 'LogBytes' in kwargs:
            Packet.Dfb.LogBytes = kwargs['LogBytes']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_create_log_file_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def DeleteLogFile( **kwargs ):
    """
    Function ID: 0x0060
    Note: DETS diagnostic function
    Description: This function deletes the specified log.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LogId
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_delete_log_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0060
        Packet.Dfb.Header.RevisionId = 1
        if 'LogId' in kwargs:
            Packet.Dfb.LogId = kwargs['LogId']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def InitializeLogFile( **kwargs ):
    """
    Function ID: 0x0061
    Note: DETS online function
    Description: This function initializes the specified log to be empty.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LogId
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_init_log_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0061
        Packet.Dfb.Header.RevisionId = 1
        if 'LogId' in kwargs:
            Packet.Dfb.LogId = kwargs['LogId']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def CopyLogFile( **kwargs ):
    """
    Function ID: 0x0062
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SrcLogId
        type: int
        default: none
        description: NA
    @param DstLogId
        type: int
        default: none
        description: NA    
    @param Append
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_copy_log_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0062
        Packet.Dfb.Header.RevisionId = 1
        if 'SrcLogId' in kwargs:
            Packet.Dfb.SrcLogId = kwargs['SrcLogId']
        if 'DstLogId' in kwargs:
            Packet.Dfb.DstLogId = kwargs['DstLogId']
        if 'Append' in kwargs:
            Packet.Dfb.Append = kwargs['Append']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                    

def GetLogFileInformation( **kwargs ):
    """
    Function ID: 0x0063
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LogId
        type: int
        default: n one
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_log_file_info_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0063
        Packet.Dfb.Header.RevisionId = 1
        if 'LogId' in kwargs:
            Packet.Dfb.LogId = kwargs['LogId']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_log_file_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetLogFile( **kwargs ):
    """
    Function ID: 0x0064
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LogId
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_log_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0064
        Packet.Dfb.Header.RevisionId = 1
        if 'LogId' in kwargs:
            Packet.Dfb.LogId = kwargs['LogId']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SelectErrorLoggingMode( **kwargs ):
    """
    Function ID: 0x0065
    Note: DETS diagnostic function
    Description: This function selects the specified error logging mode.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ErrorLoggingMode
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_select_error_logging_mode_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0065
        Packet.Dfb.Header.RevisionId = 1
        if 'ErrorLoggingMode' in kwargs:            
            Packet.Dfb.ErrorLoggingMode = kwargs['ErrorLoggingMode']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SelectReadWriteStatisticsLoggingMode( **kwargs ):
    """
    Function ID: 0x0066
    Note: DETS diagnostic function
    Description: This function selects the specified Read / Write Statistics Logging mode.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RwStatisticsLoggingMode
        type: int
        default:  none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_select_rw_statistics_logging_mode_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0066
        Packet.Dfb.Header.RevisionId = 1
        if 'RwStatisticsLoggingMode' in kwargs:            
            Packet.Dfb.RwStatisticsLoggingMode = kwargs['RwStatisticsLoggingMode']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def GenericServoCommand( **kwargs ):
    """
    Function ID: 0x0067
    Note: DETS diagnostic function
    Description: This diagnostic mode diagnostic function sends the generic servo command that is
                         specified by the input parameters.  WARNING: USE WITH CAUTION!  This function can
                         send servo commands that may significantly change the state of the drive and
                         without R/W firmware's awareness.  This may cause asserts.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CommandNum
        type: 16bit int
        default: none
        descritption: CommandNum specifies the Internal Servo Command Number.
    @param Parameters
        type: array of 8bit int elements
        default: none
        descritption: Parameters specifies the Internal Servo Command parameters.
                            Where:
                            i = 0 to 6    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_servo_command_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0067
        Packet.Dfb.Header.RevisionId = 1
        if 'CommandNum' in kwargs:            
            Packet.Dfb.CommandNum = kwargs['CommandNum']
        for i in range( len(kwargs['Parameters']) ):
            Packet.Dfb.Parameters[i] = kwargs['Parameters'][i]
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_servo_command_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def EnableDisableServoUpdates( **kwargs ):
    """
    Function ID: 0x0068
    Note: DETS diagnostic function
    Description: This diagnostic mode diagnostic function can disable either/both VCM DAC updates and
                        A-to-D updates.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DisableVcmDacUpdates
        type: boolean
        default: none
        description: DisableVcmDacUpdates, if TRUE, servo updates of the VCM DAC will be disabled.  If
                            FALSE, servo updates of the VCM DAC will be enabled.   
    @param DisableAtoDUpdates
        type: boolean
        default: none
        description: DisableAtoDUpdates, if TRUE, servo A to D updates will be disabled.  If FALSE, servo
                            A to D updates will be enabled.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_enable_disable_servo_updates_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0068
        Packet.Dfb.Header.RevisionId = 1
        if 'DisableVcmDacUpdates' in kwargs:        
            Packet.Dfb.DisableVcmDacUpdates = kwargs['DisableVcmDacUpdates']
        if 'DisableAtoDUpdates' in kwargs:
            Packet.Dfb.DisableAtoDUpdates = kwargs['DisableAtoDUpdates']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_enable_disable_servo_updates_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadNonvolatileAdaptiveParameters( **kwargs ):
    """
    Function ID: 0x0069
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ReadSap
        type: int
        default: none
        description: NA
    @param ReadRap
        type: int
        default: none
        description: NA    
    @param ReadCap
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_non_volatile_adaptive_parms_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0069
        Packet.Dfb.Header.RevisionId = 1
        if 'ReadSap' in kwargs:            
            Packet.Dfb.ReadSap = kwargs['ReadSap']
        if 'ReadRap' in kwargs:
            Packet.Dfb.ReadRap = kwargs['ReadRap']
        if 'ReadCap' in kwargs:
            Packet.Dfb.ReadCap = kwargs['ReadCap'] 
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ReadFile( **kwargs ):
    """
    Function ID: 0x006A
    Note: DETS diagnostic function
    Description: This SDBP Diagnostic reads a file specified by user.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FileVolume
        type: 16bit int
        default: none
        description: FileVolume specifies the volume number of the file.
    @param FileId
        type: 16bit int
        default: none
        description:   FileId specifies the File ID of the file.  
    @param FileSelectCopy
        type: 16bit int
        default: none
        description: FileSelectCopy specifies the copy number of the file.  
    @param ByteOffset
        type: 32bit int
        default: none
        description:   ByteOffset specifies the starting byte address in the file.  
    @param BytesToRead
        type: 32bit int
        default: none
        description: BytesToRead specifies the number of consecutive number of bytes of the file data.  
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_file_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x006A
        Packet.Dfb.Header.RevisionId = 1
        if 'FileVolume' in kwargs:
            Packet.Dfb.Input.FileVolume = kwargs['FileVolume']
        if 'FileId' in kwargs:
            Packet.Dfb.Input.FileId = kwargs['FileId']
        if 'FileSelectCopy' in kwargs:
            Packet.Dfb.Input.FileSelectCopy = kwargs['FileSelectCopy']
        if 'ByteOffset' in kwargs:
            Packet.Dfb.Input.ByteOffset = kwargs['ByteOffset']
        if 'BytesToRead' in kwargs:
            Packet.Dfb.Input.BytesToRead = kwargs['BytesToRead']    
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_file_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)          
        
def CollectPES( **kwargs ):
    """
    Function ID: 0x006B
    Note: DETS diagnostic function
    Description: This diagnostic mode diagnostic function collects on-track PES data.  The data returned
                         by this function will be an array of 16-bit values representing PES in Q12 format (i.e.
                         4096 counts per track).
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 30
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RevsToCollect
        type: 16bit int
        default: 1
        description: RevsToCollect is the number of servo revolutions worth of PES data to collect.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 30
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_collect_pes_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x006B
        Packet.Dfb.Header.RevisionId = 1
        if 'RevsToCollect' in kwargs:
            Packet.Dfb.RevsToCollect = kwargs['RevsToCollect']
        else: 
            Packet.Dfb.RevsToCollect = 1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_binary_servo_data_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def CollectSeekProfile( **kwargs ):
    """
    Function ID: 0x006C
    Note: DETS diagnostic function
    Description: This diagnostic mode diagnostic function collects seek profile data.  For the case of
                         32 bit PES requested, the data returned will be in the ServoData array as follows:
                            bytes  0 & 1 : Servo Loop Code
                            bytes  2 & 3 : low 16 bits of 32 bit Demod Position Error
                            bytes  4 & 5 : high 16 bits of 32 bit Demod Position Error
                            bytes  6 & 7 : Servo Unsafe Flag
                         These eight bytes will repeat for each servo wedge collected.
                      
                         For the case of 16 bit PES requested, the data returned will be in the ServoData array
                         as follows:
                            bytes  0 & 1 : Servo Loop Code
                            bytes  2 & 3 : 16 bit Demod Position Error
                            bytes  4 & 5 : Servo Unsafe Flag
                         These six bytes will repeat for each servo wedge collected.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param PassThrough
        type: 64bit int
        default: none
        description: PassThrough is a data field that is copied to the Diagnostic
                            Status Block.   
    @param Pes32Bit
        type: 32bit int
        default: none
        description: Pes32Bit if 0 indicates that a 16 bit PES is returned.  If
                            nonzero, a 32 bit PES will be returned.     
    @param WriteSeek
        type: boolean
        default: none
        description: WriteSeek determine the type of seek. TRUE means Write
                            Seek and False means Read Seek.   
    @param SeekLength
        type: 32bit int
        default: none
        description:  SeekLength is the length in tracks to seek away
                            from the current track.   
    @param ExtraRevNum
        type: 16bit int
        default: none
        description:  ExtraRevNum is the number of extra revs to be collected
                            after the head is settled.   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_collect_seek_profile_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x006C
        Packet.Dfb.Header.RevisionId = 2
        if 'PassThrough' in kwargs:            
            Packet.Dfb.PassThrough = kwargs['PassThrough']
        if 'Pes32Bit' in kwargs:
            Packet.Dfb.Pes32Bit = kwargs['Pes32Bit']
        if 'WriteSeek' in kwargs:
            Packet.Dfb.WriteSeek = kwargs['WriteSeek']
        if 'SeekLength' in kwargs:
            Packet.Dfb.SeekLength = kwargs['SeekLength']
        if 'ExtraRevNum' in kwargs:
            Packet.Dfb.ExtraRevNum = kwargs['ExtraRevNum']   

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_binary_servo_data_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)

def SetCongen( **kwargs ):
    """
    Function ID: 0x006C
    Note: DETS diagnostic function
    Description: This function sets the Congen information.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param EnableResetCongen
        type: int
        default: none
        description: NA
    @param Dummy32
        type: int
        default: none
        description: NA    
    @param CongenData
        type: array
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_congen_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0071
        Packet.Dfb.Header.RevisionId = 1
        if 'EnableResetCongen' in kwargs:            
            Packet.Dfb.EnableResetCongen = kwargs['EnableResetCongen']
        if 'Dummy32' in kwargs:
            Packet.Dfb.Dummy32 = kwargs['Dummy32']
        
        for i in range( len(kwargs['CongenData']) ):
            Packet.Dfb.Congen.CongenData[i] = kwargs['CongenData'][i]
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

        
        
def WriteAndCollectServoData( **kwargs ):
    """
    Function ID: 0x006D
    Note: DETS diagnostic function
    Description: This diagnostic mode diagnostic function will write the current track and collect servo
                         data while it's writing.  The servo data collected consists of the following four items
                         repeated until the write is complete:
                     
                            Servo Variable              Symbol Table Index
                            --------------                  ------------------
                            Loop Code                            43d / 2Bh
                            Demod Position Error             12d / 70h
                            Servo Wedge Count               30d / 1Eh
                            Servo Unsafe                        56d / 38h
                     
                         The data will be collected in the order given above and will be repeated until the
                         write operation has completed.  Each element of this data is 16 bits.  The data will
                         end with two instances of the value 0xFFFF.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x006D
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_binary_servo_data_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadZAPFromDiskToTable( **kwargs ):
    """
    Function ID: 0x006E
    Note: DETS diagnostic function
    Description: This function reads ZAP data from Disc to ZAP table.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x006E
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def TweakFlyHeightValues( **kwargs ):
    """
    Function ID: 0x006F
    Note: DETS diagnostic function
    Description: This function tweaks the specified Fly Height values based on the specified
                        temperature.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    Currently unable to build this packet...so the params are unknown
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_tweak_fly_height_values_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x006F
        Packet.Dfb.Header.RevisionId = 1

        #unable to build packet....
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_tweak_fly_height_values_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetBufferBlocks( **kwargs ):
    """
    Function ID: 0x0070
    Note: DETS diagnostic function
    Description: This function gets the specified buffer blocks.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SourceBufferBlockValid
        type: int
        default: none
        description: NA
    @param SourceBufferBlock
        type: int
        default: none
        description: NA    
    @param ReferenceBufferBlockValid
        type: int
        default: none
        description: NA    
    @param ReferenceBufferBlock
        type: int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_buffer_blocks_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0070
        Packet.Dfb.Header.RevisionId = 1
        if 'SourceBufferBlockValid' in kwargs:            
            Packet.Dfb.SourceBufferBlockValid = kwargs['SourceBufferBlockValid']
        if 'SourceBufferBlock' in kwargs:
            Packet.Dfb.SourceBufferBlock = kwargs['SourceBufferBlock']
        if 'ReferenceBufferBlockValid' in kwargs:
            Packet.Dfb.ReferenceBufferBlockValid = kwargs['ReferenceBufferBlockValid']
        if 'ReferenceBufferBlock' in kwargs:
            Packet.Dfb.ReferenceBufferBlock = kwargs['ReferenceBufferBlock']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_buffer_blocks_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SetCongen( **kwargs ):
    """
    Function ID: 0x0071
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param EnableResetCongen
        type: int
        default: none
        description: NA
    @param Dummy32
        type: int
        default: none
        description: NA    
    @param CongenData
        type: array
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_congen_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0071
        Packet.Dfb.Header.RevisionId = 1
        if 'EnableResetCongen' in kwargs:            
            Packet.Dfb.EnableResetCongen = kwargs['EnableResetCongen']
        if 'Dummy32' in kwargs:
            Packet.Dfb.Dummy32 = kwargs['Dummy32']
        for i in range( len(kwargs['CongenData'])):
            Packet.Dfb.Congen.CongenData[i] = kwargs['CongenData'][i]
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetTrackFormat( **kwargs ):
    """
    Function ID: 0x0077
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param UserPartitionTrackFormatType
        type: int
        default: none
        description: NA
    @param SysPartitionTrackFormatType
        type: int
        default: none
        description: NA    
    @param TrackFormatUpdateOption
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_track_format_parms_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0077
        Packet.Dfb.Header.RevisionId = 1
        if 'UserPartitionTrackFormatType' in kwargs:            
            Packet.Dfb.UserPartitionTrackFormatType = kwargs['UserPartitionTrackFormatType']
        if 'SysPartitionTrackFormatType' in kwargs:
            Packet.Dfb.SysPartitionTrackFormatType = kwargs['SysPartitionTrackFormatType']
        if 'TrackFormatUpdateOption' in kwargs:
            Packet.Dfb.TrackFormatUpdateOption = kwargs['TrackFormatUpdateOption']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_track_format_parms_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ForceChannelParameterReload( **kwargs ):
    """
    Function ID: 0x0078
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0078
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def OTCCommand( **kwargs ):
    """
    Function ID: 0x0079
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartingPhySector
        type:  int
        default: none
        description: NA
    @param SectorCount
        type:  int
        default: none
        description: NA
    @param SectorIncrement
        type:  int
        default: none
        description: NA    
    @param HalfOffsetRangeToTry
        type:  int
        default: none
        description: NA    
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_otc_command_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0079
        Packet.Dfb.Header.RevisionId = 1
        if 'StartingPhySector' in kwargs:            
            Packet.Dfb.StartingPhySector = kwargs['StartingPhySector']
        if 'SectorCount' in kwargs:
            Packet.Dfb.SectorCount = kwargs['SectorCount']
        if 'SectorIncrement' in kwargs:
            Packet.Dfb.SectorIncrement = kwargs['SectorIncrement']
        if 'HalfOffsetRangeToTry' in kwargs:
            Packet.Dfb.HalfOffsetRangeToTry = kwargs['HalfOffsetRangeToTry']


        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_otc_command_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                    
        
        
def ChangeWriteFaultThreshold( **kwargs ):
    """
    Function ID: 0x007B
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ChangePositionThreshold
        type: int
        default: none
        description: NA    
    @param NewPositionThreshold
        type: int
        default: none
        description: NA    
    @param ChangeVelocityThreshold
        type: int
        default: none
        description: NA    
    @param NewVelocityThreshold
        type: int
        default: none
        description: NA        
    """
    # Input Parameter :       rev1_change_write_threshold_sdbp_dfb
# Output Parameter :      rev1_change_write_threshold_sdbp_dsb
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_change_write_threshold_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x007B
        Packet.Dfb.Header.RevisionId = 1
        if 'ChangePositionThreshold' in kwargs:
            Packet.Dfb.ChangePositionThreshold = kwargs['ChangePositionThreshold']
        if 'NewPositionThreshold' in kwargs:
            Packet.Dfb.NewPositionThreshold = kwargs['NewPositionThreshold']
        if 'ChangeVelocityThreshold' in kwargs:
            Packet.Dfb.ChangeVelocityThreshold = kwargs['ChangeVelocityThreshold']
        if 'NewVelocityThreshold' in kwargs:
            Packet.Dfb.NewVelocityThreshold = kwargs['NewVelocityThreshold']

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_change_write_threshold_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def ServoDiscSlip( **kwargs ):
    """
    Function ID: 0x00
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param OperationSelectId        
        type: 8bit int
        default: none
        description: OperationSelectId specifies which Servo Disc Operation is to be performed.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_servo_disc_slip_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x007C
        Packet.Dfb.Header.RevisionId = 1
        if 'OperationSelectId' in kwargs:
            Packet.Dfb.OperationSelectId = kwargs['OperationSelectId']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_servo_disc_slip_sdbp_dfb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
        
        
def GetReassignedSectorsList( **kwargs ):
    """
    Function ID: 0x007D
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function retrieves a specified number of entries from
                        the Reassigned Sectors List from the R/W firmware subsystem.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param PassThrough
        type: 32bit  int
        default: none
        description: PassThrough is a field that a diagnostic client can use for any purpose.  This field
                            is simply copied from the DFB to the DSB.
    @param StartIndex
        type: 16bit int
        default: none
        description: StartIndex is the specified starting index.
    @param NumEntriesRequested
        type: 16bit int
        default: none
        description: NumEntriesRequested is the specified number of entries requested.  (If more entries are
                            requested than are in the list, then only the number of entries in the list is returned.)
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_get_reassigned_sectors_list_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x007D
        Packet.Dfb.Header.RevisionId = 2
        if 'PassThrough' in kwargs:
            Packet.Dfb.PassThrough = kwargs['PassThrough']
        if 'StartIndex' in kwargs:
            Packet.Dfb.InputInfo.StartIndex = kwargs['StartIndex']
        if 'NumEntriesRequested' in kwargs:
            Packet.Dfb.InputInfo.NumEntriesRequested = kwargs['NumEntriesRequested']
                  
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_reassigned_sectors_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetSlips(  **kwargs ):
    """
    Function ID: 0x007E
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param ListMask
        type: 
        default: 
        description: 
    @param FlagsMask
        type: 
        default: 
        description: 
    @param ChosenHead
        type: 
        default: 
        description: 
    @param DefectLogicalCylinder
        type: 
        default: 
        description: 
    @param Index
        type: 
        default: 
        description: 
    @param Cylinders
        type: 
        default: 
        description: 
    @param Indices
        type: 
        default: 
        description: 
    @param ExtraSummaryRequested
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_defect_lists_info_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x007E
        Packet.Dfb.Header.RevisionId = 1
        if 'ListMask' in kwargs:
            Packet.Dfb.ListMask = kwargs['ListMask']
        if 'FlagsMask' in kwargs:
            Packet.Dfb.FlagsMask = kwargs['FlagsMask']
        if 'ChosenHead' in kwargs:
            Packet.Dfb.ChosenHead = kwargs['ChosenHead']
        if 'DefectLogicalCylinder' in kwargs:
            Packet.Dfb.StartElement.DefectLogicalCylinder = kwargs['DefectLogicalCylinder']
        if 'Index' in kwargs:
            Packet.Dfb.StartElement.Index = kwargs['Index']
        if 'Cylinders' in kwargs:
            Packet.Dfb.ElementCount.Cylinders = kwargs['Cylinders']
        if 'Indices' in kwargs:
            Packet.Dfb.ElementCount.Indices = kwargs['Indices']
        if 'ExtraSummaryRequested' in kwargs:
            Packet.Dfb.ExtraSummaryRequested = kwargs['ExtraSummaryRequested']
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_slips_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def GetServoFlaws( **kwargs ):
    """
    Function ID: 0x007F
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param ListMask
        type: 
        default: 
        description: 
    @param FlagsMask
        type: 
        default: 
        description: 
    @param ChosenHead
        type: 
        default: 
        description: 
    @param DefectLogicalCylinder
        type: 
        default: 
        description: 
    @param Index
        type: 
        default: 
        description: 
    @param Cylinders
        type: 
        default: 
        description: 
    @param Indices
        type: 
        default: 
        description: 
    @param ExtraSummaryRequested
        type: 
        default: 
        description:
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_defect_lists_info_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x007F
        Packet.Dfb.Header.RevisionId = 1
        if 'ListMask' in kwargs:
            Packet.Dfb.ListMask = kwargs['ListMask']
        if 'FlagsMask' in kwargs:
            Packet.Dfb.FlagsMask = kwargs['FlagsMask']
        if 'ChosenHead' in kwargs:
            Packet.Dfb.ChosenHead = kwargs['ChosenHead']
        if 'DefectLogicalCylinder' in kwargs:
            Packet.Dfb.StartElement.DefectLogicalCylinder = kwargs['DefectLogicalCylinder']
        if 'Index' in kwargs:
            Packet.Dfb.StartElement.Index = kwargs['Index']
        if 'Cylinders' in kwargs:
            Packet.Dfb.ElementCount.Cylinders = kwargs['Cylinders']
        if 'Indices' in kwargs:
            Packet.Dfb.ElementCount.Indices = kwargs['Indices']
        if 'ExtraSummaryRequested' in kwargs:
            Packet.Dfb.ExtraSummaryRequested = kwargs['ExtraSummaryRequested']
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_servo_flaws_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

        
def GetBasicDriveInformation( **kwargs ):
    """
    Function ID: 0x0080
    Note: DETS diagnostic function
    Description: This diagnostic mode function gets a collection of basic drive information.  This
     information includes firmware revision information, hardware information, etc.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    none
    """

    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0080
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_basic_drive_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def CollectPESAndGetRRONRRO( **kwargs ):
    """
    Function ID: 0x0081
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will collect PES data for the specified number
                         of revolutions and return the maximum, minimum, and average PES value for each servo
                         wedge.  It will also return the 3-sigma RRO and NRRO values.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RroRevs
        type: 16bit int
        default: 1
        description: RroRevs is the number of revs to spend to collect PES data to calculate RRO.
    @param NRroRevs
        type: 16bit int
        default: 1
        description: NRroRevs is the number of revs to spend to collect PES data to calculate NRRO.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_collect_pes_and_get_rro_nrro_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0081
        Packet.Dfb.Header.RevisionId = 1
        if 'RroRevs' in kwargs:
            Packet.Dfb.RroRevs = kwargs['RroRevs']
        else:
            Packet.Dfb.RroRevs = 1
        if 'NRroRevs' in kwargs:
            Packet.Dfb.NRroRevs = kwargs['NRroRevs']
        else:
            Packet.Dfb.NRroRevs = 1
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_collect_pes_and_get_rro_nrro_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SetSeekDelay( **kwargs ):
    """
    Function ID: 0x0082
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ChangeSeekDelay
        type: 
        default: 
        description: 
    @param NewSeekDelay
        type: 
        default: 
        description: 
    @param ChangeSeekType
        type: 
        default: 
        description: 
    @param NewSeekTypeSlowSettle
        type: 
        default: 
        description: 
    @param NewSeekTypeLogicalSeek
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_seek_delay_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0082
        Packet.Dfb.Header.RevisionId = 1
        if 'ChangeSeekDelay' in kwargs:
            Packet.Dfb.ChangeSeekDelay = kwargs['ChangeSeekDelay']
        if 'NewSeekDelay' in kwargs:
            Packet.Dfb.NewSeekDelay = kwargs['NewSeekDelay']
        if 'ChangeSeekType' in kwargs:
            Packet.Dfb.ChangeSeekType = kwargs['ChangeSeekType']
        if 'NewSeekTypeSlowSettle' in kwargs:
            Packet.Dfb.NewSeekTypeSlowSettle = kwargs['NewSeekTypeSlowSettle']
        if 'NewSeekTypeLogicalSeek' in kwargs:
            Packet.Dfb.NewSeekTypeLogicalSeek = kwargs['NewSeekTypeLogicalSeek']
            
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_seek_delay_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SmartControl( **kwargs ):
    """
    Function ID: 0x0083
    Note: DETS diagnostic function
    Description: This function handles displaying and modifying SMART data.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Command
        type: 8bit int
        default: none
        description: Command defines the action requested.
                            0x00: TOGGLE_SMART - toggles SMART on/off.
                            0x01: INITIALIZE_SMART_DATA - initializes SMART statistics data (both in RAM and SMART
                            sectors).  Also initializes Fast Flush and Media Cache on the disk and clears the SMART
                            Serial Number Sector.
                            0x02: UPDATE_SMART_ATTRIBUTES - updates SMART's attributes.
                            0x03: SET_CLEAR_PREFAILURE_BIT - sets/clears specified pre-failure warranty bit.
                            0x04: INITIALIZE_SMART - is the same as INITIALIZE_SMART_DATA.
                            0x05: DUMP_SMART_ATTRIBUTES - retrieves SMART's attributes.
                            0x06: DUMP_SMART_THRESHOLDS - retrieves SMART's thresholds.
                            0x07: DUMP_SMART_GLIST - retrieves the G-List.
                            0x08: DUMP_CE_LOG - retrieves the critical event log.
                            0x09: DUMP_PENDING_LIST - retrieves the pending list.
                            0x0B: START_SHORT_DST - start the short DST after next power up or ^T.
                            0x0C: START_LONG_DST - start the long DST after next power up or ^T.
                            0x10: DUMP_2_HR_LOG - retrieves the 2 hr log.
                            0x18: DUMP_RLIST_COUNT - display number of events in the R list.
                            0x23: CLEAR_PERSISTENT_INFO - clears persistent information.
                            0xFF: NO_COMMAND
    @param VariableInput
        type: 16bit int
        default: none
        description: VariableInput is a multi-purpose input variable.
    @param BooleanBitValue
        type: 8bit int
        default: none
        description: BooleanBitValue is a variable used by the 03 command.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_smart_control_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0083
        Packet.Dfb.Header.RevisionId = 1
        if 'Command' in kwargs:
            Packet.Dfb.Command = kwargs['Command']
        if 'VariableInput' in kwargs:
            Packet.Dfb.VariableInput = kwargs['VariableInput']
        if 'BooleanBitValue' in kwargs:
            Packet.Dfb.BooleanBitValue = kwargs['BooleanBitValue']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_smart_control_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
    
def WriteCorrectionBuffer( **kwargs ):
    """
    Function ID: 0x0084
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartAddrOffset
        type: 
        default: 
        description: 
    @param EndAddrOffset
        type: 
        default: 
        description: 
    @param Pattern
        type: 
        default: 
        description: 
    @param CorrectionBufferReadBackOption
        type: 
        default: 
        description:
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_correction_buffer_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0084
        Packet.Dfb.Header.RevisionId = 1
        if 'StartAddrOffset' in kwargs:
            Packet.Dfb.StartAddrOffset = kwargs['StartAddrOffset']
        if 'EndAddrOffset' in kwargs:
            Packet.Dfb.EndAddrOffset = kwargs['EndAddrOffset']
        if 'Pattern' in kwargs:
            Packet.Dfb.Pattern = kwargs['Pattern']
        if 'CorrectionBufferReadBackOption' in kwargs:
            Packet.Dfb.CorrectionBufferReadBackOption = kwargs['CorrectionBufferReadBackOption']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_correction_buffer_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def CopyCorrectionBuffer( **kwargs ):
    """
    Function ID: 0x0085
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SourceAddrOffset
        type: 
        default: 
        description: 
    @param DestinationAddrOffset
        type: 
        default: 
        description: 
    @param SymbolCountOfCorrectionBuffer
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_copy_correction_buffer_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0085
        Packet.Dfb.Header.RevisionId = 1
        if 'SourceAddrOffset' in kwargs:
            Packet.Dfb.SourceAddrOffset = kwargs['SourceAddrOffset']
        if 'DestinationAddrOffset' in kwargs:
            Packet.Dfb.DestinationAddrOffset = kwargs['DestinationAddrOffset']
        if 'SymbolCountOfCorrectionBuffer' in kwargs:
            Packet.Dfb.SymbolCountOfCorrectionBuffer = kwargs['SymbolCountOfCorrectionBuffer']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadCorrectionBuffer( **kwargs ):
    """
    Function ID: 0x0086
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartAddrOffset
        type: 
        default: 
        description: 
    @param EndAddrOffset
        type: 
        default: 
        description: 
    @param Pattern
        type: 
        default: 
        description: 
    @param CorrectionBufferReadBackOption
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_correction_buffer_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0086
        Packet.Dfb.Header.RevisionId = 1
        if 'StartAddrOffset' in kwargs:
            Packet.Dfb.StartAddrOffset = kwargs['StartAddrOffset']
        if 'EndAddrOffset' in kwargs:
            Packet.Dfb.EndAddrOffset = kwargs['EndAddrOffset']
        if 'Pattern' in kwargs:
            Packet.Dfb.Pattern = kwargs['Pattern']
        if 'CorrectionBufferReadBackOption' in kwargs:
            Packet.Dfb.CorrectionBufferReadBackOption = kwargs['CorrectionBufferReadBackOption']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_correction_buffer_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def WriteSuperParityRAM( **kwargs ):
    """
    Function ID: 0x0087
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartAddrOffset
        type: 
        default: 
        description: 
    @param EndAddrOffset
        type: 
        default: 
        description: 
    @param Pattern
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_super_parity_ram_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0087
        Packet.Dfb.Header.RevisionId = 1
        if 'StartAddrOffset' in kwargs:
            Packet.Dfb.StartAddrOffset = kwargs['StartAddrOffset']
        if 'EndAddrOffset' in kwargs:
            Packet.Dfb.EndAddrOffset = kwargs['EndAddrOffset']
        if 'Pattern' in kwargs:
            Packet.Dfb.Pattern = kwargs['Pattern']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_super_parity_ram_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadSuperParityRAM( **kwargs ):
    """
    Function ID: 0x0088
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartAddrOffset
        type: 
        default: 
        description: 
    @param EndAddrOffset
        type: 
        default: 
        description: 
    @param Pattern
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_super_parity_ram_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0088
        Packet.Dfb.Header.RevisionId = 1
        if 'StartAddrOffset' in kwargs:
            Packet.Dfb.StartAddrOffset = kwargs['StartAddrOffset']
        if 'EndAddrOffset' in kwargs:
            Packet.Dfb.EndAddrOffset = kwargs['EndAddrOffset']
        if 'Pattern' in kwargs:
            Packet.Dfb.Pattern = kwargs['Pattern']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_super_parity_ram_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetupReadWriteDataCollection( **kwargs ):
    """
    Function ID: 0x0089
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param BitFieldEnableControllerDataCollection
        type: 
        default: 
        description: 
    @param NumRegs
        type: 
        default: 
        description: 
    @param RegAddr
        type: array of max length 14
        default: none
        description: 
    @param BitMask
        type: array of max length 14
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_setup_rw_data_collection_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0089
        Packet.Dfb.Header.RevisionId = 1
        if 'BitFieldEnableControllerDataCollection' in kwargs:
            Packet.Dfb.Options.BitFieldEnableControllerDataCollection = kwargs['BitFieldEnableControllerDataCollection']
        if 'NumRegs' in kwargs:
            Packet.Dfb.NumRegs = kwargs['NumRegs']      
        for i in range( len(kwargs['RegAddr'])):
            Packet.Dfb.RegAddr[i] = kwargs['RegAddr'][i]
        for i in range( len(kwargs['BitMask'])):
            Packet.Dfb.BitMask[i] = kwargs['BitMask'][i]

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def MSESERRead( **kwargs ):
    """
    Function ID: 0x008A
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x008A
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ProcessReadWriteCollectedData( **kwargs ):
    """
    Function ID: 0x008B
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RawDataValid
        type: 
        default: 
        description: 
    @param NumIgnoredSectors
        type: 
        default: 
        description: 
    @param TrimPercentage
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_process_rw_collected_data_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x008B
        Packet.Dfb.Header.RevisionId = 1
        if 'RawDataValid' in kwargs:
            Packet.Dfb.RawDataValid = kwargs['RawDataValid']
        if 'NumIgnoredSectors' in kwargs:
            Packet.Dfb.NumIgnoredSectors = kwargs['NumIgnoredSectors']
        if 'TrimPercentage' in kwargs:
            Packet.Dfb.TrimPercentage = kwargs['TrimPercentage']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def MeasureSeekAccessTime( **kwargs ):
    """
    Function ID: 0x008C
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LogicalSeeklength
        type: 
        default: 
        description: 
    @param SeekType
        type: 
        default: 
        description: 
    @param NumSeeks
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_measure_seek_access_time_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x008C
        Packet.Dfb.Header.RevisionId = 1
        if 'LogicalSeeklength' in kwargs:
            Packet.Dfb.LogicalSeeklength = kwargs['LogicalSeeklength']
        if 'SeekType' in kwargs:
            Packet.Dfb.SeekType = kwargs['SeekType']
        if 'NumSeeks' in kwargs:
            Packet.Dfb.NumSeeks = kwargs['NumSeeks']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_measure_seek_access_time_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetSeekSpeed( **kwargs ):
    """
    Function ID: 0x008D
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DiagSeekSpeedOptions
        type: 
        default: 
        description: 
    @param DiagSeekSpeed
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_seek_speed_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x008D
        Packet.Dfb.Header.RevisionId = 1
        if 'DiagSeekSpeedOptions' in kwargs:
            Packet.Dfb.DiagSeekSpeedOptions = kwargs['DiagSeekSpeedOptions']
        if 'DiagSeekSpeed' in kwargs:
            Packet.Dfb.DiagSeekSpeed = kwargs['DiagSeekSpeed']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_seek_speed_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
        
def SetEIBTracingState( **kwargs ):
    """
    Function ID: 0x008E
    Note: DETS diagnostic function
    Description: NA
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param EibTracingState
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev2_set_eib_tracing_state_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x008E
        Packet.Dfb.Header.RevisionId = 1
        if 'EibTracingState' in kwargs:
            Packet.Dfb.EibTracingState = kwargs['EibTracingState']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_set_eib_tracing_state_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadWriteStatisticsControl( **kwargs ):
    """
    Function ID: 0x0090
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Mission
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_stats_control_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0090
        Packet.Dfb.Header.RevisionId = 1
        if 'Mission' in kwargs:
            Packet.Dfb.Mission = kwargs['Mission']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_stats_control_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            


        
def GetDriveSelfTestStatus( **kwargs ):
    """
    Function ID: 0x0091
    Note: DETS diagnostic function
    Description: This Online Mode diagnostic function retrieves SMART Drive Self Test functionality.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0091
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_dst_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def EnterServoMatlabShell( **kwargs ):
    """
    Function ID: 0x0092
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 1
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 1
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        print('\nThis diag does not have a return DSB. The drive should now be in matlab mode.') 
    else: 
        print('Revision %d is not defined' % Revision)            

def CollectSeekData( **kwargs ):
    """
    Function ID: 0x0093
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RandomSeek
        type: 
        default: 
        description: 
    @param RandomHeadOnly
        type: 
        default: 
        description: 
    @param Cyl1
        type: 
        default: 
        description: 
    @param Cyl2
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_collect_seek_data_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0093
        Packet.Dfb.Header.RevisionId = 1
        if 'RandomSeek' in kwargs:
            Packet.Dfb.RandomSeek = kwargs['RandomSeek']
        if 'RandomHeadOnly' in kwargs:
            Packet.Dfb.SeekParms.RandomSeekOnly.RandomHeadOnly = kwargs['RandomHeadOnly']
        if 'Cyl1' in kwargs:
            Packet.Dfb.SeekParms.SeekBetweenCyls.Cyl1 = kwargs['Cyl1']
        if 'Cyl2' in kwargs:
            Packet.Dfb.SeekParms.SeekBetweenCyls.Cyl2 = kwargs['Cyl2']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_collect_seek_data_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetSAP( **kwargs ):
    """
    Function ID: 0x0094
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0094
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_sap_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def MeasureThroughput( **kwargs ):
    """
    Function ID: 0x0095
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param MaxCylSkew
        type: 
        default: 
        description: 
    @param MinCylSkew
        type: 
        default: 
        description: 
    @param MaxHeadSkew
        type: 
        default: 
        description: 
    @param MinHeadSkew
        type: 
        default: 
        description: 
    @param MaxMiniZoneSkew
        type: 
        default: 
        description: 
    @param MinMiniZoneSkew
        type: 
        default: 
        description: 
    @param Read
        type: 
        default: 
        description: 
    @param EvenMiniZoneIndex
        type: 
        default: 
        description: 
    @param OddMiniZoneIndex
        type: 
        default: 
        description: 
    @param AllHeads
        type: 
        default: 
        description: 
    @param AllZones
        type: 
        default: 
        description: 
    @param Head
        type: 
        default: 
        description: 
    @param Zone
        type: 
        default: 
        description: 
    @param SkewStepSize
        type: 
        default: 
        description: 
    @param LengthInTracks
        type: 
        default: 
        description: 
    @param OffsetInTracks
        type: 
        default: 
        description: 
    @param MaxNumRetries
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_throughput_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0095
        Packet.Dfb.Header.RevisionId = 2
        if 'MaxCylSkew' in kwargs:
            Packet.Dfb.MaxCylSkew = kwargs['MaxCylSkew']
        if 'MinCylSkew' in kwargs:
            Packet.Dfb.MinCylSkew = kwargs['MinCylSkew']
        if 'MaxHeadSkew' in kwargs:
            Packet.Dfb.MaxHeadSkew = kwargs['MaxHeadSkew']
        if 'MinHeadSkew' in kwargs:
            Packet.Dfb.MinHeadSkew = kwargs['MinHeadSkew']
        if 'MaxMiniZoneSkew' in kwargs:
            Packet.Dfb.MaxMiniZoneSkew = kwargs['MaxMiniZoneSkew']
        if 'MinMiniZoneSkew' in kwargs:
            Packet.Dfb.MinMiniZoneSkew = kwargs['MinMiniZoneSkew']
        if 'Read' in kwargs:
            Packet.Dfb.Read = kwargs['Read']
        if 'EvenMiniZoneIndex' in kwargs:
            Packet.Dfb.EvenMiniZoneIndex = kwargs['EvenMiniZoneIndex']
        if 'OddMiniZoneIndex' in kwargs:
            Packet.Dfb.OddMiniZoneIndex = kwargs['OddMiniZoneIndex']
        if 'AllHeads' in kwargs:
            Packet.Dfb.AllHeads = kwargs['AllHeads']
        if 'AllZones' in kwargs:
            Packet.Dfb.AllZones = kwargs['AllZones']
        if 'Head' in kwargs:
            Packet.Dfb.Head = kwargs['Head']
        if 'Zone' in kwargs:
            Packet.Dfb.Zone = kwargs['Zone']
        if 'SkewStepSize' in kwargs:
            Packet.Dfb.SkewStepSize = kwargs['SkewStepSize']
        if 'LengthInTracks' in kwargs:
            Packet.Dfb.LengthInTracks = kwargs['LengthInTracks']
        if 'OffsetInTracks' in kwargs:
            Packet.Dfb.OffsetInTracks = kwargs['OffsetInTracks']
        if 'MaxNumRetries' in kwargs:
            Packet.Dfb.MaxNumRetries = kwargs['MaxNumRetries']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_throughput_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetCriticalEventLog( **kwargs ):
    """
    Function ID: 0x0097
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0097
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_critical_event_log_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def WriteFaultToggle( **kwargs ):
    """
    Function ID: 0x0098
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param WriteFaultToggleOp
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_write_fault_toggle_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0098
        Packet.Dfb.Header.RevisionId = 1
        if 'WriteFaultToggleOp' in kwargs:
            Packet.Dfb.WriteFaultToggleOp = kwargs['WriteFaultToggleOp']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_write_fault_toggle_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetPList( **kwargs ):
    """
    Function ID: 0x0099
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param ListMask
        type: 
        default: 
        description: 
    @param FlagsMask
        type: 
        default: 
        description: 
    @param ChosenHead
        type: 
        default: 
        description: 
    @param DefectLogicalCylinder
        type: 
        default: 
        description: 
    @param Index
        type: 
        default: 
        description: 
    @param Cylinders
        type: 
        default: 
        description: 
    @param Indices
        type: 
        default: 
        description: 
    @param ExtraSummaryRequested
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_defect_lists_info_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x0099
        Packet.Dfb.Header.RevisionId = 1
        if 'ListMask' in kwargs:
            Packet.Dfb.ListMask = kwargs['ListMask']
        if 'FlagsMask' in kwargs:
            Packet.Dfb.FlagsMask = kwargs['FlagsMask']
        if 'ChosenHead' in kwargs:
            Packet.Dfb.ChosenHead = kwargs['ChosenHead']
        if 'DefectLogicalCylinder' in kwargs:
            Packet.Dfb.StartElement.DefectLogicalCylinder = kwargs['DefectLogicalCylinder']
        if 'Index' in kwargs:
            Packet.Dfb.StartElement.Index = kwargs['Index']
        if 'Cylinders' in kwargs:
            Packet.Dfb.ElementCount.Cylinders = kwargs['Cylinders']
        if 'Indices' in kwargs:
            Packet.Dfb.ElementCount.Indices = kwargs['Indices']
        if 'ExtraSummaryRequested' in kwargs:
            Packet.Dfb.ExtraSummaryRequested = kwargs['ExtraSummaryRequested']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_p_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetPrimaryServoFlaws( **kwargs ):     
    """
    Function ID: 0x009A
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ListMask
        type: 
        default: 
        description: 
    @param FlagsMask
        type: 
        default: 
        description: 
    @param ChosenHead
        type: 
        default: 
        description: 
    @param DefectLogicalCylinder
        type: 
        default: 
        description: 
    @param Index
        type: 
        default: 
        description: 
    @param Cylinders
        type: 
        default: 
        description: 
    @param Indices
        type: 
        default: 
        description: 
    @param ExtraSummaryRequested
        type: 
        default: 
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_defect_lists_info_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x009A
        Packet.Dfb.Header.RevisionId = 1
        if 'ListMask' in kwargs:
            Packet.Dfb.ListMask = kwargs['ListMask']
        if 'FlagsMask' in kwargs:
            Packet.Dfb.FlagsMask = kwargs['FlagsMask']
        if 'ChosenHead' in kwargs:
            Packet.Dfb.ChosenHead = kwargs['ChosenHead']
        if 'DefectLogicalCylinder' in kwargs:
            Packet.Dfb.StartElement.DefectLogicalCylinder = kwargs['DefectLogicalCylinder']
        if 'Index' in kwargs:
            Packet.Dfb.StartElement.Index = kwargs['Index']
        if 'Cylinders' in kwargs:
            Packet.Dfb.ElementCount.Cylinders = kwargs['Cylinders']
        if 'Indices' in kwargs:
            Packet.Dfb.ElementCount.Indices = kwargs['Indices']
        if 'ExtraSummaryRequested' in kwargs:
            Packet.Dfb.ExtraSummaryRequested = kwargs['ExtraSummaryRequested']                

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_primary_servo_flaws_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def EnableDisablePESOutput( **kwargs ):
    """
    Function ID: 0x009B
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function enables PES output on the servo ASIC's AMUX
                        pin with the specified left shift amount.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FetchCurrentSettingOnly
        type: boolean
        default: True
        description: FetchCurrentSettingOnly, if TRUE, obtains the current PES Output setting.  If FALSE,
                            enables or disables PES Output.
    @param EnablePesOutput
        type: boolean
        default: none
        description: EnablePesOutput, if TRUE, and enable PES Output and, if FALSE, disables PES Output.
                            NOTE: This is meaningful only when FetchCurrentSettingOnly is FALSE
    @param PesLeftShiftNumber
        type: 8bit int
        default: none
        description: PesLeftShiftNumber is the left shift to be applied to PES when PES Output is enabled
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_enable_disable_pes_output_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x009B
        Packet.Dfb.Header.RevisionId = 1
        if 'FetchCurrentSettingOnly' in kwargs:
            Packet.Dfb.FetchCurrentSettingOnly = kwargs['FetchCurrentSettingOnly']
        else:
            Packet.Dfb.FetchCurrentSettingOnly = 1
        if 'EnablePesOutput' in kwargs:
            Packet.Dfb.EnablePesOutput = kwargs['EnablePesOutput']
        if 'PesLeftShiftNumber' in kwargs:
            Packet.Dfb.PesLeftShiftNumber = kwargs['PesLeftShiftNumber']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_enable_disable_pes_output_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)             
        
def TweakWritePower( **kwargs ):
    """
    Function ID: 0x009C
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param EnableWritePowerTweak
        type: int
        default: none
        description: NA
    @param UseCurrentThermistorTemperature
        type: int
        default: none
        description: NA
    @param TweakWritePowerOnCurrentHead
        type: int
        default: none
        description: NA
    @param TweakWritePowerOnCurrentZone
        type: int
        default: none
        description: NA
    @param TweakTemperatureInDegreesCelsius
        type: int
        default: none
        description: NA
    @param TweakPartitionId
        type: int
        default: none
        description: NA
    @param TweakHead
        type: int
        default: none
        description: NA
    @param TweakZone
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_tweak_write_power_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x009C
        Packet.Dfb.Header.RevisionId = 1
        if 'EnableWritePowerTweak' in kwargs:
            Packet.Dfb.EnableWritePowerTweak = kwargs['EnableWritePowerTweak']
        if 'UseCurrentThermistorTemperature' in kwargs:
            Packet.Dfb.UseCurrentThermistorTemperature = kwargs['UseCurrentThermistorTemperature']
        if 'TweakWritePowerOnCurrentHead' in kwargs:
            Packet.Dfb.TweakWritePowerOnCurrentHead = kwargs['TweakWritePowerOnCurrentHead']
        if 'TweakWritePowerOnCurrentZone' in kwargs:
            Packet.Dfb.TweakWritePowerOnCurrentZone = kwargs['TweakWritePowerOnCurrentZone']
        if 'TweakTemperatureInDegreesCelsius' in kwargs:
            Packet.Dfb.TweakTemperatureInDegreesCelsius = kwargs['TweakTemperatureInDegreesCelsius']
        if 'TweakPartitionId' in kwargs:
            Packet.Dfb.TweakPartitionId = kwargs['TweakPartitionId']
        if 'TweakHead' in kwargs:
            Packet.Dfb.TweakHead = kwargs['TweakHead']
        if 'TweakZone' in kwargs:
            Packet.Dfb.TweakZone = kwargs['TweakZone']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_tweak_write_power_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetReadWriteWorkingParameters( **kwargs ):
    """
    Function ID: 0x009D
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x009D
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_rw_working_parms_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetReadWriteWorkingParameters( **kwargs ):
    """
    Function ID: 0x009E
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Value
        type: int
        default: none
        description: NA
    @param ParameterId
        type: int
        default: none
        description: NA
    @param HeadToBeSet
        type: int
        default: none
        description: NA
    @param ZoneToBeSet
        type: int
        default: none
        description: NA
    @param MediaPartitionId
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_rw_working_parms_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x009E
        Packet.Dfb.Header.RevisionId = 1
        if 'Value' in kwargs:
            Packet.Dfb.Value = kwargs['Value']
        if 'ParameterId' in kwargs:
            Packet.Dfb.ParameterId = kwargs['ParameterId']
        if 'HeadToBeSet' in kwargs:
            Packet.Dfb.HeadToBeSet = kwargs['HeadToBeSet']
        if 'ZoneToBeSet' in kwargs:
            Packet.Dfb.ZoneToBeSet = kwargs['ZoneToBeSet']
        if 'MediaPartitionId' in kwargs:
            Packet.Dfb.MediaPartitionId = kwargs['MediaPartitionId']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetChannelPreampTracing( **kwargs ):
    """
    Function ID: 0x009F
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function enables or disables Channel/Preamp tracing.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param EnableChannelTracing
        type: 8bit int
        default: none
        description: EnableChannelTracing is the commanded new state of the Channel Tracing feature.
    @param EnablePreampTracing
        type: 8bit int
        default: none
        description: EnablePreampTracing is the commanded new state of the Preamp Tracing feature.
    @param StartingRetry
        type: 16bit int
        default: none
        description: StartingRetry is the retry number at which Channel and Preamp tracing should start (not
                            currently supported).
    @param EndingRetry
        type: 16bit int
        default: none
        description: EndingRetry is the retry number at which Channel and Preamp tracing should end (not
                            currently supported).
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_channel_preamp_tracing_state_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x009F
        Packet.Dfb.Header.RevisionId = 1
        if 'EnableChannelTracing' in kwargs:
            Packet.Dfb.EnableChannelTracing = kwargs['EnableChannelTracing']
        if 'EnablePreampTracing' in kwargs:
            Packet.Dfb.EnablePreampTracing = kwargs['EnablePreampTracing']
        if 'StartingRetry' in kwargs:
            Packet.Dfb.StartingRetry = kwargs['StartingRetry']
        if 'EndingRetry' in kwargs:
            Packet.Dfb.EndingRetry = kwargs['EndingRetry']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_channel_preamp_tracing_state_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def FindMinOrMaxCylinders( **kwargs):
    """
    Function ID: 0x00A0
    Note: DETS diagnostic function
    Description:      This diagnostic mode function will find minimum or maximum cylinder.

                             Find Min (Or Max) Cylinder Algorithm:
                             
                             The head will be moved towards the OD (or ID) while looking for either a seek failure or an
                             abrupt change (avalanche) in a measured parameter called Test Data. The measured parameter
                             may be Acff Magnitude or Bias Current, depending on the type of drive under test. Avalanche
                             detection is complicated by the fact that the Test Data will have some statistical variation
                             (range) around an average value, and that the average value will vary over the cylinder stroke
                             of the drive.
                             
                             Before hunting for the avalanche cylinder, the statistical variation and average must be
                             characterized. To do this, the head is moved to a safe starting location, which is well
                             away from the likely avalanche cylinder, and the average and range of the Test Data are
                             measured over a band of cylinders. To estimate the average value, a low-pass filter is used
                             to reject the statistical variation and only track the average value. Range is estimated by
                             capturing the min and max values of Test Data over the that band of cylinders.
                             
                             The test limit used for avalanche detection is recalculated for each cylinder tested based
                             on the estimated average value and a scaled estimate of the statistical variation.
                             
                             (n)   designates the current sample
                             
                             (n-1) designates the previous sample
                             
                             Range = Max(TestDataValue) - Min(TestDataValue)             (measured over a band of cylinders)
                             
                             K1 = ( 1 / FilterTimeConstant )
                             
                             K2 = ( 1 - K1 )
                             
                             Average(n) = TestDataValue(n) * K1  + Average(n-1) * K2     (this is the filter equation)
                             
                             TestLimit(n) = Average(n) + RANGE_GAIN * Range(n)
                             
                             To find the avalanche cylinder, the head is stepped towards the OD (or ID) and comparing the
                             measured Test Data to the Tst Limit. If the limit is exceeded, or if the seek fails, then the
                             measurement is retried. When the number of retries exceeds the limit, then the current cylinder
                             is designated the Min (or Max) Cylinder.
                             
                             At each cylinder tested, the Cylinder Number, TestData, Average, and Limit data are collected
                             into a circular buffer (pointed to by *TestData). After the Min (or Max) Cylinder has been
                             located, the buffer will be rotated so that the Min (or Max) Cylinder is the last entry in
                             the buffer.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param OperationType
        type: 8bit int
        default: none
        description: OperationType specifies whether the min or max cylinder is to be located.
                            0x00: FIND MIN CYLINDER - specifies that the minimum cylinder will be located.
                            0x01: FIND MAX CYLINDER - specifies that the maximum cylinder will be located.
    @param Head
        type: 8bit int
        default: 0
        description: Head specified the head that will be used during the measurement.
    @param RangeGain
        type: 32bit int
        default: none
        description: RangeGain is used to scale the measured range when computing the test limit
    @param RetryCountLimit
        type: 32bit int
        default: none
        description: RetryCountLimit is the number of retries that when exceeded will designate that the
                            min (or max) cylinder has been detected.
    @param FilterTimeConstant
        type: 32bit int
        default: none
        description: FilterTimeConstant specifies the time constant in samples for the low pass filter.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_find_min_or_max_cylinders_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A0
        Packet.Dfb.Header.RevisionId = 1
        if 'OperationType' in kwargs:
            Packet.Dfb.OperationType = kwargs['OperationType']
        if 'Head' in kwargs:
            Packet.Dfb.Head = kwargs['Head']
        if 'RangeGain' in kwargs:
            Packet.Dfb.RangeGain = kwargs['RangeGain']
        if 'RetryCountLimit' in kwargs:
            Packet.Dfb.RetryCountLimit = kwargs['RetryCountLimit']
        if 'FilterTimeConstant' in kwargs:
            Packet.Dfb.FilterTimeConstant = kwargs['FilterTimeConstant']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_find_min_or_max_cylinders_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadWriteTargetWedge( **kwargs ):
    """
    Function ID: 0x00A3
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param WriteOp
        type: int
        default: none
        description: NA
    @param FormattedWedgeTransfer
        type: int
        default: none
        description: NA
    @param ContinueOnSyncError
        type: int
        default: none
        description: NA
    @param WedgesToSkip
        type: int
        default: none
        description: NA
    @param WedgeSizeInNrzSymbols
        type: int
        default: none
        description: NA
    @param DataCollectionChannelRegs
        type: int
        default: none
        description: NA
    @param DataCollectionChannelRegAddr
        type: array
        default: none
        description: NA
    @param SwapNrzData
        type: int
        default: none
        description: NA
    @param ChannelPatternGeneration
        type: int
        default: none
        description: NA
    @param TSpacing
        type: int
        default: none
        description: NA
    @param BypassChannelCoderateRegConfiguration
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_rw_target_wedge_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A3
        Packet.Dfb.Header.RevisionId = 1
        if 'WriteOp' in kwargs:
            Packet.Dfb.WriteOp = kwargs['WriteOp']
        if 'FormattedWedgeTransfer' in kwargs:
            Packet.Dfb.Options.FormattedWedgeTransfer = kwargs['FormattedWedgeTransfer']
        if 'ContinueOnSyncError' in kwargs:
            Packet.Dfb.Options.ContinueOnSyncError = kwargs['ContinueOnSyncError']
        if 'WedgesToSkip' in kwargs:
            Packet.Dfb.Options.WedgesToSkip = kwargs['WedgesToSkip']
        if 'WedgeSizeInNrzSymbols' in kwargs:
            Packet.Dfb.Options.WedgeSizeInNrzSymbols = kwargs['WedgeSizeInNrzSymbols']
        if 'DataCollectionChannelRegs' in kwargs:
            Packet.Dfb.Options.DataCollectionChannelRegs = kwargs['DataCollectionChannelRegs']
        for i in range( len(kwargs['DataCollectionChannelRegAddr'])):
            Packet.Dfb.Options.DataCollectionChannelRegAddr[i] = kwargs['DataCollectionChannelRegAddr'][i]
        if 'SwapNrzData' in kwargs:
            Packet.Dfb.Options.SwapNrzData = kwargs['SwapNrzData']
        if 'ChannelPatternGeneration' in kwargs:
            Packet.Dfb.Options.ChannelPatternGeneration = kwargs['ChannelPatternGeneration']
        if 'TSpacing' in kwargs:
            Packet.Dfb.Options.TSpacing = kwargs['TSpacing']
        if 'BypassChannelCoderateRegConfiguration' in kwargs:
            Packet.Dfb.Options.BypassChannelCoderateRegConfiguration = kwargs['BypassChannelCoderateRegConfiguration']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_target_wedge_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GoopPlot( **kwargs ):
    """
    Function ID: 0x00A4
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Head
        type: int
        default: none
        description: NA
    @param StartLogicalTrack
        type: int
        default: none
        description: NA
    @param EndLogicalTrack
        type: int
        default: none
        description: NA
    @param TLevelThreshold
        type: int
        default: none
        description: NA
    @param ForceSync
        type: int
        default: none
        description: NA
    @param SkipCount
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_goop_plot_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A4
        Packet.Dfb.Header.RevisionId = 2
        if 'Head' in kwargs:
            Packet.Dfb.Head = kwargs['Head']
        if 'StartLogicalTrack' in kwargs:
            Packet.Dfb.StartLogicalTrack = kwargs['StartLogicalTrack']
        if 'EndLogicalTrack' in kwargs:
            Packet.Dfb.EndLogicalTrack = kwargs['EndLogicalTrack']
        if 'TLevelThreshold' in kwargs:
            Packet.Dfb.TLevelThreshold = kwargs['TLevelThreshold']
        if 'ForceSync' in kwargs:
            Packet.Dfb.ForceSync = kwargs['ForceSync']
        if 'SkipCount' in kwargs:
            Packet.Dfb.SkipCount = kwargs['SkipCount']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_goop_plot_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def EnableDisableRVFF( **kwargs ):
    """
    Function ID: 0x00A5
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FetchCurrentModeOnly
        type: int
        default: none
        description: NA
    @param NewRvffControlMode
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_enable_disable_rvff_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A5
        Packet.Dfb.Header.RevisionId = 1
        if 'FetchCurrentModeOnly' in kwargs:
            Packet.Dfb.FetchCurrentModeOnly = kwargs['FetchCurrentModeOnly']
        if 'NewRvffControlMode' in kwargs:
            Packet.Dfb.NewRvffControlMode = kwargs['NewRvffControlMode']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_enable_disable_rvff_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadUnlockDDRBuffer( **kwargs ):
    """
    Function ID: 0x00A6
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will read or unlock the DDR buffer.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param UnlockDdrBuffer
        type: boolean
        default: none
        description: UnlockDdrBuffer, if TRUE, will unlock the DDR buffer to resume DDR collection.
                            and if FALSE, will read the entire DDR buffer.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_unlock_ddr_buffer_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A6
        Packet.Dfb.Header.RevisionId = 1
        if 'UnlockDdrBuffer' in kwargs:
            Packet.Dfb.UnlockDdrBuffer = kwargs['UnlockDdrBuffer']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_unlock_ddr_buffer_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def FineReadWriteOffset( **kwargs ):
    """
    Function ID: 0x00A7
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will measure the reader-to-writer offset on
                        the current track and head.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TracksToAverage
        type: 16bit int
        default: none
        description: TracksToAverage specifies the number of tracks where fine RW offset values are
                            measured and averaged.
    @param TrkStepSize
        type: 16bit int
        default: none
        description: TrkStepSize specifies the number of tracks between the sample tracks.
    @param NumberOfGuardTrks
        type: 16bit int
        default: none
        description: NumberOfGuardTrks specifieds the number of guard tracks to erase at each side
                            of the smple tracks.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_fine_rw_offset_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A7
        Packet.Dfb.Header.RevisionId = 1
        if 'TracksToAverage' in kwargs:
            Packet.Dfb.TracksToAverage = kwargs['TracksToAverage']
        if 'TrkStepSize' in kwargs:
            Packet.Dfb.TrkStepSize = kwargs['TrkStepSize']
        if 'NumberOfGuardTrks' in kwargs:
            Packet.Dfb.NumberOfGuardTrks = kwargs['NumberOfGuardTrks']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_fine_rw_offset_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ContactDetect( **kwargs ):
    """
    Function ID: 0x00A8
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flags
        type: int
        default: none
        description: NA
    @param Iterations
        type: int
        default: none
        description: NA
    @param BaselineIterations
        type: int
        default: none
        description: NA
    @param StartWedge
        type: int
        default: none
        description: NA
    @param FastIoAWedges
        type: int
        default: none
        description: NA
    @param FastIoBWedges
        type: int
        default: none
        description: NA
    @param FastIoCWedges
        type: int
        default: none
        description: NA
    @param FastIoDWedges
        type: int
        default: none
        description: NA
    @param FastIoEWedges
        type: int
        default: none
        description: NA
    @param InitialHeat
        type: int
        default: none
        description: NA
    @param CoarseHeatIncrement
        type: int
        default: none
        description: NA
    @param FixedPesThreshold
        type: int
        default: none
        description: NA
    @param FilterDelta
        type: int
        default: none
        description: NA
    @param RangeStartPoint
        type: int
        default: none
        description: NA
    @param RangeNumberOfPoints
        type: int
        default: none
        description: NA
    @param AdjustedThresholdSigmaLimit
        type: int
        default: none
        description: NA
    @param VariableContactThreshBackup
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_contact_detect_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A8
        Packet.Dfb.Header.RevisionId = 1
        if 'Flags' in kwargs:
            Packet.Dfb.Flags = kwargs['Flags']
        if 'Iterations' in kwargs:
            Packet.Dfb.Iterations = kwargs['Iterations']
        if 'BaselineIterations' in kwargs:
            Packet.Dfb.BaselineIterations = kwargs['BaselineIterations']
        if 'StartWedge' in kwargs:
            Packet.Dfb.StartWedge = kwargs['StartWedge']
        if 'FastIoAWedges' in kwargs:
            Packet.Dfb.FastIoAWedges = kwargs['FastIoAWedges']
        if 'FastIoBWedges' in kwargs:
            Packet.Dfb.FastIoBWedges = kwargs['FastIoBWedges']
        if 'FastIoCWedges' in kwargs:
            Packet.Dfb.FastIoCWedges = kwargs['FastIoCWedges']
        if 'FastIoDWedges' in kwargs:
            Packet.Dfb.FastIoDWedges = kwargs['FastIoDWedges']
        if 'FastIoEWedges' in kwargs:
            Packet.Dfb.FastIoEWedges = kwargs['FastIoEWedges']
        if 'InitialHeat' in kwargs:
            Packet.Dfb.InitialHeat = kwargs['InitialHeat']
        if 'CoarseHeatIncrement' in kwargs:
            Packet.Dfb.CoarseHeatIncrement = kwargs['CoarseHeatIncrement']
        if 'FixedPesThreshold' in kwargs:
            Packet.Dfb.FixedPesThreshold = kwargs['FixedPesThreshold']
        if 'FilterDelta' in kwargs:
            Packet.Dfb.FilterDelta = kwargs['FilterDelta']
        if 'RangeStartPoint' in kwargs:
            Packet.Dfb.RangeStartPoint = kwargs['RangeStartPoint']
        if 'RangeNumberOfPoints' in kwargs:
            Packet.Dfb.RangeNumberOfPoints = kwargs['RangeNumberOfPoints']
        if 'AdjustedThresholdSigmaLimit' in kwargs:
            Packet.Dfb.AdjustedThresholdSigmaLimit = kwargs['AdjustedThresholdSigmaLimit']
        if 'VariableContactThreshBackup' in kwargs:
            Packet.Dfb.VariableContactThreshBackup = kwargs['VariableContactThreshBackup']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_contact_detect_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SelectServoController( **kwargs ):
#A9 : SelectServoControllerDiag
# Input Parameter :       rev1_select_servo_controller_sdbp_dfb
# Output Parameter :      rev1_select_servo_controller_sdbp_dsb
    """
    Function ID: 0x00A9
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DoAllHeadsMode
        type: int
        default: none
        description: NA
    @param ChangeControllersMode
        type: int
        default: none
        description: NA
    @param ChangeInputShiftMode
        type: int
        default: none
        description: NA
    @param Head
        type: int
        default: none
        description: NA
    @param Controller
        type: int
        default: none
        description: NA
    @param InputShift
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_select_servo_controller_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00A9
        Packet.Dfb.Header.RevisionId = 1
        if 'DoAllHeadsMode' in kwargs:
            Packet.Dfb.DoAllHeadsMode = kwargs['DoAllHeadsMode']
        if 'ChangeControllersMode' in kwargs:
            Packet.Dfb.ChangeControllersMode = kwargs['ChangeControllersMode']
        if 'ChangeInputShiftMode' in kwargs:
            Packet.Dfb.ChangeInputShiftMode = kwargs['ChangeInputShiftMode']
        if 'Head' in kwargs:
            Packet.Dfb.Head = kwargs['Head']
        if 'Controller' in kwargs:
            Packet.Dfb.Controller = kwargs['Controller']
        if 'InputShift' in kwargs:
            Packet.Dfb.InputShift = kwargs['InputShift']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_select_servo_controller_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SlowWriteTargetAddress( **kwargs ):
    """
    Function ID: 0x00AA
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ConsecutiveSectors
        type: int
        default: none
        description: NA
    @param SkipAmount
        type: int
        default: none
        description: NA
    @param SkipUnit
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_slow_write_target_addr_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00AA
        Packet.Dfb.Header.RevisionId = 1
        if 'ConsecutiveSectors' in kwargs:
            Packet.Dfb.ConsecutiveSectors = kwargs['ConsecutiveSectors']
        if 'SkipAmount' in kwargs:
            Packet.Dfb.SkipAmount = kwargs['SkipAmount']
        if 'SkipUnit' in kwargs:
            Packet.Dfb.SkipUnit = kwargs['SkipUnit']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ReadCurrentServoDestination( **kwargs ):
    """
    Function ID: 0x00AB
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00AB
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_current_servo_destination_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def OddEvenEncroachmentTest( **kwargs ):
    """
    Function ID: 0x00AC
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Head
        type: int
        default: none
        description: NA
    @param StartLogicalCylinder
        type: int
        default: none
        description: NA
    @param EndLogicalCylinder
        type: int
        default: none
        description: NA
    @param RetryThreshold
        type: int
        default: none
        description: NA
    @param EccLevelThreshold
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_odd_even_encroachment_test_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00AC
        Packet.Dfb.Header.RevisionId = 1
        if 'Head' in kwargs:
            Packet.Dfb.Head = kwargs['Head']
        if 'StartLogicalCylinder' in kwargs:
            Packet.Dfb.StartLogicalCylinder = kwargs['StartLogicalCylinder']
        if 'EndLogicalCylinder' in kwargs:
            Packet.Dfb.EndLogicalCylinder = kwargs['EndLogicalCylinder']
        if 'RetryThreshold' in kwargs:
            Packet.Dfb.RetryThreshold = kwargs['RetryThreshold']
        if 'EccLevelThreshold' in kwargs:
            Packet.Dfb.EccLevelThreshold = kwargs['EccLevelThreshold']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_odd_even_encroachment_test_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetGList( **kwargs ):
    """
    Function ID: 0x00AE
    Note: DETS diagnostic function
    Description: This diagnostic mode function gets the requested G-List information.
                     
                         NOTE!! This function ONLY supports the following options for the ListMask field:
                     
                            Bit 6 (0x0040h) indicates the non-resident G List.
                            Bit 7 (0x0080h) indicates the resident G List.
                            Bit 8 (0x0100h) indicates the primary defective sectors table.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 3 DSB
    -----revision 1 parameters-----
    @param ListMask
        type: 16bit int
        default: none
        description: ListMask is a bit mask indicating which list to retrieve.  Currently this is used
                            to indicate which lists to return and to indicate whether StartElement and
                            ElementCount (below) specify cylinders, PBAS, or list ordinal numbers.
                            Bit 0  (0x0001) indicates the User Area Slip List
                            Bit 1  (0x0002) indicates the System Area Slip List
                            Bit 2  (0x0004) indicates the Reassigned Sectors List (or Alt List)
                            Bit 3  (0x0008) indicates the Servo Flaws List
                            Bit 4  (0x0010) indicates the Primary Defect List (PLIST)
                            Bit 5  (0x0020) indicates the Primary Servo Flaws List
                            Bit 6  (0x0040) indicates the Nonresident G List
                            Bit 7  (0x0080) indicates the Resident G List
                            Bit 8  (0x0100) indicates the Primary DST List
                            Bit 9  (0x0200) indicates the Data Scrub List (aka "Mickey Cert List")
                            Bit 10 (0x0400) indicates the TA List
                            Bit 11 (0x0800) indicates the Defective Tracks List
                            Bit 15 (0x8000) indicates the request specifies a range of entries
                                         by entry index and entry count instead of cylinder range.
    @param FlagsMask
        type: 16bit int
        default: none
        description: FlagsMask is a bit mask that indicates which types of PLIST entries should be
                            retrieved.  Unless a particular PLIST entry type's bit is set, it will get filtered
                            out of the return data.

                            Bit 0 [0x01]: Servo flaw.
                            Bit 1 [0x02]: Asperity flaw.
                            Bit 2 [0x04]: GList to PList flaw.
                            Bit 3 [0x08]: GList to PList data defect pad fill.
                            Bit 4 [0x10]: GList to PList servo defect pad fill.
                            Bit 5 unused
                            Bit 6 [0x40]: Scratch fill flaw visited.
                            Bit 7 [0x80]: Scratch fill flaw.
    @param ChosenHead
        type: 32bit int
        default: none
        description: ChosenHead specifies which head to return defects for
    @param DefectLogicalCylinder
        type: 32bit int
        default: none
        description: DefectLogicalCylinder is the logical cylinder number of the first list element to be
                            displayed.
    @param Index
        type: 32bit int
        default: none
        description: Index is the list index of the first list element to be displayed.
    @param Cylinders
        type: 32bit int
        default: none
        description: Cylinders is the number of cylinders whose corresponding elements will be displayed.
    @param Indices
        type: 32bit int
        default: none
        description: Indices is the number of list elements that will be displayed.
    @param ExtraSummaryRequested
        type: boolean
        default: none
        description: ExtraSummaryRequested if TRUE (1)  indicates that only special summmary information should be
                            returned.  Works only with USER_RST_LIST_MASK (see ListMask).
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_defect_lists_info_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00AE
        Packet.Dfb.Header.RevisionId = 1
        if 'ListMask' in kwargs:
            Packet.Dfb.ListMask = kwargs['ListMask']
        if 'FlagsMask' in kwargs:
            Packet.Dfb.FlagsMask = kwargs['FlagsMask']
        if 'ChosenHead' in kwargs:
            Packet.Dfb.ChosenHead = kwargs['ChosenHead']
        if 'DefectLogicalCylinder' in kwargs:
            #Packet.Dfb.StartElement.DefectLogicalCylinder = kwargs['DefectLogicalCylinder'] #due to misprint of unions
            Packet.Dfb.StartElement.DefectLogicalCylinder = kwargs['DefectLogicalCylinder']
        if 'Index' in kwargs:
            #Packet.Dfb.StartElement.Index = kwargs['Index'] #due to typelib misprint of unions
            Packet.Dfb.StartElement = kwargs['Index']
        if 'Cylinders' in kwargs:
            Packet.Dfb.ElementCount.Cylinders = kwargs['Cylinders']
        if 'Indices' in kwargs:
            Packet.Dfb.ElementCount.Indices = kwargs['Indices']
        if 'ExtraSummaryRequested' in kwargs:
            Packet.Dfb.ExtraSummaryRequested = kwargs['ExtraSummaryRequested']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev3_get_g_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            


def SaveAdaptivesToFlash( **kwargs ):
    """
    Function ID: 0x00AF
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will write the specified adaptives to non-
                        volatile memory.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param AdaptivesSelect
        type: 8bit int
        default: none
        description: AdaptivesSelect indicates which suite of adaptives should be saved to flash.
                            0x00: DIAG_CAP_FLASH_SEGMENT_ID - CAP ( Controller Adaptive Parameters )
                            0x01: DIAG_SAP_FLASH_SEGMENT_ID - SAP ( Servo Adaptive Parameters )
                            0x02: DIAG_RAP_FLASH_SEGMENT_ID - RAP ( Read/Write Adaptive Parameters )
                            0x03: DIAG_IAP_FLASH_SEGMENT_ID - IAP ( Interface Adaptive Parameters )
    @param DebugFlashWriteEnable
        type: 32bit int
        default: none
        description: DebugFlashWriteEnable is a flag that must be set TRUE to actually write the flash.
                            This feature is used for debug and is handy for testing the code path without affecting
                            the flash.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_save_adaptives_to_flash_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00AF
        Packet.Dfb.Header.RevisionId = 1
        if 'AdaptivesSelect' in kwargs:
            Packet.Dfb.AdaptivesSelect = kwargs['AdaptivesSelect']
        if 'DebugFlashWriteEnable' in kwargs:
            Packet.Dfb.DebugFlashWriteEnable = kwargs['DebugFlashWriteEnable']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            
  
def ServoBodePlot( **kwargs ):
    """
    Function ID: 0x00B0
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will perform a specified type of freqency
                     analysis of the servo loop.  This function can perform the following types of Bode
                     Plots:

                        Note: for the following measurements, Signal1 is the 'output', Signal2 is the 'input',
                        and the transfer function is output/input = Signal1/Signal2.  The labels specified for
                        Signal1, Signal2, and Injection for each of the Bode plot types are the actual variables
                        being sampled from the servo firmware.
                        
                        0x00: OPEN_LOOP_VCM_DISTURBANCE_CURRENT - the diagnostic will be configured for an
                        open-loop bode measurement, using vcm current disturbance.
                           Signal1:    i16_Current2,
                           Signal2:    i16_Current2Out,
                           Injection:  i16_TrackingVcmDisturbanceCurrent
                                                                                       
                        0x01: CLOSED_LOOP_VCM_DISTURBANCE_CURRENT - the diagnostic will be configured for a
                        closed-loop bode measurement, using vcm current disturbance.
                           Signal1:    i16_Current2,
                           Signal2:    i16_TrackingVcmDisturbanceCurrent,
                           Injection:  i16_TrackingVcmDisturbanceCurrent
                        
                        0x02: STRUCTRUAL_VCM_DISTURBANCE_CURRENT - the diagnostic will be configured for a
                        structrual bode measurement, using vcm current disturbance.
                           Signal1:    i16_DemodPositionError,
                           Signal2:    i16_Current2Out,
                           Injection:  i16_TrackingVcmDisturbanceCurrent
                        
                        0x03: OPEN_LOOP_POSITION_DISTURBANCE - the diagnostic will be configured for an open-
                        loop bode measurement, using position disturbance.
                           Signal1:    i16_DemodPositionMeasurementIn,
                           Signal2:    i16_DemodPositionMeasurementOut,
                           Injection:  i16_TrackingDemodDisturbancePosition
                        
                        0x04: SENSITIVITY_POSITION_DISTURBANCE - the diagnostic will be configured for a
                        sensitivity measurement, using position disturbance.
                           Signal1:    i16_DemodPositionError,
                           Signal2:    i16_TrackingDemodDisturbancePosition,
                           Injection:  i16_TrackingDemodDisturbancePosition
                 
                     This function will also return the time domain data associated with the last frequency
                     specified by the input parameters.

    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param BodeType
        type: 8bit int
        default: none
        description:    	
                        BodeType specifies the type of bode measurement to be done.
                        0x00: OPEN_LOOP_VCM_DISTURBANCE_CURRENT
                        0x01: CLOSED_LOOP_VCM_DISTURBANCE_CURRENT
                        0x02: STRUCTRUAL_VCM_DISTURBANCE_CURRENT
                        0x03: OPEN_LOOP_POSITION_DISTURBANCE
                        0x04: SENSITIVITY_POSITION_DISTURBANCE
    @param InjectedAmplitude
        type: 16bit int
        default: none
        description: InjectedAmplitude is the magnitude of the injected distrubance.
    @param FreqMinInHz
        type: 32bit int
        default: none
        description: FreqMinInHz is the lowest frequency in Hertz for the bode frequency response
                            measurement.  
    @param FreqMaxInHz
        type: 32bit int
        default: none
        description: FreqMaxInHz is the highest frequency in Hertz for the bode frequency response
                            measurement.
    @param NumberOfFreq
        type: 16bit int
        default: none
        description: NumberOfFreq is the number of frequencies between FreqMinInHz and FreqMaxInHz
                            to use.
    @param NumberOfSamples
        type: 32bit int
        default: none
        description: NumberOfSamples is the number of samples to collect for each frequency for the
                            DFT.
    @param EnableTracing
        type: 8bit int
        default: none
        description: EnableTracing is a serial port diagnostic command feature and is ignored by the
                            diagnostic function.  This should be treated as a reserved field for the Servo
                            Bode Plot Diagnostic Function.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_servo_bode_plot_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00B0
        Packet.Dfb.Header.RevisionId = 1
        if 'BodeType' in kwargs:
            Packet.Dfb.BodeType = kwargs['BodeType']
        if 'InjectedAmplitude' in kwargs:
            Packet.Dfb.InjectedAmplitude = kwargs['InjectedAmplitude']
        if 'FreqMinInHz' in kwargs:
            Packet.Dfb.FreqMinInHz = kwargs['FreqMinInHz']
        if 'FreqMaxInHz' in kwargs:
            Packet.Dfb.FreqMaxInHz = kwargs['FreqMaxInHz']
        if 'NumberOfFreq' in kwargs:
            Packet.Dfb.NumberOfFreq = kwargs['NumberOfFreq']
        if 'NumberOfSamples' in kwargs:
            Packet.Dfb.NumberOfSamples = kwargs['NumberOfSamples']
        if 'EnableTracing' in kwargs:
            Packet.Dfb.EnableTracing = kwargs['EnableTracing']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_servo_bode_plot_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetSerialPortBaudRate( **kwargs ):
    """
    Function ID: 0x00B2
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function will set the serial port baud rate.  This
                         function will also return a list of supported baud rates.  Specifying a new baud rate
                         of 0 (or any other invalid baud rate) is a useful way to determine what baud rates
                         are supported by the diagnostic firmware.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RequestedBaudRate
        type: 32bit int
        default: none
        description: RequestedBaudRate is the new baud rate requested.  No action is taken if an
                            unsupported Baud rate is specified
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_set_serial_port_baud_rate_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00B2
        Packet.Dfb.Header.RevisionId = 1
        if 'RequestedBaudRate' in kwargs:
            Packet.Dfb.RequestedBaudRate = kwargs['RequestedBaudRate']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_set_serial_port_baud_rate_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def CorruptLBA( **kwargs ):
    """
    Function ID: 0x00B4
    Note: DETS diagnostic function
    Description: Added support for using symbols for specifying the corruption parameters. Previously
                       only bytes were supported.
                       Added support for corrupting multiple bursts within a block. Currently up to 256
                       bursts are supported.
                       Changed the way user specifies the region for random corruption such that the user
                       can select it any way wanted.
                       Revision 2 has superseded revision 1 and revision 1 is no longer supported.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Lba
        type: 32bit int
        default: none
        description: Lba is the LBA number for the first block of the consecutive block(s) to be corrupted.
    @param NumBlocks
        type: 32bit int
        default: none 
        description: NumBlocks is the number of blocks to be corrupted.
    @param BitFieldEnableEccCorrection
        type: 8bit bitfield
        default: none
        description: 
                        Bit 1:
                        EnableByteUnit is the flag, when set, that indicates the burst information in the
                        BurstInfo[] array below is in byte unit, otherwisw the burst information is
                        in symbol unit.

                        Bit 0:
                        EnableEccCorrection is the flag, when set, that enables ECC correction duing Read Long
                        operation part of the Corrupt LBA Diagnostic function.
    @param NumBursts
        type: 32bit int
        default: none
        description: NumBursts is the number of bursts available in the BurstInfo[] array below.
    @param BurstInfo
        type: array of max length 256
        default: none
        description: BurstInfo is an array wherein each element is a 3-element array consisting of [BurstOffset, NumberOfOffsetsToCorrupt, SpanForRandomCorrupt]
        @param BurstOffset
            type: 16bit int
            default: none
            description: BurstOffset is the starting offset number indicating where the corruption should occur.
        @param NumberOfOffsetsToCorrupt
            type: 16bit int
            default: none
            description: NumberOfOffsetsToCorrupt specifies the region from the starting offset to corrupt within each block.
        @param SpanForRandomCorrupt
            type: 16bit int
            default: none
            description: SpanForRandomCorrupt, if it's not zero, specifies the number of bytes or symbols to
                                corrupt randomly within the region specified by the BurstOffset and BurstSpan.      
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_corrupt_lba_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00B4
        Packet.Dfb.Header.RevisionId = 2
        if 'Lba' in kwargs:
            Packet.Dfb.Lba = kwargs['Lba']                
        if 'NumBlocks' in kwargs:
            Packet.Dfb.NumBlocks = kwargs['NumBlocks']                
        if 'BitFieldEnableEccCorrection' in kwargs:
            Packet.Dfb.BitFieldEnableEccCorrection = kwargs['BitFieldEnableEccCorrection']                
        if 'NumBursts' in kwargs:
            Packet.Dfb.NumBursts = kwargs['NumBursts']

        i = 0
        for [BurstOffset, NumberOfOffsetsToCorrupt, SpanForRandomCorrupt] in BurstInfo:
            Packet.Dfb.BurstInfo[i].BurstOffset = BurstOffset
            Packet.Dfb.BurstInfo[i].NumberOfOffsetsToCorrupt = NumberOfOffsetsToCorrupt
            Packet.Dfb.BurstInfo[i].SpanForRandomCorrupt = SpanForRandomCorrupt
            i+=1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_rw_op_status_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def MeasureLatchForce( **kwargs ):
    """
    Function ID: 0x00B5
    Note: DETS diagnostic function
    Description: currently unable to build packet
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----

    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_measure_latch_force_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00B5
        Packet.Dfb.Header.RevisionId = 1

        #unable to build packet
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_measure_latch_force_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def HeadDegradation( **kwargs ):
    """
    Function ID: 0x00B7
    Note: DETS diagnostic function
    Description: currently unable to build dfb
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----

    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_head_degradation_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00
        Packet.Dfb.Header.RevisionId = 1
        
        #currently unable to build dfb
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_head_degradation_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def HeadSmashTest( **kwargs ):
    """
    Function ID: 0x00B9
    Note: DETS diagnostic function
    Description: This function performs head crash test with the specified current and time.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param HeadDirection
        type: 16bit int
        default: none
        description: HeadDirection describes the direction the head is going to move
                           0: Move towards OD
                           1: Move towards ID   
    @param AccelerationTime
        type: 16bit int
        default: none
        description: AccelerationTime is the acceleration time (in 0.1 ms uint) to be used for the test
    @param DecelerationTime
        type: 16bit int
        default: none
        description: DecelerationTime is the deceleration time (in 0.1 ms uint) to be used for the test
    @param AccelerationCurrent
        type: 16bit int
        default: none
        description: AccelerationCurrent is the acceleration current (in mA unit) to be used for the test
    @param DecelerationCurrent
        type: 16bit int
        default: none
        description: DecelerationCurrent is the deceleration current (in mA unit) to be used for the test
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_head_smash_test_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00B9
        Packet.Dfb.Header.RevisionId = 1
        if 'HeadDirection' in kwargs:
            Packet.Dfb.HeadDirection = kwargs['HeadDirection']
        if 'AccelerationTime' in kwargs:
            Packet.Dfb.AccelerationTime = kwargs['AccelerationTime']
        if 'DecelerationTime' in kwargs:
            Packet.Dfb.DecelerationTime = kwargs['DecelerationTime']
        if 'AccelerationCurrent' in kwargs:
            Packet.Dfb.AccelerationCurrent = kwargs['AccelerationCurrent']
        if 'DecelerationCurrent' in kwargs:
            Packet.Dfb.DecelerationCurrent = kwargs['DecelerationCurrent']        
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def CalibrateClearanceCoefficientsAdjustment( **kwargs ):
    """
    Function ID: 0x00BA
    Note: DETS diagnostic function
    Description: This diagnostic mode function calibrates the Clearance Coefficients Adjustments at the given track position
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param CylOrRadius
        type: 32bit int
        default: none
        description: Cylinder ( Norminal or Read/Write ) or Radius (mils) input
    @param Head
        type: 16bit int
        default: none
        description: Head input
    @param Iterations
        type: 16bit int
        default: none
        description: Number of revolutions to average for each heater DAC
    @param ControlFlags
        type: 32bit bitfield
        default: none
        description: Control Flag input
                            Bit [2:0]  : calibration pattern
                                         1 selects 2T pattern
                                         2 selects 4T pattern
                                         3 selects 6T pattern
                            Bit [3]    : If set, don't prep(erase and write) the calibration track
                            Bit [6:4]  : write pattern, if used, for FASTIO
                                         0 selects 1T pattern
                                         1 selects 2T pattern
                                         4 selects 8T pattern
                                         5 selects scrambled pattern
                            Bit [7]    : If set, select Heater Only calibration.
                                         If cleared, select Write+Heat calibration which is currently not supported
                            Bit [8]    : For Clearance Coefficients Adjustment Calibration (HIRP) Diag,
                                         if set, use starting and ending Heater DAC values specified by user
                            Bit [8]    : For MD Contact Detect Diag, if set, find contact heater DAC value
                            Bit [10:9] : Track Position Validity input
                                         0 Input cylinder/head input is Nominal track position
                                         1 Input cylinder/head input is Read/Write track position
                                         2 Input radius/head input is Radius track position
                            Bit [11]   : If set, use the process adapted values for FIR taps
                            Bit [12]   : If set, ouput debug data, if any.
                            Bit [13]   : If set, collect and ouput raw measurements data
                            Bit [14]   : If set, dump channel registers settings during the calibration
                            Bit [15]   : If set, use the process adapted values for NPML taps
                            Bit [16]   : Save Channel Calibration Processor Registers to AFH sim file.
                            Bit [17]   : Restore Channel Calibration Processor Registers from AFH sim file.
                            Bit [18]   : If set, collect raw measurements data
                            Bit [19]   : If set, don't opti ATTR during HscMeasurementOpti, just opti VGAR with a fixed ATTR.
    @param WriteCurrentInput
        type: 16bit int
        default: none
        description: Write Current input
    @param WriteDampingInput
        type: 16bit int
        default: none
        description: Write Current Damping input
    @param WriteDampingDurationInput
        type: 16bit int
        default: none
        description: Write Current Damping Duration input
    @param PreHeaterStart
        type: 16bit int
        default: none
        description: Starting preheater DAC input
    @param HeaterStart
        type: 16bit int
        default: none
        description: Starting heater DAC input
    @param HeaterEnd
        type: 16bit int
        default: none
        description: Ending heater DAC input
                            If this has non-zero value, then PctOfTgtClr is ignored.
    @param HeaterIncrement
        type: 16bit int
        default: none
        description: Heater DAC increment input
    @param CorrelationThreshold
        type: 16bit int
        default: none
        description: If r^2 if below this theshold, test will be retried
    @param MeasureRetries
        type: 16bit int
        default: none
        description: Test will retry this number of times if r^2 is below threshold
    @param PctOfBpi
        type: 8bit int
        default: none
        description: Percentage of BPI to use during measurement
    @param PctOfTgtClr
        type: 8bit int
        default: none
        description: Percentage of target clearance to use when calculating ending heater
    @param UpperHiwpLimit
        type: 32bit int
        default: none
        description: Upper limit of coefficents calculated HIWP to include in regression data set
    @param LowerHiwpLimit
        type: 32bit int
        default: none
        description: Lower limit of coefficents calculated HIWP to include in regression data set
    @param AgcValue
        type: 16bit int
        default: none
        description: NAGain( VGAR ) input
    @param CTFFR
        type: 16bit int
        default: none
        description: CTFFR input   
    @param ATT2R
        type: 8bit int
        default: none
        description: ATT2R input
    @param HscLength
        type: 16bit int
        default: none
        description: HSC integration length
    @param APreWrNumSvoWedges
        type: 16bit int
        default: none
        description: A for FASTIO operation
    @param BWrNumSvoWedges
        type: 16bit int
        default: none
        description: B for FASTIO operation
    @param CPostWrNumSvoWedges
        type: 16bit int
        default: none
        description: C for FASTIO operation
    @param DRdNumSvoWedges
        type: 16bit int
        default: none
        description: D for FASTIO operation
    @param ETrailingNumSvoWedges
        type: 16bit int
        default: none
        description: E for FASTIO operation
    @param DebugFlag
        type: int
        default: none
        description: DebugFlag is a flag for debugging purpose only
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_cal_clearance_coefs_adj_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00BA
        Packet.Dfb.Header.RevisionId = 1
        if 'CylOrRadius' in kwargs:
            Packet.Dfb.UserInput.CylOrRadius = kwargs['CylOrRadius']
        if 'Head' in kwargs:
            Packet.Dfb.UserInput.Head = kwargs['Head']
        if 'Iterations' in kwargs:
            Packet.Dfb.UserInput.Iterations = kwargs['Iterations']
        if 'ControlFlags' in kwargs:
            Packet.Dfb.UserInput.ControlFlags = kwargs['ControlFlags']
        if 'WriteCurrentInput' in kwargs:
            Packet.Dfb.UserInput.WriteCurrentInput = kwargs['WriteCurrentInput']
        if 'WriteDampingInput' in kwargs:
            Packet.Dfb.UserInput.WriteDampingInput = kwargs['WriteDampingInput']
        if 'WriteDampingDurationInput' in kwargs:
            Packet.Dfb.UserInput.WriteDampingDurationInput = kwargs['WriteDampingDurationInput']
        if 'PreHeaterStart' in kwargs:
            Packet.Dfb.UserInput.PreHeaterStart = kwargs['PreHeaterStart']
        if 'HeaterStart' in kwargs:
            Packet.Dfb.UserInput.HeaterStart = kwargs['HeaterStart']
        if 'HeaterEnd' in kwargs:
            Packet.Dfb.UserInput.HeaterEnd = kwargs['HeaterEnd']
        if 'HeaterIncrement' in kwargs:
            Packet.Dfb.UserInput.HeaterIncrement = kwargs['HeaterIncrement']
        if 'CorrelationThreshold' in kwargs:
            Packet.Dfb.UserInput.CorrelationThreshold = kwargs['CorrelationThreshold']
        if 'MeasureRetries' in kwargs:
            Packet.Dfb.UserInput.MeasureRetries = kwargs['MeasureRetries']
        if 'PctOfBpi' in kwargs:
            Packet.Dfb.UserInput.PctOfBpi = kwargs['PctOfBpi']
        if 'PctOfTgtClr' in kwargs:
            Packet.Dfb.UserInput.PctOfTgtClr = kwargs['PctOfTgtClr']
        if 'UpperHiwpLimit' in kwargs:
            Packet.Dfb.UserInput.UpperHiwpLimit = kwargs['UpperHiwpLimit']
        if 'LowerHiwpLimit' in kwargs:
            Packet.Dfb.UserInput.LowerHiwpLimit = kwargs['LowerHiwpLimit']
        if 'AgcValue' in kwargs:
            Packet.Dfb.UserInput.AgcValue = kwargs['AgcValue']
        if 'CTFFR' in kwargs:
            Packet.Dfb.UserInput.CTFFR = kwargs['CTFFR']
        if 'ATT2R' in kwargs:
            Packet.Dfb.UserInput.ATT2R = kwargs['ATT2R']
        if 'HscLength' in kwargs:
            Packet.Dfb.UserInput.HscLength = kwargs['HscLength']
        if 'APreWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.APreWrNumSvoWedges = kwargs['APreWrNumSvoWedges']
        if 'BWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.BWrNumSvoWedges = kwargs['BWrNumSvoWedges']
        if 'CPostWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.CPostWrNumSvoWedges = kwargs['CPostWrNumSvoWedges']
        if 'DRdNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.DRdNumSvoWedges = kwargs['DRdNumSvoWedges']
        if 'ETrailingNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.ETrailingNumSvoWedges = kwargs['ETrailingNumSvoWedges']
        if 'DebugFlag' in kwargs:
            Packet.Dfb.UserInput.DebugFlag = kwargs['DebugFlag']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_cal_clearance_coefs_adj_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def MDModulationDetectionContactDetect( **kwargs ):
    """
    Function ID: 0x00BC
    Note: DETS diagnostic function
    Description: This SDBP Diagnostic executes MD(Modulation Detection) Contact Detect Diag at the given track position
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    @param CylOrRadius
        type: 32bit int
        default: none
        description: Cylinder ( Norminal or Read/Write ) or Radius (mils) input
    @param Head
        type: 16bit int
        default: none
        description: Head input
    @param Iterations
        type: 16bit int
        default: none
        description: Number of revolutions to average for each heater DAC
    @param ControlFlags
        type: 32bit int
        default: none
        description: Control Flags input
                            Bit [2:0]  : calibration pattern
                                         1 selects 2T pattern
                                         2 selects 4T pattern
                                         3 selects 6T pattern
                            Bit [3]    : If set, don't prep(erase and write) the calibration track
                            Bit [6:4]  : write pattern, if used, for FASTIO
                                         0 selects 1T pattern
                                         1 selects 2T pattern
                                         4 selects 8T pattern
                                         5 selects scrambled pattern
                            Bit [7]    : If set, select Heater Only calibration.
                                         If cleared, select Write+Heat calibration which is currently not supported
                            Bit [8]    : For Clearance Coefficients Adjustment Calibration (HIRP) Diag,
                                         if set, use starting and ending Heater DAC values specified by user
                            Bit [8]    : For MD Contact Detect Diag, if set, find contact heater DAC value
                            Bit [10:9] : Track Position Validity input
                                         0 Input cylinder/head input is Nominal track position
                                         1 Input cylinder/head input is Read/Write track position
                                         2 Input radius/head input is Radius track position
                            Bit [11]   : If set, use the process adapted values for FIR taps
                            Bit [12]   : If set, ouput debug data, if any.
                            Bit [13]   : If set, collect and ouput raw measurements data
                            Bit [14]   : If set, dump channel registers settings during the calibration
                            Bit [15]   : If set, use the process adapted values for NPML taps
                            Bit [16]   : Save Channel Calibration Processor Registers to AFH sim file.
                            Bit [17]   : Restore Channel Calibration Processor Registers from AFH sim file.
                            Bit [18]   : If set, collect raw measurements data
                            Bit [19]   : If set, don't opti ATTR during HscMeasurementOpti, just opti VGAR with a fixed ATTR.
    @param WriteCurrentInput
        type: 16bit int
        default: none
        description: Write Current input
    @param WriteDampingInput
        type: 16bit int
        default: none
        description: Write Current Damping input
    @param WriteDampingDurationInput
        type: 16bit int
        default: none
        description: Write Current Damping Duration input
    @param PreHeaterStart
        type: 16bit int
        default: none
        description: Starting preheater DAC input
    @param HeaterStart
        type: 16bit int
        default: none
        description: Starting heater DAC input
    @param HeaterEnd
        type: 16bit int
        default: none
        description: Ending heater DAC input
                            If this has non-zero value, then PctOfTgtClr is ignored.
    @param HeaterIncrement
        type: 16bit int
        default: none
        description: Heater DAC increment input
    @param CorrelationThreshold
        type: 16bit int
        default: none
        description: If r^2 if below this theshold, test will be retried
    @param MeasureRetries
        type: 16bit int
        default: none
        description: Test will retry this number of times if r^2 is below threshold
    @param PctOfBpi
        type: 8bit int
        default: none
        description: Percentage of BPI to use during measurement
    @param PctOfTgtClr
        type: 8bit int
        default: none
        description: Percentage of target clearance to use when calculating ending heater
    @param UpperHiwpLimit
        type: 32bit int
        default: none
        description: Upper limit of coefficents calculated HIWP to include in regression data set
    @param LowerHiwpLimit
        type: 32bit int
        default: none
        description: Lower limit of coefficents calculated HIWP to include in regression data set
    @param AgcValue
        type: 16bit int
        default: none
        description: NAGain( VGAR ) input
    @param CTFFR
        type: 16bit int
        default: none
        description: CTFFR input   
    @param ATT2R
        type: 8bit int
        default: none
        description: ATT2R input
    @param HscLength
        type: 16bit int
        default: none
        description: HSC integration length
    @param APreWrNumSvoWedges
        type: 16bit int
        default: none
        description: A for FASTIO operation
    @param BWrNumSvoWedges
        type: 16bit int
        default: none
        description: B for FASTIO operation
    @param CPostWrNumSvoWedges
        type: 16bit int
        default: none
        description: C for FASTIO operation
    @param DRdNumSvoWedges
        type: 16bit int
        default: none
        description: D for FASTIO operation
    @param ETrailingNumSvoWedges
        type: 16bit int
        default: none
        description: E for FASTIO operation
    @param DebugFlag
        type: int
        default: none
        description: DebugFlag is a flag for debugging purpose only
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket( 'rev2_md_contact_detect_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00BC
        Packet.Dfb.Header.RevisionId = 2
        if 'CylOrRadius' in kwargs:
            Packet.Dfb.UserInput.CylOrRadius = kwargs['CylOrRadius']
        if 'Head' in kwargs:
            Packet.Dfb.UserInput.Head = kwargs['Head']
        if 'Iterations' in kwargs:
            Packet.Dfb.UserInput.Iterations = kwargs['Iterations']
        if 'ControlFlags' in kwargs:
            Packet.Dfb.UserInput.ControlFlags = kwargs['ControlFlags']
        if 'WriteCurrentInput' in kwargs:
            Packet.Dfb.UserInput.WriteCurrentInput = kwargs['WriteCurrentInput']
        if 'WriteDampingInput' in kwargs:
            Packet.Dfb.UserInput.WriteDampingInput = kwargs['WriteDampingInput']
        if 'WriteDampingDurationInput' in kwargs:
            Packet.Dfb.UserInput.WriteDampingDurationInput = kwargs['WriteDampingDurationInput']
        if 'PreHeaterStart' in kwargs:
            Packet.Dfb.UserInput.PreHeaterStart = kwargs['PreHeaterStart']
        if 'HeaterStart' in kwargs:
            Packet.Dfb.UserInput.HeaterStart = kwargs['HeaterStart']
        if 'HeaterEnd' in kwargs:
            Packet.Dfb.UserInput.HeaterEnd = kwargs['HeaterEnd']
        if 'HeaterIncrement' in kwargs:
            Packet.Dfb.UserInput.HeaterIncrement = kwargs['HeaterIncrement']
        if 'PctOfBpi' in kwargs:
            Packet.Dfb.UserInput.PctOfBpi = kwargs['PctOfBpi']
        if 'PatternSelect' in kwargs:
            Packet.Dfb.UserInput.PatternSelect = kwargs['PatternSelect']
        if 'AgcValue' in kwargs:
            Packet.Dfb.UserInput.AgcValue = kwargs['AgcValue']
        if 'CTFFR' in kwargs:
            Packet.Dfb.UserInput.CTFFR = kwargs['CTFFR']
        if 'ATT2R' in kwargs:
            Packet.Dfb.UserInput.ATT2R = kwargs['ATT2R']
        if 'HscLength' in kwargs:
            Packet.Dfb.UserInput.HscLength = kwargs['HscLength']
        if 'APreWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.APreWrNumSvoWedges = kwargs['APreWrNumSvoWedges']
        if 'BWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.BWrNumSvoWedges = kwargs['BWrNumSvoWedges']
        if 'CPostWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.CPostWrNumSvoWedges = kwargs['CPostWrNumSvoWedges']
        if 'DRdNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.DRdNumSvoWedges = kwargs['DRdNumSvoWedges']
        if 'ETrailingNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.ETrailingNumSvoWedges = kwargs['ETrailingNumSvoWedges']
        if 'CoarseSearchStartClearanceOffset' in kwargs:
            Packet.Dfb.UserInput.CoarseSearchStartClearanceOffset = kwargs['CoarseSearchStartClearanceOffset']
        if 'FineSearchStartClearanceOffset' in kwargs:
            Packet.Dfb.UserInput.FineSearchStartClearanceOffset = kwargs['FineSearchStartClearanceOffset']
        if 'ContactSearchLimitClearanceOffset' in kwargs:
            Packet.Dfb.UserInput.ContactSearchLimitClearanceOffset = kwargs['ContactSearchLimitClearanceOffset']
        if 'DebugFlag' in kwargs:
            Packet.Dfb.UserInput.DebugFlag = kwargs['DebugFlag']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_md_contact_detect_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetRWZoneGroupInformation( **kwargs ):
    """
    Function ID: 0x00BE
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00BE
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_rw_zone_group_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetRWZoneInformation( **kwargs ):  
    """
    Function ID: 0x00BF
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00BF
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_rw_zone_info_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def FieldAdjustFlyHeight( **kwargs ):
    """
    Function ID: 0x00C0
    Note: DETS diagnostic function
    Description: This diagnostic mode function performs the dual track Field Adjust Fly Height amplitude ratio measurements for a
                         range of heater DAC values at a given test location. The test location reference patterns must be initialized by
                         calling the diag once with the HEATER_ONLY bit of ControlFlags set. The diag also has a clearance mode which
                         displays the write clearance at each heater DAC after it is back calculated from the HIRP measurements.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CylOrRadius
        type: 32bit int
        default: none
        description: Cylinder ( Norminal or Read/Write ) or Radius (mils) input
    @param Head
        type: 16bit int
        default: none
        description: Head input
    @param NumFastIoCollections
        type: 16bit int
        default: none
        description: Number of fast io collections to average for each heater DAC
    @param ControlFlags
        type: 32bit bitfield
        default: none
        description: Control Flag input
                            Bit [2:0]  : calibration pattern
                                         1 selects 2T pattern
                                         2 selects 4T pattern
                                         3 selects 6T pattern
                            Bit [3]    : If set, don't prep(erase and write) the calibration track
                            Bit [6:4]  : write pattern, if used, for FASTIO
                                         0 selects 1T pattern
                                         1 selects 2T pattern
                                         4 selects 8T pattern
                                         5 selects scrambled pattern
                            Bit [7]    : If set, select Heater Only calibration.
                                         If cleared, select Write+Heat calibration which is currently not supported
                            Bit [8]    : For Clearance Coefficients Adjustment Calibration (HIRP) Diag,
                                         if set, use starting and ending Heater DAC values specified by user
                            Bit [8]    : For MD Contact Detect Diag, if set, find contact heater DAC value
                            Bit [10:9] : Track Position Validity input
                                         0 Input cylinder/head input is Nominal track position
                                         1 Input cylinder/head input is Read/Write track position
                                         2 Input radius/head input is Radius track position
                            Bit [11]   : If set, use the process adapted values for FIR taps
                            Bit [12]   : If set, ouput debug data, if any.
                            Bit [13]   : If set, collect and ouput raw measurements data
                            Bit [14]   : If set, dump channel registers settings during the calibration
                            Bit [15]   : If set, use the process adapted values for NPML taps
                            Bit [16]   : Save Channel Calibration Processor Registers to AFH sim file.
                            Bit [17]   : Restore Channel Calibration Processor Registers from AFH sim file.
                            Bit [18]   : If set, collect raw measurements data
                            Bit [19]   : If set, don't opti ATTR during HscMeasurementOpti, just opti VGAR with a fixed ATTR.
    @param WriteCurrentInput
        type: 16bit int
        default: none
        description: Write Current input
    @param WriteDampingInput
        type: 16bit int
        default: none
        description: Write Current Damping input
    @param WriteDampingDurationInput
        type: 16bit int
        default: none
        description: Write Current Damping Duration input
    @param PreHeaterStart
        type: 16bit int
        default: none
        description: Starting preheater DAC input
    @param HeaterStart
        type: 16bit int
        default: none
        description: Starting heater DAC input
    @param HeaterEnd
        type: 16bit int
        default: none
        description: Ending heater DAC input
                            If this has non-zero value, then PctOfTgtClr is ignored.
    @param HeaterIncrement
        type: 16bit int
        default: none
        description: Heater DAC increment input
    @param CorrelationThreshold
        type: 16bit int
        default: none
        description: If r^2 if below this theshold, test will be retried
    @param MeasureRetries
        type: 16bit int
        default: none
        description: Test will retry this number of times if r^2 is below threshold
    @param PctOfBpi
        type: 8bit int
        default: none
        description: Percentage of BPI to use during measurement
    @param PctOfTgtClr
        type: 8bit int
        default: none
        description: Percentage of target clearance to use when calculating ending heater
    @param UpperHiwpLimit
        type: 32bit int
        default: none
        description: Upper limit of coefficents calculated HIWP to include in regression data set
    @param LowerHiwpLimit
        type: 32bit int
        default: none
        description: Lower limit of coefficents calculated HIWP to include in regression data set
    @param AgcValue
        type: 16bit int
        default: none
        description: NAGain( VGAR ) input
    @param CTFFR
        type: 16bit int
        default: none
        description: CTFFR input   
    @param ATT2R
        type: 8bit int
        default: none
        description: ATT2R input
    @param HscLength
        type: 16bit int
        default: none
        description: HSC integration length
    @param APreWrNumSvoWedges
        type: 16bit int
        default: none
        description: A for FASTIO operation
    @param BWrNumSvoWedges
        type: 16bit int
        default: none
        description: B for FASTIO operation
    @param CPostWrNumSvoWedges
        type: 16bit int
        default: none
        description: C for FASTIO operation
    @param DRdNumSvoWedges
        type: 16bit int
        default: none
        description: D for FASTIO operation
    @param ETrailingNumSvoWedges
        type: 16bit int
        default: none
        description: E for FASTIO operation
    @param DebugFlag
        type: int
        default: none
        description: DebugFlag is a flag for debugging purpose only
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_field_adjust_fly_height_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C0
        Packet.Dfb.Header.RevisionId = 1
        if 'CylOrRadius' in kwargs:
            Packet.Dfb.UserInput.CylOrRadius = kwargs['CylOrRadius']
        if 'Head' in kwargs:
            Packet.Dfb.UserInput.Head = kwargs['Head']
        if 'NumFastIoCollections' in kwargs:
            Packet.Dfb.UserInput.NumFastIoCollections = kwargs['NumFastIoCollections']
        if 'ControlFlags' in kwargs:
            Packet.Dfb.UserInput.ControlFlags = kwargs['ControlFlags']
        if 'WriteCurrentInput' in kwargs:
            Packet.Dfb.UserInput.WriteCurrentInput = kwargs['WriteCurrentInput']
        if 'WriteDampingInput' in kwargs:
            Packet.Dfb.UserInput.WriteDampingInput = kwargs['WriteDampingInput']
        if 'WriteDampingDurationInput' in kwargs:
            Packet.Dfb.UserInput.WriteDampingDurationInput = kwargs['WriteDampingDurationInput']
        if 'PreHeaterStart' in kwargs:
            Packet.Dfb.UserInput.PreHeaterStart = kwargs['PreHeaterStart']
        if 'ContactDac' in kwargs:
            Packet.Dfb.UserInput.ContactDac = kwargs['ContactDac']
        if 'HeaterStart' in kwargs:
            Packet.Dfb.UserInput.HeaterStart = kwargs['HeaterStart']
        if 'HeaterEnd' in kwargs:
            Packet.Dfb.UserInput.HeaterEnd = kwargs['HeaterEnd']
        if 'HeaterIncrement' in kwargs:
            Packet.Dfb.UserInput.HeaterIncrement = kwargs['HeaterIncrement']
        if 'MeasureRetries' in kwargs:
            Packet.Dfb.UserInput.MeasureRetries = kwargs['MeasureRetries']
        if 'PctOfBpiLowFreq' in kwargs:
            Packet.Dfb.UserInput.PctOfBpiLowFreq = kwargs['PctOfBpiLowFreq']
        if 'PctOfBpiHighFreq' in kwargs:
            Packet.Dfb.UserInput.PctOfBpiHighFreq = kwargs['PctOfBpiHighFreq']
        if 'PctOfTgtClr' in kwargs:
            Packet.Dfb.UserInput.PctOfTgtClr = kwargs['PctOfTgtClr']
        if 'VgarLowFreq' in kwargs:
            Packet.Dfb.UserInput.VgarLowFreq = kwargs['VgarLowFreq']
        if 'VgarHighFreq' in kwargs:
            Packet.Dfb.UserInput.VgarHighFreq = kwargs['VgarHighFreq']
        if 'CTFFR' in kwargs:
            Packet.Dfb.UserInput.CTFFR = kwargs['CTFFR']
        if 'ATT2R' in kwargs:
            Packet.Dfb.UserInput.ATT2R = kwargs['ATT2R']
        if 'HscLength' in kwargs:
            Packet.Dfb.UserInput.HscLength = kwargs['HscLength']
        if 'ChannelPreheatRevs' in kwargs:
            Packet.Dfb.UserInput.ChannelPreheatRevs = kwargs['ChannelPreheatRevs']
        if 'APreWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.APreWrNumSvoWedges = kwargs['APreWrNumSvoWedges']
        if 'BWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.BWrNumSvoWedges = kwargs['BWrNumSvoWedges']
        if 'CPostWrNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.CPostWrNumSvoWedges = kwargs['CPostWrNumSvoWedges']
        if 'DRdNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.DRdNumSvoWedges = kwargs['DRdNumSvoWedges']
        if 'ETrailingNumSvoWedges' in kwargs:
            Packet.Dfb.UserInput.ETrailingNumSvoWedges = kwargs['ETrailingNumSvoWedges']
        if 'UseWritesToPreheatChannel' in kwargs:
            Packet.Dfb.UserInput.UseWritesToPreheatChannel = kwargs['UseWritesToPreheatChannel']
        if 'EnableClearanceDisplayMode' in kwargs:
            Packet.Dfb.UserInput.EnableClearanceDisplayMode = kwargs['EnableClearanceDisplayMode']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_field_adjust_fly_height_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetModifySingleTrackDirectedOfflineScanInformation( **kwargs ):   
    """
    Function ID: 0x00C1
    Note: DETS diagnostic function
    Description: currently unable to build dfb for this diag
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 2 DSB
    -----revision 1 parameters-----

    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_modify_single_track_directed_offline_scan_information_command_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C1
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev2_get_modify_single_track_directed_offline_scan_information_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def ClearSingleTrackDirectedOfflineScanWriteCounters( **kwargs ):
    """
    Function ID: 0x00C2
    Note: DETS diagnostic function
    Description: This diagnostic mode function will zero out the Single Track DOS write counters.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C2
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SetUserCylinderHeadMiniZoneSkew( **kwargs ):     
    """
    Function ID: 0x00C3
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CylSkew
        type: int
        default: none
        description: NA
    @param HeadSkew
        type: int
        default: none
        description: NA
    @param MiniZoneSkew
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_user_skew_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C3
        Packet.Dfb.Header.RevisionId = 1
        if 'CylSkew' in kwargs:
            Packet.Dfb.CylSkew = kwargs['CylSkew']
        if 'HeadSkew' in kwargs:
            Packet.Dfb.HeadSkew = kwargs['HeadSkew']
        if 'MiniZoneSkew' in kwargs:
            Packet.Dfb.MiniZoneSkew = kwargs['MiniZoneSkew']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_user_skew_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def SMARTDriveSelfTest( **kwargs ):
    """
    Function ID: 0x00C4
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function controls SMART Drive Self Test operation.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TestNumber
        type: 32bit int
        default: non
        description: TestNumber indicates which DST to run.
                            For ATA drives
                            00: Offline immediate
                            01: Offline short
                            02: Offline long
                            03: Offline conveyance
                            04: Offline selective
                            OFFLINE_RESERVED (5-63)
                            Offline vendor specific (64-126)
                            64: Offline factory
                            65: Offline short serial
                            66: Offline long serial
                            80: Offline Lenovo long self test
                            97: Offline NetApp short
                            98: Offline NetApp long
                            124: Offline repair long
                            125: Offline AV scan long
                            126: Offline EMC long
                            127: Abort offline
                            128: Captive mode
                            129: Captive short
                            130: Captive long
                            131: Captive conveyance
                            132: Captive selective
                            Captive reserved (133-191),
                            Captive vendor specific (192-255)
                            192: Captive factory
                            225: Captive NetApp short
                            226: Captive NetApp long
                            252: Captive repair long
                            253: Captive AV scan long
                            254: Captive EMC long
                            655355: Restart   
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_smart_drive_self_test_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C4
        Packet.Dfb.Header.RevisionId = 1
        if 'TestNumber' in kwargs:
            Packet.Dfb.TestNumber = kwargs['TestNumber']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_generic_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetDataScrubList ( **kwargs ):
#
    """
    Function ID: 0x00C5
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function retrieves the Data Scrub List (which is also
                         known as the Mickey Cert List) from the R/W firmware subsystem.
                     
                         The Data Scrub List is made up of LBAs that have successfully completed mini-cert during
                         reallocation (and therefore were NOT reallocated) and a count ("Scrub Count") of how many
                         times this has happened.  This function returns a list of the LBAs and counts as well as
                         many of the ways the LBA can be described by the diagnostic firmware.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartIndex
        type: int
        default: none
        description: NA
    @param NumEntriesRequested
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_data_scrub_list_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C5
        Packet.Dfb.Header.RevisionId = 1
        if 'StartIndex' in kwargs:
            Packet.Dfb.StartIndex = kwargs['StartIndex']
        if 'NumEntriesRequested' in kwargs:
            Packet.Dfb.NumEntriesRequested = kwargs['NumEntriesRequested']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_data_scrub_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def UpdateDataScrubList( **kwargs ):
    """
    Function ID: 0x00C6
    Note: DETS diagnostic function
    Description: This diagnostic mode diagnostic function allows users to update the Data Scrub List by
                         initializing it, adding entries to it, or deleting entries from it.
                     
                         The Data Scrub List is made up of LBAs that have successfully completed mini-cert during
                         reallocation (and therefore were NOT reallocated) and a count ("Scrub Count") of how many
                         times this has happened.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param UpdateOperation
        type: 8bit int
        default: none
        description: Specified if update operation.
                            0x00: Entire list should be purged.
                            0x01: Insert new entry in list or update existing entry.
                            0x02: Delete specified entry in list.   
    @param DiscUpdateRequired
        type: boolean 
        default: none
        description: DiscUpdateRequired, if set TRUE (1), will save the updated list to disc
                            and if set FALSE (0), will only update the in-memory copy. 
    @param NumListEntries
        type: 16bit int
        default: none
        description:   Number of entries in specified list.     
    @param ListEntry
        type: array of max length 256
        default: none
        description: of the form [ [LBA, Count], [LBA,Count], [LBA,Count],...]
        @param LBA
            type: 32bit int
            default: none
            description: Lba is the logical block address of Data Scrub List entry.
        @param Count
            type: 8bit int
            default: none
            description: Count is the number successful scrub attempts for this Data Scrub List entry.              
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_update_data_scrub_list_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C6
        Packet.Dfb.Header.RevisionId = 1

        if 'UpdateOperation' in kwargs:        
            Packet.Dfb.UpdateDataScrubListInput.UpdateInfo.UpdateOperation = kwargs['UpdateOperation']  
        if 'DiscUpdateRequired' in kwargs:        
            Packet.Dfb.UpdateDataScrubListInput.UpdateInfo.DiscUpdateRequired = kwargs['DiscUpdateRequired']  
        if 'NumListEntries' in kwargs:        
            Packet.Dfb.UpdateDataScrubListInput.UpdateInfo.NumListEntries = kwargs['NumListEntries']  

        i = 0
        for [LBA, Count]  in range( len(kwargs['ListEntry'])):
            Packet.Dfb.UpdateDataScrubListInput.ListEntry[i].LBA = LBA
            Packet.Dfb.UpdateDataScrubListInput.ListEntry[i].Count = Count
            i+=1
        
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_update_data_scrub_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetHardwareJumperSetting( **kwargs ):
    """
    Function ID: 0x00C7
    Note: DETS diagnostic function
    Description: This SDBP Diagnostic returns hardware jumper setting.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param HardwareJumperSelect
        type: 32bit int
        default: none
        description: HardwareJumperSelect selects the hardware jumper that will be checked.  The following are
                            valid selections.
                            0x00: SATA Configuration Hardware Jumper
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_hardware_jumper_setting_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C7
        Packet.Dfb.Header.RevisionId = 1
        if 'HardwareJumperSelect' in kwargs:
            Packet.Dfb.HardwareJumperSelect = kwargs['HardwareJumperSelect']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_hardware_jumper_setting_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetTAList( **kwargs ):
    """
    Function ID: 0x00C8
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function retrieves the TA (Thermal Asperity) List from
                         the R/W firmware.  This list contains tracks that have TAs on them.  If supported, the
                         list also includes head information.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartIndex
        type: 32bit int
        default: none
        description: StartIndex is the starting index of the TA List at which retrieval of the list should
                            start.   
    @param NumEntriesRequested
        type: 32bit int
        default: none
        description: NumEntriesRequested is the number of entries of the TA List that should be retrieved.
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_ta_list_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C8
        Packet.Dfb.Header.RevisionId = 1
        if 'StartIndex' in kwargs:
            Packet.Dfb.InputInfo.StartIndex = kwargs['StartIndex']
        if 'NumEntriesRequested' in kwargs:
            Packet.Dfb.InputInfo.NumEntriesRequested = kwargs['NumEntriesRequested']      

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_ta_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def MeasureOptimumSkew( **kwargs ):
    """
    Function ID: 0x00C9
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_generic_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00C9
        Packet.Dfb.Header.RevisionId = 1

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_measure_optimum_skew_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)            

def GetDefectiveTracksList( **kwargs ):  
    """
    Function ID: 0x00CA
    Note: DETS diagnostic function
    Description: This Diagnostic Mode diagnostic function retrieves the Defective Tracks List from the
                         R/W firmware.  This list is made of up tracks on which TAs and excessive Servo Defects
                         have been found.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TargetHeadSpecified
        type: bool
        default: none
        description: TargetHeadSpecified, if TRUE (non-zero), indicates that the TargetHead
                            parameter is valid.  If false, then the TargetHead parameter is not
                            valid and entries for all heads will be retrieved.
    @param TargetHead
        type: 8bit int
        default: none
        description: TargetHead, if specified as a valid head number by setting
                            TargetHeadSpecified to a non-zero value, will retrieve entries only for
                            the specified head.
    @param StartIndex
        type: 32bit int
        default: none
        description: StartIndex is the specified starting index.
    @param NumEntriesRequested
        type: 32bit int
        default: none
        description: NumEntriesRequested is the specified number of entries requested.  (If
                        more entries are requested than are in the list, then only the number of
                        entries in the list is returned.)
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_defective_tracks_list_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00CA
        Packet.Dfb.Header.RevisionId = 1
        if 'TargetHeadSpecified' in kwargs:
            Packet.Dfb.InputInfo.TargetHeadSpecified = kwargs['TargetHeadSpecified']
        if 'TargetHead' in kwargs:
            Packet.Dfb.InputInfo.TargetHead = kwargs['TargetHead']
        if 'StartIndex' in kwargs:
            Packet.Dfb.InputInfo.StartIndex = kwargs['StartIndex']
        if 'NumEntriesRequested' in kwargs:
            Packet.Dfb.InputInfo.NumEntriesRequested = kwargs['NumEntriesRequested']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_get_defective_tracks_list_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                 

def GetBonanzaMemory( **kwargs ):
    """
    Function ID: 0x00CC
    Note: DETS diagnostic function
    Description: This diagnostics will get contents of a Bonanza memory.
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param MemoryType
        type: 8bit int
        default: none
        description: MemoryType specifies which Bonanza memory space is to be accessed.
    @param BufferSelect
        type: 8bit int
        default: none
        description: BufferSelect specifies one of the four available buffers to be accessed.
    @param StartElement
        type: 16bit int
        default: none
        description: StartElement specifies the index of the first memory element to be accessed.
    @param NumberOfElements
        type: 16bit int
        default: none
        description: NumberOfElements specifies the number of elements to return
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_get_bonanza_memory_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00CC
        Packet.Dfb.Header.RevisionId = 1
        if 'MemoryType' in kwargs:
            Packet.Dfb.MemoryType = kwargs['MemoryType']
        if 'BufferSelect' in kwargs:
            Packet.Dfb.BufferSelect = kwargs['BufferSelect']
        if 'StartElement' in kwargs:
            Packet.Dfb.StartElement = kwargs['StartElement']
        if 'NumberOfElements' in kwargs:
            Packet.Dfb.Dfb.NumberOfElements = kwargs['NumberOfElements']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'get_bonanza_memory_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                 
        
        
def ReadSerialPortTestResults( **kwargs ):
    """
    Function ID: 0x00D2
    Note: DETS diagnostic function
    Description: 
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SptIndex
        type: int
        default: none
        description: NA
    @param ByteOffset
        type: int
        default: none
        description: NA
    @param BytesToRead
        type: int
        default: none
        description: NA
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket( 'rev1_read_serial_port_test_results_sdbp_dfb' )
        Packet.SdbpHeader.FromPort = 7
        Packet.SdbpHeader.ToPort = 7
        Packet.SdbpHeader.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.Dfb.Header.FunctionId = 0x00D2
        Packet.Dfb.Header.RevisionId = 1
        if 'SptIndex' in kwargs:
            Packet.Dfb.Input.SptIndex = kwargs['SptIndex']
        if 'ByteOffset' in kwargs:
            Packet.Dfb.Input.ByteOffset = kwargs['ByteOffset']
        if 'BytesToRead' in kwargs:
            Packet.Dfb.Input.BytesToRead = kwargs['BytesToRead']        

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('rev1_generic_sdbp_dsb')
        Response = typelib.variablelize ( 'rev1_generic_sdbp_dsb', ResponsePacket[:MinPacketSize] )
        if Response.Dsb.Header.Error != 0:
            print('Warning: There was an error reported in the response packet.')
        try:
            return typelib.variablelize( 'rev1_read_serial_port_test_results_sdbp_dsb', ResponsePacket ) 
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response        
    else: 
        print('Revision %d is not defined' % Revision)                     
        
#----------DITS wrappers----------#        
def SetDataScrubbing( **kwargs ):
    """
    Function ID: 0x0101
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DSFlag
        type: 
        default: none
        description: 
    @param Rsvd1
        type: 
        default: none
        description: 
    @param Rsvd2
        type: 
        default: none
        description: 
    @param Rsvd3
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'data_scrubbing_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0101
        Packet.Revision = 1
        if 'DSFlag' in kwargs:
            Packet.DfbInfo.rev1.DSFlag = kwargs['DSFlag']
        if 'Rsvd1' in kwargs:
            Packet.DfbInfo.rev1.Rsvd1 = kwargs['Rsvd1']
        if 'Rsvd2' in kwargs:
            Packet.DfbInfo.rev1.Rsvd2 = kwargs['Rsvd2']
        if 'Rsvd3' in kwargs:
            Packet.DfbInfo.rev1.Rsvd3 = kwargs['Rsvd3']

     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)

def SetDIIRetryControl( **kwargs ):
    """
    Function ID: 0x0102
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DiiFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'dii_retry_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0102
        Packet.Revision = 1
        if 'DiiFlag' in kwargs:
            Packet.DfbInfo.rev1.DiiFlag = kwargs['DiiFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)
        
def SetECCControl( **kwargs ):
    """
    Function ID: 0x0103
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Tlevel
        type: 
        default: none
        description: 
    @param ETFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'ecc_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0103
        Packet.Revision = 1
        if 'Tlevel' in kwargs:
            Packet.DfbInfo.rev1.Tlevel = kwargs['Tlevel']
        if 'ETFlag' in kwargs:
            Packet.DfbInfo.rev1.ETFlag = kwargs['ETFlag']

     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetErrorRecoveryStep( **kwargs ):
    """
    Function ID: 0x0104
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ErrorRecoveryStep
        type: 
        default: none
        description: 
    @param ECTFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'error_recovery_step_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0104
        Packet.Revision = 1
        if 'ErrorRecoveryStep' in kwargs:
            Packet.DfbInfo.rev1.ErrorRecoveryStep = kwargs['ErrorRecoveryStep']
        if 'ECTFlag' in kwargs:
            Packet.DfbInfo.rev1.ECTFlag = kwargs['ECTFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetFactoryProcess( **kwargs ):
    """
    Function ID: 0x0105
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FPFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'factory_process_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0105
        Packet.Revision = 1
        if 'FPFlag' in kwargs:
            Packet.DfbInfo.rev1.FPFlag = kwargs['FPFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetForceNextResetCold( **kwargs ):
    """
    Function ID: 0x0106
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FCRFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'force_next_reset_cold_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0106
        Packet.Revision = 1
        if 'FCRFlag' in kwargs:
            Packet.DfbInfo.rev1.FCRFlag = kwargs['FCRFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetFreeRetryControl( **kwargs ):
    """
    Function ID: 0x0107
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FRFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'free_retry_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0107
        Packet.Revision = 1
        if 'FRFlag' in kwargs:
            Packet.DfbInfo.rev1.FRFlag = kwargs['FRFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetHiddenRetryControl( **kwargs ):
    """
    Function ID: 0x0108
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DHFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'hidden_retry_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0108
        Packet.Revision = 1
        if 'DHFlag' in kwargs:
            Packet.DfbInfo.rev1.DHFlag = kwargs['DHFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetInterCommandActivity( **kwargs ):
    """
    Function ID: 0x0109
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param IAFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'inter_command_activity_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0109
        Packet.Revision = 1
        if 'IAFlag' in kwargs:
            Packet.DfbInfo.rev1.IAFlag = kwargs['IAFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetMapReadOffsetServoFlawsDuringFormat( **kwargs ):
    """
    Function ID: 0x010A
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FMRFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'map_rd_offst_servo_flws_during_format_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x010A
        Packet.Revision = 1
        if 'FMRFlag' in kwargs:
            Packet.DfbInfo.rev1.FMRFlag = kwargs['FMRFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetMapWriteOffsetServoFlawsDuringFormat( **kwargs ):
    """
    Function ID: 0x010B
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FMWFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'map_wt_offst_servo_flws_during_format_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x010B
        Packet.Revision = 1
        if 'FMWFlag' in kwargs:
            Packet.DfbInfo.rev1.FMWFlag = kwargs['FMWFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetPowerManagementControl( **kwargs ):
    """
    Function ID: 0x010C
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param PFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_power_management_control_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x010C
        Packet.Revision = 1
        if 'PFlag' in kwargs:
            Packet.DfbInfo.rev1.PFlag = kwargs['PFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetPowerOnSelfTest( **kwargs ):
    """
    Function ID: 0x010D
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param PSFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_power_on_self_test_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x010D
        Packet.Revision = 1
        if 'PSFlag' in kwargs:
            Packet.DfbInfo.rev1.PSFlag = kwargs['PSFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetEnableSpinup( **kwargs ):
    """
    Function ID: 0x010E
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ESFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'enable_spinup_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x010E
        Packet.Revision = 1
        if 'ESFlag' in kwargs:
            Packet.DfbInfo.rev1.ESFlag = kwargs['ESFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetReportHiddenRetryControl( **kwargs ):
    """
    Function ID: 0x010F
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RHFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'report_hidden_retry_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x010F
        Packet.Revision = 1
        if 'RHFlag' in kwargs:
            Packet.DfbInfo.rev1.RHFlag = kwargs['RHFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetSTIRControl( **kwargs ):
    """
    Function ID: 0x0110
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'stir_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0110
        Packet.Revision = 1
        if 'SFlag' in kwargs:
            Packet.DfbInfo.rev1.SFlag = kwargs['SFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetSystemTableRecovery( **kwargs ):
    """
    Function ID: 0x0111
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param LFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'system_table_recovery_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0111
        Packet.Revision = 1
        if 'LFlag' in kwargs:
            Packet.DfbInfo.rev1.LFlag = kwargs['LFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetTCCControl( **kwargs ):
    """
    Function ID: 0x0112
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param MFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'tcc_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0112
        Packet.Revision = 1
        if 'MFlag' in kwargs:
            Packet.DfbInfo.rev1.MFlag = kwargs['MFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetClearFormatCorruptCondition( **kwargs ):
    """
    Function ID: 0x0113
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CFCFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'clear_format_corrupt_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0113
        Packet.Revision = 1
        if 'CFCFlag' in kwargs:
            Packet.DfbInfo.rev1.CFCFlag = kwargs['CFCFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetVoltageMargin( **kwargs ):
    """
    Function ID: 0x0114
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param VoltageMargin
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'voltage_margin_control_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0114
        Packet.Revision = 1
        if 'VoltageMargin' in kwargs:
            Packet.DfbInfo.rev1.VoltageMargin = kwargs['VoltageMargin']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetWriteCurrentOffset( **kwargs ):
    """
    Function ID: 0x0116
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Offset
        type: 
        default: none
        description: 
    @param Direction
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_current_offset_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0116
        Packet.Revision = 1
        if 'Offset' in kwargs:
            Packet.DfbInfo.rev1.Offset = kwargs['Offset']
        if 'Direction' in kwargs:
            Packet.DfbInfo.rev1.Direction = kwargs['Direction']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetZAPControl( **kwargs ):
    """
    Function ID: 0x0117
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ZapSelection
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'zap_control_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0117
        Packet.Revision = 1
        if 'ZapSelection' in kwargs:
            Packet.DfbInfo.rev1.ZapSelection = kwargs['ZapSelection']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetContinuousHeatToWriter( **kwargs ):
    """
    Function ID: 0x011A
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CHFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'continuous_heat_to_writer_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x011A
        Packet.Revision = 1
        if 'CHFlag' in kwargs:
            Packet.DfbInfo.rev1.CHFlag = kwargs['CHFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetMRBiasChop( **kwargs ):
    """
    Function ID: 0x011B
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param BFlag
        type: 
        default: none
        description: 0 is off, 1 is on
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'mr_bias_chop_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x011B
        Packet.Revision = 1
        if 'BFlag' in kwargs:
            Packet.DfbInfo.rev1.BFlag = kwargs['BFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetPFast( **kwargs ):
    """
    Function ID: 0x011C
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 2
        description: Which revision packet to send to the drive. Revision 2 DFB results in revision 1 DSB
    -----revision 2 parameters-----
    @param PFFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 2
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 2:
        Packet = typelib.createPacket(['sdbp_packet_header', 'p_fast_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x011C
        Packet.Revision = 2
        if 'PFFlag' in kwargs:
            Packet.DfbInfo.rev1.PFFlag = kwargs['PFFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetCERTOfSystemDefectTable( **kwargs ):
    """
    Function ID: 0x011D
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CRAFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'disable_cert_of_reserved_defect_table_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x011D
        Packet.Revision = 1
        if 'CRAFlag' in kwargs:
            Packet.DfbInfo.rev1.CRAFlag = kwargs['CRAFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetDataECCCorrectionOnTheFly( **kwargs ):
    """
    Function ID: 0x0120
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ECCFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'data_ecc_on_the_fly_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0120
        Packet.Revision = 1
        if 'ECCFlag' in kwargs:
            Packet.DfbInfo.rev1.ECCFlag = kwargs['ECCFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetDataIntegrityCheck( **kwargs ):
    """
    Function ID: 0x0121
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DDIC
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_data_integrity_check_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0121
        Packet.Revision = 1
        if 'DDIC' in kwargs:
            Packet.DfbInfo.rev1.DDIC = kwargs['DDIC']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetWriteProtect( **kwargs ):
    """
    Function ID: 0x0122
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DisableWriteProtect
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_write_protect_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0122
        Packet.Revision = 1
        if 'DisableWriteProtect' in kwargs:
            Packet.DfbInfo.rev1.DisableWriteProtect = kwargs['DisableWriteProtect']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetUDSControl( **kwargs ):
    """
    Function ID: 0x0123
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param UDSControlByte
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_uds_control_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0123
        Packet.Revision = 1
        if 'UDSControlByte' in kwargs:
            Packet.DfbInfo.rev1.UDSControlByte = kwargs['UDSControlByte']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetFastFormat( **kwargs ):
    """
    Function ID: 0x0124
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FFFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'fast_format_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0124
        Packet.Revision = 1
        if 'FFFlag' in kwargs:
            Packet.DfbInfo.rev1.FFFlag = kwargs['FFFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetServoCoast( **kwargs ):
    """
    Function ID: 0x0126
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SCFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_servo_coast_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0126
        Packet.Revision = 1
        if 'SCFlag' in kwargs:
            Packet.DfbInfo.rev1.SCFlag = kwargs['SCFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetLDPCIterationControl( **kwargs ):
    """
    Function ID: 0x0127
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ControlFlags
        type: 
        default: none
        description: 
    @param LLIStatusThresh
        type: 
        default: none
        description: 
    @param BitsInErrThresh
        type: 
        default: none
        description: 
    @param IterationCntThresh
        type: 
        default: none
        description: 
    @param LowLLRThresh
        type: 
        default: none
        description: 
    @param LLRSoftSumThresh
        type: 
        default: none
        description: 
    @param ErasureCntThresh
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_channel_bci_logging_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0129
        Packet.Revision = 1
        if 'ControlFlags' in kwargs:
            Packet.DfbInfo.rev1.ControlFlags = kwargs['ControlFlags']
        if 'LLIStatusThresh' in kwargs:
            Packet.DfbInfo.rev1.LLIStatusThresh = kwargs['LLIStatusThresh']
        if 'BitsInErrThresh' in kwargs:
            Packet.DfbInfo.rev1.BitsInErrThresh = kwargs['BitsInErrThresh']
        if 'IterationCntThresh' in kwargs:
            Packet.DfbInfo.rev1.IterationCntThresh = kwargs['IterationCntThresh']
        if 'LowLLRThresh' in kwargs:
            Packet.DfbInfo.rev1.LowLLRThresh = kwargs['LowLLRThresh']
        if 'LLRSoftSumThresh' in kwargs:
            Packet.DfbInfo.rev1.LLRSoftSumThresh = kwargs['LLRSoftSumThresh']
        if 'ErasureCntThresh' in kwargs:
            Packet.DfbInfo.rev1.ErasureCntThresh = kwargs['ErasureCntThresh']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             
        
def SetChannelBCILoggingOffline( **kwargs ):
    """
    Function ID: 0x0128
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param OfflineFlags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_channel_bci_logging_offline_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0128
        Packet.Revision = 1
        if 'OfflineFlags' in kwargs:
            Packet.DfbInfo.rev1.OfflineFlags = kwargs['OfflineFlags']    
                 
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        '''MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        print Response
        if Response.StatusBlock.SenseKey != 0:
            print 'Warning: There was an error reported in the response packet.'   
        try:
            variablelized_header = typelib.variablelize('diag_common_return_block',ResponsePacket[:MinPacketSize])
            variablelized_packet = typelib.variablelize('set_channel_bci_logging_offline_return',ResponsePacket[MinPacketSize:])
            variablelized_header.merge(variablelized_packet)
            return variablelized_header
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print 'Revision %d is not defined' % Revision'''
        
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            variablelized_packet = typelib.variablelize('set_channel_bci_logging_offline_return',ResponsePacket[MinPacketSize:])
            Response.merge(variablelized_packet)
            return Response
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)        
        
def SetChannelBCILoggingControl( **kwargs ):
    """
    Function ID: 0x0129
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param ControlFlags
        type: 
        default: none
        description: 
    @param LLIStatusThresh
        type: 
        default: none
        description: 
    @param BitsInErrThresh
        type: 
        default: none
        description: 
    @param IterationCntThresh
        type: 
        default: none
        description: 
    @param LowLLRThresh
        type: 
        default: none
        description: 
    @param LLRSoftSumThresh
        type: 
        default: none
        description: 
    @param ErasureCntThresh
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_channel_bci_logging_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0129
        Packet.Revision = 1
        if 'ControlFlags' in kwargs:
            Packet.DfbInfo.rev1.ControlFlags = kwargs['ControlFlags']
        if 'LLIStatusThresh' in kwargs:
            Packet.DfbInfo.rev1.LLIStatusThresh = kwargs['LLIStatusThresh']
        if 'BitsInErrThresh' in kwargs:
            Packet.DfbInfo.rev1.BitsInErrThresh = kwargs['BitsInErrThresh']
        if 'IterationCntThresh' in kwargs:
            Packet.DfbInfo.rev1.IterationCntThresh = kwargs['IterationCntThresh']
        if 'LowLLRThresh' in kwargs:
            Packet.DfbInfo.rev1.LowLLRThresh = kwargs['LowLLRThresh']
        if 'LLRSoftSumThresh' in kwargs:
            Packet.DfbInfo.rev1.LLRSoftSumThresh = kwargs['LLRSoftSumThresh']
        if 'ErasureCntThresh' in kwargs:
            Packet.DfbInfo.rev1.ErasureCntThresh = kwargs['ErasureCntThresh']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

        
def InduceSelfTestError( **kwargs ):
    """
    Function ID: 0x012D
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TestMask
        type: 
        default: none
        description:     
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'induce_self_test_error_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x012D
        Packet.Revision = 1
        if 'TestMask' in kwargs:
            Packet.DfbInfo.TestMask = kwargs['TestMask']        
              
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetFDE( **kwargs ):
    """
    Function ID: 0x012F
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FdeOn
        type: 
        default: none
        description:  
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_fde_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x012F
        Packet.Revision = 1
        if 'FdeOn' in kwargs:
            Packet.DfbInfo.FdeOn = kwargs['FdeOn']             

     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def TranslatePCHStoLBA( **kwargs ):
    """
    Function ID: 0x0130
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param cyl
        type: 
        default: none
        description: 
    @param sector
        type: 
        default: none
        description: 
    @param head
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'translate_pchs_to_lba_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0130
        Packet.Revision = 1
        if 'cyl' in kwargs:
            Packet.DfbInfo.rev1.cyl = kwargs['cyl']
        if 'sector' in kwargs:
            Packet.DfbInfo.rev1.sector = kwargs['sector']
        if 'head' in kwargs:
            Packet.DfbInfo.rev1.head = kwargs['head']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('translated_pchs_to_lba_return',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def PCHStoLBA( **kwargs ):
    """
    Function ID: 0x0130
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param cyl
        type: 
        default: none
        description: 
    @param sector
        type: 
        default: none
        description: 
    @param head
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'translate_pchs_to_lba_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0130
        Packet.Revision = 1
        if 'cyl' in kwargs:
            Packet.DfbInfo.rev1.cyl = kwargs['cyl']
        if 'sector' in kwargs:
            Packet.DfbInfo.rev1.sector = kwargs['sector']
        if 'head' in kwargs:
            Packet.DfbInfo.rev1.head = kwargs['head']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        return cnrserial.extractPCHSToLBATranslation(ResponsePacket[MinPacketSize:])
    else: 
        print('Revision %d is not defined' % Revision)             

def UserLBAtoPCHS( **kwargs ):
    """
    Function ID: 0x0131
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param lba_lsdw
        type: 
        default: none
        description: 
    @param lba_msdw
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'translate_user_lba_to_pchs_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0131
        Packet.Revision = 1
        if 'lba_lsdw' in kwargs:
            Packet.DfbInfo.rev1.lba_lsdw = kwargs['lba_lsdw']
        if 'lba_msdw' in kwargs:
            Packet.DfbInfo.rev1.lba_msdw = kwargs['lba_msdw']

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        return cnrserial.extractUserLBAtoPCHSTranslation(ResponsePacket[MinPacketSize:])
    else: 
        print('Revision %d is not defined' % Revision)             

def TranslateUserLBAtoPCHS( **kwargs ):
    """
    Function ID: 0x0131
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param lba_lsdw
        type: 
        default: none
        description: 
    @param lba_msdw
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'translate_user_lba_to_pchs_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0131
        Packet.Revision = 1
        if 'lba_lsdw' in kwargs:
            Packet.DfbInfo.rev1.lba_lsdw = kwargs['lba_lsdw']
        if 'lba_msdw' in kwargs:
            Packet.DfbInfo.rev1.lba_msdw = kwargs['lba_msdw']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('translated_user_lba_to_pchs_return',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def PhysicalSeek( **kwargs ):
    """
    Function ID: 0x0133
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param cyl
        type: 
        default: none
        description: 
    @param offset
        type: 
        default: 0
        description: 
    @param head
        type: 
        default: none
        description: 
    @param flags
        type: 
        default: 0
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'physical_seek_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0133
        Packet.Revision = 1
        if 'cyl' in kwargs:
            Packet.DfbInfo.rev1.cyl = kwargs['cyl']
        if 'offset' in kwargs:
            Packet.DfbInfo.rev1.offset = kwargs['offset']
        else:
            Packet.DfbInfo.rev1.offset = 0
        if 'head' in kwargs:
            Packet.DfbInfo.rev1.head = kwargs['head']
        if 'flags' in kwargs:
            Packet.DfbInfo.rev1.flags = kwargs['flags']
        else:
            Packet.DfbInfo.rev1.flags = 0
                
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
        ResponsePacket *= 2
        
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            new_responsepacket = ResponsePacket[8:8 + 28]
            variablelized_header = typelib.variablelize('physical_seek_ret_value',new_responsepacket)
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def LogicalSeek( **kwargs ):
    """
    Function ID: 0x0134
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartLBA
        type: 
        default: none
        description: 
    @param offset
        type: 
        default: none
        description: 
    @param flags1
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'logical_seek_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0134
        Packet.Revision = 1
        if 'StartLBA' in kwargs:
            Packet.DfbInfo.rev1.StartLBA = kwargs['StartLBA']
        if 'offset' in kwargs:
            Packet.DfbInfo.rev1.offset = kwargs['offset']
        if 'flags1' in kwargs:
            Packet.DfbInfo.rev1.flags1 = kwargs['flags1']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
        ResponsePacket *= 2
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            new_responsepacket = ResponsePacket[8:8 + 28]
            variablelized_header = typelib.variablelize('logical_seek_ret_value',new_responsepacket)                       
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReadPhysicalSector( **kwargs ):
    """
    Function ID: 0x0135
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param XfrLength
        type: 
        default: none
        description: 
    @param Sector
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param Flag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_physical_sector_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0135
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.rev1.Cyl = kwargs['Cyl']
        if 'XfrLength' in kwargs:
            Packet.DfbInfo.rev1.XfrLength = kwargs['XfrLength']
        if 'Sector' in kwargs:
            Packet.DfbInfo.rev1.Sector = kwargs['Sector']
        if 'Head' in kwargs:
            Packet.DfbInfo.rev1.Head = kwargs['Head']
        if 'Flag' in kwargs:
            Packet.DfbInfo.rev1.Flag = kwargs['Flag']

        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_physical_sector_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WritePhysicalSector( **kwargs ):
    """
    Function ID: 0x0136
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param XferLength
        type: 
        default: none
        description: 
    @param Sector
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param Flag
        type: 
        default: none
        description: 
    @param WriteData
        type: string 
        default: a string of 0's of length sdbp.BlockSizeInBytes assigned to sdbp.WriteBuffer
        Description: this is the data to be written
    """
    global WriteBuffer, BlockSizeInBytes
    
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_physical_sector_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1       
        Packet.FunctionId = 0x0136
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.rev1.Cyl = kwargs['Cyl']
        if 'XferLength' in kwargs:
            Packet.DfbInfo.rev1.XferLength = kwargs['XferLength']
        if 'Sector' in kwargs:
            Packet.DfbInfo.rev1.Sector = kwargs['Sector']
        if 'Head' in kwargs:
            Packet.DfbInfo.rev1.Head = kwargs['Head']
        if 'Flag' in kwargs:
            Packet.DfbInfo.rev1.Flag = kwargs['Flag']
        if 'WriteData' in kwargs:
            WriteBuffer = kwargs['WriteData']
        else:
            WriteBuffer = '\x00' * BlockSizeInBytes       

        #Packet header + packet footer + the length of the write buffer
        Packet.Length = 504 + (Packet.DfbInfo.rev1.XferLength * BlockSizeInBytes)
        
        # packet + (packet_start_offset - packet size
        ResponsePacket = SendReceiveSDBP( Packet.dump() 
                                                                    + ((512 - Packet.size()) * '\x00')
                                                                    + (Packet.DfbInfo.rev1.XferLength * WriteBuffer), TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('write_physical_sector_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReadLBA( **kwargs ):
    """
    Function ID: 0x0137
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartLBALow
        type: 
        default: none
        description: 
    @param StartLBAHigh
        type: 
        default: none
        description: 
    @param XfrLength
        type: 
        default: none
        description: 
    @param flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_lba_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0137
        Packet.Revision = 1
        if 'StartLBALow' in kwargs:
            Packet.DfbInfo.rev1.StartLBALow = kwargs['StartLBALow']
        if 'StartLBAHigh' in kwargs:
            Packet.DfbInfo.rev1.StartLBAHigh = kwargs['StartLBAHigh']
        if 'XfrLength' in kwargs:
            Packet.DfbInfo.rev1.XfrLength = kwargs['XfrLength']
        if 'flags' in kwargs:
            Packet.DfbInfo.rev1.flags = kwargs['flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_lba_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteLBA( **kwargs ):
    """
    Function ID: 0x0138
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartLBALow
        type: 
        default: none
        description: 
    @param StartLBAHigh
        type: 
        default: none
        description: 
    @param XfrLength
        type: 
        default: none
        description: 
    @param flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_lba_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0138
        Packet.Revision = 1
        if 'StartLBALow' in kwargs:
            Packet.DfbInfo.rev1.StartLBALow = kwargs['StartLBALow']
        if 'StartLBAHigh' in kwargs:
            Packet.DfbInfo.rev1.StartLBAHigh = kwargs['StartLBAHigh']
        if 'XfrLength' in kwargs:
            Packet.DfbInfo.rev1.XfrLength = kwargs['XfrLength']
        if 'flags' in kwargs:
            Packet.DfbInfo.rev1.flags = kwargs['flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('write_lba_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReadLongLBA( **kwargs ):
    """
    Function ID: 0x0139
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartLBALow
        type: 
        default: none
        description: 
    @param StartLBAHigh
        type: 
        default: none
        description: 
    @param XfrLength
        type: 
        default: none
        description: 
    @param flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_long_lba_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0139
        Packet.Revision = 1
        if 'StartLBALow' in kwargs:
            Packet.DfbInfo.rev1.StartLBALow = kwargs['StartLBALow']
        if 'StartLBAHigh' in kwargs:
            Packet.DfbInfo.rev1.StartLBAHigh = kwargs['StartLBAHigh']
        if 'XfrLength' in kwargs:
            Packet.DfbInfo.rev1.XfrLength = kwargs['XfrLength']
        if 'flags' in kwargs:
            Packet.DfbInfo.rev1.flags = kwargs['flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_long_lba_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteLongLBA( **kwargs ):
    """
    Function ID: 0x013A
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param StartLBALow
        type: 
        default: none
        description: 
    @param StartLBAHigh
        type: 
        default: none
        description: 
    @param XfrLength
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_long_lba_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x013A
        Packet.Revision = 1
        if 'StartLBALow' in kwargs:
            Packet.DfbInfo.rev1.StartLBALow = kwargs['StartLBALow']
        if 'StartLBAHigh' in kwargs:
            Packet.DfbInfo.rev1.StartLBAHigh = kwargs['StartLBAHigh']
        if 'XfrLength' in kwargs:
            Packet.DfbInfo.rev1.XfrLength = kwargs['XfrLength']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('write_long_lba_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReadTrack( **kwargs ):
    """
    Function ID: 0x013B
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Offset
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param RepeatCount
        type: 
        default: none
        description: 
    @param Flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_track_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x013B
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.Rev1.Cyl = kwargs['Cyl']
        if 'Offset' in kwargs:
            Packet.DfbInfo.Rev1.Offset = kwargs['Offset']
        if 'Head' in kwargs:
            Packet.DfbInfo.Rev1.Head = kwargs['Head']
        if 'RepeatCount' in kwargs:
            Packet.DfbInfo.Rev1.RepeatCount = kwargs['RepeatCount']
        if 'Flags' in kwargs:
            Packet.DfbInfo.Rev1.Flags = kwargs['Flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_track_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)                    

def WriteTrack( **kwargs ):
    """
    Function ID: 0x013C
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Offset
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param RepeatCount_Duration
        type: 
        default: none
        description: 
    @param Flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_track_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x013C
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.Rev1.Cyl = kwargs['Cyl']
        if 'Offset' in kwargs:
            Packet.DfbInfo.Rev1.Offset = kwargs['Offset']
        if 'Head' in kwargs:
            Packet.DfbInfo.Rev1.Head = kwargs['Head']
        if 'RepeatCount_Duration' in kwargs:
            Packet.DfbInfo.Rev1.RepeatCount_Duration = kwargs['RepeatCount_Duration']
        if 'Flags' in kwargs:
            Packet.DfbInfo.Rev1.Flags = kwargs['Flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('write_track_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)                        

def EraseTrack( **kwargs ):
    """
    Function ID: 0x013F
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param Flags
        type: 
        default: none
        description: 0 to disable STIR control, 1 to enable STIR control
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'erase_track_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x013F
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.Rev1.Cyl = kwargs['Cyl']
        if 'Head' in kwargs:
            Packet.DfbInfo.Rev1.Head = kwargs['Head']
        if 'Flags' in kwargs:
            Packet.DfbInfo.Rev1.Flags = kwargs['Flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('erase_track_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def HeadSpikeScreen( **kwargs ):
    """
    Function ID: 0x0140
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param cyl
        type: 
        default: none
        description: 
    @param head
        type: 
        default: none
        description: 
    @param duration
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'head_spike_screen_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0140
        Packet.Revision = 1
        if 'cyl' in kwargs:
            Packet.DfbInfo.rev1.cyl = kwargs['cyl']
        if 'head' in kwargs:
            Packet.DfbInfo.rev1.head = kwargs['head']
        if 'duration' in kwargs:
            Packet.DfbInfo.rev1.duration = kwargs['duration']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             
def COEReadTrack( **kwargs ):
    """
    Function ID: 0x0141
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param RepeatCount
        type: 
        default: none
        description: 
    @param Flags
        type: 
        default: none
        description: 
    @param TLevel
        type: 
        default: none
        description: 
    @param TLevelDDRS
        type: 
        default: none
        description: 
    @param EDAC0Counter
        type: 
        default: none
        description: 
    @param EDAC1Counter
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'coe_read_track_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0141
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.Rev1.Cyl = kwargs['Cyl']
        if 'Head' in kwargs:
            Packet.DfbInfo.Rev1.Head = kwargs['Head']
        if 'RepeatCount' in kwargs:
            Packet.DfbInfo.Rev1.RepeatCount = kwargs['RepeatCount']
        if 'Flags' in kwargs:
            Packet.DfbInfo.Rev1.Flags = kwargs['Flags']
        if 'TLevel' in kwargs:
            Packet.DfbInfo.Rev1.TLevel = kwargs['TLevel']
        if 'TLevelDDRS' in kwargs:
            Packet.DfbInfo.Rev1.TLevelDDRS = kwargs['TLevelDDRS']
        if 'EDAC0Counter' in kwargs:
            Packet.DfbInfo.Rev1.EDAC0Counter = kwargs['EDAC0Counter']
        if 'EDAC1Counter' in kwargs:
            Packet.DfbInfo.Rev1.EDAC1Counter = kwargs['EDAC1Counter']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('coe_read_track_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReadWedgeSupersector( **kwargs ):
    """
    Function ID: 0x0142
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param WedgeXfrOptions
        type: 
        default: none
        description: 
    @param Wedge
        type: 
        default: none
        description: 
    @param XfrLengthPerWedge
        type: 
        default: none
        description: 
    @param NumXfrWedge
        type: 
        default: none
        description: 
    @param XfrWedgeType
        type: 
        default: none
        description: 
    @param NumWedgesToSkip
        type: 
        default: none
        description: 
    @param RegisterAddress
        type: 
        default: none
        description: 
    @param RegisterBank
        type: 
        default: none
        description: 
    @param FaultMask
        type: 
        default: none
        description: 
    @param NumRegsToRead
        type: 
        default: none
        description: 
    @param Reserved
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_wedge_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0142
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.rev1.Cyl = kwargs['Cyl']
        if 'Head' in kwargs:
            Packet.DfbInfo.rev1.Head = kwargs['Head']
        if 'WedgeXfrOptions' in kwargs:
            Packet.DfbInfo.rev1.WedgeXfrOptions = kwargs['WedgeXfrOptions']
        if 'Wedge' in kwargs:
            Packet.DfbInfo.rev1.Wedge = kwargs['Wedge']
        if 'XfrLengthPerWedge' in kwargs:
            Packet.DfbInfo.rev1.XfrLengthPerWedge = kwargs['XfrLengthPerWedge']
        if 'NumXfrWedge' in kwargs:
            Packet.DfbInfo.rev1.NumXfrWedge = kwargs['NumXfrWedge']
        if 'XfrWedgeType' in kwargs:
            Packet.DfbInfo.rev1.XfrWedgeType = kwargs['XfrWedgeType']
        if 'NumWedgesToSkip' in kwargs:
            Packet.DfbInfo.rev1.NumWedgesToSkip = kwargs['NumWedgesToSkip']
        if 'RegisterAddress' in kwargs:
            Packet.DfbInfo.rev1.RegisterAddress = kwargs['RegisterAddress']
        if 'RegisterBank' in kwargs:
            Packet.DfbInfo.rev1.RegisterBank = kwargs['RegisterBank']
        if 'FaultMask' in kwargs:
            Packet.DfbInfo.rev1.FaultMask = kwargs['FaultMask']
        if 'NumRegsToRead' in kwargs:
            Packet.DfbInfo.rev1.NumRegsToRead = kwargs['NumRegsToRead']
        if 'Reserved' in kwargs:
            Packet.DfbInfo.rev1.Reserved = kwargs['Reserved']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_wedge_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteWedgeSupersector( **kwargs ):
    """
    Function ID: 0x0143
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param WedgeXfrOptions
        type: 
        default: none
        description: 
    @param Wedge
        type: 
        default: none
        description: 
    @param XfrLengthPerWedge
        type: 
        default: none
        description: 
    @param NumXfrWedge
        type: 
        default: none
        description: 
    @param XfrWedgeType
        type: 
        default: none
        description: 
    @param NumWedgesToSkip
        type: 
        default: none
        description: 
    @param Reserved2
        type: 
        default: none
        description: 
    @param FaultMask
        type: 
        default: none
        description: 
    @param PatternLength
        type: 
        default: none
        description: 
    @param PatternOffset
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_wedge_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0143
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.rev1.Cyl = kwargs['Cyl']
        if 'Head' in kwargs:
            Packet.DfbInfo.rev1.Head = kwargs['Head']
        if 'WedgeXfrOptions' in kwargs:
            Packet.DfbInfo.rev1.WedgeXfrOptions = kwargs['WedgeXfrOptions']
        if 'Wedge' in kwargs:
            Packet.DfbInfo.rev1.Wedge = kwargs['Wedge']
        if 'XfrLengthPerWedge' in kwargs:
            Packet.DfbInfo.rev1.XfrLengthPerWedge = kwargs['XfrLengthPerWedge']
        if 'NumXfrWedge' in kwargs:
            Packet.DfbInfo.rev1.NumXfrWedge = kwargs['NumXfrWedge']
        if 'XfrWedgeType' in kwargs:
            Packet.DfbInfo.rev1.XfrWedgeType = kwargs['XfrWedgeType']
        if 'NumWedgesToSkip' in kwargs:
            Packet.DfbInfo.rev1.NumWedgesToSkip = kwargs['NumWedgesToSkip']
        if 'Reserved2' in kwargs:
            Packet.DfbInfo.rev1.Reserved2 = kwargs['Reserved2']
        if 'FaultMask' in kwargs:
            Packet.DfbInfo.rev1.FaultMask = kwargs['FaultMask']
        if 'PatternLength' in kwargs:
            Packet.DfbInfo.rev1.PatternLength = kwargs['PatternLength']
        if 'PatternOffset' in kwargs:
            Packet.DfbInfo.rev1.PatternOffset = kwargs['PatternOffset']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('write_wedge_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteSystemFile( **kwargs ):
    """
    Function ID: 0x0145
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param File
        type: 
        default: none
        description: 
    @param Length
        type: 
        default: none
        description: 
    @param Offset
        type: 
        default: none
        description: 
    @param Flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_system_files_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0145
        Packet.Revision = 1
        if 'File' in kwargs:
            Packet.DfbInfo.rev1.File = kwargs['File']
        if 'Length' in kwargs:
            Packet.DfbInfo.rev1.Length = kwargs['Length']
        if 'Offset' in kwargs:
            Packet.DfbInfo.rev1.Offset = kwargs['Offset']
        if 'Flags' in kwargs:
            Packet.DfbInfo.rev1.Flags = kwargs['Flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def FormatTrack( **kwargs ):
    """
    Function ID: 0x0147
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    @param Flags
        type: 
        default: none
        description: 
    @param Pattern
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'format_track_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0147
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.rev1.Cyl = kwargs['Cyl']
        if 'Head' in kwargs:
            Packet.DfbInfo.rev1.Head = kwargs['Head']
        if 'Flags' in kwargs:
            Packet.DfbInfo.rev1.Flags = kwargs['Flags']
        if 'Pattern' in kwargs:
            Packet.DfbInfo.rev1.Pattern = kwargs['Pattern']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ProcessPList( **kwargs ):
    """
    Function ID: 0x0148
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flags
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'process_plist_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0148
        Packet.Revision = 1
        if 'Flags' in kwargs:
            Packet.DfbInfo.rev1.Flags = kwargs['Flags']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteDriveMemory( **kwargs ):
    """
    Function ID: 0x014A
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param MemoryOffset
        type: 
        default: none
        description: 
    @param XferLength
        type: 
        default: none
        description: 
    @param MemoryArea
        type: 
        default: none
        description: 
    @param RegisterSize
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_drive_memory_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x014A
        Packet.Revision = 1
        if 'MemoryOffset' in kwargs:
            Packet.DfbInfo.rev1.MemoryOffset = kwargs['MemoryOffset']
        if 'XferLength' in kwargs:
            Packet.DfbInfo.rev1.XferLength = kwargs['XferLength']
        if 'MemoryArea' in kwargs:
            Packet.DfbInfo.rev1.MemoryArea = kwargs['MemoryArea']
        if 'RegisterSize' in kwargs:
            Packet.DfbInfo.rev1.RegisterSize = kwargs['RegisterSize']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteDriveTables( **kwargs ):
    """
    Function ID: 0x014C
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flags
        type: 
        default: none
        description: 
    @param Table
        type: 
        default: none
        description: 
    @param MemoryOffset
        type: 
        default: none
        description: 
    @param TransferLength
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_drive_tables_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x014C
        Packet.Revision = 1
        if 'Flags' in kwargs:
            Packet.DfbInfo.rev1.Flags = kwargs['Flags']
        if 'Table' in kwargs:
            Packet.DfbInfo.rev1.Table = kwargs['Table']
        if 'MemoryOffset' in kwargs:
            Packet.DfbInfo.rev1.MemoryOffset = kwargs['MemoryOffset']
        if 'TransferLength' in kwargs:
            Packet.DfbInfo.rev1.TransferLength = kwargs['TransferLength']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReadReadChannel( **kwargs ):
    """
    Function ID: 0x014D
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 3
        description: Which revision packet to send to the drive. Revision 3 DFB results in revision 1 DSB
    -----revision 3 parameters-----
    @param RegisterAddress
        type: 
        default: none
        description: 
    @param RegisterCount
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 3
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 3:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_channel_read_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x014D
        Packet.Revision = 3
        if 'RegisterAddress' in kwargs:
            Packet.DfbInfo.rev3.RegisterAddress = kwargs['RegisterAddress']
        if 'RegisterCount' in kwargs:
            Packet.DfbInfo.rev3.RegisterCount = kwargs['RegisterCount']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_channel_read_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             
        
def WriteReadChannel( **kwargs ):
    """
    Function ID: 0x014E
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 3
        description: Which revision packet to send to the drive. Revision 3 DFB results in revision 1 DSB
    -----revision 3 parameters-----
    @param RegisterAddress
        type: 
        default: none
        description: 
    @param RegisterValue
        type: 
        default: none
        description: 
    @param MaskValue
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 3
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 3:
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_channel_write_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x014E
        Packet.Revision = 3
        if 'RegisterAddress' in kwargs:
            Packet.DfbInfo.rev3.RegisterAddress = kwargs['RegisterAddress']
        if 'RegisterValue' in kwargs:
            Packet.DfbInfo.rev3.RegisterValue = kwargs['RegisterValue']
        if 'MaskValue' in kwargs:
            Packet.DfbInfo.rev3.MaskValue = kwargs['MaskValue']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('read_channel_write_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SendServoCommand( **kwargs ):
    """
    Function ID: 0x014F
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flags
        type: 
        default: none
        description: 
    @param Pad
        type: 
        default: none
        description: 
    @param ServoCmd
        type: 
        default: none
        description: 
    @param ServoCmdParam1
        type: 
        default: none
        description: 
    @param ServoCmdParam2
        type: 
        default: none
        description: 
    @param ServoCmdParam3
        type: 
        default: none
        description: 
    @param ServoCmdParam4
        type: 
        default: none
        description: 
    @param ServoCmdParam5
        type: 
        default: none
        description: 
    @param ServoCmdParam6
        type: 
        default: none
        description: 
    @param ServoCmdParam7
        type: 
        default: none
        description: 
    @param ServoCmdParam8
        type: 
        default: none
        description: 
    @param ServoCmdParam9
        type: 
        default: none
        description: 
    @param ServoCmdParam10
        type: 
        default: none
        description: 
    @param ServoCmdParam11
        type: 
        default: none
        description: 
    @param ServoCmdParam12
        type: 
        default: none
        description: 
    @param ServoCmdParam13
        type: 
        default: none
        description: 
    @param ServoCmdParam14
        type: 
        default: none
        description: 
    @param ServoCmdParam15
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'send_servo_cmd_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x014F
        Packet.Revision = 1
        if 'Flags' in kwargs:
            Packet.DfbInfo.rev1.Flags = kwargs['Flags']
        if 'Pad' in kwargs:
            Packet.DfbInfo.rev1.Pad = kwargs['Pad']
        if 'ServoCmd' in kwargs:
            Packet.DfbInfo.rev1.ServoCmd = kwargs['ServoCmd']
        if 'ServoCmdParam1' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam1 = kwargs['ServoCmdParam1']
        if 'ServoCmdParam2' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam2 = kwargs['ServoCmdParam2']
        if 'ServoCmdParam3' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam3 = kwargs['ServoCmdParam3']
        if 'ServoCmdParam4' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam4 = kwargs['ServoCmdParam4']
        if 'ServoCmdParam5' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam5 = kwargs['ServoCmdParam5']
        if 'ServoCmdParam6' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam6 = kwargs['ServoCmdParam6']
        if 'ServoCmdParam7' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam7 = kwargs['ServoCmdParam7']
        if 'ServoCmdParam8' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam8 = kwargs['ServoCmdParam8']
        if 'ServoCmdParam9' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam9 = kwargs['ServoCmdParam9']
        if 'ServoCmdParam10' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam10 = kwargs['ServoCmdParam10']
        if 'ServoCmdParam11' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam11 = kwargs['ServoCmdParam11']
        if 'ServoCmdParam12' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam12 = kwargs['ServoCmdParam12']
        if 'ServoCmdParam13' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam13 = kwargs['ServoCmdParam13']
        if 'ServoCmdParam14' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam14 = kwargs['ServoCmdParam14']
        if 'ServoCmdParam15' in kwargs:
            Packet.DfbInfo.rev1.ServoCmdParam15 = kwargs['ServoCmdParam15']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def GetTemperature( **kwargs ):
    """
    Function ID: 0x0150
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param TemperatureType
        type: int
        default: 0
        description: 
                        0 	 Converted Temperature
                        1 	Temperature Reference Voltage
                        2 	Temperature Voltage 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'get_temperature_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0150
        Packet.Revision = 1
        if 'TemperatureType' in kwargs:
            Packet.DfbInfo.rev1.TemperatureType = kwargs['TemperatureType']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('get_temperature_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)               


def SMARTCommand( **kwargs ):
    """
    Function ID: 0x0152
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Command
        type: 
        default: none
        description: 
    @param DataSetSelectorValue
        type: 
        default: none
        description: 
    @param WriteAltToneSetup
        type: 
        default: none
        description: 
    @param DataSourceSelectorValue
        type: 
        default: none
        description: 
    @param NumberOfHours
        type: 
        default: none
        description: 
    @param MemoryOffset
        type: 
        default: none
        description: 
    @param AllocLength
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'smart_command_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0152
        Packet.Revision = 1
        if 'Command' in kwargs:
            Packet.DfbInfo.rev1.Command = kwargs['Command']
        if 'DataSetSelectorValue' in kwargs:
            Packet.DfbInfo.rev1.Argument1.DataSetSelectorValue = kwargs['DataSetSelectorValue']
        if 'WriteAltToneSetup' in kwargs:
            Packet.DfbInfo.rev1.Argument1.WriteAltToneSetup = kwargs['WriteAltToneSetup']
        if 'DataSourceSelectorValue' in kwargs:
            Packet.DfbInfo.rev1.Argument1.DataSourceSelectorValue = kwargs['DataSourceSelectorValue']
        if 'NumberOfHours' in kwargs:
            Packet.DfbInfo.rev1.Argument2.NumberOfHours = kwargs['NumberOfHours']
        if 'MemoryOffset' in kwargs:
            Packet.DfbInfo.rev1.MemoryOffset = kwargs['MemoryOffset']
        if 'AllocLength' in kwargs:
            Packet.DfbInfo.rev1.AllocLength = kwargs['AllocLength']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('smart_command_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def GetDriveInformation( **kwargs ):
    """
    Function ID: 0x0156
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Specifier
        type: 
        default: none
        description: 
    @param AllocationLength
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'get_drive_information_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionID = 0x0156
        Packet.Revision = 1
        if 'Specifier' in kwargs:
            Packet.DfbInfo.rev1.Specifier = kwargs['Specifier']
        if 'AllocationLength' in kwargs:
            Packet.DfbInfo.rev1.AllocationLength = kwargs['AllocationLength']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SpinupSpindown( **kwargs ):
    """
    Function ID: 0x0157
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param SpinUpFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'spin_up_or_down_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionID = 0x0157
        Packet.Revision = 1
        if 'SpinUpFlag' in kwargs:
            Packet.DfbInfo.rev1.SpinUpFlag = kwargs['SpinUpFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def GetServoErrorFIFO( **kwargs ):
    """
    Function ID: 0x0158
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    none
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'get_servo_error_fifo_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0158
        Packet.Revision = 1
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def FormatSystemArea( **kwargs ):
    """
    Function ID: 0x0159
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Pattern
        type: 
        default: none
        description: 
    @param Reserved
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'format_system_area_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0159
        Packet.Revision = 1
        if 'Pattern' in kwargs:
            Packet.DfbInfo.rev1.Pattern = kwargs['Pattern']
        if 'Reserved' in kwargs:
            Packet.DfbInfo.rev1.Reserved = kwargs['Reserved']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ForceMemoryECCErrors( **kwargs ):
    """
    Function ID: 0x015D
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Offset
        type: 
        default: none
        description: 
    @param MemoryArea
        type: 
        default: none
        description: 
    @param ErrorType
        type: 
        default: none
        description: 
    @param Reserved
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'force_memory_ecc_errors_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x015D
        Packet.Revision = 1
        if 'Offset' in kwargs:
            Packet.DfbInfo.Rev1.Offset = kwargs['Offset']
        if 'MemoryArea' in kwargs:
            Packet.DfbInfo.Rev1.MemoryArea = kwargs['MemoryArea']
        if 'ErrorType' in kwargs:
            Packet.DfbInfo.Rev1.ErrorType = kwargs['ErrorType']
        if 'Reserved' in kwargs:
            Packet.DfbInfo.Rev1.Reserved = kwargs['Reserved']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ModifyActiveServoFaultMask( **kwargs ):
    """
    Function ID: 0x015E
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FaultMask
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'modify_active_servo_fault_mask_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x015E
        Packet.Revision = 1
        if 'FaultMask' in kwargs:
            Packet.DfbInfo.Rev1.FaultMask = kwargs['FaultMask']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReportTrackAttributes( **kwargs ):
    """
    Function ID: 0x015F
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Cyl
        type: 
        default: none
        description: 
    @param Head
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'report_track_attrib_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x015F
        Packet.Revision = 1
        if 'Cyl' in kwargs:
            Packet.DfbInfo.Cyl = kwargs['Cyl']
        if 'Head' in kwargs:
            Packet.DfbInfo.Head = kwargs['Head']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('report_track_attrib_return',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def WriteCongen( **kwargs ):
    """
    Function ID: 0x0161
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flags
        type: 
        default: none
        description: 
    @param FileType
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'write_congen_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0161
        Packet.Revision = 1
        if 'Flags' in kwargs:
            Packet.DfbInfo.Rev1.Flags = kwargs['Flags']
        if 'FileType' in kwargs:
            Packet.DfbInfo.Rev1.FileType = kwargs['FileType']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ManufactureControl( **kwargs ):
    """
    Function ID: 0x0163
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'manufacturecontrol_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0163
        Packet.Revision = 1
        if 'Flag' in kwargs:
            Packet.DfbInfo.rev1.Flag = kwargs['Flag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def ReloadRAP( **kwargs ):
    """
    Function ID: 0x0164
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param RwDataPartitionTrackFormatType
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'reload_rap_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0164
        Packet.Revision = 1
        if 'RwDataPartitionTrackFormatType' in kwargs:
            Packet.DfbInfo.Rev1.RwDataPartitionTrackFormatType = kwargs['RwDataPartitionTrackFormatType']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('reload_rap_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetFullRetryControl( **kwargs ):
    """
    Function ID: 0x0165
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param FullRetryFlag
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'full_retry_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0165
        Packet.Revision = 1
        if 'FullRetryFlag' in kwargs:
            Packet.DfbInfo.rev1.FullRetryFlag = kwargs['FullRetryFlag']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             
      
def ReadChannelBCILogs(**kwargs):
    """
    Function ID: 0x016E
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param OptionFlags
        type: bitfield
        default: 0x00
        description:
                        StOnly
                        Status Only - bit 0
                        * Set = Only status data are returned. LogData, FirstEntryReturned and NumberEntriesReturned are not returned. 
                                    All other parameters are ignored.
                        * Clear = All status and log data are returned. 

                        ReAll
                        Return All entries specified by Start Entry and Max Entries - bit 1
                        * Set = The number of SLE entries currently recorded in the log buffer will be ignored, and the number of entries 
                                    returned will be determined from the MaxEntries value, the StartEntry value, and the allocated size of the SLE buffer as: 
                                    values = min( max(BufferSize-FirstEntry, 0), MaxEntries)
                        * Clear = Only the number of SLEs logged since the last setup will be returned. 
    @param StartEntry
        type: 
        default: none
        description: 
    @param MaxEntry
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
                
        Packet = typelib.createPacket(['sdbp_packet_header', 'read_channel_bci_logs_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x016E
        Packet.Revision = 1
        if 'StartEntry' in kwargs:
            Packet.DfbInfo.rev1.StartEntry = kwargs['StartEntry']
        if 'MaxEntry' in kwargs:
            Packet.DfbInfo.rev1.MaxEntry = kwargs['MaxEntry']
        if 'OptionFlags' in kwargs:
            Packet.DfbInfo.rev1.OptionFlags = kwargs['OptionFlags']
        else: 
            Packet.DfbInfo.rev1.OptionFlags = 0x00
        print(Packet)
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)

        
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            if Packet.DfbInfo.rev1.OptionFlags&1 == 1: #check to see if the status only bit it set or cleared
                variablelized_header = typelib.variablelize('read_channel_bci_logs_status_return',ResponsePacket[MinPacketSize:])
            else:
                variablelized_header = typelib.variablelize('read_channel_bci_logs_addr_return',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             
        
def GetSkews( **kwargs ):
    """
    Function ID: 0x0171
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'get_skews_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0171
        Packet.Revision = 1
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('get_skews_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def SetSkews( **kwargs ):
    """
    Function ID: 0x0172
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param CylSkew
        type: 
        default: none
        description: 
    @param HeadSkew
        type: 
        default: none
        description: 
    @param MiniZoneSkew
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'set_skews_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0172
        Packet.Revision = 1
        if 'CylSkew' in kwargs:
            Packet.DfbInfo.rev1.Skews.CylSkew = kwargs['CylSkew']
        if 'HeadSkew' in kwargs:
            Packet.DfbInfo.rev1.Skews.HeadSkew = kwargs['HeadSkew']
        if 'MiniZoneSkew' in kwargs:
            Packet.DfbInfo.rev1.Skews.MiniZoneSkew = kwargs['MiniZoneSkew']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def GetServoConfig( **kwargs ):
    """
    Function ID: 0x0173
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param DfbInfo
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'diag_function_block'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0173
        Packet.Revision = 1
        if 'DfbInfo' in kwargs:
            Packet.DfbInfo = kwargs['DfbInfo']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('get_servo_config_ret',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def EWLMControl( **kwargs ):
    """
    Function ID: 0x0174
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Flags
        type: 
        default: none
        description: 
    @param EnhWorkloadMgmtPeriodIn100msIncrements
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'enh_workload_mgmt_log_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0174
        Packet.Revision = 1
        if 'Flags' in kwargs:
            Packet.DfbInfo.Flags = kwargs['Flags']
        if 'EnhWorkloadMgmtPeriodIn100msIncrements' in kwargs:
            Packet.DfbInfo.EnhWorkloadMgmtPeriodIn100msIncrements = kwargs['EnhWorkloadMgmtPeriodIn100msIncrements']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('enh_workload_mgmt_log_ret_value',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

def LockUnlockDiagnostics( **kwargs ):
    """
    Function ID: 0x0FFFF
    Note: DITS diagnostic function
    Description:
    -----all revision parameters-----
    @param WaitValue
        type: int or float
        default: 0
        description: The amount of time to wait in between polls for a returned packet.
    @param TimeoutValue 
        type: int
        default: 10
        description: The total amount of time to wait for a return packet before declaring failure
    @param Revision
        type: int
        default: 1
        description: Which revision packet to send to the drive. Revision 1 DFB results in revision 1 DSB
    -----revision 1 parameters-----
    @param Key
        type: 
        default: none
        description: 
    """
    if 'Revision' in kwargs:
        Revision = kwargs['Revision']
    else:
        Revision = 1
        
    if 'WaitValue' in kwargs:
        WaitValue = kwargs['WaitValue']
    else:
        WaitValue = 0
        
    if 'TimeoutValue' in kwargs:
        TimeoutValue = kwargs['TimeoutValue']
    else:
        TimeoutValue = 10
    
    if Revision == 1:
        Packet = typelib.createPacket(['sdbp_packet_header', 'lock_unlock_dfb'])
        Packet.FromPort = 1
        Packet.ToPort = 1
        Packet.Length = Packet.size() - typelib.getTypeSize('sdbp_packet_header')
        Packet.FunctionId = 0x0FFFF
        Packet.Revision = 1
        if 'Key' in kwargs:
            Packet.DfbInfo.rev1.Key = kwargs['Key']
     
        ResponsePacket = SendReceiveSDBP( Packet.dump() , TimeoutValue, WaitValue)
    
        MinPacketSize = typelib.getTypeSize('diag_common_return_block')
        Response = typelib.variablelize ( 'diag_common_return_block', ResponsePacket[:MinPacketSize] )
        if Response.StatusBlock.SenseKey != 0:
            print('Warning: There was an error reported in the response packet.')   
        try:
            MinPacketSize = typelib.getTypeSize('sdbp_packet_header')
            variablelized_packet = typelib.variablelize('sdbp_packet_header',ResponsePacket[:MinPacketSize])
            variablelized_header = typelib.variablelize('diag_status_block',ResponsePacket[MinPacketSize:])
            variablelized_packet.merge(variablelized_header)
            return variablelized_packet
        except:
            print('ERROR: Unable to process the DSB. The header is returned.') #unhandled error packet, alternate path
            return Response
    else: 
        print('Revision %d is not defined' % Revision)             

#----------data array used in bulding packets----------#

#each entry is of the form:
#       [function ID, sdbp header type, sending DFB type, receiving DFB type, sending DFB revision #, receiving DFB revision #]

             

#----------EweChye's UDS stuff and functions----------#
def getRAPFile():
    Packet = typelib.createPacket('rev1_generic_sdbp_dfb' )
    fillDETSHeader( Packet )
    Packet.Dfb.Header.FunctionId = DETSFunc.GET_RAP_DIAG_ID
    Packet.Dfb.Header.RevisionId = 1
    return Packet.dump()

def putRAPFile ( RAPFile ):
    Packet = typelib.createPacket('rev1_set_rap_sdbp_dfb')
    fillDETSHeader( Packet )
    Packet.Dfb.Header.FunctionId = DETSFunc.SET_RAP_DIAG_ID
    Packet.Dfb.Header.RevisionId = 1
    Packet.Rap = RAPFile
    return Packet.dump()


def ListToString ( List ):
    ReturnString = ''
    for Index in range( List.numElements() ):
        ReturnString = ReturnString + chr( List[Index] )
    return ReturnString

def DecriptString ( StringArray ):
    EncryptHelpers = [ 7, 6, 8, 23, 8, 12, 21, 17, 29, 15, 13, 19, 7, 28, 12, 12, 21, 5, 20, 26, 11, 29, 16, 24, 15, 13, 9, 1, 7, 30, 17, 14 ]
    XORSeed = 0xbe
    Index = 0
    ReturnString = ''
    for Index in range( StringArray.numElements()):
        ReturnString = ReturnString + chr( ( XORSeed ^ StringArray[ Index ] ) ^ EncryptHelpers[ Index ])
        XORSeed = StringArray[ Index ]
    return ReturnString


def convertABCDDigit ( Digit ):
    if Digit < 10:
        return chr(Digit + ord('0'))
    return chr(Digit - 10 + ord('A'))

def convertBCDToString( BCDChar ):
    if  isinstance(BCDChar, int):
        ConvertList = [ BCDChar ]
        LengthOfList = 1
    else:
        ConvertList = BCDChar
        LengthOfList = ConvertList.numElements()


    ReturnVal = ''
    Index = 0
    for Index in range( LengthOfList ):
        BCDChar = ConvertList[ Index ]
        Digit1 = (BCDChar & 0xF0 ) >> 4                   
        ReturnVal = ReturnVal + convertABCDDigit( Digit1 )

        Digit2 = (BCDChar & 0xF )
        ReturnVal = ReturnVal + convertABCDDigit( Digit2 )
        Index = Index + 1

    return ReturnVal

def processDriveAndFWInfo( DriveAndFWInfo ):
    DriveAndFWInfo._mycstruct__StructureFinalized = False
    DriveAndFWInfo.UDSTimeStampInus = (DriveAndFWInfo.DriveAndFWOnly.TimeStamp.TimestampBits32Thru47<<32) + (DriveAndFWInfo.DriveAndFWOnly.TimeStamp.TimestampBits16Thru31<<16) + DriveAndFWInfo.DriveAndFWOnly.TimeStamp.TimestampBits00Thru15

    BuildYear = convertBCDToString(DriveAndFWInfo.BuildInfo.Year_BCD[0]) + convertBCDToString(DriveAndFWInfo.BuildInfo.Year_BCD[1]) 
    BuildMonth = convertBCDToString(DriveAndFWInfo.BuildInfo.Month_BCD )
    BuildDay   = convertBCDToString(DriveAndFWInfo.BuildInfo.Day_BCD ) 
    DriveAndFWInfo.BuildDate =  BuildMonth + '/' + BuildDay + '/' + BuildYear 

    BuildHour   =  convertBCDToString( DriveAndFWInfo.BuildInfo.Time_BCD_MSB );
    BuildMinute =  convertBCDToString( DriveAndFWInfo.BuildInfo.Time_BCD_Mid );
    BuildSecond =  convertBCDToString( DriveAndFWInfo.BuildInfo.Time_BCD_LSB );
    DriveAndFWInfo.BuildTime =  BuildHour + ':' + BuildMinute + ':' + BuildSecond


    BuildYear = convertBCDToString(DriveAndFWInfo.BuildInfo.Pkg_Year_BCD[0]) + convertBCDToString(DriveAndFWInfo.BuildInfo.Pkg_Year_BCD[1]) 
    BuildMonth = convertBCDToString(DriveAndFWInfo.BuildInfo.Pkg_Month_BCD )
    BuildDay   = convertBCDToString(DriveAndFWInfo.BuildInfo.Pkg_Day_BCD ) 
    DriveAndFWInfo.PackageDate =  BuildMonth + '/' + BuildDay + '/' + BuildYear 

    BuildHour   =  convertBCDToString( DriveAndFWInfo.BuildInfo.Pkg_Time_BCD_MSB );
    BuildMinute =  convertBCDToString( DriveAndFWInfo.BuildInfo.Pkg_Time_BCD_Mid );
    BuildSecond =  convertBCDToString( DriveAndFWInfo.BuildInfo.Pkg_Time_BCD_LSB );
    DriveAndFWInfo.PackageTime =  BuildHour + ':' + BuildMinute + ':' + BuildSecond

    DriveAndFWInfo.GID        = convertBCDToString( DriveAndFWInfo.BuildInfo.GID )
    DriveAndFWInfo.ChangeList = convertBCDToString( DriveAndFWInfo.BuildInfo.ChangeList_BCD )
	#sprintf( ufiFirmwareInfo->IPAddress, "%d.%d.%d.%d",  FWBuildInfo->IPaddress[0], FWBuildInfo->IPaddress[1],
	#														FWBuildInfo->IPaddress[2], FWBuildInfo->IPaddress[3]);


    DriveAndFWInfo.ComputerName = DecriptString( DriveAndFWInfo.BuildInfo.ComputerName );
    DriveAndFWInfo.PartNumber = DecriptString( DriveAndFWInfo.BuildInfo.PartNumber )
    DriveAndFWInfo.BuilderId  = DecriptString( DriveAndFWInfo.BuildInfo.BuilderId )
    DriveAndFWInfo.LocalRev  = DecriptString( DriveAndFWInfo.BuildInfo.LocalRev )
    DriveAndFWInfo.CustRel  = DecriptString( DriveAndFWInfo.BuildInfo.CustRel )

    DriveAndFWInfo.PackageRev = DecriptString( DriveAndFWInfo.BuildInfo.PackageRev )
    DriveAndFWInfo.SATAExtCustRel = DecriptString( DriveAndFWInfo.BuildInfo.SATAExtCustRel )


    DriveAndFWInfo.ProductIDNumberASCII            = ListToString( DriveAndFWInfo.DriveAndFWOnly.ProductIDNumberASCII  )
    DriveAndFWInfo.FirmwareRevisionHiAndLoASCII    = ListToString( DriveAndFWInfo.DriveAndFWOnly.FirmwareRevisionHiAndLoASCII  )
    DriveAndFWInfo.CustomerFirmwareRevisionASCII   = ListToString( DriveAndFWInfo.DriveAndFWOnly.CustomerFirmwareRevisionASCII  )
    DriveAndFWInfo.ServoFirmwareRevisionASCII      = ListToString( DriveAndFWInfo.DriveAndFWOnly.ServoFirmwareRevisionASCII  )
    DriveAndFWInfo.DriveSerialNumberASCII          = ListToString( DriveAndFWInfo.DriveAndFWOnly.DriveSerialNumberASCII  )

    DriveAndFWInfo.BuildInfo.removeAttr('GID')
    DriveAndFWInfo.BuildInfo.removeAttr('Pkg_Time_BCD_MSB')
    DriveAndFWInfo.BuildInfo.removeAttr('Pkg_Time_BCD_Mid')
    DriveAndFWInfo.BuildInfo.removeAttr('Pkg_Time_BCD_LSB')
    DriveAndFWInfo.BuildInfo.removeAttr('Time_BCD_MSB')
    DriveAndFWInfo.BuildInfo.removeAttr('Time_BCD_Mid')
    DriveAndFWInfo.BuildInfo.removeAttr('Time_BCD_LSB')
    DriveAndFWInfo.BuildInfo.removeAttr('Day_BCD')
    DriveAndFWInfo.BuildInfo.removeAttr('Month_BCD')
    DriveAndFWInfo.BuildInfo.removeAttr('Year_BCD')
    DriveAndFWInfo.BuildInfo.removeAttr('Pkg_Day_BCD')
    DriveAndFWInfo.BuildInfo.removeAttr('Pkg_Month_BCD')
    DriveAndFWInfo.BuildInfo.removeAttr('Pkg_Year_BCD')
    DriveAndFWInfo.BuildInfo.removeAttr('PartNumber')

    DriveAndFWInfo.BuildInfo.removeAttr('ComputerName' );
    DriveAndFWInfo.BuildInfo.removeAttr('PackageRev' )
    DriveAndFWInfo.BuildInfo.removeAttr('BuilderId' )
    DriveAndFWInfo.BuildInfo.removeAttr('LocalRev' )
    DriveAndFWInfo.BuildInfo.removeAttr('CustRel' )
    DriveAndFWInfo.BuildInfo.removeAttr('SATAExtCustRel' )


    DriveAndFWInfo.DriveAndFWOnly.removeAttr('ProductIDNumberASCII'  )
    DriveAndFWInfo.DriveAndFWOnly.removeAttr('FirmwareRevisionHiAndLoASCII'  )
    DriveAndFWInfo.DriveAndFWOnly.removeAttr('CustomerFirmwareRevisionASCII'  )
    DriveAndFWInfo.DriveAndFWOnly.removeAttr('ServoFirmwareRevisionASCII'  )
    DriveAndFWInfo.DriveAndFWOnly.removeAttr('DriveSerialNumberASCII'  )
    DriveAndFWInfo.DriveAndFWOnly.removeAttr('TimeStamp')




    DriveAndFWInfo.DriveAndFWOnly.removeAttr('WorldWideName')


    #DescriptString( ufiFirmwareInfo->PartNumber,    FWBuildInfo->PartNumber, 	sizeof( FWBuildInfo->PartNumber ));
	#DescriptString( ufiFirmwareInfo->ComputerName,  FWBuildInfo->ComputerName,  sizeof( FWBuildInfo->ComputerName ));
	#DescriptString( ufiFirmwareInfo->PackageRev,    FWBuildInfo->PackageRev,  	sizeof( FWBuildInfo->PackageRev ));
	#DescriptString( ufiFirmwareInfo->BuilderID,     FWBuildInfo->BuilderId,  	sizeof( FWBuildInfo->BuilderId ));
	#DescriptString( ufiFirmwareInfo->LocalRev,      FWBuildInfo->LocalRev,  	sizeof( FWBuildInfo->LocalRev ));
	#DescriptString( ufiFirmwareInfo->CustRel,       FWBuildInfo->CustRel, 		sizeof( FWBuildInfo->CustRel ));

    DriveAndFWInfo._mycstruct__StructureFinalized = True
    #print DriveAndFWInfo
    return DriveAndFWInfo


def removeEscapeSequence( Binary ):
    ReturnPacket = ''
    Index = 0
    while Index < len(Binary):
        if ord( Binary[Index]) != 0xDB:
            ReturnPacket = ReturnPacket + Binary[Index ]
            Index += 1
        else:
            if Binary[Index+1] in [chr( 0xdb ), chr(0xc0 )]: 
                ReturnPacket = ReturnPacket + Binary[ Index + 1 ]
            else:
                sys.stderr.write( "\nNON-PSEUDO ESCAPE SEQUENCE SEEN at offset 0x%08X\n\n" % Index )
            Index += 2
    return ReturnPacket


def removeSerialPortProgramHeader ( Packet ):
    # check for eslip packet header
    if ord(Packet[0]) == 0xc0:
        Packet = removeEscapeSequence( Packet )

        #remove the sdbp header
        Packet = Packet[6:] 
        Packet = Packet[:-3]


    # check for serdump packet header
    if Packet[:12] == ';Serial Port':
        #print 'Found Header'
        return Packet[0x100:]
    return Packet


def UDSGetCodeRevision( UDSFileName ):
    UDSData = open( UDSFileName, 'rb' ).read()

    ResponsePacket = removeSerialPortProgramHeader( UDSData )
    MinPacketSize = typelib.getTypeSize('packet_header_and_fw_info')
    ParsedUDSData = typelib.variablelize ( 'packet_header_and_fw_info', ResponsePacket[:MinPacketSize] )
    ParsedUDSData = processDriveAndFWInfo( ParsedUDSData.DriveAndFWInfo )
    print(ParsedUDSData)

    if ParsedUDSData.SATAExtCustRel == 'FFFF':
        return ParsedUDSData.PackageRev + '.' + ParsedUDSData.CustRel 
    else:
        return ParsedUDSData.PackageRev + '.' + ParsedUDSData.CustRel + ParsedUDSData.SATAExtCustRel 



     #define CURRENT_LOG_PAGES_TRACE_CONTENT_TYPE          0x0030
     #define CURRENT_LOG_PAGES_TRACE_CONTENT_REV           0x0001

     #define VOLATILE_FAST_TRACE_CONTENT_TYPE              0x0038
     #define VOLATILE_FAST_TRACE_CONTENT_REV               0x0001

     #define BACKDOOR_STANDARD_CAPTURE_CONTENT_TYPE        0x0048
     #define BACKDOOR_STANDARD_CAPTURE_CONTENT_REV         0x0001

     #define VOLATILE_TRIGGER_CAPTURE_TRACE_CONTENT_TYPE   0x0050
     #define VOLATILE_TRIGGER_CAPTURE_TRACE_CONTENT_REV    0x0001

     #define VOLATILE_TRIGGER_CAPTURE_2_TRACE_CONTENT_TYPE 0x0060
     #define VOLATILE_TRIGGER_CAPTURE_2_TRACE_CONTENT_REV  0x0001

     #define VOLATILE_TRIGGER_CAPTURE_3_TRACE_CONTENT_TYPE 0x0068
     #define VOLATILE_TRIGGER_CAPTURE_3_TRACE_CONTENT_REV  0x0001

     #define VOLATILE_FAST_WRAP_TRACE_CONTENT_TYPE         0x0070
     #define VOLATILE_FAST_WRAP_TRACE_CONTENT_REV          0x0001

     #define VOLATILE_SLOW_WRAP_TRACE_CONTENT_TYPE         0x0080
     #define VOLATILE_SLOW_WRAP_TRACE_CONTENT_REV          0x0001

     #define VOLATILE_LOG_PAGE_3A_TRACE_CONTENT_TYPE       0x0088
     #define VOLATILE_LOG_PAGE_3A_TRACE_CONTENT_REV        0x0001

     #define VOLATILE_NON_WRAP_TRACE_CONTENT_TYPE          0x0090
     #define VOLATILE_NON_WRAP_TRACE_CONTENT_REV           0x0001

     #define VOLATILE_SECURITY_TRACE_CONTENT_TYPE          0x0098
     #define VOLATILE_SECURITY_TRACE_CONTENT_REV           0x0001

     #define LIFETIME_DNLD_FMT_TRACE_CONTENT_TYPE          0x00A0
     #define LIFETIME_DNLD_FMT_TRACE_CONTENT_REV           0x0001

     #define CONFIGURATION_DISC_TRACE_CONTENT_TYPE         0x00B0
     #define CONFIGURATION_DISC_TRACE_CONTENT_REV          0x0001

     #define FINISHED_FRAME_INDEX_FILE_TRACE_CONTENT_TYPE  0x00D0
     #define FINISHED_FRAME_INDEX_FILE_TRACE_CONTENT_REV   0x0001

     #define FINISHED_FRAME_FIRMWARE_ERR_CAPT_TRACE_CONTENT_TYPE    0x00E0
     #define FINISHED_FRAME_FIRMWARE_ERR_CAPT_TRACE_CONTENT_REV     0x0001

     #define FINISHED_FRAME_AUTO_DUMP_ERR_CAPT_TRACE_CONTENT_TYPE   0x00E4
     #define FINISHED_FRAME_AUTO_DUMP_ERR_CAPT_TRACE_CONTENT_REV    0x0001

     #define FINISHED_FRAME_MECH_MEDIA_ERR_CAPT_TRACE_CONTENT_TYPE  0x00E8
     #define FINISHED_FRAME_MECH_MEDIA_ERR_CAPT_TRACE_CONTENT_REV   0x0001

     #define FINISHED_FRAME_RPRTD_CNTLR_ERR_CAPT_TRACE_CONTENT_TYPE 0x00F0
     #define FINISHED_FRAME_RPRTD_CNTLR_ERR_CAPT_TRACE_CONTENT_REV  0x0001

     #define FINISHED_FRAME_OVFL_MECH_MEDIA_ERR_CAPT_TRACE_CONTENT_TYPE 0x00F4
     #define FINISHED_FRAME_OVFL_MECH_MEDIA_ERR_CAPT_TRACE_CONTENT_REV  0x0001

     #define FINISHED_FRAME_HOST_INTFC_ERR_CAPT_TRACE_CONTENT_TYPE  0x00F8
     #define FINISHED_FRAME_HOST_INTFC_ERR_CAPT_TRACE_CONTENT_REV   0x0001

     #define FINISHED_FRAME_FAST_WRAP_TRACE_CONTENT_TYPE   0x0100
     #define FINISHED_FRAME_FAST_WRAP_TRACE_CONTENT_REV    0x0001

     #define FINISHED_FRAME_SLOW_WRAP_TRACE_CONTENT_TYPE   0x0110
     #define FINISHED_FRAME_SLOW_WRAP_TRACE_CONTENT_REV    0x0001

     #define FINISHED_FRAME_LOG_PAGE_3A_TRACE_CONTENT_TYPE 0x0118
     #define FINISHED_FRAME_LOG_PAGE_3A_TRACE_CONTENT_REV  0x0001

     #define FINISHED_FRAME_NON_WRAP_TRACE_CONTENT_TYPE    0x0120
     #define FINISHED_FRAME_NON_WRAP_TRACE_CONTENT_REV     0x0001

     #define FINISHED_FRAME_SECURITY_TRACE_CONTENT_TYPE    0x0128
     #define FINISHED_FRAME_SECURITY_TRACE_CONTENT_REV     0x0001

     #define SMART_STRUCTURES_TRACE_CONTENT_TYPE           0x0130
     #define SMART_STRUCTURES_TRACE_CONTENT_REV            0x0001

     #define SMART_FRAMES_TRACE_CONTENT_TYPE               0x0140
     #define SMART_FRAMES_TRACE_CONTENT_REV                0x0001

     #define ONE_FINISHED_FRM_FAST_WRAP_TRACE_CONTENT_TYPE 0x0148
     #define ONE_FINISHED_FRM_FAST_WRAP_TRACE_CONTENT_REV  0x0001

     #define ONE_FINISHED_FRM_SLOW_WRAP_TRACE_CONTENT_TYPE 0x014C
     #define ONE_FINISHED_FRM_SLOW_WRAP_TRACE_CONTENT_REV  0x0001

     #define TRACE_END_BLOCK_CONTENT_TYPE                  0xFFFFU
     #define TRACE_END_BLOCK_CONTENT_REV                   0xFFFFU
     #define TRACE_END_BLOCK_CONTENT_SIZE_BYTES            0xFFFFFFFFUL

     #define TRACE_CONTENT_PAD_BEGIN_TYPE                  0x0000
     #define TRACE_CONTENT_PAD_BEGIN_REV                   0x0000
     #define TRACE_CONTENT_PAD_BEGIN_SIZE_BYTES            0x00000000


    #enum trace_content_index
    # typelib.getEnum('trace_content_index')
    # 
    #trace_content_header		
    #   TraceContentID  0x0
    #   Revision  0x0
    #   TraceContentSizeInBytes  0x0
    #capture_header
    #   Revision  0x0
    #   RAMSubType  0x0
    #   RAMType  0x0
    #   NativeRAMAddress  0x0
    #   SizeInBytes  0x0
    #packet_footer
    #   TraceEndBlock.TraceContentID  0x0
    #   TraceEndBlock.Revision  0x0
    #   TraceEndBlock.TraceContentSizeInBytes  0x0
    #   SegFooter.Signature  0x0
    #   SegFooter.TraceSessionID  0x0
    #   SegFooter.TraceSegmentIndex  0x0
    #   SegFooter.TotalTraceContentSizeInBytes  0x0
    #   SegFooter.TraceContentThisSegmentInBytes  0x0


#    print Response

    
def getMemModuleFromUDS( UDSRawData ):
    ParsedData = processUDSBDResponse( UDSRawData )
    for i in ParsedData:
        if isinstance( i,driveMemoryContent ):
            return i
    raise Exception('No Drive Memory Module found. Content ID 0x48')

def parseBackdoorStandardCaptureContent ( Content ):
    ReturnDriveMemory = driveMemoryContent()
    CapturePacketSize = typelib.getTypeSize('capture_header')

    while len( Content ) > 0 :
        CaptureHeader = typelib.variablelize( 'capture_header', Content[:CapturePacketSize] )
        #print CaptureHeader
        ReturnDriveMemory.addMemoryRegion( CaptureHeader.NativeRAMAddress, CaptureHeader.SizeInBytes, Content[ CapturePacketSize:CapturePacketSize + CaptureHeader.SizeInBytes] )
        Content = Content[ CapturePacketSize + CaptureHeader.SizeInBytes:] 

    return ReturnDriveMemory
#==================================================================================================================
#
# UDS functions
#
#==================================================================================================================
def fillUDSBDHeader ( Packet ):
    Packet.PacketHeader.ToPort   = 30
    Packet.PacketHeader.FromPort = 30
    Packet.PacketHeader.Length   =  Packet.size() - typelib.getTypeSize('sdbp_packet_header')

#==================================================================================================================
def UDSFastTrace ():
    Packet = typelib.createPacket('backdoor_debug_request_packet')
    fillUDSBDHeader( Packet )
    Packet.FuncID = 0
    Packet.Revision =  1
    return Packet.dump ()
#==================================================================================================================
def UDSGetVars ():
    Packet = typelib.createPacket('backdoor_debug_request_packet')
    fillUDSBDHeader( Packet )
    Packet.FuncID = 1
    Packet.Revision =  1
    return Packet.dump ()

#==================================================================================================================
# will only work for 1) even addresses 
def UDSReadMem ( StartAddress, Range ):
    Packet = typelib.createPacket('backdoor_debug_addr_range_request_packet')
    fillUDSBDHeader( Packet )
    Packet.FuncID = 2
    Packet.Revision =  1
    if StartAddress % 2 != 0 :
        raise Exception('Start addresss must be 2 byte aligned (%x)' % StartAddress )
    Packet.StartAddressNative = StartAddress
    Packet.LengthInBytes = Range
    return Packet.dump ()

#==================================================================================================================
# need to redo UDS into a class..... damn it
def UDSGetSN ( UDSDump ):
    ResponsePacket = removeSerialPortProgramHeader( UDSDump )

    MinPacketSize = typelib.getTypeSize('packet_header_and_fw_info')
    ParsedUDSData = typelib.variablelize ( 'packet_header_and_fw_info', ResponsePacket[:MinPacketSize] )
    ParsedUDSData = processDriveAndFWInfo( ParsedUDSData.DriveAndFWInfo )

    return ParsedUDSData.DriveSerialNumberASCII


#==================================================================================================================
def UDSWriteMem ( StartAddress, Range, WriteValue ):
    Packet = typelib.createPacket('backdoor_debug_addr_range_request_packet')
    fillUDSBDHeader( Packet )
    Packet.FuncID = 3
    Packet.Revision =  1

    if Range not in [2,4]:
        raise Exception('Range must be either 2 or 4 bytes (%x)' % Range )

    if StartAddress % 2 != 0 :
        raise Exception('Start addresss must be 2 byte aligned (%x)' % StartAddress )


    Packet.StartAddressNative = StartAddress
    Packet.LengthInBytes = Range
    Packet.ValueToWrite = WriteValue
    return Packet.dump ()



