import binascii

def printBinData(hdr,binData,lineWidth=48):
  chars = [binascii.hexlify(ch) for ch in binData]
  #print "TestBlock: ", " ".join(chars), "\n"      # Everything in one line
  result = "%s "%hdr
  while chars:
    for group in range(lineWidth/8):
      charSet,chars = chars[:8],chars[8:]
      result = "%s%s   " % (result," ".join(charSet),)
      if not chars: break
    result = "%s\n          "%(result.strip(),)                  
  print(result.strip(), "\n")
  
def sendPacket(packet, **kargs):
    printBinData('Sent:    ',packet)
    return SendBuffer(packet, checkSRQ=0, addSDBP=0)

def waitForAPacket(TimeoutValue,WaitValue,**kargs):
    buf=ReceiveBuffer(delSDBP=0, checkSRQ=0, timeout=TimeoutValue)
    printBinData('Response:',buf)
    return buf

def extractPCHSToLBATranslation(binPacket):
  """
  Extract the PCHS to LBA Translation from the returned binary packet 
  Packet Structure: https://wiki.seagate.com/confluence/display/Firmware/DITS+Translate+PCHS+to+LBA
  """
  chars = [binascii.hexlify(ch) for ch in binPacket]
  
  final = ""
  i = len(chars) - 1
  
  zeroFlag = 0
  # Loop through the returned packet starting at the end.
  while i >= 0:
    var = chars[i:i + 1]
    # Skip leading zeros. If we hit a value > 0 any 0's after that must be included in the final value
    if ''.join(var) != '00' or zeroFlag:
      final += ''.join(var)
      zeroFlag = 1
    i -= 1
  
  return int(final,16)

def extractUserLBAtoPCHSTranslation(binPacket):
  """
  Extract the UserLBA to PCHS Translation from the returned binary packet 
  Packet Structure: https://wiki.seagate.com/confluence/display/Firmware/DITS+Translate+User+LBA+to+PCHS
  """
  chars = [binascii.hexlify(ch) for ch in binPacket]
  
  # Get the head
  head = ''.join(chars[6][1:])
  
  # Get the sector
  sec = ''.join(chars[5])
  sec += ''.join(chars[4])
  sector = int('0x%s' % sec,16)
  
  # Get the cylinder
  i=3
  cyl = ""  
  while i>=0:
    cyl += ''.join(chars[i])
    i-=1
  
  cylinder = int('0x%s' % cyl,16)
  
  return int(cylinder), int(head), int(sector)

