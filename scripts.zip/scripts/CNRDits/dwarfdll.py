""" \file dwarfdll.py
Python wrapper for dwarfdll.dll.  Provides native Python access to the functions contained in the DLL.
"""

""" \mainpage
\htmlonly
<meta http-equiv="refresh" content="0; url=files.html">
The <a href="files.html">Files</a> page should be the default.
\endhtmlonly
"""

import struct
import os
import re
from ctypes import *
import types
#import gui

class DwarfdllException(Exception):
    """ Generic exception class to indicate a non-zero status returned from a dwarfdll.dll call """
    pass

class DwarfdllInvalidParamException(Exception):
    """ Generic exception class to indicate invalid parameters passed to this wrapper API """
    pass

class DwarfdllErrorCodes:

    """ Error code enumerations.  Python doesn't have enumerations.  This class serves to contain the list of
    possible error codes from the dwarfdll.dll.  It also contains a simple function to do a reverse lookup (get
    the symbolic name from a returned error code).  New error codes should be added here and explicitly assigned
    values."""
    # Function completed succesfully
    DWARF_SUCCESS                = 0
    # Unable to read/process input file
    UNABLE_TO_READ_FILE          = 1
    # Index supplied to function is out of range
    INDEX_OUT_OF_RANGE           = 2
    # Unable to return variable list as it hasn't been filled in yet
    VARIABLE_LIST_NOT_LOADED     = 3
    # Unable to fill in structure list as it hasn't been filled in yet
    STRUCTURE_LIST_NOT_LOADED    = 4
    # Unable to fill in function list as it hasn't been filled in yet
    FUNCTION_LIST_NOT_LOADED     = 5
    # list of types not loaded ( no call to LoadDwarfFile, or LoadDwarfFile failed )
    TYPE_LIST_NOT_LOADED         = 6
    # unable to find a type coresponding to a variable.......
    UNABLE_TO_FIND_TYPE          = 7

    @staticmethod
    def GetErrorDesc(errorCode):

        """ Static method to return a symbolic name from an error code value.
            @param errorCode The integer error code that you want the description for. """

        for errorCodeName in dir(DwarfdllErrorCodes):
            errorCodeValue = getattr(DwarfdllErrorCodes, errorCodeName)
            if isinstance(errorCodeValue, int):
                if errorCode == errorCodeValue:
                    return errorCodeName + (" (0x%04X)" % errorCode)

        return "UNKNOWN_ERROR (0x%04X)" % (errorCode)

class DwarfdllStruct(Structure):

    """ This base class should be inherited by all structures that will be used for dwarfdll.dll calls.  It contains
    a simple function to output the contents of the structure. It could be expanded to do other common tasks or structure
    manipulation. """
    def __init__(self):
        """ Copies over contents from py_struct into local fields.
            @param py_struct_to_copy structure to copy  (if not specified, defaults are used"""

    def __str__(self):
        strValue = self.__class__.__name__ + " struct:\n"

        for (fieldName, fieldType) in self._fields_:
            strValue += "\t%s: %s\n" % (fieldName, repr(getattr(self, fieldName)))

        return strValue


# This constant should be exported by the DLL
MAX_NAME_LENGTH = 1024

""" Implementation of the wrapper class for the var_type, func_type and type_type struct used in the DLL.
    Just like a C struct, the member order and data types are important here.  ctypes handles internal structure padding
    the same way as C which simplifies some things. """

class var_type(DwarfdllStruct):

    _fields_ = [
        ("Name",                    c_char * MAX_NAME_LENGTH    ),
        ("Address",                 c_uint                  ),
        ("VariableTypeLocation",    c_uint                  ),
               ]

class func_type(DwarfdllStruct):


    _fields_ = [
        ("Name",                    c_char * MAX_NAME_LENGTH    ),
        ("Address",                 c_uint                      ),
        ("Size",                    c_uint                      ),
        ("FunctionTypeLocation",    c_uint                      ),
                ]


def atom ( Item, SizeOfItem):
    if isinstance( Item, mycstruct ):
        return Item.dump()
    elif isinstance( Item, mycarray ):
        return Item.dump()
    else:
        ReturnStr = ''
        if SizeOfItem == 1:
            ReturnStr = ReturnStr + struct.pack( 'B', Item )
        elif SizeOfItem == 2: 
            ReturnStr = ReturnStr + struct.pack( 'H', Item )
        elif SizeOfItem == 4: 
            ReturnStr = ReturnStr + struct.pack( 'I', Item)
        elif SizeOfItem == 8: 
            ReturnStr = ReturnStr + struct.pack( 'Q', Item)
        return ReturnStr


def unatom ( Binpack, SizeOfItem ):
    if SizeOfItem == 1:
        return struct.unpack( 'B', Binpack )[0]
    elif SizeOfItem == 2: 
        return struct.unpack( 'H', Binpack )[0]
    elif SizeOfItem == 4: 
        return struct.unpack( 'I', Binpack )[0]
    elif SizeOfItem == 8:
        return struct.unpack( 'Q', Binpack )[0]



    raise Exception("unatom unhandled type")



class mycarray:
    def __init__ ( self, NumElements, SizeOfElement, MemberName = '', ParentStruct = None):
        self.__ObjectList = {}
        self.__Size = SizeOfElement * NumElements
        self.__NumElements = NumElements
        self.__SizeOfItem = SizeOfElement
        self.__Raw  = '\x00' * self.__Size
        self.__MemberName = MemberName
        self.__ParentStruct = ParentStruct
        self.__StructureFinalized = False
    
    def __setitem__(self, Key, Value):
        if not isinstance(Key, int):
            raise Exception('Key index not an integer')

        if Key >= self.__NumElements:
            raise Exception('Index out of range')

        OffsetOfItem = Key * self.__SizeOfItem
        NewValue = atom( Value, self.__SizeOfItem )
        self.__Raw = self.__Raw[:OffsetOfItem] + NewValue + self.__Raw[OffsetOfItem+self.__SizeOfItem:]

        if isinstance( Value, mycstruct ) or isinstance( Value, mycarray ):
            self.__ObjectList[ Key ] = Value

        if self.__StructureFinalized and self.__ParentStruct != None:
            self.__ParentStruct .callbackModify( self.__MemberName, OffsetOfItem, self.__SizeOfItem, NewValue )


    def __getitem__(self, Key ):
        if not isinstance(Key, int):
            raise Exception('Key index not an integer')

        if Key >= self.__NumElements:
            raise Exception('Index out of range')

        if Key in self.__ObjectList:
            NewValue = self.__ObjectList[ Key ]
        else:
            OffsetOfItem = Key * self.__SizeOfItem
            NewValue = unatom( self.__Raw[OffsetOfItem:OffsetOfItem+self.__SizeOfItem], self.__SizeOfItem )

        return NewValue

    def __str__(self, Prepend = ''):
        ReturnStr = Prepend + '['
        for i in range( self.__NumElements ):
            ElementItem = self.__getitem__( i ) 
            if isinstance( ElementItem, mycstruct ):
                #def __str__(self, Prepend = '\t'):
                ReturnStr =  ReturnStr + ElementItem.__str__(  '%s[%d]' % ( Prepend, i) )
            elif isinstance( ElementItem, mycarray ):
                ReturnStr = ReturnStr + ElementItem.__str__( '%s[%d]' % (Prepend, i ) )
            else:
                ReturnStr = ReturnStr + "%d " % ElementItem
            if i == (self.__NumElements-1):
                ReturnStr = ReturnStr + ']\n'
            else:
                ReturnStr = ReturnStr + ','

        return ReturnStr

    def numElements ( self ):
        return self.__NumElements

    def size ( self ):
        return self.__Size


    def structureFinalized ( self ):
        self.__StructureFinalized = True

    # dump the binary packet out. Takes no parameters
    def dump ( self ):
        return self.__Raw
    
    def callbackModify( self, AttrName, Offset, Size, Value ):
        Index = int( AttrName )
        OffsetOfItem = Index * self.__SizeOfItem + Offset
        self.__Raw = self.__Raw[:OffsetOfItem] + Value + self.__Raw[OffsetOfItem+Size:] 
        if self.__StructureFinalized and self.__ParentStruct != None:
            self.__ParentStruct .callbackModify( self.__MemberName, OffsetOfItem,  Size, Value )
            


class mycstruct:
    def __init__ (self, Size, MemberName = '', ParentStruct = None): 
        self.__attrList = []
        self.__StructureFinalized = False
        self.__Size = Size
        self.__Raw  = '\x00' * Size
        self.__MemberName = MemberName
        self.__ParentStruct = ParentStruct

    def __setattr__(self, attrName, attrValue):
        try:
            if self.__StructureFinalized and ( attrName[:10] != '_mycstruct' ) and ( attrName[:9] != '_Internal' ):
                if attrName not in self.__attrList:
                    raise Exception("Trying to modify non existant member : %s" % attrName )
        except AttributeError:
            pass
        # Set the attribute
        self.__dict__[attrName] = attrValue

        # Add it to the list if it's not already there
        if  not (attrName in self.__attrList) and ( attrName[:10] != '_mycstruct' ) and ( attrName[:9] != '_Internal' ):
            self.__attrList.append(attrName)

        if attrName in self.__attrList:
            try:
                SizeOfItem = self.__dict__[ '_Internal_Size' + attrName ]
                OffsetOfItem = self.__dict__[ '_Internal_Offset' + attrName ]
                if type( attrValue) in [int]:
                    NewValue = atom( attrValue, SizeOfItem )
                    self.__Raw = self.__Raw[:OffsetOfItem] + NewValue + self.__Raw[OffsetOfItem+SizeOfItem:]
                    if self.__StructureFinalized and self.__ParentStruct != None:
                        self.__ParentStruct .callbackModify( self.__MemberName, OffsetOfItem, SizeOfItem, NewValue )


            except:
                pass

    def removeAttr ( self, AttributeName ):
        self.__attrList.remove( AttributeName )

    def callbackModify( self, AttrName, Offset, Size, Value ):
        OffsetOfItem = self.__dict__[ '_Internal_Offset' + AttrName ] + Offset

        self.__Raw = self.__Raw[:OffsetOfItem] + Value + self.__Raw[OffsetOfItem+Size:] 
        if self.__StructureFinalized and self.__ParentStruct != None:
            self.__ParentStruct .callbackModify( self.__MemberName, OffsetOfItem,  Size, Value )

    def __str__(self, Prepend = '\t'):
        resultStr = ''
        # print all instance variables
        for attrName in self.__attrList:
            if attrName[0] != '_':
                if isinstance( self.__dict__[attrName], mycstruct ):
                    SendDown = Prepend + ('%s.' % attrName)
                    resultStr += self.__dict__[attrName].__str__( SendDown )
                elif isinstance( self.__dict__[attrName], mycarray ):
                    SendDown = Prepend + ('%s ' % attrName)
                    resultStr += self.__dict__[attrName].__str__( SendDown )
                elif isinstance(self.__dict__[attrName], int) :
                    resultStr += (Prepend + "%s  0x%x\n") % (attrName, self.__dict__[attrName])
                else:
                    resultStr += (Prepend + "%s  %s\n") % (attrName, self.__dict__[attrName])
        return resultStr

    # merge NewStruct with current struct
    def merge ( self, NewStruct ):
        OrigFinalized = self.__StructureFinalized
        self.__StructureFinalized = False

        for Attr in NewStruct.__attrList:
            if  Attr[0] != '_':
                if Attr in self.__attrList:
                    raise Exception("Duplicated member in structure %s" % Attr )
                setattr( self, Attr,  NewStruct.__dict__[ Attr ] )
                setattr( self, "_Internal_Size" + Attr,   NewStruct.__dict__[ "_Internal_Size" + Attr ] )
                setattr( self, "_Internal_Offset" + Attr, NewStruct.__dict__[ "_Internal_Offset" + Attr ]  + self.__Size)
                if isinstance( NewStruct.__dict__[ Attr ], mycstruct ):
                    self.__dict__[ Attr ]._mycstruct__ParentStruct =  self
                if isinstance( NewStruct.__dict__[ Attr ], mycarray ):
                    self.__dict__[ Attr ]._mycarray__ParentStruct =  self

                        
        self.__Raw = self.__Raw + NewStruct.__Raw
        self.__Size = self.__Size + NewStruct.__Size
        self.__StructureFinalized = OrigFinalized


        
    def structureFinalized ( self ):
        self.__StructureFinalized = True

    def size ( self ):
        return self.__Size

    def list (self):
        print('Size = 0x%x (%d)' % (self.size(), self.size()))
        for AttrName in self.__attrList :
            SizeOfItem = self.__dict__[ '_Internal_Size' + AttrName ]
            OffsetOfItem = self.__dict__[ '_Internal_Offset' + AttrName ]
            TypeName = self.__dict__[AttrName].__class__
            print('%04X %04X %-18s %s' % ( OffsetOfItem, SizeOfItem, TypeName, AttrName ))



    # dump the binary packet out. Takes no parameters
    def dump ( self ):
        return self.__Raw
#        , Offset = 0, Size = 0  ):
#        ReturnStr = ''
#        for Item in self.__attrList:
#            if Item[0] != '_':
#                #print Item, type(self.__dict__[Item])
#                if self.__dict__["_Offset"+Item] > Offset:
#                    ReturnStr = ReturnStr + '\x00' * (  self.__dict__["_Offset"+Item] - Offset)
#                    Offset = self.__dict__["_Offset"+Item]
#                elif self.__dict__["_Offset"+Item] < Offset:
#                    Offset = self.__dict__["_Offset"+Item]
#                    ReturnStr = ReturnStr[:Offset]
#
#                if isinstance( self.__dict__[Item], mycstruct ):
#                    ReturnStr = ReturnStr + self.__dict__[Item].dump( Offset, Size )
#                elif type( self.__dict__[Item]) == list:
#                    SizeOfItem = self.__dict__[ '_Size'+Item]
#                    for EachItem in self.__dict__[Item]:
#                        if isinstance( EachItem, mycstruct ):
#                            SubString = EachItem.dump( 0, 0 )
#                            ReturnStr = ReturnStr + SubString
#                        else:
#                            ReturnStr = ReturnStr + self.__Atom( EachItem, SizeOfItem  )
#                else:          
#                    ReturnStr = ReturnStr + self.__Atom( self.__dict__[Item], self.__dict__["_Size"+Item] )
#
#                Offset = Offset + self.__dict__["_Size"+Item]
#                #print repr(ReturnStr)
#        return ReturnStr




    #def __str__(self):
    #    # print all instance variables
    #    resultStr = '';
    #    for attrName in dir(self):
    #        if (attrName[0] != "_") and (type(self.__dict__[attrName]) != types.MethodType):
    #            resultStr += "\t%s: %s\n" % (attrName, self.__dict__[attrName])
    #
    #    return resultStr

class type_type(DwarfdllStruct):

    BASE             = 0
    POINTER          = 1                         # pointer type
    ENUM             = 2                         # enum type
    STRUCT           = 3                         # struct
    UNION            = 4                         # a union
    TYPEDEF          = 5                         # typedef type
    ARRAY            = 6                         # array type
    CONSTANT         = 7                         # a constant!
    VOLATILE         = 8                         # volatile varaiable
    BITFIELD         = 9                         # bit-field
    ENUM_CONST       = 10                        # enum constant
    PARAMETER        = 11                        # type is a parameter declaration
    ASSEMBLY         = 12                        # type was declared in assembly


    _fields_ = [
        ("Name",                    c_char * MAX_NAME_LENGTH    ),
        ("TypeName",                c_char * MAX_NAME_LENGTH    ),
        ("Type",                    c_uint                      ),
        ("Size",                    c_uint                      ),
        ("NumElements",             c_uint                      ),
        ("Address",                 c_uint                      ),
        ("TypeLocation",            c_uint                      ),
        ("BitMask",                 c_uint                      )
               ]

    def GetName( self ):
        """ Override get for Name field, this getter will remove unnecessary characters in the name
            This is helpful for array-names that come decorated with dimension in the name"""
        ### This is a work-around for array-names that have dimension information embedded
        ### This needs to be explicitly removed for aesthetics only!
        return self.Name.split(" ")[-1]

    Name = property( fget=GetName )
    
    def GetTypeAsString( self ):
    	for TypeString in dir( type_type ):
    		TypeAsInt = getattr( type_type, TypeString )
    		if isinstance(TypeAsInt, int) and TypeAsInt == self.Type:
    			return TypeString
    	return "(unknown type)"
    			

CurrentAXFFileLocations = []
def __LogAXFFileLocation ( FileLocations,  directory, files ):
    global CurrentAXFFileLocations 
    for eachfile in files:
        #print directory + ' ' + eachfile
        if eachfile.lower() == 'final.axf':
            FileName = directory + '\\final.axf'
            CurrentAXFFileLocations = CurrentAXFFileLocations + [ FileName ]
            return

def FindAXFFile ( InitialPath = '' ):
    global CurrentAXFFileLocations 
    CurrentAXFFileLocations = []
    os.path.walk( InitialPath, __LogAXFFileLocation, CurrentAXFFileLocations )
    return CurrentAXFFileLocations


class dwarfdll:

    """ Wrapper class for dwarfdll.dll. """

    def __init__(self):

        """ Initialize the interface to dwarfdll.dll. """

        try:
            self.DwarfFileName = ''
            self.dwarfdllLib = cdll.dwarfdll
            self.dwarfdllLib.restype = c_uint
        except:
            raise
            raise DwarfdllException("Could not load dwarfdll.dll!!")

    # will try and find the axf file based on an initial directory
    def FuzzLoadAXFFile ( self, InitialDirectory ):
        InitialDirectory = InitialDirectory.lower()
        ReturnList = []
        if InitialDirectory.find( "\\f1_dev") != -1:
            SearchDirectory = InitialDirectory.split("\\f1_dev")[0]
            print(SearchDirectory)
            ReturnList = FindAXFFile( SearchDirectory )
        if  len(ReturnList) == 0 :
            ReturnList = FindAXFFile( InitialDirectory )

        if len(ReturnList) == 0:
            raise "Unable to find any final.axf in the directory " + InitialDirectory

        if len(ReturnList) == 2:
            print(ReturnList)
            raise "Got more than 1 final.axf in the directories " 

        print('Trying to load axf file ' + ReturnList[0])
        self.LoadDwarfFile( ReturnList[0] )
        print('File Loaded!')





    def LoadDwarfFileVarsNFuncs(self, elfFileName ):
        """ Open a elf/axf file, loads the variables and functions and the types associated with the vars and funcs, but not all other types
            This is faster than calling LoadDwarfFile. If the user is not using types that don't have global variables associated with it, then
            use this function.
            @param elfFileName Elf file to open """
        errorCode = self.dwarfdllLib._LoadDwarfFileVarsNFuncs( elfFileName )

        if errorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _LoadDwarfFile" % (DwarfdllErrorCodes.GetErrorDesc(errorCode)))
        self.DwarfFileName = elfFileName
        self.FunctionList = self.RetrieveFuncList()
        self.VarList = self.RetrieveVarList()

    def LoadDwarfFile(self, elfFileName):
        """ Open a elf/axf file
            @param elfFileName Elf file to open """
        errorCode = self.dwarfdllLib._LoadDwarfFile( elfFileName )

        if errorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _LoadDwarfFile" % (DwarfdllErrorCodes.GetErrorDesc(errorCode)))

        self.DwarfFileName = elfFileName
        self.FunctionList = self.RetrieveFuncList()
        self.VarList = self.RetrieveVarList()

    def FindFunctionFromAddress ( self, PCValue ):
        for curr_func in self.FunctionList:
            if PCValue >= curr_func.Address and PCValue < (curr_func.Address + curr_func.Size) :
                ReturnValue = {}
                ReturnValue['Name']    = curr_func.Name
                ReturnValue['Address'] = curr_func.Address
                ReturnValue['Size']    = curr_func.Size
                return ReturnValue
        raise Exception('Unable to find function given address 0x%08x' % PCValue )

    def FindFunction ( self, FunctionName ):
        for curr_func in self.FunctionList:
            if FunctionName == curr_func.Name:
                    ReturnValue = {}
                    ReturnValue['Name']    = curr_func.Name
                    ReturnValue['Address'] = curr_func.Address
                    ReturnValue['Size']    = curr_func.Size
                    return ReturnValue
        raise Exception('Unable to find function %s' % FunctionName )

    def getTaskName ( self, TaskIndex ):
        TCBInitializerList = self.GetTable( 'TCBInitializerList')
        EntryFunctionAddress =   TCBInitializerList[ TaskIndex ].Entry
        FunctionName = self.GetFunctionNameGivenAddress( EntryFunctionAddress )
        #print '%08x %s' % (EntryFunctionAddress, FunctionName)
        return FunctionName


    def GetNumVars(self):
        """ Retrieves the number of variables in the loaded elf-file.
            @return Number of variables in the dll file"""
        NumVars = c_uint( 0 )
        self.dwarfdllLib._GetNumVars( byref(NumVars) )
        return NumVars.value

    def RetrieveVarList(self):
        """ Retrieves the list of all variables in the loaded elf-file.
            @return List of variables retrieved from the axf file"""
        NumVars = self.GetNumVars()
        VarList = []
        for index in range(NumVars):
            VarList.append( var_type() )
            self.dwarfdllLib._RetrieveVarList(byref(VarList[index]), index, 1 )
        return VarList

    def GetNumTypes(self, SingleVariable):
        """ Retrieves the count of the elements of a variable.
            @param  Single variable whose elements need to be retrieved.
            @return Count of all elements for the variable"""
        NumTypes = c_uint( 0 )
        VariableTypeName = " " * MAX_NAME_LENGTH
        self.dwarfdllLib._GetNumTypes( byref(SingleVariable), byref(NumTypes), c_char_p( VariableTypeName ) )
        return NumTypes.value

    def GetAddressSourceFileLocation ( self, Address ):
        SourceFileName = " " * MAX_NAME_LENGTH
        SourceFileLineNo = c_uint( 0 )
        self.dwarfdllLib._GetAddressSourceFileLocation( Address,  c_char_p( SourceFileName ), byref(SourceFileLineNo) )
        return [ SourceFileName.rstrip('\x00 '), SourceFileLineNo.value ]



    def RetrieveTypeList(self, Variable):
        """ Retrieves the list of all the elements of a variable.
            @param  Single variable whose elements need to be retrieved.
            @return List of all elements for the variable"""
        NumTypes = self.GetNumTypes( Variable )


        TypesList = []
        for index in range(NumTypes):
            TypesList.append( type_type() )
            self.dwarfdllLib._RetrieveTypeList(byref(TypesList[index]), index, 1 )
        return TypesList


    def GetCodeContent ( self, Address, Size ):
        ReturnString = " " * Size
        ErrorCode = self.dwarfdllLib._GetContent( Address, Size, c_char_p(ReturnString) )
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetVariableNameGivenAddress" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        return str( ReturnString )




    def FindVariableNameFromAddress ( self, PCValue ):
        for curr_var in self.VarList:
            variable = self.GetVariableAddressAndSize(curr_var.Name)
            if PCValue >= curr_var.Address and PCValue < (curr_var.Address + variable[1]) :
                ReturnValue = {}
                ReturnValue['Name']    = curr_var.Name
                ReturnValue['Address'] = curr_var.Address
                ReturnValue['Size']    = variable[1]
                return ReturnValue

#        for curr_var in self.VarList:
#            variable = self.GetVariableAddressAndSize(curr_var.Name)
#
#            if PCValue >= curr_var.Address and PCValue < (curr_var.Address + variable[1]) :
#                ReturnValue = {}
#                ReturnValue['Name']    = curr_var.Name
#                ReturnValue['Address'] = curr_var.Address
#                ReturnValue['Size']    = variable[1]
#            return ReturnValue
#

        raise Exception('Unable to find variable given address 0x%08x' % PCValue )


    def GetVariableTypeString( self, Variable ):
        """ Retrieves the variable-type string
            @param  Single variable whose type-string is to be retrieved
            @return The string """
        VariableTypeName = " " * MAX_NAME_LENGTH
        self.dwarfdllLib._GetVariableTypeString( byref(Variable), c_char_p(VariableTypeName) )
        return VariableTypeName.rstrip()

    def GetVariableType( self, Variable ):
        """ Retrieves the variable-type's type_type
            @param  Single variable whose type_type is to be retrieved
            @return The retrieved type_type """
        TheType = type_type()
        self.dwarfdllLib._GetVariableType( byref(Variable), byref(TheType) )
        return TheType

    def GetSubType( self, TheType, Index=0 ):
        """ Retrieves the type-type's sub-type
            @param  Single type_type whose type_type is to be retrieved
            @param  The index of sub-type
            @return The retrieved type_type, if valid else None is returned """
        TheSubType = type_type()
        ErrorCode = self.dwarfdllLib._GetSubType( byref(TheType), byref(TheSubType), c_uint(Index) )
        if ErrorCode == DwarfdllErrorCodes.DWARF_SUCCESS:
            return TheSubType
        # Workaround when DLL doesn't return DWARF_SUCCESS and we are dead-sure atleast one sub-type exists
        # -------------------------------------------------------------------------------------------------
        # elif TheType.Type in [TheType.TYPEDEF, TheType.CONSTANT, TheType.VOLATILE, TheType.ARRAY, TheType.STRUCT, TheType.UNION] and Index == 0:
        #    return TheSubType
        else:
            return None


    def GetNumFunctions( self ):
        """ Retrieves the number of functions in the dwarf file
            @return Count of all functions"""
        NumFunctions = c_uint(0)
        self.dwarfdllLib._GetNumFunctions( byref(NumFunctions) )
        return NumFunctions


    def RetrieveFuncList( self ):
        """ Retrieves the number of list of functions in the dwarf file
            @return Count of all functions"""
        FunctionList = []
        for index in range( self.GetNumFunctions().value ):
            FunctionList.append( func_type() )
            self.dwarfdllLib._RetrieveFuncList( byref( FunctionList[index] ), index, 1 )
        return FunctionList

        """ The following methods are extension of API's exported by the DLL
            Objective is not to overcrowd the DLL and extend the functionality (as needed)
            in the python wrapper"""


    def GetArrayBaseTypeAndDimensionProduct( self, ArrayType ):
        """ For a type_type of array, returns the number of elements and the base-type
            @example uint8 XorTestPattern[3][8] would return [uint8, 3x8=24]
            @param ArrayType, a type_type of ArrayType
            @return Base sub type_type and product of dimension """
        if ArrayType.Type != ArrayType.ARRAY:
            raise DwarfdllInvalidParamException( "Paremeter should be of ARRAY type_type" )

        ReturnDim = ArrayType.NumElements
        ElementType = ArrayType
        while not ElementType.Type in [ ElementType.BASE, ElementType.POINTER, ElementType.ENUM, ElementType.BITFIELD, ElementType.STRUCT, ElementType.UNION]:
            ElementType = self.GetSubType ( ElementType, 0 )
            if ElementType == None:
                break
            if ElementType.Type == ElementType.ARRAY:
                ReturnDim *= ElementType.NumElements
        return [ ElementType, ReturnDim ]

    def GetArrayMultiDimensionInfo( self, ArrayType):
        if ArrayType.Type != ArrayType.ARRAY:
            raise DwarfdllInvalidParamException( "Paremeter should be of ARRAY type_type" )

        ReturnDimInfo = []
        ElementType = ArrayType

        while ElementType.Type == ElementType.ARRAY:
            ReturnDimInfo.append( ElementType.NumElements )
            ElementType = self.GetSubType ( ElementType, 0 )
        return ReturnDimInfo

    def GetEnumValueAsString( self, EnumType, IntValue ):
        """ Given an enum, the only thing we need after traversing further down is the string
            To keep outside logic simple, we do it here!
            @param EnumType, a type_type of ENUM
            @param The integer value whose enum is required
            @return The enum string"""
        if EnumType.Type != EnumType.ENUM:
            raise DwarfdllInvalidParamException( "Paremeter should be of ENUM type_type" )

        StringValue = "*** value not enumerated ***"
        Index = 0
        while True:
            EnumConstType = self.GetSubType( EnumType, Index )
            Index += 1
            if EnumConstType == None:
                break
            if EnumConstType.Type == EnumConstType.ENUM_CONST and EnumConstType.Address == IntValue:
                StringValue = EnumConstType.TypeName
                break

        return StringValue


    def GetBitFieldValueAsInt( self, BitFieldType, IntValue ):
        """@param BitFieldType, a type_type of BITFIELD
            @param IntValue,     an integer from which we'll scoop-out out bit-value
            @return The bit-value"""

        if BitFieldType.Type != BitFieldType.BITFIELD:
            raise DwarfdllInvalidParamException( "Paremeter should be of BITFIELD type_type" )

        Mask = BitFieldType.BitMask

        IntValue     = IntValue & Mask

        while not ( Mask & 1 ):
            Mask     = Mask     >> 1
            IntValue = IntValue >> 1

        return IntValue

    def GetVariableNameGivenAddress( self, Address ):
        VariableName = " " * MAX_NAME_LENGTH
        ErrorCode = self.dwarfdllLib._GetVariableNameGivenAddress( Address,  c_char_p(VariableName))
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetVariableNameGivenAddress" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        return str( VariableName ).strip(' \x00')

    def GetVariableContent (self, VariableName ):
        VariableTypeName = " " * 10000
        SizeOfContent = c_int( 10000 )

        ErrorCode = self.dwarfdllLib._GetVariableContent( VariableName, c_char_p(VariableTypeName), byref( SizeOfContent) )
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetVariableContent" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        return [ VariableTypeName, SizeOfContent.value ]

    def GetVariableTypeGivenVariableName( self, VariableName ):
        TheType = type_type()
        ErrorCode = self.dwarfdllLib._GetTypeGivenVariableName( VariableName,  byref(TheType ))
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetTypeGivenVariableName" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        #print TheType
        return TheType


    def __GetTypeDetails( self, Type, ReturnList, Offset, Size = 0, SoFar = '' ):
        if Type.Type in [ Type.TYPEDEF, Type.VOLATILE, Type.CONSTANT]:
            SubType = self.GetSubType ( Type, 0 )
            return self.__GetTypeDetails( SubType, ReturnList, Offset, SubType.Size, SoFar )

        if Type.Type in [ Type.BASE, Type.POINTER, Type.ENUM, Type.BITFIELD ]:
            FormatStr = '%04X %04X %s' % ( Offset, Type.Size, SoFar )
            ReturnList = ReturnList + [ FormatStr ]
            return ReturnList

        if Type.Type in [ Type.ARRAY ]:
            SubType = self.GetSubType ( Type, 0 )
            SizeOfElement = SubType.Size * SubType.NumElements
            CurrentPos = 0

            PassInOffset = Offset 
            PassInSoFar = SoFar + '[ 0 ]'
            ReturnList = self.__GetTypeDetails( SubType, ReturnList, PassInOffset, SizeOfElement, PassInSoFar )

            ReturnList = ReturnList + ['     .']
            ReturnList = ReturnList + ['     .']
            ReturnList = ReturnList + ['     .']

            PassInOffset = Offset + SizeOfElement * ( Type.NumElements - 1 )
            PassInSoFar = SoFar + '[ ' + str( Type.NumElements - 1 ) + ' ]'
            ReturnList = self.__GetTypeDetails( SubType, ReturnList, PassInOffset, SizeOfElement, PassInSoFar )


            return ReturnList

        if Type.Type in [ Type.UNION, Type.STRUCT ]:
            index = 0
            while True:
                SubType = self.GetSubType ( Type, index )
                index = index + 1
                if SubType != None:

                    PassInSoFar = SoFar + "." + SubType.Name 
                    SizeOfElement = SubType.Size * SubType.NumElements
                    PassInOffset = SubType.Address + Offset
                    ReturnList = self.__GetTypeDetails( SubType, ReturnList, PassInOffset, SizeOfElement, PassInSoFar )
                else:
                    break
            return ReturnList





    def __Variablelize ( self, Type, Content,):
        if Type.Type == Type.ASSEMBLY:
            if Type.Size == 1:
                return struct.unpack( 'B', Content )[0]
            if Type.Size == 2:
                return struct.unpack( 'H', Content )[0]
            if Type.Size == 4:
                return struct.unpack( 'L', Content )[0]
            SizeOfElement = 4
            CurrentPos = 0
            ReturnList = []
            for i  in range( Type.Size/SizeOfElement):
                ReturnList = ReturnList + [ struct.unpack('L', Content[ CurrentPos:CurrentPos+SizeOfElement] )[0] ]
                CurrentPos = CurrentPos + SizeOfElement
            return ReturnList 




        if Type.Type in [ Type.TYPEDEF, Type.VOLATILE, Type.CONSTANT]:
            SubType = self.GetSubType ( Type, 0 )
            return self.__Variablelize( SubType, Content )


        if Type.Type in [ Type.BASE, Type.POINTER, Type.ENUM, Type.BITFIELD ]:
            if Type.Size == 1:
                return struct.unpack( 'B', Content )[0]
            elif Type.Size == 2:
                return struct.unpack( 'H', Content )[0]
            elif Type.Size == 4:
                return struct.unpack( 'L', Content )[0]
            elif Type.Size == 8:
                Dword1 =  struct.unpack( 'L', Content[:4] )[0]
                Dword2 =  struct.unpack( 'L', Content[4:] )[0]
                return (Dword2 << 32) + Dword1

            raise Exception('Unhandled size %d' % Type.Size )

        if Type.Type in [ Type.ARRAY ]:
            ReturnList = []
            #Dim = self.GetArrayBaseTypeAndDimensionProduct( Type )
            #print Dim
            SubType = self.GetSubType ( Type, 0 )
            SizeOfElement = SubType.Size * SubType.NumElements
            CurrentPos = 0
            #debug for i in range( 1 ):
            for i in range( Type.NumElements ):
                ReturnList = ReturnList + [ self.__Variablelize( SubType, Content[ CurrentPos:CurrentPos+SizeOfElement] ) ]
                CurrentPos = CurrentPos + SizeOfElement
            return ReturnList


        if Type.Type in [ Type.UNION, Type.STRUCT ]:
            ReturnType = mycstruct( Type.Size )
            index = 0
            while True:
                SubType = self.GetSubType ( Type, index )
                index = index + 1
                if SubType != None:
                    #print SubType
                    SubContent = Content[SubType.Address:SubType.Address+SubType.Size*SubType.NumElements]
                    #ReturnType[ SubType.Name ] = self.__Variablelize( SubContent, SubType )
                    setattr( ReturnType,  SubType.Name, self.__Variablelize( SubType, SubContent ) )
                    setattr( ReturnType,  "_" + SubType.Name, SubType.Size )
                else:
                    break
            return ReturnType

    def GetVariableAddress ( self, VariableName ):
        VariableAddress = c_int( 0 )
        ErrorCode = self.dwarfdllLib._GetVariableAddress( VariableName, byref( VariableAddress ))
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetVariableAddress" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        return VariableAddress.value



    def GetVariableAddressAndSize ( self, VariableName ):
        VariableType = self.GetVariableTypeGivenVariableName( VariableName )
        Size = VariableType.Size * VariableType.NumElements
        Address = self.GetVariableAddress( VariableName )
        return ( Address, Size )

    def VariablelizeStr ( self, VariableName, String ):
        ContentType = self.GetVariableTypeGivenVariableName( VariableName )
        return self.__Variablelize( ContentType, String )

    def Variablelize ( self, VariableName, ContentGetter ):
        ContentType = self.GetVariableTypeGivenVariableName( VariableName )
        AddressOfVariable = self.GetVariableAddress( VariableName ) 
        #print '%x %x' % ( ContentType.Size, ContentType.NumElements ) 
        #print '%x %x' % ( AddressOfVariable, AddressOfVariable+ContentType.Size*ContentType.NumElements ) 
        Content = ContentGetter( AddressOfVariable, ContentType.Size*ContentType.NumElements )
        return self.__Variablelize( ContentType, Content )
        
    def GetTable(self, VariableName):
        Content = self.GetVariableContent( VariableName )
        ContentType = self.GetVariableTypeGivenVariableName( VariableName )

        return self.__Variablelize(  ContentType, Content[0] )

    def GetString( self, VariableName ):
        Data = self.GetTable( VariableName )
        ReturnString = ''
        for i in Data:
            if (i) != 0:
                ReturnString = ReturnString + chr(i)
        return ReturnString

    def GetFunctionNameGivenAddress( self, Address ):
        FunctionName = " " * MAX_NAME_LENGTH
        ErrorCode = self.dwarfdllLib._GetFunctionNameGivenAddress( Address,  c_char_p(FunctionName))
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetFunctionNameGivenAddress" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        return str( FunctionName ).strip(' \x00')

    def GetNumTypeDefs ( self ):
        NumTypeDefs = c_int( 0 )
        ErrorCode = self.dwarfdllLib._GetNumTypeDefs( byref( NumTypeDefs ))
        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetNumTypeDefs" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
        return NumTypeDefs.value

    
    def GetType( self, TypeToFind ):
        TheType = type_type()
        for i in range( self.GetNumTypeDefs()):
            ErrorCode = self.dwarfdllLib._RetrieveTypeDefList( byref( TheType ), i, 1 )
            if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
                raise DwarfdllException("%s encountered during call to _RetrieveTypeDefList" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))
            if TheType.Name == TypeToFind:
                return TheType
        ErrorStr = "Unable to find type '" + TypeToFind + "'"
        raise ErrorStr                    

    def GetTypeDetails( self, TypeToFind ):
        TypeType = self.GetType( TypeToFind )
        ReturnList = []
        ReturnList = self.__GetTypeDetails( TypeType, ReturnList, 0, 0,TypeToFind )
        return ReturnList


    def GetEnumList ( self, EnumName ):
        EnumType = self.GetType( EnumName )
        if EnumType.Type != EnumType.ENUM:
            raise DwarfdllInvalidParamException( "Parameter should be of ENUM type_type" )
        EnumList = []
        Index = 0
        while True:
            EnumConstType = self.GetSubType( EnumType, Index )
            Index += 1
            if EnumConstType == None:
                break
            EnumList = EnumList + [ (EnumConstType.TypeName, EnumConstType.Address ) ]
        return EnumList

    def GetParameterList ( self, FunctionName ):
        ReturnList = []
        index = 0;
        while True:
            TheType = type_type()
            ErrorCode = self.dwarfdllLib._GetFunctionNamesParameters( FunctionName, byref(TheType), index )
            if ErrorCode == DwarfdllErrorCodes.DWARF_SUCCESS: 
                ReturnList = ReturnList + [ TheType ]
            else:
                break
            index = index + 1

        return ReturnList;

    def GetStackUsageList ( self, Function ):
        LocList = " " * MAX_NAME_LENGTH


        if isinstance(Function, int) or isinstance(Function, int):
            ErrorCode = self.dwarfdllLib._GetFunctionLocListStringFromAddress( Function,  c_char_p(LocList), MAX_NAME_LENGTH)
        elif isinstance(Function, str):
            ErrorCode = self.dwarfdllLib._GetFunctionLocListString( Function, c_char_p(LocList), MAX_NAME_LENGTH)
        else:
            print(type( Function ))
            raise Exception('Unhandled type in GetStackUsageList')

        if ErrorCode != DwarfdllErrorCodes.DWARF_SUCCESS:
            raise DwarfdllException("%s encountered during call to _GetFunctionNameGivenAddress" % (DwarfdllErrorCodes.GetErrorDesc(ErrorCode)))

        ReturnLocList = str( LocList ).strip(' \x00')
        ActualList = list(map( int, re.findall( '\d+', ReturnLocList ) ))


        ReturnList = []
        if len( ActualList ) == 0 :
            return ReturnList
        NumEntries = ActualList[0]
        for i in range(NumEntries):
            ReturnList = ReturnList + [ ActualList[ i*3 + 1: i*3 + 4 ] ]
        return ReturnList


    def GetTypeString( self, Type ):
        TypeNameList =      \
            [               \
                'BASE'     ,\
                'POINTER'  ,\
                'ENUM'     ,\
                'STRUCT'   ,\
                'UNION'    ,\
                'TYPEDEF'  ,\
                'ARRAY'    ,\
                'CONSTANT' ,\
                'VOLATILE' ,\
                'BITFIELD' ,\
                'ENUM_CONST'\
            ]
        return TypeNameList[ Type.Type ]

def loadfile( FileName ):
    Elf = dwarfdll()
    Elf.LoadDwarfFile( FileName )
    return Elf
        
def load():
    FileName = gui.getAXFOpenFilename()
    return loadfile( FileName )

