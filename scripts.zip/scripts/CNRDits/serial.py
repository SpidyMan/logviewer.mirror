import cnr
import time
import struct

# Sends an ESLIP packet to the drive. Parameter is a list of 8 bit intgeters that make up
# the packet.
#
#   e.g. to unlock the dets commands
#         Packet = [ 7, 0, 7, 0,
#				     4, 0, 0, 0,
#				     3, 0, 1, 0 ]				# setup packet to send
#	      serial.sendPacket( SendPacket )       # send the packet
#         response = serial.waitForAPacket( 1 ) # wait for a packet
#
def sendPacket( PacketToSend ):
	cnr.snd( PacketToSend )
	
#this is a wait for an ESLIP packet function. The first parameter is the time to wait for the packet in 
#seconds ( floating point number for milliseconds ).  WaitValue is the time to sleep while waiting
#for a packet. This allows other processes to run instead of just being stuck in a polling loop. 
#Echo is to display what is happening while waiting for the packet. Usually true for debug only
#
# e.g.
#       Response = waitForAPacket( 2 )
#         waits for an ESLIP packet from the drive for 2 seconds.  Response is None if no packet
#         was received.
# 
def waitForAPacket( TimeoutValue, WaitValue = 1, Echo = False):
    # receive packet from drive, TimeoutValue is in seconds. To be used with waiting for long packets
	StartTime = time.clock()
	LastNumBytesInBuffer = cnr.gnbb()
	while (time.clock() - StartTime) < TimeoutValue:
		#if we got a packet then break
		if cnr.gnp() == 1:
			break
		#wait a second
		time.sleep( WaitValue )
		CurrentBytesInBuffer = cnr.gnbb()
		NumberOfPackets = cnr.gnp()
		NumBytesInPackets = cnr.gnpb()
		if  Echo:
			print("We got %d bytes, and %d packets (%d)" % ( CurrentBytesInBuffer, NumberOfPackets, NumBytesInPackets ))
		# if we haven't received any new data from drive
		if  LastNumBytesInBuffer == CurrentBytesInBuffer and TimeoutValue > 5:
			break
		LastNumBytesInBuffer = CurrentBytesInBuffer
	#check if we got a packet
	if  cnr.gnp() == 1:
		return cnr.rcv()	
	else:
		return None

def writeBuffer ( Str ):
	cnr.wb( Str )

# write a charater to the serial port. Great for sending control characters
#	  e.g. serial.writeChar( 26 ) 
#             sends a ctrl-z to the drive ( 1 is ctlA, 2 is ctlB etc... )
#     
def writeChar( c ):
	cnr.wc( c )

# looks for a charater from the serial port. parameter 1 c is the charater to look for
# and TimeoutValue is the amount of time to look for that character in seconds ( floating point number )
# return true, if character is found
# return flase, if character is not found within the TimeoutValue
#
#  e.g.  
#           serial.writeChar( 26 )	# send ctl-Z
#           if not serial.waitForChar( '>', 2 ):
#               print 'unable to go to diag prompt'
#
#           serial.writeString( 'S1234,0\r' )
#           if not serial.waitForChar( '>', 2.5 ):
#               printf 'Seek hung or took more than 2.5 seconds'
def waitForChar( c, TimeoutValue =1.0 ):
	ReturnString = ''
	StartTime  = time.clock()
	if c == None:
		LocalInt = -1;
	else:
		LocalInt = struct.unpack('B', c )[0]

	while ( time.clock() - StartTime ) < TimeoutValue:
		x = cnr.rc()
		if x == LocalInt:
			ReturnString = ReturnString + chr(x)
			return ReturnString
		if ( x > 0 ) and ( x < 255 ):
			ReturnString = ReturnString + chr(x)
	return None
	
# keep getting character from the serial port until no serial character comes in
# TimeoutValue seconds.
def waitForCharUntilTimeout ( TimeoutValue = 1.0, ProgressCallback = None, ProgressInterval = 0):
	ReturnString = ''
	
	StartTime = time.clock()
	ProgressStartTime = StartTime;
	while ( time.clock() - StartTime ) < TimeoutValue: 
		x = cnr.rc();
		if x != -1:
			StartTime = time.clock()
			ReturnString = ReturnString + chr(x)
		if ProgressCallback != None:
			DeltaTime = time.clock() - ProgressStartTime;
			if DeltaTime > ProgressInterval:
				ProgressStartTime = time.clock()
				ProgressCallback( len( ReturnString ))
	return ReturnString

# flush the serial port.  Takes one optional parameter, which is the amount of time
# the routine will check for characters.  If not entered, assumed to be zero, which means
# flush the current internal serial port buffer.
def flush( TimeoutValueInms  = 0):
	TimeoutValueIns = TimeoutValueInms/1000.0
	StartTime  = time.clock()
	while True :
		x = cnr.rc()
		if x == -1:
			if ( time.clock() - StartTime ) >= TimeoutValueIns:
				break

# sets the baud rate of the serial port
def setbaud ( BaudRate ):
	cnr.setbaud( BaudRate )

# disable echo of serial com to the terminal
def disableSerialEcho ():
	cnr.disableSerialEcho()

# enable echo of serial com to the terminal
def enableSerialEcho ():
	cnr.enableSerialEcho()

# disables the SLIP engine
def disableSLIPEngine ():
	cnr.disableSLIPEngine()

# enables the SLIP engine
def enableSLIPEngine ():
	cnr.enableSLIPEngine()
